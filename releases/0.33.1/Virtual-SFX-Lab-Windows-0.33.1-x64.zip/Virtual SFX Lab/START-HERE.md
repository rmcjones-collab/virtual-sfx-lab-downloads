# Virtual SFX Lab for Windows — Module 1: Wave Studio

Windows desktop receiver and visualizer, version 0.33.1 — studio V0.34 (receiver reliability, tray icon, Virtual SFX Lab branding) (one-folder build: `Virtual SFX Lab.exe` plus an `_internal` folder that must stay beside it). This build is for 64-bit Intel/AMD Windows 10 or 11 and uses your existing Edge, Chrome, or other modern browser. Python, the receiver, the launcher, the web application, this guide, and third-party notices are bundled inside the executable.

## First launch

1. Stop your old Wave Studio receiver. Keep Vista running and keep real flame hardware disconnected from the rehearsal network.
2. Extract the ZIP to a stable folder, such as `Documents\Virtual SFX Lab`, keep `Virtual SFX Lab.exe` and `_internal` together, then double-click **Virtual SFX Lab.exe**. No Python installation, ZIP extraction, administrator access, or separate launcher is required.
3. Choose your **Console** (Vista 3, grandMA3 console / onPC, grandMA2 console / onPC, or Other) and leave **Input mode** set to **sACN (same-PC console software)**.
4. Choose or type the **Console interface IPv4** shown in Vista's Network preferences (grandMA3: Menu → Network; grandMA2: Setup → Network). Your working setup used `192.168.137.1`; use it only if it is still Vista's selected local address. `0.0.0.0` asks Windows to choose the default interface, which may not match Vista on a multi-adapter PC.
5. Leave **Universes** at `1,2,3,4` and **Local web port** at `8765` unless your setup requires different values.
6. Step 2 of the window has two buttons. **Skip for now — open studio without a receiver** opens the demo, full studio and First Guide with no sACN or Art-Net input at all (use this if you are not connecting Vista yet; nothing in step 1 needs to be filled in). **Start receiver + open studio** (or pressing Enter) starts live input with the settings above. Click **Stop** at any time to switch between the two. Your browser opens on the **demo landing page** so you can learn the basic controls first; **Open the full studio** on that page opens the complete program, and the **First Guide** manual opens on top of it until you untick “Open when the studio starts”. The browser opens automatically unless you clear that checkbox. Keep the desktop launcher open while using live input.
7. Keep your working Vista Streaming ACN output. For the initial test, use sACN universe **1**, priority **100**, assign the intended internal Vista universe, and enable output. Vista's documented workflow adds the network connection and then assigns the internal universe ([Vista user guide](https://www.stars-europe.com/pdf/produits/LECONSOLE4+.pdf)).
8. In the browser, select **Live sACN**. Match each fixture's sACN universe and DMX start address to Vista, and apply any patch changes.
9. Check the launcher's **UDP received** and **DMX packets** counters. “Receiving DMX” means accepted level frames are arriving, not that the fixture is patched correctly or that a real device is safe to fire.

The desktop application remembers successfully started settings, but does not automatically start network reception when you next open it. Click Start receiver each time.

## Controls

- **Refresh:** Re-enumerates local IPv4 interfaces. You can type an address if it is absent from the list. Match Vista's current selection, not an address from an old screenshot.
- **Stop:** Stops reception and the local web server. The browser clears live effects when the stream closes. Restarting requires a fresh low-to-high trigger transition for visual effects.
- **Open visualizer:** Reopens the locally served demo landing page without restarting the receiver; the full studio and manual are one click away.
- **Setup guide:** Opens this bundled offline guide.
- **Open log folder:** Opens `%LOCALAPPDATA%\WaveStudio`, containing `settings.json` and bounded, rotating `receiver.log` files. Settings and logs are per Windows user; browser fixture layouts remain in browser storage or exported JSON.
- **Close the launcher:** Stops the receiver. Closing only the browser does not stop it.
- **Art-Net (separate PC):** Retains the existing Art-Net receiver and discovery replies. It uses UDP 6454 and zero-based port-addresses, so do not select it for your same-PC Vista configuration. Switching modes resets the universe list to the mode's defaults.

This build does not extract anything to a temporary folder: the Python runtime, receiver and web app live in `_internal` next to the executable, which also avoids the behaviour that antivirus heuristics flagged in the earlier single-file build. your settings and logs remain in `%LOCALAPPDATA%\WaveStudio` ([PyInstaller operating mode](https://pyinstaller.org/en/stable/operating-mode.html)).

## grandMA3 and grandMA2

The receiver speaks standard sACN (ANSI E1.31 "Final" and the older "Draft" layout grandMA2 offers) and Art-Net, so a grandMA3 or grandMA2 console — or onPC software with MA hardware attached — drives the virtual units exactly like Vista. Leave **Input mode** on sACN, type the IPv4 address of the adapter on the console's network, start the receiver and choose **Live sACN** in the browser.
- **Console preset:** in the Virtual SFX Lab window choose **Console** (Vista 3, grandMA3 console / onPC, grandMA2 console / onPC, Other sACN / Art-Net source) above *Input mode*. The preset sets the hint text under the form and the status line ("Listening — waiting for grandMA3"), and the studio's **Vista & MA Receiver** dialog opens on that console's tab. The network side is unchanged: standard sACN (E1.31 Final **and** the grandMA2 Draft layout, multicast or unicast) or Art-Net 4. Command line: `receiver.py --protocol sacn --console grandma3 --interface <ip>`; Python scripts: `Start-Wave-Studio-grandMA.cmd`.

- **grandMA3:** Menu → DMX Protocols → sACN. First line: Enabled = Yes, Mode = Output Multicast, Local Universe = 1, Amount = 4, sACN Universe = 1, Priority 100; switch **Enable Output** on. A station that is alone also needs **Send sACN If Idle Master** on. Art-Net alternative: Mode Unicast to this PC's IP, Local Universe 1, Art-Net Absolute 0, Enable Output and Send Art-Net If IdleMaster on, with the launcher in **Art-Net (separate PC)** mode on a different computer than the console software. MA documents that grandMA3 onPC outputs no parameters without grandMA3 hardware, and that onPC systems are limited to 4,096 parameters (six per X2 unit) ([grandMA3 help](https://help.malighting.com/grandMA3/2.2/HTML/qsg_output_dmx.html)).
- **grandMA2:** Setup → Network → Network Protocols → sACN: Local Start 1, Amount 4, sACN Universe 1, Priority 100, **Protocol Final** (the receiver does not parse the 2006 Draft format), Mode Output Multicast; switch **sACN Output Active** on and, when alone, **Network DMX if Alone** on. Art-Net alternative: Network 1, Subnet 0, Universe 0 for Wave Studio slot 0, Mode Output Unicast or Broadcast, Art-Net Output Active on ([grandMA2 help](https://help.malighting.com/grandMA2/en/help/key_network_dmx_protocols.html)). grandMA2 onPC also needs MA onPC hardware to unlock output parameters.
- **Universe numbering:** sACN universe 1 = Art-Net port address 0 (grandMA3 "Art-Net Absolute 0", grandMA2 Network 1 / Subnet 0 / Universe 0) = Wave Studio patch slot 0.
- **Export For grandMA** in the studio's Layout Controls writes a GDTF fixture type and an MVR scene (grandMA3: Menu → Show Creator → Partial Show Read → MVR), a grandMA2 fixture-type XML and fixture-layer XML (Fixture Types → Import, then `CD EditSetup` / `Import "wavestudio_layer" At Layer 1`), plus patch and cue CSV sheets. Cue contents are programmed on the console from sheet 04; MA consoles do not import cue values from CSV. First Guide Part 5.6 has the full walkthrough.
- **MA panel:** the studio's MA panel (under the Cue Stack) mirrors the grandMA command section — Fixture 1 Thru 4 At 30 Please, Store Cue, Go+, X1–X10 and the rest. A real grandMA2 / grandMA3 can press those keys over the sACN control universe: open *Physical grandMA console* in the panel, press *Patch Keys In Order* (channels 101–184), patch one dimmer per key on the desk at those addresses on Temp executor buttons, then connect the console mapping in *Bank & Mapping Controls*. `06-ma-keys.csv` in Export For grandMA lists every key and channel; First Guide Part 5.7 has the details.

## Security and permissions

This independently built executable is **unsigned**. It has no publisher certificate or established signing reputation. Treat Windows security warnings seriously; do not disable Defender, SmartScreen, or your firewall to run it. If your organization blocks unsigned software, ask your IT administrator to review it or continue using the already-working Python package.

If Windows asks for network permission, allow only the appropriate trusted/private rehearsal network. The web server listens only on `127.0.0.1`. sACN mode listens on UDP 5568, joins the selected multicast groups, and sends no application-level sACN or firing packets. Art-Net mode sends discovery replies only, never ArtDmx or firing commands.

This app does not contain Vista or supply a Vista output license. It is a visual rehearsal tool, not a firing controller, safety-validation system, or certified Explo emulator.

## Troubleshooting

- **Cannot start / address already in use:** Stop the old Python receiver and any second Wave Studio instance. Check that another application is not using UDP 5568 or the selected local web port. Do not kill Vista or change its working output to force a connection.
- **Selected address is not local:** Use Refresh and confirm Vista's selected interface is still connected. Re-enter its current IPv4.
- **Browser does not open:** Click Open visualizer, or type the local URL displayed in the launcher into your browser.
- **UDP received stays at zero:** Check Vista output assignment/enabling, the selected interface, subscriptions, and appropriate firewall permission. Same-PC multicast behavior depends on Vista and Windows; the Python version was confirmed working on your setup, but this packaged executable requires its own acceptance test.
- **UDP increases but DMX packets do not:** Note Rejected, Filtered, and Source conflicts, then check your universe list and other active sACN senders.
- **Packets arrive but no animation:** Check Live sACN, fixture universe/address, the six-channel profile, and low-before-high triggering. A packet count alone does not validate your patch.
- **Changed protocol or web port:** Stop reception first. After starting again, open or reload the visualizer; old tabs can retain old protocol labels until refreshed.
- **Settings are wrong:** Close the application, rename `%LOCALAPPDATA%\WaveStudio\settings.json`, and reopen. This resets launcher preferences, not fixture layouts.

No Art-Net node appears in sACN mode. Vista uses multicast sACN rather than a discovered receiver list ([Vista support discussion](https://vistaforum.chroma-q.com/t/weird-issue-with-vista-not-outputting-sacn-unless-i-open-up-sacnview-first/3236)).

## Build and test scope

Built with official Windows CPython 3.13.13 and PyInstaller 6.22.0 using a Wine compatibility environment. The application is a native Windows x64 executable, not a Linux binary or a script renamed to `.exe`. This build has not been code-signed and has not been tested on physical Windows hardware with Vista. The previously supplied Python sACN package was confirmed working by the user.

Protocol regression tests, packaged HTTP/SSE serving, synthetic sACN reception, browser rendering, and launcher behavior are checked during packaging. A final Windows/Vista test is still required before relying on this executable for rehearsal.

## References and notices

The visualization retains the published Explo six-channel DMX interpretation and 88-program catalog, with the existing prototype limitations. Consult the [Explo manual](https://explo.at/wp-content/uploads/2025/06/X2-Wave-Flamer-v2.0-ENG-2.pdf) and [program DMX values](https://explo.at/wp-content/uploads/2025/06/X2-Wave-Flame-Sequences-DMX-Values.pdf), and do not treat artistic rendering as a prediction of flame size, timing, mechanics, or safety distances.

Open the [bundled runtime license notices](licenses.html) for third-party terms. No third-party runtime needs to be installed separately.
