# Wave Studio Colleague Test Checklist

Use one person as the **Operator** and the other as the **Instructor**, then swap roles. Use virtual units only; do not connect or operate live flame equipment for this test.

## Before You Start

- [ ] Open the **latest attached Wave Studio preview**, not the older live site. Use the preview's Share controls to give your colleague access if necessary.
- [ ] Use separate devices or browser profiles. Ideally test one desktop and one phone.
- [ ] Confirm both users see **AI Assist**, **Chat**, the camera icon, and **Screenshot**.
- [ ] Use headphones, and choose a private test space without sensitive information on your screen.
- [ ] In Chat, each person creates a display name. Confirm your friend codes are different.

## Connect And Exchange Messages

- [ ] Operator sends a friend request using the Instructor's code. Instructor accepts it.
- [ ] Create a room with the colleague selected. Confirm both people appear in **Room Members**.
- [ ] Each person sends a text message. Check that the sender and message are correct on both devices.
- [ ] Press **Screenshot** beside Full Screen, choose **Attach To Chat**, review it, then press **Send**. Confirm the other person receives a readable layout image.
- [ ] Record a voice note, stop recording, review it, then send it. Confirm the other person can play and understand it.
- [ ] Reload one browser, reopen Chat and select the same room. Confirm the message history and attachments return.

## Test Mic, Camera And Screen Sharing

- [ ] Both users press **Join Call**. Confirm neither microphone nor camera starts automatically.
- [ ] Enable microphones individually. Speak in both directions and check for understandable audio, echo and dropouts.
- [ ] Open the camera panel and press **Start Camera**. Confirm the initial preview stays local.
- [ ] On the phone, try **Front Camera** and **Rear Camera**. Confirm the intended camera actually appears; device support may vary.
- [ ] Press **Share Camera In Call**. Confirm the colleague sees the feed. Press **Stop Camera** and verify the feed stops.
- [ ] Record a short camera example, stop, review and attach it to Chat. Send it and confirm playback on the other device. Camera examples are recorded without audio in this version.
- [ ] On desktop, press **Share Screen** and choose only a non-sensitive test window or tab. Confirm the colleague sees it, then press **Stop Screen Share** and verify sharing ends.

## Test Instructor Permission

- [ ] Instructor selects the Operator and presses **Request Workspace Control**.
- [ ] Operator first presses **Decline**. Confirm the Instructor cannot control the workspace.
- [ ] Repeat the request and choose **Allow Workspace Control**.
- [ ] Instructor shows, resizes, moves, minimizes and restores a panel. Confirm the Operator sees the changes.
- [ ] Operator presses **Stop Instructor Control**. Confirm further instructor actions are blocked.
- [ ] Confirm these controls only arrange panels. They must not operate faders, playback, ignition, DMX, files or other applications.

## Test Recovery And Shutdown

- [ ] Leave and immediately rejoin the call three times. Confirm the connection returns each time.
- [ ] Create/select a second room. Confirm old messages do not appear in the new conversation and shared media/control stop during the switch.
- [ ] Reconnect, then press **Leave Call**. Check that microphone, camera and screen-sharing indicators stop.
- [ ] If everything works on the same Wi-Fi, repeat a short call with one device on another network or mobile data.

## Record Any Failure

Copy this template for each issue:

```text
Test step:
Operator device / browser:
Instructor device / browser:
Same Wi-Fi or different networks:
What we clicked:
Expected result:
Actual result / exact error:
Does it happen again:
Screenshot or short recording attached:
```

Do not include passwords, access tokens or private client information in screenshots or diagnostics.

## Important Limits

The hosted preview may require access approval or a browser verification check. Camera, microphone and screen capture also depend on browser permissions; mobile screen sharing may be unavailable.

No TURN relay is configured, so a call can work on the same network but fail across restrictive networks. Report that separately from a chat or friend-request failure.

AI Assist is currently a non-AI app guide. Chat uses visitor-specific prototype storage, not a durable account system. Passing this checklist is not certification for controlling or assessing the safety of physical flame equipment.
