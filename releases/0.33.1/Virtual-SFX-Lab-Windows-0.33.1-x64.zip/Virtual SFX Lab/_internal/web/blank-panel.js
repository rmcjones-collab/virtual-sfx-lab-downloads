import {mirrorPanel} from './panel-mirror.js?v=v0340-20261007f';
// Blank panel: an empty card the user fills with studio button shortcuts (through the shared Buttons
// editor, so the same safety rules apply) and live read-only views of other panels ("screens").
// Stored data is panel keys only — never markup, selectors or URLs.
export function createBlankPanel({get,change,screens,sourceFor,reveal,buttons}){
 const el=document.createElement('section');el.className='blank-panel';
 el.innerHTML='<div class="blank-toolbar"><button type="button" data-blank-buttons>Add Buttons</button><label class="blank-screen-pick">Add Screen <select data-blank-screen aria-label="Add A Live Screen From Another Panel"><option value="">Choose A Panel…</option></select></label></div><p class="widget-hint blank-empty">This Panel Starts Empty. Add Studio Buttons Or Live Screens From Other Panels.</p><div class="blank-screens"></div>';
 const pick=el.querySelector('[data-blank-screen]'),list=el.querySelector('.blank-screens'),views=new Map();
 el.querySelector('[data-blank-buttons]').onclick=()=>buttons();
 const current=()=>(get().screens??[]).filter(k=>screens().some(s=>s.key===k));
 pick.onchange=()=>{
  const key=pick.value;pick.value='';if(!key)return;
  const o=get(),list=o.screens??[];if(list.includes(key)||list.length>=6)return;
  o.screens=[...list,key];change();render();
 };
 function remove(key){const o=get();o.screens=(o.screens??[]).filter(k=>k!==key);if(!o.screens.length)delete o.screens;change();render()}
 function move(key,dir){const o=get(),s=[...(o.screens??[])],i=s.indexOf(key),j=i+dir;if(i<0||j<0||j>=s.length)return;[s[i],s[j]]=[s[j],s[i]];o.screens=s;change();render()}
 function render(){
  const all=screens(),keys=current();
  pick.replaceChildren(new Option(keys.length>=6?'Six Screens Maximum':'Choose A Panel…',''));
  for(const s of all)if(!keys.includes(s.key))pick.append(new Option(s.title,s.key));
  pick.disabled=keys.length>=6;
  for(const [k,v] of views)if(!keys.includes(k)){v.box.remove();views.delete(k)}
  keys.forEach((k,i)=>{
   let v=views.get(k);const title=all.find(s=>s.key===k)?.title??k;
   if(!v){
    const source=sourceFor(k);if(!source)return;
    const box=document.createElement('article');box.className='blank-screen';
    const head=document.createElement('div');head.className='blank-screen-head';
    const name=document.createElement('strong');
    const actions=document.createElement('span');
    for(const [label,text,fn] of [['Move Screen Up','↑',()=>move(k,-1)],['Move Screen Down','↓',()=>move(k,1)],['Go To Panel','Open',()=>reveal(k)],['Remove Screen','×',()=>remove(k)]]){const b=document.createElement('button');b.type='button';b.textContent=text;b.title=label;b.setAttribute('aria-label',label);b.onclick=fn;actions.append(b)}
    head.append(name,actions);
    const m=mirrorPanel(source,()=>reveal(k));m.el.querySelector('button')?.remove();m.el.querySelector('.widget-hint')?.remove();
    box.append(head,m.el);v={box,m,name};views.set(k,v);
   }
   v.name.textContent=title;
   if(list.children[i]!==v.box)list.insertBefore(v.box,list.children[i]??null);
  });
  el.querySelector('.blank-empty').hidden=keys.length>0;
 }
 return {el,render,tick(){if(!el.isConnected)return;for(const v of views.values())v.m.tick()}};
}
