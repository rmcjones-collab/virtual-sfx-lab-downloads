const clone=v=>structuredClone(v);
const safeKey=k=>typeof k==='string'&&k.length<100&&!['__proto__','prototype','constructor'].includes(k);
const roots=new Set(['format','version','fixtures','fuel','selectedId','selectedIds','layoutLocked','sceneScale','view','favorites','favoriteTiming','playback','preferences']);
export function normalize(layout){
 const out=clone(layout);
 for(const key of ['fixtures','fuel'])out[key]=Object.fromEntries((out[key]??[]).map(f=>[String(f.id),f]));
 return out;
}
export function denormalize(layout){
 const out=clone(layout);
 for(const key of ['fixtures','fuel'])out[key]=Object.values(out[key]??{}).sort((a,b)=>a.id-b.id);
 return out;
}
export function difference(before,after,path=[]){
 if(JSON.stringify(before)===JSON.stringify(after))return [];
 if(before&&after&&!Array.isArray(before)&&!Array.isArray(after)&&typeof before==='object'&&typeof after==='object'){
  return [...new Set([...Object.keys(before),...Object.keys(after)])].flatMap(k=>difference(before[k],after[k],[...path,k]));
 }
 return [{path,...(after===undefined?{remove:true}:{value:clone(after)})}];
}
export function applyPatch(base,patch){
 if(!Array.isArray(patch)||patch.length>2000)throw Error('Invalid action changes');
 for(const op of patch){
  if(!Array.isArray(op.path)||!op.path.length||op.path.length>12||!op.path.every(safeKey)||!roots.has(op.path[0]))throw Error('Unsupported action path');
  let target=base;
  for(const key of op.path.slice(0,-1)){
   if(!Object.hasOwn(target,key)||!target[key]||typeof target[key]!=='object')throw Error(`Action depends on a removed item: ${op.path.join('.')}`);
   target=target[key];
  }
  const key=op.path.at(-1);
  if(op.remove===true)delete target[key];else{if(!Object.hasOwn(op,'value'))throw Error('Action needs a value');target[key]=clone(op.value)}
 }
 return base;
}
const UUID=/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const isoTime=v=>typeof v==='string'&&v.length<=40&&/^\d{4}-\d{2}-\d{2}T[\d:.]+(Z|[+-]\d{2}:\d{2})$/.test(v)&&!Number.isNaN(Date.parse(v));
export function rebuild(doc){
 // Header fields reach file names, API paths and the Markdown export, so they are checked like the actions.
 if(doc&&(typeof doc.id!=='string'||!UUID.test(doc.id)||typeof doc.title!=='string'||doc.title.length>200||/[\u0000-\u001f\u007f\u200b-\u200d\u202a-\u202e\u2066-\u2069\ufeff]/.test(doc.title)||!isoTime(doc.startedAt)||(doc.updatedAt!==undefined&&!isoTime(doc.updatedAt))))throw Error('Invalid session header (id, title or dates).');
 if(doc?.format!=='wave-studio-session'||doc.version!==1||!doc.initial||!Array.isArray(doc.actions)||doc.actions.length>2000)throw Error('Choose a valid Wave Studio session document (up to 2,000 actions).');
 const state=normalize(doc.initial);
 for(const action of doc.actions){
  if(typeof action.label!=='string'||action.label.length>200||!Number.isFinite(action.at)||action.at<0)throw Error('Invalid session action');
  if(action.enabled!==false)applyPatch(state,action.patch);
 }
 return denormalize(state);
}
export function readSession(text){
 if(text.length>8000000)throw Error('Session document is too large (8 MB maximum).');
 // The authoritative block is the last one, fenced on its own lines.
 const blocks=[...text.matchAll(/^```wave-session-json[ \t]*\r?\n([\s\S]*?)\r?\n```[ \t]*$/gm)];
 const data=JSON.parse(blocks.length?blocks.at(-1)[1]:text);rebuild(data);return data;
}
export function sessionMarkdown(doc){
 return `# ${String(doc.title).replace(/[\r\n#]/g,' ')}\n\nStarted: ${String(doc.startedAt).replace(/[\r\n`]/g,' ')}\n\nThis editable Wave Studio session contains ${doc.actions.length} actions. Import this document in Setup > Session Files, remove or replace actions, then apply the reconstructed layout and settings. Applying always pauses playback and disconnects live input; it does not replay or transmit firing commands.\n\n## Action Log\n\n${doc.actions.map((a,i)=>`- ${i+1}. ${(a.at/1000).toFixed(2)} s: ${a.label.replace(/[\r\n]/g,' ')}${a.enabled===false?' [Removed]':''}`).join('\n')}\n\n## Editable Session Data\n\nThe block below is authoritative when reopening this document. Editing the readable summary alone does not change the session.\n\n\`\`\`wave-session-json\n${JSON.stringify(doc,null,2)}\n\`\`\`\n`;
}
