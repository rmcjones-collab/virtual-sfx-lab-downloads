// Runs inside the AI Build frame (sandboxed, opaque origin, its own default-src 'none' policy).
// It is the only script in the frame. It starts the app's code in a worker created here, so the
// worker shares the frame's opaque origin and policy (no network, no studio storage or cookies),
// applies the worker's screen updates and sends it user input. Only store, run, state and error
// messages go to the studio, which checks them.
(()=>{
 'use strict';
 const EVENTS=new Set(['click','dblclick','input','change','keydown','keyup','pointerdown','pointerup','pointermove','focus','blur','wheel']);
 const listeners=new Map(),canvases=new Map();let lastMove=0,worker=null;
 const toWorker=m=>{try{worker?.postMessage(m)}catch{}};
 const post=m=>parent.postMessage(m,'*');
 const all=sel=>{try{return [...document.querySelectorAll(sel)]}catch{return []}};
 const BAD_ATTR=/^(on|srcdoc$|formaction$|action$|xlink:href$)/i;
 const BAD_URL=/^\s*(javascript|vbscript|data:text\/html)/i;
 function clean(root){
  for(const n of root.querySelectorAll?root.querySelectorAll('script,iframe,object,embed,base,meta,link,form[action]'):[])n.remove();
  for(const n of [root,...(root.querySelectorAll?root.querySelectorAll('*'):[])]){if(!n.attributes)continue;for(const a of [...n.attributes])if(BAD_ATTR.test(a.name)||(/^(href|src)$/i.test(a.name)&&BAD_URL.test(a.value)))n.removeAttribute(a.name)}
 }
 function setHTML(n,html){const t=document.createElement('template');t.innerHTML=String(html);clean(t.content);n.replaceChildren(t.content)}
 function apply(op){
  const nodes=all(op.sel);
  for(const n of nodes){
   if(op.op==='text')n.textContent=String(op.value??'');
   else if(op.op==='html')setHTML(n,op.value??'');
   else if(op.op==='append'){const t=document.createElement('template');t.innerHTML=String(op.value??'');clean(t.content);n.append(t.content)}
   else if(op.op==='attr'){const name=String(op.name||'');if(!name||BAD_ATTR.test(name))continue;if(op.value===null||op.value===false)n.removeAttribute(name);else{const v=String(op.value);if(/^(href|src)$/i.test(name)&&BAD_URL.test(v))continue;n.setAttribute(name,v)}}
   else if(op.op==='style'){const prop=String(op.name||'');if(prop.startsWith('--'))n.style.setProperty(prop,String(op.value??''));else n.style[prop]=op.value??''}
   else if(op.op==='toggle')n.classList.toggle(String(op.name||''),op.force===undefined?undefined:!!op.force);
   else if(op.op==='value'){if('checked' in n&&typeof op.value==='boolean')n.checked=op.value;else if('value' in n)n.value=String(op.value??'')}
   else if(op.op==='remove')n.remove();
   else if(op.op==='focus')n.focus?.();
  }
 }
 function describe(e,target){
  const d={type:e.type,id:target.id||'',dataset:{...target.dataset},value:'value' in target?String(target.value):undefined,checked:'checked' in target?!!target.checked:undefined,text:(target.textContent||'').slice(0,200)};
  if('key' in e){d.key=e.key;d.shift=e.shiftKey;d.alt=e.altKey;d.ctrl=e.ctrlKey||e.metaKey}
  if('clientX' in e){const r=target.getBoundingClientRect();d.x=e.clientX-r.left;d.y=e.clientY-r.top;d.width=r.width;d.height=r.height;d.buttons=e.buttons}
  if(e.type==='wheel'){d.deltaX=e.deltaX;d.deltaY=e.deltaY}
  const index=all(listeners.get(e.__id)?.sel||'').indexOf(target);d.index=index;
  return d;
 }
 function listen({id,sel,event}){
  if(!EVENTS.has(event)||listeners.has(id))return;
  const fn=e=>{
   const target=e.target.closest?.(sel);if(!target)return;
   if(event==='pointermove'){const now=performance.now();if(now-lastMove<30)return;lastMove=now}
   if(event==='click'&&target.closest('a'))e.preventDefault();
   if(event==='keydown'&&['ArrowUp','ArrowDown',' '].includes(e.key)&&!target.matches('input,textarea'))e.preventDefault();
   e.__id=id;toWorker({type:'event',id,data:describe(e,target)});
  };
  listeners.set(id,{sel,event,fn});document.addEventListener(event,fn,{capture:['focus','blur'].includes(event),passive:event!=='keydown'&&event!=='click'});
 }
 function canvasInfo({req,sel}){
  const c=all(sel).find(n=>n.tagName==='CANVAS');
  if(!c){toWorker({type:'reply',req,error:`No canvas matches ${sel}`});return}
  const r=c.getBoundingClientRect(),dpr=Math.min(2,devicePixelRatio||1),width=Math.max(1,Math.round((r.width||Number(c.getAttribute('width'))||300)*dpr)),height=Math.max(1,Math.round((r.height||Number(c.getAttribute('height'))||150)*dpr));
  canvases.set(sel,c);toWorker({type:'reply',req,value:{width,height,dpr}});
 }
 function frame({sel,bitmap}){
  const c=canvases.get(sel);if(!c||!bitmap)return;
  if(c.width!==bitmap.width)c.width=bitmap.width;if(c.height!==bitmap.height)c.height=bitmap.height;
  const ctx=c.getContext('bitmaprenderer');if(ctx)ctx.transferFromImageBitmap(bitmap);else{c.getContext('2d')?.drawImage(bitmap,0,0);bitmap.close?.()}
 }
 function start(code){
  if(worker||typeof code!=='string')return;
  const url=URL.createObjectURL(new Blob([code],{type:'text/javascript'}));
  try{worker=new Worker(url,{name:'AI Build App'})}catch(err){URL.revokeObjectURL(url);post({type:'aib-error',message:`The App Could Not Start: ${String(err?.message||err).slice(0,200)}`});return}
  setTimeout(()=>URL.revokeObjectURL(url),5000);
  worker.onmessage=e=>{
   const m=e.data;if(!m||typeof m!=='object')return;
   try{
    if(m.type==='ops'&&Array.isArray(m.ops))m.ops.slice(0,2000).forEach(apply);
    else if(m.type==='listen')listen(m);
    else if(m.type==='canvas')canvasInfo(m);
    else if(m.type==='frame')frame(m);
    else if(m.type==='store')post({type:'aib-store',data:m.data});
    else if(m.type==='run')post({type:'aib-run',command:String(m.command)});
    else if(m.type==='state')post({type:'aib-state',req:m.req});
    else if(m.type==='error')post({type:'aib-error',message:String(m.message).slice(0,300)});
   }catch(err){post({type:'aib-error',message:String(err?.message||err).slice(0,300)})}
  };
  worker.onerror=e=>{e.preventDefault?.();post({type:'aib-error',message:e.message||'The App Script Failed To Load. Check The Source For A Syntax Error.'})};
 }
 addEventListener('message',e=>{
  if(e.source!==parent)return;const m=e.data;if(!m||typeof m!=='object')return;
  if(m.type==='aib-start')start(m.code);
  else if(m.type==='aib-reply')toWorker({type:'reply',req:m.req,value:m.value});
 });
 document.addEventListener('submit',e=>e.preventDefault(),true);
 document.addEventListener('click',e=>{if(e.target.closest?.('a[href]'))e.preventDefault()},true);
 clean(document.body);
 new ResizeObserver(()=>toWorker({type:'resize',width:innerWidth,height:innerHeight})).observe(document.documentElement);
 post({type:'aib-ready'});
})();
