// Customize checkpoints and named Customized Layouts.
// Saved privately for this visitor on the Wave Studio server (like the workspace
// itself), with this browser's storage as a backup and the current session as a
// last resort. Everything is re-validated before use; note text is never copied.
const CACHE_KEY='wave-studio-custom-layouts-v2';
const MAX_LAYOUTS=24,MAX_BYTES=1400000;
const DEVICES={desktop:'Desktop',mobile:'Phone',fullscreenDesktop:'Full Screen Desktop',fullscreenMobile:'Full Screen Phone'};
const CONTENT_KEYS=['notes','activeNoteId'];
const isDevice=d=>typeof d==='string'&&Object.hasOwn(DEVICES,d);
const empty=()=>({version:1,checkpoints:{},layouts:[]});
const readCache=()=>{try{const v=JSON.parse(localStorage.getItem(CACHE_KEY)||'null');return v&&typeof v==='object'?v:null}catch{return null}};
const writeCache=(value,owner)=>{try{localStorage.setItem(CACHE_KEY,JSON.stringify(owner?{...value,owner}:value));return true}catch{return false}};
const cleanName=v=>String(v||'').replace(/[\u0000-\u001f<>]/g,'').replace(/\s+/g,' ').trim().slice(0,60);
export function mountLayoutLibrary({config,activeDevice,validateWorkspace,apply,status,editing,remote}){
 // synced: the server copy has been read at least once this visit. Until then the server is never
 // overwritten, so a stale browser copy cannot replace layouts saved from another device.
 let data=empty(),where='session',synced=false,unsent=false;const removed=new Set();
 // owner: opaque per-visitor tag from the server. The browser copy is only reused for the identity that wrote it;
 // made: layouts and checkpoints created in this tab, which are always kept.
 let owner=null,cacheOwner=null;const made={layouts:new Set(),checkpoints:new Set()};
 const tag=v=>typeof v?.owner==='string'&&/^[0-9a-f]{24}$/.test(v.owner)?v.owner:null;
 const ownOnly=v=>({version:1,checkpoints:Object.fromEntries(Object.entries(v.checkpoints).filter(([d])=>made.checkpoints.has(d))),layouts:v.layouts.filter(l=>made.layouts.has(l?.id))});
 // Same record rules as the server, so a damaged browser copy is skipped rather than shown or sent.
 const goodEntry=l=>l&&typeof l==='object'&&typeof l.id==='string'&&/^layout-[a-z0-9]{1,20}$/.test(l.id)&&typeof l.name==='string'&&l.name.length>=1&&l.name.length<=60&&!/[\u0000-\u001f<>]/.test(l.name)&&isDevice(l.device)&&typeof l.savedAt==='string'&&!Number.isNaN(Date.parse(l.savedAt))&&l.profile&&typeof l.profile==='object'&&Array.isArray(l.profile.panels);
 const shape=v=>{
  const c=v?.checkpoints&&typeof v.checkpoints==='object'&&!Array.isArray(v.checkpoints)?v.checkpoints:{};
  const checkpoints=Object.fromEntries(Object.entries(c).filter(([d,x])=>isDevice(d)&&x&&typeof x==='object'&&typeof x.savedAt==='string'&&x.profile&&typeof x.profile==='object'));
  return {version:1,checkpoints,layouts:Array.isArray(v?.layouts)?v.layouts.filter(goodEntry).slice(0,64):[]};
 };
 const stamp=v=>Date.parse(v?.savedAt)||0,newer=(a,b)=>stamp(a)>=stamp(b)?a:b;
 // Server and local copies are combined: the newer checkpoint per screen, and every layout by id (newer wins),
 // except layouts deleted here while the server was unreachable.
 function merge(local,server){
  const out=shape(server);out.checkpoints={...out.checkpoints};
  for(const [d,c] of Object.entries(local.checkpoints))if(isDevice(d)&&c&&typeof c==='object')out.checkpoints[d]=out.checkpoints[d]?newer(c,out.checkpoints[d]):c;
  const byId=new Map(out.layouts.filter(l=>l&&typeof l.id==='string'&&!removed.has(l.id)).map(l=>[l.id,l]));
  for(const l of local.layouts)if(l&&typeof l.id==='string')byId.set(l.id,byId.has(l.id)?newer(l,byId.get(l.id)):l);
  out.layouts=[...byId.values()];return out;
 }
 async function reconcile(){
  if(synced)return true;
  try{const server=await remote('GET');owner=tag(server);data=merge(cacheOwner&&cacheOwner===owner?data:ownOnly(data),server);synced=true;writeCache(data,owner);return true}catch{return false}
 }
 // Saves to the server first; the browser copy and session memory are fallbacks.
 async function persist(){
  const text=JSON.stringify(data);if(text.length>MAX_BYTES)return 'full';
  const cached=writeCache(data,owner||cacheOwner);
  try{if(!await reconcile())throw Error('offline');if(JSON.stringify(data).length>MAX_BYTES)return 'full';if(library().length>MAX_LAYOUTS){writeCache(data,owner);where='browser';unsent=true;return 'over'}await remote('PUT',data);where='server';unsent=false;return 'server'}
  catch{where=cached?'browser':'session';unsent=true;return where}
 }
 const ready=(async()=>{
  const cached=readCache();cacheOwner=tag(cached);
  try{const server=await remote('GET');const has=v=>v&&(Object.keys(v.checkpoints||{}).length||(v.layouts||[]).length);
   owner=tag(server);const mine=has(cached)&&owner&&cacheOwner===owner;
   data=shape(has(server)||!mine?server:cached);where='server';synced=true;if(!has(server)&&mine)await persist();
  }catch{data=shape(cached);where=cached?'browser':'session';synced=false}
  sync();
 })();
 // A stored profile is only used after the full workspace validator accepts it.
 function validProfile(device,profile){
  if(!isDevice(device)||!profile||typeof profile!=='object')return null;
  try{const doc=structuredClone(config());doc[device]=structuredClone(profile);return validateWorkspace(doc)[device]}catch{return null}
 }
 // Layout data comes from the snapshot; panel note text stays as it is now.
 function keepContent(next,current){
  const out=structuredClone(next);
  for(const item of out.panels){
   const now=current.panels.find(p=>p.key===item.key);
   for(const k of CONTENT_KEYS){delete item.options?.[k];if(now?.options&&now.options[k]!==undefined)(item.options??={})[k]=structuredClone(now.options[k])}
  }
  return out;
 }
 function stripContent(profile){
  const out=structuredClone(profile);
  for(const item of out.panels)for(const k of CONTENT_KEYS)if(item.options)delete item.options[k];
  return out;
 }
 const checkpoints=()=>data.checkpoints;
 function checkpointFor(device){const c=checkpoints()[device],profile=c&&validProfile(device,c.profile);return profile?{savedAt:c.savedAt,profile}:null}
 function capture(){
  // The arrangement is taken now; it is written only after the first server read, so it is not lost when that read lands.
  const device=activeDevice(),point={savedAt:new Date().toISOString(),profile:stripContent(config()[device])};
  ready.then(()=>{data.checkpoints[device]=point;made.checkpoints.add(device);sync();return persist()}).then(r=>{if(r==='session')status('Revert Point Kept For This Session Only. Storage Is Unavailable.')});
 }
 function same(a,b){return JSON.stringify(stripContent(a))===JSON.stringify(stripContent(b))}
 function revert(){
  const device=activeDevice(),c=checkpointFor(device);if(!c){status('No Saved Customize Layout To Revert To Yet.');return}
  const current=config()[device];if(same(c.profile,current)){status('Already At The Last Saved Customize Layout.');return}
  if(!confirm(`Revert ${DEVICES[device]} To The Layout Saved When You Pressed Customize Workspace (${new Date(c.savedAt).toLocaleString()})? Panel Notes Are Kept; Panels Added Since Then Are Removed.`))return;
  const profile=validProfile(device,keepContent(c.profile,current));if(!profile){status('Saved Customize Layout Is No Longer Valid.');return}
  apply(device,profile);status('Reverted To The Last Saved Customize Layout.');
 }
 const library=()=>data.layouts.filter(goodEntry);
 const store=async list=>{const before=data.layouts,keep=new Set(list.map(l=>l.id));for(const l of before)if(l&&!keep.has(l.id))removed.add(l.id);data.layouts=list;const r=await persist();if(r==='full')data.layouts=before;return r};
 const savedNote=r=>r==='server'?'':r==='over'?` Saved In This Browser Only: Combining This Browser And The Server Gives More Than ${MAX_LAYOUTS} Layouts. Delete Some To Save Online Again.`:r==='browser'?' Saved In This Browser Only (Server Unavailable).':' Kept For This Session Only — Storage Is Unavailable, So Download A Workspace Copy To Keep It.';
 const dialog=document.createElement('dialog');dialog.className='workspace-dialog layout-library-dialog';dialog.id='layout-library';dialog.setAttribute('aria-labelledby','layout-library-title');
 dialog.innerHTML='<div class="dialog-head"><h2 id="layout-library-title">Customized Layouts</h2><button type="button" data-ll-close>Close</button></div><p class="widget-hint" data-ll-device></p><form class="layout-library-save"><label>Layout name <input type="text" maxlength="60" required placeholder="e.g. Rehearsal Desk" data-ll-name></label><button type="submit">Save Current Layout</button></form><p class="layout-library-status" role="status" data-ll-status></p><div class="layout-library-list" data-ll-list></div><p class="widget-hint">Saved privately for this visitor, like your workspace. Layouts include panels, sizes and button arrangements; note text is not saved in them. Loading a layout keeps your current notes, and Revert Customize can undo a load.</p>';
 document.body.append(dialog);
 const $d=s=>dialog.querySelector(s),say=t=>{$d('[data-ll-status]').textContent=t};
 $d('[data-ll-close]').onclick=()=>dialog.close();
 $d('.layout-library-save').onsubmit=async e=>{
  e.preventDefault();const name=cleanName($d('[data-ll-name]').value);if(!name){say('Enter A Layout Name.');return}
  // Wait for the saved library first; building the list before it arrives would replace it with this one entry.
  await ready;
  const device=activeDevice(),list=library(),existing=list.find(l=>l.device===device&&l.name.toLowerCase()===name.toLowerCase());
  if(existing&&!confirm(`Replace The Saved Layout “${existing.name}”?`))return;
  if(!existing&&list.length>=MAX_LAYOUTS){say(`Up To ${MAX_LAYOUTS} Layouts Can Be Saved. Delete One First.`);return}
  const entry={id:existing?.id||`layout-${Date.now().toString(36)}`,name,device,savedAt:new Date().toISOString(),profile:stripContent(config()[device])};
  const next=existing?list.map(l=>l===existing?entry:l):[...list,entry];
  made.layouts.add(entry.id);const r=await store(next);
  if(r==='full'){say('Layout Storage Is Full. Delete A Saved Layout First.');return}
  $d('[data-ll-name]').value='';say(`Saved “${name}”.${savedNote(r)}`);draw();
 };
 function load(entry){
  const device=activeDevice();if(entry.device!==device)return;
  if(!confirm(`Load “${entry.name}”? Your current ${DEVICES[device]} arrangement becomes the Revert Customize point.`))return;
  const current=config()[device],checked=validProfile(device,entry.profile),profile=checked&&validProfile(device,keepContent(checked,current));
  if(!profile){say('This Saved Layout Is No Longer Valid And Was Not Loaded.');return}
  const point={savedAt:new Date().toISOString(),profile:stripContent(current)};ready.then(()=>{data.checkpoints[device]=point;made.checkpoints.add(device);return persist()});
  apply(device,profile);say(`Loaded “${entry.name}”.`);status(`Loaded Layout “${entry.name}”. Revert Customize Returns To The Previous Arrangement.`);draw();
 }
 function draw(){
  const device=activeDevice(),list=library().filter(l=>l.device===device).sort((a,b)=>a.name.localeCompare(b.name));
  $d('[data-ll-device]').textContent=`Showing ${DEVICES[device]} layouts. Each screen type keeps its own layouts.`;
  const host=$d('[data-ll-list]');host.replaceChildren();
  if(!list.length){const p=document.createElement('p');p.className='widget-hint';p.textContent='No Saved Layouts For This Screen Yet.';host.append(p)}
  for(const entry of list){
   const row=document.createElement('div');row.className='layout-library-row';
   const text=document.createElement('span');const name=document.createElement('strong');name.textContent=entry.name;const when=document.createElement('small');when.textContent=new Date(entry.savedAt).toLocaleString();text.append(name,when);
   const loadB=document.createElement('button');loadB.type='button';loadB.textContent='Load';loadB.setAttribute('aria-label',`Load ${entry.name}`);loadB.onclick=()=>load(entry);
   const del=document.createElement('button');del.type='button';del.textContent='Delete';del.setAttribute('aria-label',`Delete ${entry.name}`);
   del.onclick=async()=>{if(!confirm(`Delete The Saved Layout “${entry.name}”?`))return;await ready;await store(library().filter(l=>l.id!==entry.id));say(`Deleted “${entry.name}”.`);draw()};
   row.append(text,loadB,del);host.append(row);
  }
 }
 // Opening the library retries an unreachable server once; changes made while it was down are then sent.
 function open(){say('');draw();dialog.showModal();$d('[data-ll-name]').focus();ready.then(async()=>{if(!synced&&await reconcile()&&unsent)await persist()}).then(draw)}
 function sync(){
  const c=checkpointFor(activeDevice()),current=config()[activeDevice()];
  for(const b of document.querySelectorAll('[data-revert-customize]')){
   b.disabled=!c||same(c.profile,current);
   b.title=c?`Revert To The Layout Saved ${new Date(c.savedAt).toLocaleString()}`:'Press Customize Workspace To Save A Layout You Can Revert To';
  }
 }
 setInterval(sync,1000);
 return {capture,revert,open,sync};
}
