import {presets, sample, angle, SOURCE} from './presets.js?v=v0340-20261007f';
import {DMXEngine, decodeProgram, validPatch, nextPatch, angleLimits, validAngles, limitSample} from './dmx.js?v=v0340-20261007f';
import {mountPlayback} from './playback-ui.js?v=v0340-20261007f';
import {mountCueStack} from './cue-stack.js?v=v0340-20261007f';
import {PlaybackBank} from './playback-model.js?v=v0340-20261007f';
import {drawFlameJet,drawFlamerBody,nozzleVisual,FLAME_LENGTH_GAIN} from './flame-visuals.js?v=v0340-20261007f';
import {createTimecode} from './timecode.js?v=v0340-20261007f';
import {mountRearPanel} from './rear-panel.js?v=v0340-20261007f';
import {GRID_STEP,groupTranslation,spacingInfo,evenSpacing} from './layout-tools.js?v=v0340-20261007f';
import {createDefaultFixtures,createDefaultStage} from './default-layout.js?v=v0340-20261007f';
import {FuelLedger} from './fuel-model.js?v=v0340-20261007f';
import {mountFuelUI} from './fuel-ui.js?v=v0340-20261007f';
import {mountSessions} from './session-ui.js?v=v0340-20261007f';
import {bindCueTransport} from './transport-controls.js?v=v0340-20261007f';
import {mountSaveOptions,mergeSaveBundle} from './save-options.js?v=v0340-20261007f';
import {requestFileSave} from './file-save.js?v=v0340-20261007f';
import {mountVistaExport} from './vista-export.js?v=v0340-20261007f';
import {mountGrandMAExport} from './grandma-export.js?v=v0340-20261007f';
import {createMAEngine,createMAPanel} from './ma-console.js?v=v0340-20261007f';
import {BUILD_VERSION} from './watermark.js?v=v0340-20261007f';
import {mountWorkspace} from './workspace-ui.js?v=v0340-20261007f';
import {showDefaultFeedback} from './default-feedback.js?v=v0340-20261007f';
import {mountSettingsHub} from './settings-hub.js?v=v0340-20261007f';
import {mountStageRecorder,recordingDefaults,validateRecording} from './stage-recorder.js?v=v0340-20261007f';
import {describeSequences} from './sequence-caption.js?v=v0340-20261007f';
import {LayoutChase,fixtureName,validFixtureName,nextFixturePosition} from './layout-chase.js?v=v0340-20261007f';
import {freshWorkspace,validateWorkspace} from './workspace-model.js?v=v0340-20261007f';
import {mountQuickActions} from './quick-actions.js?v=v0340-20261007f';
import {DEFAULT_SEED} from './default-seed.js?v=v0340-20261007f';
import {mountSupport} from './support-ui.js?v=v0340-20261007f';
import {mountMobileStagePanels} from './mobile-stage-panels.js?v=v0340-20261007f';
import {mountMobileMaPanel} from './ma-mobile-panel.js?v=v0340-20261007f';
import {mountMobileSequencePicker} from './mobile-sequence-picker.js?v=v0340-20261007f';
import {mountPanelContainment} from './panel-containment.js?v=v0340-20261007f';
import {mountPresence} from './presence.js?v=v0340-20261007f';
import {recordVisit} from './traffic.js?v=v0340-20261007f';
import {studioGateEnabled,trialState,trialLabel} from './trial.js?v=v0340-20261007f';
mountPanelContainment();
const $=s=>document.querySelector(s);
// Virtual SFX Lab studio gate: off during the open beta (the full studio opens directly from the
// landing page). ?gate=on re-enables the seven-day trial and lock screen for testing.
const trialGate=studioGateEnabled();
if(trialGate)document.documentElement.classList.add('trial-checking');
(async()=>{
 const pill=$('#trial-pill'),lock=$('#trial-lock');
 const show=state=>{if(!pill)return;pill.hidden=false;pill.textContent=trialLabel(state);pill.dataset.state=state.status;pill.classList.toggle('is-ending',state.status==='active'&&state.daysLeft<=2)};
 try{
  const state=await trialState();
  if(!trialGate){document.documentElement.classList.remove('trial-checking');if(state.status==='licensed')show(state);return}
  if(state.status==='none'){location.replace('./welcome.html?studio=trial#license');return}
  show(state);
  if(state.status==='expired'){
   document.documentElement.classList.add('trial-locked');
   lock.addEventListener('cancel',e=>e.preventDefault());
   lock.addEventListener('close',()=>{if(document.documentElement.classList.contains('trial-locked'))lock.showModal()});
   $('#trial-lock-demo').onclick=()=>location.assign('./welcome.html#demo-editor');
   lock.showModal();
  }
 }catch{}
 finally{document.documentElement.classList.remove('trial-checking')}
})();
const state={...createDefaultStage(),targetTime:null,time:0,playing:true,filter:'all',live:false,liveTime:0,
 get nativeTime(){
  const bank=playbackUI?.bank;
  return bank?.enabled?(playbackUI.transportState().presetDuration||presets[bank.chase.presetId-1].duration):this.preset.duration;
 },
 get effectiveTime(){return Math.max(.01,Math.min(10,Math.round((this.targetTime??this.nativeTime)*100)/100))},
 get speed(){
  return this.nativeTime/this.effectiveTime;
 },
 get preset(){return presets[this.fixtures.find(f=>f.id===this.selectedId).presetId-1]}};
const dmxEngine=new DMXEngine();
const fuel=new FuelLedger();
let fuelUI=null;
let studioSequencePicker=null;
let playbackUI=null,cueStack=null,maEngine=null;
let rearPanel=null;
state.favorites=[];state.favoriteTiming={};state.libraryTab='catalog';state.panX=0;state.panY=0;
state.snapToGrid=false;
state.layoutLocked=false;
state.selectMultiple=false;
state.layoutPinned=true;
document.body.dataset.layoutPinned='true';
let sessions=null;
let stageRecorder=null;
let workspaceUI=null;
const timecode=createTimecode();
const layoutChase=new LayoutChase();
function stopLayoutChase(){layoutChase.stop();const b=$('#layout-chase');if(b){b.textContent='Chase';b.setAttribute('aria-pressed','false')}}
document.addEventListener('wave-release-all',stopLayoutChase);
state.fitScale=1;state.fitCenter=null;
const viewZoom=()=>Math.max(.0001,state.zoom)*state.fitScale;
let transportHolding=false;
let spacingEdit=null;
let dmxStream=null,dmxConnected=false,dmxConnecting=false,dmxStats={received:0,rejected:0,conflicts:0},lastMonitor=0;
let dmxDiscoveryConfig=null;
let dmxProtocol='Art-Net',receiverConfig=null;
const universeOffset=()=>dmxProtocol==='sACN'?1:0;
const selectedFixture=()=>state.fixtures.find(f=>f.id===state.selectedId);
const selectedFixtures=()=>state.fixtures.filter(f=>state.selectedIds.includes(f.id));
function editSelection(change,message){
 const fixtures=selectedFixtures();if(!fixtures.length)return;
 remember();fixtures.forEach(change);updateDetails();renderFixtures();announce(`${fixtures.length} selected unit(s): ${message}`);
}
const favouritePriority=()=>state.libraryTab==='favorites';
const favouriteActive=()=>favouritePriority()&&state.favorites.includes(state.preset.id)&&!playbackUI?.bank.enabled;
const stageGap=()=>favouriteActive()?favoriteTime(state.preset.id).gap:1.1;
const stageDuration=()=>(favouriteActive()?state.preset.duration:Math.max(...state.fixtures.map(f=>presets[f.presetId-1].duration)))+stageGap();
// Explo manual 4.2.14: invert mirrors positions 1↔15 ... 7↔9, with 8 unchanged.
// Keep the source preset and time ordering intact; transform output angles only.
const outputPositions=fixture=>presets[fixture.presetId-1].positions.map(p=>fixture.inverted?16-p:p);
function fixtureSample(fixture,t){
 const result=sample(presets[fixture.presetId-1],t);
 return limitSample(fixture,result);
}
function fixtureIndicator(fixture){
 if(state.live){
  const r=dmxEngine.record(fixture),fresh=state.liveTime-r.last<=dmxEngine.timeout;
  const channel=r.values?.[5]??0,armed=fresh&&channel>=50&&channel<=200;
  return {armed,brightness:armed?channel/255:0,origin:'Received CH6 status (not physical confirmation)'};
 }
 const bank=playbackUI?.bank;
 if(bank?.virtualOwns(fixture)){
  const channel=bank.virtualEngine.record(fixture).values?.[5]??0,armed=channel>=50&&channel<=200;
  return {armed,brightness:armed?channel/255:0,origin:'Virtual DMX CH6 (not hardware)'};
 }
 const armed=fixture.virtualArmed!==false;
 const intensity=bank?.enabled?bank.view(fixture,state.fixtures,state.selectedIds).intensity:bank?.master(fixture,state.selectedIds)??1;
 return {armed,brightness:armed?intensity:0,origin:'Simulated arm state'};
}
const history=[];
function remember(){const snapshot={fixtures:structuredClone(state.fixtures),selectedId:state.selectedId,selectedIds:[...state.selectedIds],layoutLocked:state.layoutLocked,nextId:state.nextId,sceneScale:state.sceneScale,favorites:[...state.favorites],favoriteTiming:structuredClone(state.favoriteTiming),playback:playbackUI?.serialize(),preferences:capturePreferences()};history.push(snapshot);if(history.length>40)history.shift();$('#undo-layout').disabled=false;return snapshot}
function announce(message){$('#layout-status').textContent=message}
const clamp=(n,lo,hi)=>Math.max(lo,Math.min(hi,n));
let themeOverridden=false;
function applyDefaultTheme(){
 if(!themeOverridden)document.documentElement.dataset.theme=DEFAULT_SEED.preferences?.theme==='light'&&!matchMedia('(max-width:700px)').matches?'light':'dark';
}
applyDefaultTheme();
const canvas=$('#stage'),ctx=canvas.getContext('2d'),timeline=$('#timeline'),tc=timeline.getContext('2d');
let W=600,H=500,dpr=1;
const fmt=a=>(a>0?'+':'')+Math.round(a)+'°';
// Home (park) state is runtime only: which units are parked and the last angle each head was drawn at.
const HOME_SECONDS=.45,parkedUnits=new Map(),lastDrawnAngles=new Map();
let labelGap=Infinity;
function homeAngleFor(f){const limits=angleLimits(f);return clamp(Math.round(f.homeAngle??0),limits.min,limits.max)}
function resumeUnits(ids){let n=0;for(const id of ids)if(parkedUnits.delete(id))n++;return n}
let homeReadoutKey='';
function syncHomeReadout(fixture,parked){
 const group=selectedFixtures(),angles=[...new Set(group.map(f=>Math.round(f.homeAngle??0)))];
 const key=`${fixture.id}|${angles.join(',')}|${parked}|${state.live}|${group.length}`;if(key===homeReadoutKey)return;homeReadoutKey=key;
 const input=$('#home-angle');if(!input)return;
 input.dataset.homeSummary=!group.length?'No Selection':angles.length===1?fmt(angles[0]):'Mixed';
 if(document.activeElement!==input)input.value=angles.length===1?String(angles[0]):'';
 input.placeholder=angles.length>1?'Mixed':'0';
 $('#home-selected').disabled=state.live||!group.length;
 $('#home-status').textContent=state.live?'Live Input owns the heads. Home is available in Presets and Virtual Faders.':!group.length?'Select units to set a home angle.':parked?`Parked at home. Choose a look, raise a fader or press Restart to resume.`:`Home ${angles.length>1?'varies per unit':fmt(angles[0])} · press Home or the H key to park ${group.length} unit(s) and release their cues.`;
}
const pad=n=>String(n).padStart(3,'0');
const family=p=>p.type==='wave'?'Continuous wave':p.type==='step'?(p.long?'Long stepped bursts':'Short stepped bursts'):(p.long?'Long single burst':'Short single burst');
const favoriteTime=id=>state.favoriteTiming[id]??{duration:presets[id-1].duration,gap:1.1};
let libraryOutputKey='';
function libraryPresetId(){
 const fixture=selectedFixture();
 if(state.live)return dmxEngine.view(fixture,state.liveTime).preset.id;
 if(playbackUI?.bank.enabled)return playbackUI.bank.view(fixture,state.fixtures,state.selectedIds).preset.id;
 return fixture.presetId;
}
function followLibrary(force=false,reveal=true){
 if(transportHolding)reveal=false;
 const id=libraryPresetId(),key=`${state.selectedId}:${state.live?'live':playbackUI?.bank.enabled?'bank':'manual'}:${id}`;
 if(!force&&key===libraryOutputKey)return;
 libraryOutputKey=key;
 const mobileNow=$('#mobile-now');
 if(mobileNow)mobileNow.textContent=`F${String(state.selectedId).padStart(2,'0')} · ${id?`Sequence ${pad(id)}`:'Direct DMX'}`;
 const quickSeq=$('#mobile-sequence-select');
 if(quickSeq&&document.activeElement!==quickSeq){quickSeq.value=id?String(id):'';quickSeq.disabled=state.live||!state.selectedIds.length}
 studioSequencePicker?.sync();
 const stageList=$('#mobile-stage-sequences');
 if(stageList){
  stageList.querySelectorAll('[data-stage-preset]').forEach(button=>{
   const active=Number(button.dataset.stagePreset)===id;
   button.classList.toggle('active',active);button.setAttribute('aria-pressed',String(active));
  });
  const active=stageList.querySelector('.active');
  if(reveal&&active&&stageList.clientHeight){
   const row=active.getBoundingClientRect(),pane=stageList.getBoundingClientRect();
   stageList.scrollTop+=row.top+row.height/2-(pane.top+stageList.clientTop+stageList.clientHeight/2);
  }
 }
 const list=$('#preset-list');
 list.querySelectorAll('.preset').forEach(button=>{
  const active=Number(button.dataset.id)===id;
  button.classList.toggle('active',active);button.setAttribute('aria-pressed',String(active));
 });
 // Centre the current cue in this pane without scrolling the page.
 const active=list.querySelector('.preset.active');
 if(reveal&&active&&list.clientHeight){
  const centred=!matchMedia('(max-width:700px)').matches&&$('#tour').checked;
  const inset=centred?Math.max(0,(list.clientHeight-active.getBoundingClientRect().height)/2):0;
  list.style.paddingTop=`${inset}px`;list.style.paddingBottom=`${inset}px`;
  const row=active.getBoundingClientRect(),pane=list.getBoundingClientRect();
  if(matchMedia('(max-width:700px)').matches||$('#tour').checked)list.scrollTop+=row.top+row.height/2-(pane.top+list.clientTop+list.clientHeight/2);
  else if(row.top<pane.top)list.scrollTop+=row.top-pane.top;
  else if(row.bottom>pane.bottom)list.scrollTop+=row.bottom-pane.bottom;
 }
}
function renderStageLibrary(){
 const list=$('#mobile-stage-sequences');if(!list)return;
 const order=favouritePriority()?state.favorites:presets.map(p=>p.id),key=order.join(',')+'|'+state.favorites.join(',');
 if(list.dataset.order!==key){
  list.dataset.order=key;list.innerHTML=order.length?order.map(id=>{const p=presets[id-1],starred=state.favorites.includes(id);return `<div class="stage-sequence-item"><button type="button" class="stage-sequence-row" data-stage-preset="${id}" aria-pressed="false"><span class="stage-sequence-number">${pad(id)}</span><span class="stage-sequence-title">${p.name}</span><span class="stage-sequence-duration">${p.duration.toFixed(2)}s</span></button><button type="button" class="favorite-star" data-stage-star="${id}" aria-label="${starred?'Remove':'Add'} Sequence ${pad(id)} ${starred?'From':'To'} Favourites" aria-pressed="${starred}"><span class="star-icon" aria-hidden="true"></span></button></div>`}).join(''):'<p class="empty">Add Favourite Cues In The Sequences Tab.</p>';
  list.querySelectorAll('[data-stage-preset]').forEach(b=>b.onclick=()=>select(Number(b.dataset.stagePreset)));
  list.querySelectorAll('[data-stage-star]').forEach(b=>b.onclick=()=>{
   const id=Number(b.dataset.stageStar),scroll=list.scrollTop;
   toggleFavourite(id);list.scrollTop=scroll;
   (list.querySelector(`[data-stage-star="${id}"]`)??list.querySelector('[data-stage-star]'))?.focus({preventScroll:true});
  });
 }
 $('#mobile-stage-library-title').textContent=favouritePriority()?'Favourites':'Sequence Library';
 $('.mobile-stage-library-heading span').textContent=`${order.length} ${favouritePriority()?'Favourites':'Sequences'}`;
 list.querySelectorAll('[data-stage-preset]').forEach(b=>b.disabled=state.live||!state.selectedIds.length);
 list.querySelectorAll('[data-stage-star]').forEach(b=>b.disabled=state.live);
}
function toggleFavourite(id){
 const was=state.favorites.includes(id);remember();
 state.favorites=was?state.favorites.filter(x=>x!==id):[...state.favorites,id];
 if(was)delete state.favoriteTiming[id];
 if(favouritePriority()&&!state.favorites.length){state.playing=false;syncPlay()}
 renderList();
 favoriteNotice(`Sequence ${pad(id)} ${was?'removed from':'added to'} favourites. Existing saved cues are unchanged.`);
}
function renderList(){
 renderStageLibrary();
 const listElement=$('#preset-list'),scroll=listElement.scrollTop,previousOutput=libraryOutputKey;
 const q=$('#search').value.toLowerCase().replace(/^#/,'');
 const favorites=state.libraryTab==='favorites';
 $('.library').classList.toggle('favorites-library',favorites);
 const list=(favorites?state.favorites.map(id=>presets[id-1]):presets).filter(p=>(favorites||state.filter==='all'||p.type===state.filter)&&(!q||(`${pad(p.id)} ${p.name} ${family(p)} ${p.positions.map(angle).join(' ')} ${p.id>70?'dmx':''}`).toLowerCase().includes(q)));
 $('#result-count').textContent=`${list.length} ${favorites?'FAVORITES':'SEQUENCES'}`;
 $('#favorite-count').textContent=state.favorites.length;
 $('#favorite-tools').hidden=!favorites;
 $('.filters').hidden=favorites;
 $('#save-favorite-cue').disabled=!state.favorites.length||!state.selectedIds.length||state.live;
 $('#preset-list').setAttribute('aria-labelledby',favorites?'tab-favorites':'tab-catalog');
 for(const tab of ['catalog','favorites']){const button=$(`#tab-${tab}`),active=state.libraryTab===tab;button.setAttribute('aria-selected',String(active));button.tabIndex=active?0:-1}
 $('#preset-list').innerHTML=list.length?list.map(p=>{
  const starred=state.favorites.includes(p.id),order=state.favorites.indexOf(p.id);
  return `<div class="preset-row ${favorites?'favorite-row':''}" data-preset-row="${p.id}">
  ${favorites?`<div class="favorite-sort"><span>${String(order+1).padStart(2,'0')}</span><button class="favorite-handle" draggable="${!q}" data-drag="${p.id}" aria-label="Drag sequence ${pad(p.id)} to reorder" title="Drag to reorder; or use adjacent arrows" ${q?'disabled':''}>⠿</button><button data-move="-1" aria-label="Move sequence ${pad(p.id)} up" ${q||order===0?'disabled':''}>↑</button><button data-move="1" aria-label="Move sequence ${pad(p.id)} down" ${q||order===state.favorites.length-1?'disabled':''}>↓</button></div>`:''}
  <button class="preset ${p.id===state.preset.id?'active':''}" data-id="${p.id}" aria-pressed="${p.id===state.preset.id}"><span class="id">${pad(p.id)}</span><span><span class="preset-title">${p.type==='single'?`${p.long?'Long':'Short'} burst`:p.type==='step'?`${p.long?'Long':'Short'} steps`:p.id===53||p.id===54?'Full wave':'Wave'}</span><small>${p.type==='single'?fmt(angle(p.positions[0])):p.positions.length>7?`${p.positions[0]} through ${p.positions.at(-1)}`:p.positions.join(' → ')}${p.id>70?' · DMX only':''}</small></span><span class="seconds">${p.duration.toFixed(2)}s</span></button><button class="favorite-star" data-star="${p.id}" aria-label="${starred?'Unstar':'Star'} sequence ${pad(p.id)}" aria-pressed="${starred}" title="${starred?'Remove from favorites':'Add to favorites'}"><span class="star-icon" aria-hidden="true"></span></button></div>`;
 }).join(''):`<p class="empty">${favorites&&!state.favorites.length?'No favorites yet. Open All sequences and star a look to start your chase.':q?'No matches. Clear search to see the full list.':'No matching sequences.'}</p>`;
 $('#preset-list').querySelectorAll('.preset').forEach(b=>{b.disabled=state.live||!state.selectedIds.length;b.onclick=()=>select(+b.dataset.id)});
 $('#preset-list').querySelectorAll('[data-star]').forEach(b=>b.onclick=()=>{
  const id=+b.dataset.star,scroll=$('#preset-list').scrollTop;toggleFavourite(id);$('#preset-list').scrollTop=scroll;
  ($(`[data-star="${id}"]`)??$('#preset-list [data-star]'))?.focus({preventScroll:true});
 });
 $('#preset-list').querySelectorAll('.favorite-row').forEach(row=>{
  const id=+row.dataset.presetRow;
  const timing=favoriteTime(id);
  row.insertAdjacentHTML('beforeend',`<div class="favorite-timing"><label>Duration (s)<input data-time="duration" type="number" min=".01" max="10" step=".01" value="${timing.duration.toFixed(2)}" aria-label="Duration for favorite ${pad(id)}"></label><label>Gap (s)<input data-time="gap" type="number" min="0" max="60" step=".01" value="${timing.gap.toFixed(2)}" aria-label="Gap after favorite ${pad(id)}"></label><button class="reset-favorite-time" title="Reset duration to preset and gap to 1.10 s">Reset</button></div>`);
  row.querySelectorAll('[data-time]').forEach(input=>input.onchange=()=>{
   if(input.value===''||!input.checkValidity()){input.value=favoriteTime(id)[input.dataset.time].toFixed(2);favoriteNotice('Use duration 0.01–10 s or gap 0–60 s. Invalid edit discarded.');return}
   remember();state.favoriteTiming[id]={...favoriteTime(id),[input.dataset.time]:Math.round(Number(input.value)*100)/100};input.value=state.favoriteTiming[id][input.dataset.time].toFixed(2);favoriteNotice('Favorite timing updated. Save as a new cue; existing cues are unchanged.');
   if(favouriteActive()&&state.preset.id===id){state.targetTime=favoriteTime(id).duration;$('#speed').value=state.targetTime.toFixed(2)}
  });
  row.querySelector('.reset-favorite-time').onclick=()=>{remember();delete state.favoriteTiming[id];if(favouriteActive()&&state.preset.id===id)state.targetTime=favoriteTime(id).duration;const scroll=$('#preset-list').scrollTop;renderList();$('#preset-list').scrollTop=scroll;favoriteNotice(`Sequence ${pad(id)} timing reset.`)};
  row.querySelectorAll('[data-move]').forEach(b=>b.onclick=()=>{
   const at=state.favorites.indexOf(id),to=at+Number(b.dataset.move);
   if(to<0||to>=state.favorites.length)return;
   remember();state.favorites.splice(at,1);state.favorites.splice(to,0,id);finishFavoriteMove(id,b.dataset.move);
  });
  const handle=row.querySelector('[data-drag]');
  handle.ondragstart=e=>{favoriteDrag=id;e.dataTransfer.effectAllowed='move';e.dataTransfer.setData('text/plain',String(id));row.classList.add('favorite-dragging')};
  handle.ondragend=clearFavoriteDrag;
  row.ondragover=e=>{
   if(favoriteDrag===null||q)return;e.preventDefault();e.dataTransfer.dropEffect='move';
   $('#preset-list').querySelectorAll('.drop-before,.drop-after').forEach(r=>r.classList.remove('drop-before','drop-after'));
   row.classList.add(e.clientY<row.getBoundingClientRect().top+row.offsetHeight/2?'drop-before':'drop-after');
   const box=$('#preset-list').getBoundingClientRect();if(e.clientY<box.top+36)$('#preset-list').scrollTop-=12;else if(e.clientY>box.bottom-36)$('#preset-list').scrollTop+=12;
  };
  row.ondrop=e=>{
   if(favoriteDrag===null||q)return;e.preventDefault();
   const moved=favoriteDrag,after=e.clientY>=row.getBoundingClientRect().top+row.offsetHeight/2;clearFavoriteDrag();
   if(moved===id)return;
   remember();state.favorites=state.favorites.filter(x=>x!==moved);const at=state.favorites.indexOf(id)+(after?1:0);state.favorites.splice(at,0,moved);finishFavoriteMove(moved);
  };
 });
 listElement.scrollTop=scroll;
 followLibrary(true,false);
 if(previousOutput&&previousOutput!==libraryOutputKey)followLibrary(true);
}
let favoriteDrag=null;
function favoriteNotice(message){$('#favorite-status').textContent=message}
function clearFavoriteDrag(){favoriteDrag=null;$('#preset-list').querySelectorAll('.favorite-dragging,.drop-before,.drop-after').forEach(r=>r.classList.remove('favorite-dragging','drop-before','drop-after'))}
function finishFavoriteMove(id,direction){
 const scroll=$('#preset-list').scrollTop;renderList();$('#preset-list').scrollTop=scroll;
 const row=$(`[data-preset-row="${id}"]`);((direction?row.querySelector(`[data-move="${direction}"]:not(:disabled)`):null)??row.querySelector('[data-drag]'))?.focus({preventScroll:true});
 favoriteNotice(`Sequence ${pad(id)} moved to position ${state.favorites.indexOf(id)+1}. Save order as cue to keep this chase.`);
}
function select(id,play=true){
 stopLayoutChase();
 if(state.live||!state.selectedIds.length)return;
 if(favouritePriority()&&!state.favorites.includes(id))return;
 if(favouritePriority()&&playbackUI?.bank.enabled)$('#mode-preview').click();
 remember();resumeUnits(state.selectedIds);selectedFixtures().forEach(f=>f.presetId=id);state.targetTime=favouritePriority()?favoriteTime(id).duration:null;state.time=0;state.playing=play;
 if(favouritePriority())$('#tour').checked=true;
 updateDetails();if(favouritePriority()){state.targetTime=favoriteTime(id).duration;$('#speed').value=state.targetTime.toFixed(2)}followLibrary(true);renderFixtures();
}
function updateDetails(){
 const p=state.preset,fixture=selectedFixture(),positions=outputPositions(fixture);
 let name=p.name;
 if(fixture.inverted){
  if(p.type==='single')name=`${p.long?'Long':'Short'} burst · ${fmt(angle(positions[0]))}`;
  else if(p.id===53||p.id===54)name=`Full wave · ${positions[0]<positions.at(-1)?'left to right':'right to left'}`;
  else name=`${p.type==='wave'?'Wave':p.long?'Long steps':'Short steps'} · ${positions.length>7?`${positions[0]} through ${positions.at(-1)}`:positions.join(' → ')}`;
 }
 $('#preset-number').textContent=pad(p.id);$('#preset-name').textContent=name;
 $('#family').textContent=family(p).toUpperCase();
 $('#output-mode').textContent=fixture.inverted?'INVERT ON · MIRRORED OUTPUT':'INVERT OFF · CATALOG OUTPUT';
 $('#output-mode').classList.toggle('is-inverted',!!fixture.inverted);
 $('#description').textContent=p.type==='wave'?'A continuous flame follows the moving head from the first position to the last.':p.type==='step'?'Separate bursts at successive positions. The head moves between bursts with emission off.':'A single fixed-angle burst. Short and long variants differ in emission time.';
 $('#duration').textContent=p.duration.toFixed(2)+' s';
 const limits=angleLimits(fixture),bounded=positions.map(pos=>clamp(angle(pos),limits.min,limits.max));
 $('#angle-path').textContent=(p.type==='single'?[bounded[0]]:[bounded[0],bounded.at(-1)]).map(fmt).join(' → ');
 $('#positions').textContent=positions.length>7?`${positions[0]} through ${positions.at(-1)}`:positions.join(' → ');
 $('#availability').textContent=p.id>70?'DMX only':'Radio / DMX';
 $('#scrub').max=stageDuration();$('#end-time').textContent=` / ${stageDuration().toFixed(2)} s`;$('#timeline-label').textContent=`F${String(state.selectedId).padStart(2,'0')} emission`;syncPlay();syncRate();
}
function syncPlay(){const playing=playbackUI?.bank.enabled?!playbackUI.transportState().paused:state.playing;$('#play').textContent=playing?'Pause':'Play';$('#play').setAttribute('aria-label',playing?'Pause preview':'Play preview')}
function resize(){
 const r=canvas.parentElement.getBoundingClientRect();if(r.width<1||r.height<1)return;
 const oldW=W,oldH=H;W=r.width;H=r.height;dpr=Math.min(devicePixelRatio||1,2);
 if(state.fitCenter&&(Math.abs(oldW-W)>.5||Math.abs(oldH-H)>.5)){
  state.fitCenter={x:state.fitCenter.x*W/oldW,y:state.fitCenter.y*H/oldH};
 }
 canvas.width=W*dpr;canvas.height=H*dpr;
 const tr=timeline.getBoundingClientRect();timeline.width=tr.width*dpr;timeline.height=tr.height*dpr;
 if(!state.fitCenter)fitFlameView(false);
 positionHandles();
}
new ResizeObserver(resize).observe(canvas.parentElement);new ResizeObserver(resize).observe(timeline);
// Native focus/scrollIntoView must reserve room for the pinned stage and transport.
// Only reserve that room when the stage really overlays the page (classic pinned layout).
// Inside a custom workspace or full screen the stage is an ordinary panel, and reserving
// its height made clicking or typing in other panels' fields jump the page upward.
function stageOverlaysPage(){
 const stage=$('.stage-live'),body=document.body.classList;
 return !!stage&&state.layoutPinned&&!body.contains('custom-workspace-mode')&&!body.contains('workspace-focus-mode')&&getComputedStyle(stage).position==='sticky'&&!stage.closest('.workspace-card,#workspace-focus');
}
function syncStageScrollPadding(){
 const stage=$('.stage-live'),height=stage?Math.ceil(stage.getBoundingClientRect().height)+12:0;
 document.documentElement.style.setProperty('--stage-overlay-height',`${height}px`);
 document.documentElement.style.scrollPaddingTop=stageOverlaysPage()?`${height}px`:'0px';
}
new ResizeObserver(syncStageScrollPadding).observe($('.stage-live'));
new MutationObserver(syncStageScrollPadding).observe(document.body,{attributes:true,attributeFilter:['class']});
function line(x1,y1,x2,y2,color,width=1){ctx.beginPath();ctx.moveTo(x1,y1);ctx.lineTo(x2,y2);ctx.strokeStyle=color;ctx.lineWidth=width;ctx.stroke()}
const rand=n=>{const f=Math.sin(n*127.1+311.7)*43758.5453123;return f-Math.floor(f)};
// Rendering-only profiles. They do not change catalog pulse times or sequence duration.
const flameProfile=p=>p.type==='wave'
 ?{travel:.22,life:.66}
 :p.long
 ?{travel:.19,life:.64}
 :{travel:.14,life:.59};
// Deterministic particle reconstruction allows exact replay and arbitrary scrubbing.
// This is an artistic renderer, not fluid dynamics or a calibrated flame envelope.
function worldGeometry(fixture){
 const modelScale=Math.min(Math.min(1,W/500)*(fixture.bodyScale??state.sceneScale),(W-56)/(106*11+4));
 const margin=Math.max(28,55*modelScale);
 return {ox:margin+fixture.x*Math.max(20,W-margin*2),oy:65+fixture.y*Math.max(40,H-110-66*modelScale),modelScale};
}
function geometry(fixture){
 const world=worldGeometry(fixture),z=viewZoom(),center=state.fitCenter??{x:W/2,y:H-85};
 return {ox:W/2+(world.ox-center.x)*z+state.panX*W,oy:H/2+(world.oy-center.y)*z+state.panY*H,modelScale:world.modelScale*z};
}
function flameRadius(fixture){
 const {oy}=worldGeometry(fixture);
 return Math.min(W*.39,H*.4,Math.max(25,oy-60))*(fixture.bodyScale??state.sceneScale)*viewZoom();
}
function drawFixture(fixture){
 const bank=playbackUI?.bank;
 const bankView=!state.live&&bank?.enabled?bank.view(fixture,state.fixtures,state.selectedIds):null;
 const liveView=state.live?dmxEngine.view(fixture,state.liveTime):bankView;
 const intensity=state.live?1:bankView?.virtualDmx?bankView.intensity:fixture.virtualArmed===false?0:bankView?bankView.intensity:bank?.master(fixture,state.selectedIds)??1;
 const p=liveView?.preset||presets[fixture.presetId-1],isSelected=state.selectedIds.includes(fixture.id),isActive=fixture.id===state.selectedId;
 const chaseActive=layoutChase.running&&!state.live&&!bank?.enabled;
 const time=chaseActive?layoutChase.time:liveView?liveView.time:state.time;
 const sourceSample=chaseActive?t=>layoutChase.sample(fixture,p,fixtureSample,t):liveView?liveView.sample:t=>fixtureSample(fixture,t);
 const sampleAt=t=>{const s=sourceSample(t);return !state.live&&!bankView?.virtualDmx&&fixture.virtualArmed===false?{...s,on:false}:s};
 const {ox,oy,modelScale}=geometry(fixture),R=flameRadius(fixture),scale=(fixture.flameScale??100)/100;
 let sampled=sampleAt(chaseActive?time:Math.min(time,p.duration)),parkedSample=null;
 // Home: a parked head eases to its home angle with emission off until a look, fader or transport resumes it.
 const parked=!state.live&&parkedUnits.get(fixture.id);
 if(parked){
  if(bankView&&bankView.intensity>0&&(bankView.slot!==null||bankView.virtualDmx))parkedUnits.delete(fixture.id);
  else{
   const target=homeAngleFor(fixture),k=clamp((performance.now()/1000-parked.at)/HOME_SECONDS,0,1),ease=k*k*(3-2*k);
   sampled={angle:parked.from+(target-parked.from)*ease,on:false,blocked:false,requestedAngle:target};parkedSample=sampled;
  }
 }
 const s={...sampled,on:sampled.on&&intensity>0},jetSample=parkedSample?()=>parkedSample:sampleAt;
 lastDrawnAngles.set(fixture.id,s.angle);
 const pt=(deg,r)=>[ox+Math.sin(deg*Math.PI/180)*r,oy-Math.cos(deg*Math.PI/180)*r];
 // Mount rotation: the whole unit (body, head sweep, guides and flame) turns about its base point; labels stay upright.
 ctx.save();const mountRotation=(fixture.rotation||0)*Math.PI/180;if(mountRotation){ctx.translate(ox,oy);ctx.rotate(mountRotation);ctx.translate(-ox,-oy)}
 if($('#guides').checked&&isSelected&&isActive){
  for(let deg=-105;deg<=105;deg+=15){const [x,y]=pt(deg,R);line(ox,oy,x,y,deg%45===0?'#b9c7ce20':'#b9c7ce0c');const [tx,ty]=pt(deg,R+18);ctx.fillStyle='#7c898f';ctx.font='12px Satoshi, sans-serif';ctx.textAlign='center';ctx.textBaseline='middle';if(deg%30===0||Math.abs(deg)===105)ctx.fillText(fmt(deg),tx,ty)}
  ctx.beginPath();ctx.arc(ox,oy,R,-195*Math.PI/180,15*Math.PI/180);ctx.strokeStyle='#77889028';ctx.stroke();
  const limits=angleLimits(fixture);
  if(limits.min!==-105||limits.max!==105){
   for(const [label,deg] of [['MIN',limits.min],['MAX',limits.max]]){
    const [x,y]=pt(deg,R);line(ox,oy,x,y,'#ffb17c99',1.5);
    const [tx,ty]=pt(deg,R*.7);ctx.fillStyle='#ffb17c';ctx.font='12px Satoshi,sans-serif';ctx.fillText(`${label} ${fmt(deg)}`,tx,ty);
   }
  }
 }
 if($('#path').checked&&isSelected&&isActive&&p.id!==0){
  const limits=angleLimits(fixture);
  const pp=p.positions.map(pos=>(clamp(angle(fixture.inverted?16-pos:pos),limits.min,limits.max)+105)/15+1);
  if(p.type==='wave'){ctx.beginPath();ctx.arc(ox,oy,R*.87,(angle(Math.min(...pp))-90)*Math.PI/180,(angle(Math.max(...pp))-90)*Math.PI/180);ctx.strokeStyle='#f39a5d55';ctx.setLineDash([3,5]);ctx.stroke();ctx.setLineDash([])}
  pp.forEach((p,i)=>{let[x,y]=pt(angle(p),R*.87);ctx.beginPath();ctx.arc(x,y,3,0,Math.PI*2);ctx.fillStyle='#f3ac7299';ctx.fill();if(pp.length<=5){ctx.fillStyle='#d1a17a';ctx.font='12px Satoshi,sans-serif';ctx.textAlign='center';ctx.fillText(String(i+1),x,y-12)}});
 }
 const profile=flameProfile(liveView?.profile||p);
 const nozzle=fixture.nozzle??'outdoor';
 const tipAngle=s.angle*Math.PI/180;
 const activeParticles=drawFlameJet(ctx,{x:ox+Math.sin(tipAngle)*14*modelScale,y:oy-Math.cos(tipAngle)*14*modelScale,
  length:R*scale,time,sampleAt:jetSample,profile,nozzle,id:fixture.id,intensity,endTime:chaseActive?Infinity:p.duration,
  detail:state.fixtures.length>8?.6:1});
 // Soft floor reflection, not a scale or clearance indicator.
 if(activeParticles){const glow=ctx.createRadialGradient(ox,oy+35,0,ox,oy+35,R*.65);glow.addColorStop(0,`rgba(206,100,43,${Math.min(activeParticles/1000,.10)*intensity})`);glow.addColorStop(1,'rgba(100,40,10,0)');ctx.fillStyle=glow;ctx.fillRect(ox-R,oy-30,R*2,R)}
 ctx.globalAlpha=1;
 const f=modelScale;
 const indicator=fixtureIndicator(fixture);
 drawFlamerBody(ctx,{x:ox,y:oy,scale:f,angle:s.angle,armed:indicator.armed,brightness:indicator.brightness,nozzle,fuelLevel:fuel.ratio(fixture.id)});
 if(s.on&&(chaseActive||time<p.duration)){ctx.globalAlpha=intensity;const tx=ox+Math.sin(tipAngle)*14*modelScale,ty=oy-Math.cos(tipAngle)*14*modelScale;const g=ctx.createRadialGradient(tx,ty,0,tx,ty,8*state.sceneScale);g.addColorStop(0,'#fff8cc');g.addColorStop(.2,'#ffb65e99');g.addColorStop(1,'#ff640000');ctx.fillStyle=g;ctx.fillRect(tx-10,ty-10,20,20);ctx.globalAlpha=1}
 ctx.restore();
 // Labels only draw when neighbouring heads leave room for them; the active unit always shows its label.
 {
  const narrow=W<520,base=fixture.name||`F${String(fixture.id).padStart(2,'0')}`;
  ctx.font=`${narrow?11:12}px Satoshi,sans-serif`;ctx.textAlign='center';
  const full=`${base}${fixture.inverted?' · INV':''}${fixture.rotation?` · ${fixture.rotation}°`:''}`,fullFits=ctx.measureText(full).width<=labelGap-6,baseFits=ctx.measureText(base).width<=labelGap-6;
  ctx.fillStyle=isSelected?'#ffb17c':'#aab5ba';
  if(fullFits||(isActive&&!baseFits))ctx.fillText(full,ox,oy+66*f+15,Math.max(40,Math.min(180,fullFits?labelGap-4:180)));
  else if(baseFits||isActive){ctx.fillText(base,ox,oy+66*f+15,Math.max(40,Math.min(180,labelGap-4)));if(fixture.inverted)ctx.fillText('INV',ox,oy+66*f+15+(narrow?12:13),Math.max(40,labelGap-4))}
 }
 if(isActive){
  $('#virtual-armed').checked=indicator.armed;$('#virtual-armed').disabled=state.live||selectedFixtures().some(f=>bank?.virtualOwns(f))||!state.selectedIds.length;
  $('#virtual-armed').indeterminate=!state.live&&selectedFixtures().some(f=>(f.virtualArmed!==false)!==(fixture.virtualArmed!==false));
  $('#indicator-status').textContent=`${indicator.armed?'ARMED':'DISARMED'} · ${indicator.origin} · indicator ${Math.round(indicator.brightness*100)}%`;
  $('#live-angle').textContent=fmt(s.angle);
  const emitting=s.on&&(chaseActive||time<p.duration);
  $('#emission').textContent=parkedSample?`Homed · parked at ${fmt(homeAngleFor(fixture))}`:s.blocked?'Outside angle limits · no flame':emitting?'Flame emitting':state.live?dmxEngine.record(fixture).status:time>=p.duration?'Flame decay / stage gap':'Head repositioning';
  syncHomeReadout(fixture,!!parkedSample);
  $('#emission-dot').style.background=emitting?'var(--accent)':'var(--muted)';
 }
}
function draw(){
 ctx.setTransform(dpr,0,0,dpr,0,0);ctx.fillStyle='#0d1013';ctx.fillRect(0,0,W,H);
 if(state.snapToGrid){
  const reference=selectedFixture(),a=geometry({...reference,x:0,y:0}),b=geometry({...reference,x:1,y:1});
  // The grid continues across every visible pixel, including outside normalized 0–1.
  for(const [origin,step,extent,vertical]of [[a.ox,(b.ox-a.ox)*GRID_STEP,W,true],[a.oy,(b.oy-a.oy)*GRID_STEP,H,false]]){
   const stride=Math.max(1,Math.ceil(12/Math.max(.00001,Math.abs(step)))),spacing=Math.abs(step)*stride;
   if(spacing<.01)continue;
   const start=Math.floor(-origin/spacing),end=Math.ceil((extent-origin)/spacing);
   for(let i=start;i<=end;i++){const p=origin+i*spacing,color=(i*stride)%5===0?'#ffb17c40':'#ffb17c1c';if(vertical)line(p,0,p,H,color);else line(0,p,W,p,color)}
  }
 }else{
  for(let x=W*.5%40;x<W;x+=40)line(x,55,x,H-50,'#ffffff08');
  for(let y=H*.69%40;y<H-50;y+=40)line(0,y,W,y,'#ffffff08');
 }
 const ordered=[...state.fixtures].sort((a,b)=>a.y-b.y);
 {const xs=state.fixtures.map(f=>geometry(f).ox).sort((a,b)=>a-b);labelGap=Infinity;for(let i=1;i<xs.length;i++)labelGap=Math.min(labelGap,xs[i]-xs[i-1])}
 ordered.forEach(drawFixture);
 followLibrary();
 positionHandles();
 $('#state-label').textContent=state.live?(dmxConnected?`LIVE ${dmxProtocol.toUpperCase()} · VISUAL ONLY`:'LIVE INPUT DISCONNECTED'):playbackUI?.bank.enabled?'FADER PLAYBACK · VISUAL ONLY':timecode.get().chase?'TIMECODE PREVIEW · VISUAL ONLY':state.playing?'PLAYING':'PAUSED';
 const transport=playbackUI?.bank.enabled?playbackUI.transportState():null;
 $('#current-time').textContent=(transport?.time??state.time).toFixed(2);
 $('#end-time').textContent=` / ${(transport?.total??stageDuration()).toFixed(2)} s`;
 $('#scrub').max=transport?.total||stageDuration();$('#scrub').value=transport?.time??state.time;
 $('#timeline-label').textContent=transport?`Cue: ${transport.label}`:`F${String(state.selectedId).padStart(2,'0')} emission`;
 if(transport){$('#loop').checked=transport.loop??$('#loop').checked;syncPlay()}
 drawTimeline();
 fuelUI?.sync();
}
function drawTimeline(){
 const transport=playbackUI?.bank.enabled?playbackUI.transportState():null;
 const w=timeline.width/dpr,h=timeline.height/dpr,total=transport?.total||stageDuration();
 tc.setTransform(dpr,0,0,dpr,0,0);tc.clearRect(0,0,w,h);
 const style=getComputedStyle(document.documentElement),accent=style.getPropertyValue('--accent');
 tc.fillStyle=style.getPropertyValue('--panel2');tc.fillRect(0,5,w,Math.max(1,h-8));
 tc.fillStyle=accent;tc.globalAlpha=.55;
 if(transport)tc.fillRect(0,6,transport.time/total*w,Math.max(1,h-10));
 else for(let x=0;x<w;x++){if(fixtureSample(selectedFixture(),x/w*total).on)tc.fillRect(x,6,1,Math.max(1,h-10))}
 tc.globalAlpha=1;const x=(transport?.time??state.time)/total*w;
 tc.fillStyle=style.getPropertyValue('--ink');tc.fillRect(x-1,2,2,h-2);tc.beginPath();tc.moveTo(x-4,0);tc.lineTo(x+4,0);tc.lineTo(x,5);tc.fill();
}
let last=0;
function animate(now){
 const dt=Math.min((now-last)/1000,.05);last=now;
 syncRate();
 const bank=playbackUI?.bank,bankStart=bank?.time??0,virtualStart=bank?.virtualTime??0;
 if(layoutChase.running&&(state.live||bank?.enabled||document.hidden||timecode.get().chase))stopLayoutChase();
 const chaseStart=layoutChase.time;if(!document.hidden)layoutChase.tick(dt);
 if($('#layout-chase'))$('#layout-chase').disabled=state.live||!state.selectedIds.length;
 const tcState=timecode.get(),chasing=tcState.chase&&!state.live&&!bank?.enabled;
 if(chasing){state.time=((tcState.seconds%stageDuration())+stageDuration())%stageDuration();if(state.playing){state.playing=false;syncPlay()}}
 playbackUI?.tick(dt);
 cueStack?.tick();
 rearPanel?.tick();
 if(state.live){state.liveTime=now/1000;dmxEngine.tick(state.fixtures,state.liveTime);if(now-lastMonitor>100){renderDmxMonitor();lastMonitor=now}}
 if(!document.hidden){
  for(const fixture of state.fixtures){
   if(layoutChase.running){if(fixture.virtualArmed!==false&&(bank?.master(fixture,state.selectedIds)??1)>0)fuel.window(fixture.id,fixture.nozzle,dt,offset=>layoutChase.sample(fixture,presets[fixture.presetId-1],fixtureSample,chaseStart+offset).on);continue}
   const manual=!state.live&&!bank?.enabled;
   if(manual&&(chasing||!state.playing||studioSequencePicker?.isOpen()||fixture.virtualArmed===false))continue;
   if(!manual&&!state.live&&!bank.virtualOwns(fixture)&&(fixture.virtualArmed===false||bank.time===bankStart))continue;
   const start=state.time,speed=state.speed;
   fuel.window(fixture.id,fixture.nozzle,dt,offset=>{
    if(manual)return (bank?.master(fixture,state.selectedIds)??1)>0&&fixtureSample(fixture,start+offset*speed).on;
    let view;
    if(state.live)view=dmxEngine.view(fixture,state.liveTime-dt+offset);
    else if(bank.virtualOwns(fixture)){
     if(bank.virtualTime===virtualStart||bank.grandMaster<=0)return false;
     view=bank.virtualEngine.view(fixture,virtualStart+(bank.virtualTime-virtualStart)*offset/dt);
    }else view=bank.view(fixture,state.fixtures,state.selectedIds,bankStart+(bank.time-bankStart)*offset/dt);
    return (view.intensity??1)>0&&view.time<view.preset.duration&&view.sample(view.time).on;
   },manual?speed:bank?.enabled?Math.max(1,(bank.time-bankStart)/dt):1);
  }
 }
 if(!chasing&&!state.live&&!playbackUI?.bank.enabled&&state.playing&&!document.hidden&&!studioSequencePicker?.isOpen()){
  // The adjustment scales preset motion; the separate 1.10 s decay/gap stays real time.
  const end=stageDuration()-stageGap();
  if(state.time<end){
   const remaining=(end-state.time)/state.speed;
   state.time+=dt<=remaining?dt*state.speed:(end-state.time)+(dt-remaining);
  }else state.time+=dt;
  if(state.time>stageDuration()){
   if($('#tour').checked){
    if(favouritePriority()){
     if(!state.favorites.length){state.playing=false;syncPlay()}
     else{
      const i=state.favorites.indexOf(state.preset.id),id=state.favorites[(i+1)%state.favorites.length];
      (state.selectedIds.length?selectedFixtures():state.fixtures).forEach(f=>f.presetId=id);state.time=0;updateDetails();state.targetTime=favoriteTime(id).duration;$('#speed').value=state.targetTime.toFixed(2);
     }
    }else{state.fixtures.forEach(f=>f.presetId=f.presetId%88+1);state.time=0;updateDetails()}
    followLibrary(true);renderFixtures();sessions?.record('Auto-Next Sequence',true);
   }
   else if($('#loop').checked)state.time%=stageDuration();
   else{state.time=stageDuration();state.playing=false;syncPlay()}
  }
 }
 draw();requestAnimationFrame(animate);
}
$('#play').onclick=()=>{if(favouritePriority()&&!state.favorites.length){announce('Add Favourite Cues Before Playing This List.');return}if(favouritePriority()&&!state.favorites.includes(state.preset.id)){select(state.favorites[0]);return}if(playbackUI.bank.enabled){playbackUI.transport('play');syncPlay();return}if(state.time>=stageDuration())state.time=0;state.playing=!state.playing;if(state.playing)resumeUnits(state.fixtures.map(f=>f.id));syncPlay()};
$('#restart').onclick=()=>{if(favouritePriority()&&!state.favorites.length){announce('Add Favourite Cues Before Playing This List.');return}if(favouritePriority()&&!state.favorites.includes(state.preset.id)){select(state.favorites[0]);return}if(playbackUI.bank.enabled){playbackUI.transport('restart');syncPlay();return}resumeUnits(state.fixtures.map(f=>f.id));state.time=0;state.playing=true;syncPlay()};
function navigateList(action){
 if(state.live)return;
 if(playbackUI.bank.enabled&&!favouritePriority()){playbackUI.transport(action);syncPlay();return}
 const order=favouritePriority()?state.favorites:presets.map(p=>p.id);
 if(!order.length){announce('No Favourite Cues. Add Favourites Before Playing This List.');return}
 const at=order.indexOf(state.preset.id),next=action==='first'?0:action==='last'?order.length-1:(Math.max(0,at)+(action==='prev'?-1:1)+order.length)%order.length;
 select(order[next]);
}
bindCueTransport({buttons:{prev:$('#prev'),next:$('#next'),first:$('#cue-start'),last:$('#cue-end')},onTap:navigateList,onHolding:value=>transportHolding=value,getList:()=>{
 const mobile=$('#mobile-stage-sequences');return mobile?.clientHeight&&mobile.getClientRects().length?mobile:$('#preset-list');
}});
$('#loop').onchange=e=>{if(playbackUI.bank.enabled)playbackUI.transport('loop',e.target.checked)};
$('#tour').addEventListener('change',()=>followLibrary(true));
$('#scrub').oninput=e=>{if(playbackUI.bank.enabled)playbackUI.transport('seek',+e.target.value);else{state.time=+e.target.value;state.playing=false}syncPlay()};
let rateContext='';
function syncRate(){
 const context=state.live?'live':playbackUI?.bank.enabled?`bank:${playbackUI.transportState().cueId??'chase'}:${playbackUI.transportState().presetDuration??''}`:`manual:${state.selectedId}:${state.preset.id}`;
 if(context!==rateContext){state.targetTime=null;rateContext=context;$('#speed').value=state.effectiveTime.toFixed(2)}
 $('#rate-native').textContent=state.nativeTime.toFixed(2);
 $('#rate-minus').disabled=state.effectiveTime<=.01;
 $('#rate-plus').disabled=state.effectiveTime>=10;
}
function setRate(input,commit=false){
 const value=Number(input.value);
 if(input.value.trim()===''||!Number.isFinite(value)||value<.01||value>10){
  input.setAttribute('aria-invalid','true');
  if(commit){input.value=state.effectiveTime.toFixed(2);input.removeAttribute('aria-invalid')}
  return;
 }
 state.targetTime=Math.round(value*100)/100;
 if(commit)input.value=state.effectiveTime.toFixed(2);
 $('#speed').removeAttribute('aria-invalid');
 syncRate();
}
$('#speed').oninput=e=>setRate(e.target);
$('#speed').onchange=e=>setRate(e.target,true);
for(const [id,direction] of [['rate-minus',-1],['rate-plus',1]])$(`#${id}`).onclick=e=>{
 state.targetTime=clamp(Math.round((state.effectiveTime+direction*(e.shiftKey?.1:.01))*100)/100,.01,10);
 $('#speed').value=state.effectiveTime.toFixed(2);$('#speed').removeAttribute('aria-invalid');syncRate();
};
$('#rate-reset').onclick=()=>{state.targetTime=null;$('#speed').value=state.effectiveTime.toFixed(2);syncRate()};
$('#zoom-value').outerHTML='<input id="zoom-value" type="number" min="0" max="250" step="1" value="100" aria-label="Layout Zoom Percent" title="0–250%. Fit View Is 100%. Zero Is A Minimum-Scale Overview.">';
function setZoom(value){
 cancelGesture();state.zoom=clamp(value,0,2.5);
 $('#zoom-value').value=Math.round(state.zoom*100);positionHandles();
 const zr=$('#mobile-zoom-range');if(zr){zr.value=String(Math.round(state.zoom*100));$('#mobile-zoom-output').textContent=`${Math.round(state.zoom*100)}%`}
 syncSpacingControl();
}
function fitFlameView(reset=true){
 if(W<1||H<1)return;
 let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity;
 for(const f of state.fixtures){
  const g=worldGeometry(f),base=Math.min(W*.39,H*.4,Math.max(25,g.oy-60))*(f.bodyScale??state.sceneScale);
  const length=base*(f.flameScale??100)/100*nozzleVisual(f.nozzle??'outdoor').height*FLAME_LENGTH_GAIN;
  const limits=angleLimits(f),positions=outputPositions(f).map(p=>clamp(angle(p),limits.min,limits.max));
  const low=state.live||playbackUI?.bank.enabled?limits.min:Math.min(...positions),high=state.live||playbackUI?.bank.enabled?limits.max:Math.max(...positions);
  // Beta 0.20: phones fit the units themselves (with upward headroom) so every fixture is readable.
  const phone=matchMedia('(max-width:700px)').matches;
  const angles=phone?[0]:[low,high,...[-90,0,90].filter(a=>a>=low&&a<=high)];
  if(phone){minX=Math.min(minX,g.ox-64*g.modelScale);maxX=Math.max(maxX,g.ox+64*g.modelScale);minY=Math.min(minY,g.oy-20*g.modelScale-length*.45);maxY=Math.max(maxY,g.oy+70*g.modelScale+20);continue}
  minX=Math.min(minX,g.ox-60*g.modelScale);maxX=Math.max(maxX,g.ox+60*g.modelScale);
  minY=Math.min(minY,g.oy-20*g.modelScale);maxY=Math.max(maxY,g.oy+70*g.modelScale+20);
  for(const a of angles){const rad=a*Math.PI/180,x=g.ox+Math.sin(rad)*(length*1.07+14*g.modelScale),y=g.oy-Math.cos(rad)*(length*1.07+14*g.modelScale);
   minX=Math.min(minX,x-length*.07);maxX=Math.max(maxX,x+length*.07);minY=Math.min(minY,y-length*.18);maxY=Math.max(maxY,y+length*.08)}
 }
 state.fitScale=Math.max(.00001,Math.min((W-48)/Math.max(1,maxX-minX),(H-70)/Math.max(1,maxY-minY)));
 state.fitCenter={x:(minX+maxX)/2,y:(minY+maxY)/2};
 if(reset){cancelGesture();state.panX=0;state.panY=0;setZoom(1)}
}
$('#fit-view').onclick=()=>fitFlameView();
$('#fit-view').title='Fit All Programmed Flame Envelopes And Units. Set This View To 100%.';
$('#zoom-value').onchange=e=>{const v=Number(e.target.value);if(Number.isFinite(v))setZoom(v/100)};
$('#zoom-out').onclick=()=>setZoom(state.zoom/1.2);
$('#zoom-in').onclick=()=>setZoom(state.zoom?state.zoom*1.2:.01);
$('#viewport').addEventListener('wheel',e=>{
 if(!e.ctrlKey)return;
 e.preventDefault();
 const delta=e.deltaY*(e.deltaMode===1?16:e.deltaMode===2?H:1);
 setZoom((state.zoom||.01)*Math.exp(-clamp(delta,-500,500)*.002));
},{passive:false});
$('#search').oninput=renderList;
for(const tab of ['catalog','favorites']){
 const button=$(`#tab-${tab}`);
 button.onclick=()=>{
  state.libraryTab=tab;state.targetTime=null;$('#search').value='';renderList();
  if(tab==='favorites'){
   if(playbackUI?.bank.enabled)$('#mode-preview').click();
   if(!state.favorites.length){state.playing=false;syncPlay()}
   else if(!state.favorites.includes(state.preset.id))select(state.favorites[0],state.playing);
   else{state.targetTime=favoriteTime(state.preset.id).duration;$('#speed').value=state.targetTime.toFixed(2)}
  }
  favoriteNotice(tab==='favorites'?'Favourites Have Playback Priority. Auto-Next Follows This Order; Drag To Reorder.':'Star Any Sequence To Add It To Favourites.');followLibrary(true);
 };
 button.onkeydown=e=>{
  if(['ArrowLeft','ArrowRight','Home','End'].includes(e.key)){
   e.preventDefault();e.stopPropagation();const next=e.key==='Home'?'catalog':e.key==='End'?'favorites':tab==='catalog'?'favorites':'catalog';$(`#tab-${next}`).click();$(`#tab-${next}`).focus();
  }
 };
}
$('#save-favorite-cue').onclick=()=>{
 if(!state.favorites.length||!state.selectedIds.length||state.live){favoriteNotice('Star a sequence and select at least one virtual fixture first.');return}
 try{remember();favoriteNotice(playbackUI.recordSequence($('#favorite-cue-name').value.trim(),state.favorites,state.favorites.map(favoriteTime)));$('#favorite-cue-name').value=''}catch(e){favoriteNotice(e.message)}
};
document.querySelectorAll('[data-filter]').forEach(b=>b.onclick=()=>{state.filter=b.dataset.filter;document.querySelectorAll('[data-filter]').forEach(x=>x.classList.toggle('active',x===b));renderList()});
let editingFlameScale=false;
$('#size').oninput=e=>{if(!editingFlameScale){remember();editingFlameScale=true}const n=Number(e.target.value);selectedFixtures().forEach(f=>f.flameScale=n);$('#size-output').textContent=n+'%'};
$('#size').onchange=$('#size').onblur=()=>editingFlameScale=false;
$('#theme').onclick=()=>{themeOverridden=true;document.documentElement.dataset.theme=document.documentElement.dataset.theme==='dark'?'light':'dark'};
$('#snapshot').onclick=()=>{draw();canvas.toBlob(blob=>{if(blob)requestFileSave(blob,`wave-studio-${state.fixtures.length}-flamers-${state.time.toFixed(2)}s.png`)},'image/png')};
function setSelection(ids,active){
 if(ids.join(',')!==state.selectedIds.join(','))stopLayoutChase();
 state.selectedIds=[...new Set(ids)].filter(id=>state.fixtures.some(f=>f.id===id));
 if(state.selectedIds.includes(active))state.selectedId=active;
 else if(state.selectedIds.length&&!state.selectedIds.includes(state.selectedId))state.selectedId=state.selectedIds.at(-1);
 playbackUI?.bank.selectGroup(state.selectedIds,state.selectedId);
 updateDetails();followLibrary(true);renderFixtures();
}
function activateFixture(id,toggle=false){
 const ids=toggle?(state.selectedIds.includes(id)?state.selectedIds.filter(x=>x!==id):[...state.selectedIds,id]):[id];
 setSelection(ids,id);announceSelection();
}
function announceSelection(){announce(state.selectedIds.length?`${state.selectedIds.length} selected. Settings apply to all selected units. Faders and flashes use this group on their next operation.`:'No units selected. Click a unit or drag a box on the empty stage.')}
function refreshStage(){state.time=Math.min(state.time,stageDuration());updateDetails();renderList();renderFixtures()}
function positionHandles(){
 state.fixtures.forEach(f=>{
  const b=document.getElementById(`fixture-${f.id}`);if(!b)return;
  const {ox,oy,modelScale}=geometry(f);
  b.style.left=`${ox}px`;b.style.top=`${oy-13*modelScale}px`;
  b.style.width=`${Math.max(48,112*modelScale)}px`;b.style.height=`${Math.max(48,83*modelScale)}px`;
  b.style.zIndex=state.selectedIds.includes(f.id)?(f.id===state.selectedId?'3':'2'):'1';
 });
}
function renderFixtures(){
 state.fixtures.forEach(f=>{if(!validPatch(f.patch))f.patch=nextPatch(state.fixtures)});
 state.selectedIds=state.selectedIds.filter(id=>state.fixtures.some(f=>f.id===id));
 const selected=selectedFixture();
 const hasSelection=state.selectedIds.length>0;
 syncSpacingControl();
 $('#selection-count').textContent=`${state.selectedIds.length} selected`;
 $('#clear-selection').disabled=!hasSelection;
 $('#selection-editor-note').textContent=hasSelection?`Editing ${state.selectedIds.length} selected unit(s). Values shown from F${String(selected.id).padStart(2,'0')}; changing a value applies to the group.`:'No layout selection. Select a unit to edit its settings.';
 for(const id of ['fixture-x','fixture-y','fixture-invert','fixture-min-angle','fixture-max-angle','reset-angle-limits','dmx-universe','dmx-address','dmx-patch'])$(`#${id}`).disabled=!hasSelection;
 $('.library').inert=state.live;
 $('#save-favorite-cue').disabled=!state.favorites.length||!hasSelection||state.live;
 $('#preset-list').querySelectorAll('.preset').forEach(b=>b.disabled=state.live||!hasSelection);
 document.querySelectorAll('[data-stage-preset]').forEach(b=>b.disabled=state.live||!hasSelection);
 $('#fixture-count').textContent=`${state.fixtures.length} / 40`;
 $('#add-fixture').disabled=state.fixtures.length>=40;
 $('#remove-fixture').disabled=state.fixtures.length===1||!hasSelection;
 $('#delete-fixtures').disabled=state.fixtures.length===1||!hasSelection;
 syncRotationControls(hasSelection);
 $('#apply-all').disabled=state.fixtures.length===1||!hasSelection;
 $('#copy-angle-limits').disabled=state.fixtures.length===1||!hasSelection;
 $('#selected-fixture').textContent=fixtureName(selected);
 if($('#fixture-name')){$('#fixture-name').disabled=!hasSelection;if(document.activeElement!==$('#fixture-name'))$('#fixture-name').value=selected.name??''}
 $('#fixture-invert').checked=!!selected.inverted;
 $('#fixture-invert').indeterminate=selectedFixtures().some(f=>!!f.inverted!==!!selected.inverted);
 $('#fixture-nozzle').value=selected.nozzle??'outdoor';$('#fixture-nozzle').disabled=!hasSelection;
 $('#invert-state').textContent=$('#fixture-invert').indeterminate?'MIXED':selected.inverted?'ON':'OFF';
 const mobileInvert=$('#mobile-stage-invert');
 if(mobileInvert){
  mobileInvert.disabled=!hasSelection;
  mobileInvert.setAttribute('aria-pressed',$('#fixture-invert').indeterminate?'mixed':String(!!selected.inverted));
  mobileInvert.title=`Invert selected fixtures: ${$('#invert-state').textContent}`;
 }
 const limits=angleLimits(selected);
 $('#fixture-min-angle').value=limits.min;$('#fixture-max-angle').value=limits.max;
 $('#angle-limit-status').textContent=`${fmt(limits.min)} to ${fmt(limits.max)} · fixed after Invert`;
 $('#fixture-x').value=Math.round(selected.x*100);$('#fixture-y').value=Math.round(selected.y*100);
 $('#stage-scale').value=String(selected.bodyScale??state.sceneScale);$('#stage-scale').disabled=!hasSelection;
 $('#size').value=selected.flameScale??100;$('#size').disabled=!hasSelection;$('#size-output').textContent=`${selected.flameScale??100}%`;
 $('#dmx-universe').value=selected.patch.universe+universeOffset();$('#dmx-address').value=selected.patch.address;
 $('#dmx-patch-status').textContent=patchDescription(selected.patch);
 const strip=$('#fixture-strip'),focusedChip=strip.contains(document.activeElement)?document.activeElement.dataset.fixture:null;
 strip.innerHTML=state.fixtures.map(f=>`<button data-fixture="${f.id}" class="${state.selectedIds.includes(f.id)?'active':''}" aria-pressed="${state.selectedIds.includes(f.id)}">F${String(f.id).padStart(2,'0')} <span>· ${pad(f.presetId)}</span>${f.inverted?' <span class="invert-badge">INV</span>':''}</button>`).join('');
 strip.querySelectorAll('button').forEach(b=>{
  const f=state.fixtures.find(f=>f.id===+b.dataset.fixture);if(f.name){b.textContent=`F${String(f.id).padStart(2,'0')} · ${f.name}`;b.title=fixtureName(f)}
  b.onclick=e=>activateFixture(+b.dataset.fixture,state.selectMultiple||e.ctrlKey||e.metaKey);
  b.onkeydown=e=>{if((e.ctrlKey||e.metaKey)&&['Enter',' '].includes(e.key)){e.preventDefault();e.stopPropagation();activateFixture(+b.dataset.fixture,true)}};
 });
 if(focusedChip)strip.querySelector(`[data-fixture="${focusedChip}"]`)?.focus({preventScroll:true});
 const layer=$('#fixture-handles');
 layer.querySelectorAll('button').forEach(b=>{if(!state.fixtures.some(f=>`fixture-${f.id}`===b.id))b.remove()});
 state.fixtures.forEach(f=>{
  let b=document.getElementById(`fixture-${f.id}`);
  if(!b){
   b=document.createElement('button');b.id=`fixture-${f.id}`;b.className='fixture-handle';b.dataset.fixture=f.id;layer.append(b);
   b.addEventListener('pointerdown',beginDrag);b.addEventListener('pointermove',moveDrag);
   b.addEventListener('pointerup',endDrag);b.addEventListener('pointercancel',cancelDrag);
   b.addEventListener('lostpointercapture',cancelDrag);
   // Pointer selection happens on down/up. Keyboard activation has detail 0.
   b.addEventListener('click',e=>{if(e.detail===0)activateFixture(f.id,state.selectMultiple||e.ctrlKey||e.metaKey)});
   b.addEventListener('keydown',e=>{
    if((e.ctrlKey||e.metaKey)&&['Enter',' '].includes(e.key)){e.preventDefault();e.stopPropagation();activateFixture(f.id,true);return}
    if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key))return;
    e.preventDefault();e.stopPropagation();
    if(state.layoutLocked)return;
    if(!state.selectedIds.includes(f.id))activateFixture(f.id);
    remember();
    const step=state.snapToGrid?(e.shiftKey?.1:GRID_STEP):(e.shiftKey?.05:.01);
    translateSelection(selectionPositions(),e.key==='ArrowLeft'?-step:e.key==='ArrowRight'?step:0,e.key==='ArrowUp'?-step:e.key==='ArrowDown'?step:0);
    renderFixtures();announce(`${state.selectedIds.length} selected unit(s) nudged. Undo restores positions.`);
   });
  }
  b.classList.toggle('selected',state.selectedIds.includes(f.id));
  b.setAttribute('aria-pressed',String(state.selectedIds.includes(f.id)));
  b.setAttribute('aria-label',`${fixtureName(f)}, fixture ${f.id}, preset ${f.presetId}, Invert ${f.inverted?'on':'off'}. Ctrl-click toggles selection. Drag to move the selected group or use arrow keys.`);
 });
 positionHandles();
}
$('#virtual-armed').onchange=e=>{
 const value=e.target.checked;editSelection(f=>f.virtualArmed=value,`simulated ${value?'armed':'disarmed'} state. No hardware changed.`);
};
$('#fixture-nozzle').onchange=e=>{
 const value=e.target.value;editSelection(f=>f.nozzle=value,`${nozzleVisual(value).label} nozzle. Relative visual height only.`);
};
let drag=null,marquee=null,pan=null;
const panSurface=$('#viewport');
panSurface.addEventListener('pointerdown',e=>{
 if(e.button!==1)return;
 e.preventDefault();e.stopPropagation();cancelGesture();
 pan={pointer:e.pointerId,x:e.clientX,y:e.clientY,beforeX:state.panX,beforeY:state.panY};
 panSurface.setPointerCapture(e.pointerId);panSurface.classList.add('is-panning');
},true);
panSurface.addEventListener('mousedown',e=>{if(e.button===1)e.preventDefault()});
panSurface.addEventListener('auxclick',e=>{if(e.button===1)e.preventDefault()});
panSurface.addEventListener('pointermove',e=>{
 if(!pan||e.pointerId!==pan.pointer)return;
 const r=canvas.getBoundingClientRect();
 state.panX=clamp(pan.beforeX+(e.clientX-pan.x)/r.width,-100,100);
 state.panY=clamp(pan.beforeY+(e.clientY-pan.y)/r.height,-100,100);
 positionHandles();
});
function finishPan(e,cancel=false){
 if(!pan||e.pointerId!==pan.pointer)return;
 const done=pan;pan=null;
 if(cancel){state.panX=done.beforeX;state.panY=done.beforeY}
 panSurface.classList.remove('is-panning');
 if(panSurface.hasPointerCapture(done.pointer))panSurface.releasePointerCapture(done.pointer);
 positionHandles();announce(cancel?'View pan cancelled.':'View panned. Fixture positions unchanged; Fit view recenters.');
}
panSurface.addEventListener('pointerup',e=>finishPan(e));
panSurface.addEventListener('pointercancel',e=>finishPan(e,true));
panSurface.addEventListener('lostpointercapture',e=>finishPan(e,true));
const selectionPositions=()=>state.fixtures.filter(f=>state.selectedIds.includes(f.id)).map(({id,x,y})=>({id,x,y}));
function applyPositions(positions){
 for(const p of positions){const f=state.fixtures.find(f=>f.id===p.id);if(f){f.x=p.x;f.y=p.y}}
}
function translateSelection(starts,dx,dy,snap=state.snapToGrid){
 if(state.layoutLocked)return;
 applyPositions(groupTranslation(starts,dx,dy,{snap,anchorId:state.selectedId,unbounded:true}));
}
function syncSpacingControl(){
 const starts=selectionPositions(),info=spacingInfo(starts),slider=$('#layout-spacing');
 slider.disabled=starts.length<2||state.layoutLocked;
 $('#arrange').disabled=state.layoutLocked;
 syncRotationControls(state.selectedIds.length>0);
 for(const axis of ['x','y'])$(`#fixture-${axis}`).disabled=state.layoutLocked;
 if(!spacingEdit){
  slider.max='250';
  slider.value=String(Math.round(info.span/visibleSpacingSpan()*10000)/100);
 }
 $('#spacing-value').textContent=starts.length>1?`${(info.span/visibleSpacingSpan()*100).toFixed(1)}% View`:'Select 2+';
 slider.setAttribute('aria-valuetext',starts.length>1?`${(info.span/(starts.length-1)*100).toFixed(1)} percent horizontal gap, ${starts.length} selected`:'Select at least two units');
}
function visibleSpacingSpan(){
 const fixture=selectedFixture()??state.fixtures[0];
 const {modelScale}=worldGeometry(fixture),margin=Math.max(28,55*modelScale);
 return Math.min(40,Math.max(.01,(W-56)/Math.max(20,W-2*margin)/viewZoom()));
}
function beginSpacing(){
 if(spacingEdit||$('#layout-spacing').disabled)return;
 cancelGesture();
 spacingEdit={starts:selectionPositions(),snapshot:null,visibleSpan:visibleSpacingSpan()};
}
function finishSpacing(cancel=false){
 if(!spacingEdit)return;
 const edit=spacingEdit;spacingEdit=null;
 if(cancel){
  applyPositions(edit.starts);
  if(edit.snapshot&&history.at(-1)===edit.snapshot)history.pop();
  $('#undo-layout').disabled=!history.length;
 }
 renderFixtures();
 if(edit.snapshot)announce(cancel?'Spacing cancelled. Original positions restored.':`${edit.starts.length} units spaced evenly from left to right. Heights unchanged; Undo restores positions.`);
}
$('#layout-spacing').onpointerdown=beginSpacing;
$('#layout-spacing').oninput=e=>{
 beginSpacing();if(!spacingEdit)return;
 const next=evenSpacing(spacingEdit.starts,Number(e.target.value)/100*spacingEdit.visibleSpan,{snap:state.snapToGrid,unbounded:true,maxSpan:2.5*spacingEdit.visibleSpan});
 const changed=next.some(p=>Math.abs(state.fixtures.find(f=>f.id===p.id).x-p.x)>1e-9);
 if(changed&&!spacingEdit.snapshot)spacingEdit.snapshot=remember();
 applyPositions(next);positionHandles();
 $('#fixture-x').value=Math.round(selectedFixture().x*100);
 syncSpacingControl();
};
$('#layout-spacing').onchange=()=>finishSpacing();
$('#layout-spacing').onblur=()=>finishSpacing();
$('#layout-spacing').onpointercancel=()=>finishSpacing(true);
window.addEventListener('pointerup',()=>finishSpacing());
$('#snap-grid').onclick=()=>{
 cancelGesture();state.snapToGrid=!state.snapToGrid;
 $('#snap-grid').setAttribute('aria-pressed',String(state.snapToGrid));
 announce(state.snapToGrid?'Snap to grid on: 5% layout steps. Drag the active unit to align the group; spacing is preserved.':'Snap to grid off. Free placement restored.');
};
const lockButton=document.createElement('button');lockButton.id='layout-lock';lockButton.type='button';$('#snap-grid').after(lockButton);
function syncLock(){lockButton.textContent=state.layoutLocked?'Locked':'Unlocked';lockButton.setAttribute('aria-pressed',String(state.layoutLocked));lockButton.title='Lock Or Unlock Fixture Positions';syncSpacingControl()}
lockButton.onclick=()=>{cancelGesture();state.layoutLocked=!state.layoutLocked;syncLock();announce(state.layoutLocked?'Layout locked. Selection and playback remain available.':'Layout unlocked. Drag units freely or edit X / Y.');};
syncLock();
const multipleButton=document.createElement('button');multipleButton.id='select-multiple';multipleButton.type='button';multipleButton.textContent='Select Multiple';lockButton.after(multipleButton);
const compactLayoutMedia=matchMedia('(max-width:700px)');
function compactLayoutLabels(){multipleButton.textContent=compactLayoutMedia.matches?'Multi-Select':'Select Multiple';$('#arrange').textContent=compactLayoutMedia.matches?'Arrange':'Arrange Row'}
compactLayoutLabels();compactLayoutMedia.addEventListener('change',compactLayoutLabels);
new ResizeObserver(entries=>{const width=entries[0].contentRect.width;$('.zoom-controls').style.setProperty('--layout-row-font',`${Math.min(10.5,Math.max(6,width/34))}px`)}).observe($('.zoom-controls'));
function syncMultiple(){multipleButton.setAttribute('aria-pressed',String(state.selectMultiple));multipleButton.title=state.selectMultiple?'Tap Units To Add Or Remove Them. Turn Off To Move Units.':'Select Multiple Units Without Ctrl Or Command';}
multipleButton.onclick=()=>{cancelGesture();state.selectMultiple=!state.selectMultiple;syncMultiple();announce(state.selectMultiple?'Select Multiple On. Tap units to add or remove them; drag empty stage to toggle a group.':'Select Multiple Off. Tap one unit or drag to place the selected group.')};
syncMultiple();
function syncLayoutPinned(){
 document.body.dataset.layoutPinned=String(state.layoutPinned);
 $('#layout-screen-mode').value=state.layoutPinned?'pinned':'scroll';
 syncStageScrollPadding();
}
$('#layout-screen-mode').onchange=e=>{cancelGesture();state.layoutPinned=e.target.value==='pinned';syncLayoutPinned();announce(state.layoutPinned?'Layout screen stays visible while you scroll.':'Layout screen scrolls with the page.')};
syncLayoutPinned();
function beginDrag(e){
 if(e.button!==0||drag||marquee)return;
 e.preventDefault();e.stopPropagation();
 const id=+e.currentTarget.dataset.fixture;
 e.currentTarget.focus({preventScroll:true});
 if(state.selectMultiple||e.ctrlKey||e.metaKey){activateFixture(id,true);return}
 if(!state.selectedIds.includes(id))activateFixture(id);
 else setSelection(state.selectedIds,id);
 if(state.layoutLocked)return;
 drag={id,pointer:e.pointerId,target:e.currentTarget,startX:e.clientX,startY:e.clientY,starts:selectionPositions(),moved:false,snapshot:null};
 e.currentTarget.setPointerCapture(e.pointerId);
}
function moveDrag(e){
 if(!drag||e.pointerId!==drag.pointer)return;
 const px=e.clientX-drag.startX,py=e.clientY-drag.startY;
 if(!drag.moved&&Math.hypot(px,py)<4)return;
 if(!drag.moved){drag.snapshot=remember();drag.moved=true;drag.target.classList.add('dragging')}
 const {modelScale}=worldGeometry(selectedFixture()),margin=Math.max(28,55*modelScale),r=canvas.getBoundingClientRect();
 translateSelection(drag.starts,px*W/r.width/Math.max(20,W-2*margin)/viewZoom(),py*H/r.height/Math.max(40,H-110-66*modelScale)/viewZoom());
 $('#fixture-x').value=Math.round(selectedFixture().x*100);$('#fixture-y').value=Math.round(selectedFixture().y*100);positionHandles();
 announce(`Moving ${drag.starts.length} selected unit(s). Release to place. Esc cancels.`);
}
function endDrag(e){
 if(!drag||e.pointerId!==drag.pointer)return;
 const finished=drag;drag=null;finished.target.classList.remove('dragging');
 if(finished.target.hasPointerCapture(finished.pointer))finished.target.releasePointerCapture(finished.pointer);
 if(!finished.moved)activateFixture(finished.id);
 else{renderFixtures();announce(`${finished.starts.length} unit(s) placed. Spacing preserved. Undo restores the group move.`)}
}
function cancelDrag(e){
 if(!drag||e.pointerId!==drag.pointer)return;
 const cancelled=drag;drag=null;applyPositions(cancelled.starts);
 if(cancelled.snapshot&&history.at(-1)===cancelled.snapshot)history.pop();
 $('#undo-layout').disabled=!history.length;cancelled.target.classList.remove('dragging');
 if(cancelled.target.hasPointerCapture(cancelled.pointer))cancelled.target.releasePointerCapture(cancelled.pointer);
 renderFixtures();announce('Drag cancelled; original group positions restored.');
}
const marqueeBox=$('#selection-box');
function stagePoint(e){const r=canvas.getBoundingClientRect();return{x:clamp((e.clientX-r.left)*W/r.width,0,W),y:clamp((e.clientY-r.top)*H/r.height,0,H)}}
canvas.addEventListener('pointerdown',e=>{
 if(e.button!==0||drag||marquee)return;
 e.preventDefault();
 marquee={pointer:e.pointerId,start:stagePoint(e),before:[...state.selectedIds],active:state.selectedId,toggle:state.selectMultiple||e.ctrlKey||e.metaKey,moved:false};
 canvas.setPointerCapture(e.pointerId);
});
canvas.addEventListener('pointermove',e=>{
 if(!marquee||e.pointerId!==marquee.pointer)return;
 const p=stagePoint(e),s=marquee.start;
 if(!marquee.moved&&Math.hypot(p.x-s.x,p.y-s.y)<4)return;
 marquee.moved=true;
 const left=Math.min(p.x,s.x),top=Math.min(p.y,s.y),right=Math.max(p.x,s.x),bottom=Math.max(p.y,s.y);
 Object.assign(marqueeBox.style,{left:`${left}px`,top:`${top}px`,width:`${right-left}px`,height:`${bottom-top}px`});marqueeBox.hidden=false;
 const hits=state.fixtures.filter(f=>{const g=geometry(f),hw=Math.max(48,112*g.modelScale)/2,y=g.oy-13*g.modelScale,h=Math.max(48,83*g.modelScale);return g.ox+hw>=left&&g.ox-hw<=right&&y+h>=top&&y<=bottom}).map(f=>f.id);
 const ids=marquee.toggle?[...marquee.before.filter(id=>!hits.includes(id)),...hits.filter(id=>!marquee.before.includes(id))]:hits;
 setSelection(ids);announceSelection();
});
function finishMarquee(e,cancel=false){
 if(!marquee||e.pointerId!==marquee.pointer)return;
 const done=marquee;marquee=null;marqueeBox.hidden=true;
 if(canvas.hasPointerCapture(done.pointer))canvas.releasePointerCapture(done.pointer);
 if(cancel)setSelection(done.before,done.active);
 else if(!done.moved&&!done.toggle)setSelection([]);
 announceSelection();
}
canvas.addEventListener('pointerup',e=>finishMarquee(e));
canvas.addEventListener('pointercancel',e=>finishMarquee(e,true));
canvas.addEventListener('lostpointercapture',e=>finishMarquee(e,true));
// Beta 0.20: drag across the Unit List to select several fixtures (Ctrl/Cmd or Multi-Select adds/toggles).
{
 const strip=$('#fixture-strip');let chipDrag=null,swallowClick=false;
 const box=document.createElement('div');box.className='strip-select-box';box.hidden=true;document.body.append(box);
 strip.addEventListener('pointerdown',e=>{
  if(e.button!==0||e.pointerType==='touch'||drag||marquee)return;
  chipDrag={pointer:e.pointerId,x:e.clientX,y:e.clientY,before:[...state.selectedIds],active:state.selectedId,toggle:state.selectMultiple||e.ctrlKey||e.metaKey,moved:false};
 });
 strip.addEventListener('pointermove',e=>{
  if(!chipDrag||e.pointerId!==chipDrag.pointer)return;
  if(!chipDrag.moved){if(Math.hypot(e.clientX-chipDrag.x,e.clientY-chipDrag.y)<6)return;chipDrag.moved=true;strip.setPointerCapture(e.pointerId);strip.classList.add('strip-selecting')}
  e.preventDefault();
  const left=Math.min(e.clientX,chipDrag.x),right=Math.max(e.clientX,chipDrag.x),top=Math.min(e.clientY,chipDrag.y),bottom=Math.max(e.clientY,chipDrag.y);
  Object.assign(box.style,{left:`${left}px`,top:`${top}px`,width:`${right-left}px`,height:`${Math.max(2,bottom-top)}px`});box.hidden=false;
  const hits=[...strip.querySelectorAll('button[data-fixture]')].filter(b=>{const r=b.getBoundingClientRect();return r.right>=left&&r.left<=right&&r.bottom>=top&&r.top<=bottom}).map(b=>+b.dataset.fixture);
  const ids=chipDrag.toggle?[...chipDrag.before.filter(id=>!hits.includes(id)),...hits.filter(id=>!chipDrag.before.includes(id))]:hits;
  if(ids.join(',')!==state.selectedIds.join(','))setSelection(ids,hits.at(-1));
  // Keep a horizontally scrolling list moving while dragging near its edges.
  const r=strip.getBoundingClientRect();if(e.clientX>r.right-24)strip.scrollLeft+=12;else if(e.clientX<r.left+24)strip.scrollLeft-=12;
 });
 const finish=(e,cancel=false)=>{
  if(!chipDrag||(e.pointerId!==undefined&&e.pointerId!==chipDrag.pointer))return;
  const done=chipDrag;chipDrag=null;box.hidden=true;strip.classList.remove('strip-selecting');
  if(strip.hasPointerCapture?.(done.pointer))strip.releasePointerCapture(done.pointer);
  if(!done.moved)return;
  swallowClick=true;setTimeout(()=>swallowClick=false,0);
  if(cancel)setSelection(done.before,done.active);
  announceSelection();
 };
 strip.addEventListener('pointerup',e=>finish(e));
 strip.addEventListener('pointercancel',e=>finish(e,true));
 strip.addEventListener('click',e=>{if(swallowClick){e.preventDefault();e.stopPropagation();swallowClick=false}},true);
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&chipDrag?.moved){e.preventDefault();finish({pointerId:chipDrag.pointer},true)}});
}
function cancelGesture(){if(drag)cancelDrag({pointerId:drag.pointer});if(marquee)finishMarquee({pointerId:marquee.pointer},true);if(pan)finishPan({pointerId:pan.pointer},true);if(spacingEdit)finishSpacing(true)}
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&(drag||marquee||pan||spacingEdit)){e.preventDefault();cancelGesture()}});
window.addEventListener('blur',cancelGesture);
$('#select-all-fixtures').onclick=()=>{setSelection(state.fixtures.map(f=>f.id));announceSelection()};
$('#clear-selection').onclick=()=>{setSelection([]);announceSelection()};
$('#add-fixture').onclick=()=>{
 if(state.fixtures.length>=40)return;
 stopLayoutChase();cancelGesture();
 remember();
 const f=selectedFixture();
 const newFixture={id:state.nextId++,presetId:f.presetId,inverted:false,nozzle:f.nozzle??'outdoor',flameScale:f.flameScale??100,bodyScale:f.bodyScale??state.sceneScale,minAngle:-105,maxAngle:105,patch:nextPatch(state.fixtures),...nextFixturePosition(state.fixtures)};
 state.fixtures.push(newFixture);state.selectedId=newFixture.id;state.selectedIds=[newFixture.id];
 fuel.reset(newFixture.id);
 refreshStage();announce(`Flamer ${newFixture.id} added. Existing fixture positions and scale are unchanged. Undo restores the previous layout.`);
};
function arrangeFixtureRow(){
 const n=state.fixtures.length,{modelScale}=worldGeometry(state.fixtures[0]);
 const margin=Math.max(28,55*modelScale),step=212*modelScale/(W-2*margin);
 state.fixtures.forEach((f,i)=>{f.x=.5+(i-(n-1)/2)*step;f.y=.75});
}
function deleteSelectedFixtures(){
 stopLayoutChase();
 if(!state.selectedIds.length||state.fixtures.length===1)return;
 cancelGesture();
 const ids=state.selectedIds.filter(id=>state.fixtures.some(f=>f.id===id));
 const retaining=ids.length===state.fixtures.length;
 if(retaining)ids.splice(ids.indexOf(state.selectedId),1);
 if(!ids.length)return;
 remember();ids.forEach(id=>dmxEngine.reset(id));
 state.fixtures=state.fixtures.filter(f=>!ids.includes(f.id));
 state.selectedId=state.fixtures.some(f=>f.id===state.selectedId)?state.selectedId:state.fixtures.at(-1).id;
 state.selectedIds=[state.selectedId];refreshStage();
 announce(`${ids.length} fixture(s) deleted. ${retaining?'Kept the active unit: at least one fixture is required. ':''}Undo restores the group.`);
}
$('#delete-fixtures').onclick=deleteSelectedFixtures;
// Mount rotation: selected units turn together in 5° steps through a full 360°. Hold a button to keep turning.
const ROTATE_STEP=5;
function rotationOf(f){return f.rotation||0}
function syncRotationControls(hasSelection){
 const rots=selectedFixtures().map(rotationOf),mixed=rots.some(r=>r!==rots[0]);
 const off=!hasSelection||state.layoutLocked;
 for(const readout of document.querySelectorAll('.rotate-readout')){
  readout.textContent=hasSelection?(mixed?'MIXED':`${rots[0]}°`):'—';
  readout.title=hasSelection?(mixed?'Selected units have different rotations. Click to reset all to 0°.':`Rotation ${rots[0]}°. Click to reset to 0°.`):'Select a unit to rotate it';
  readout.setAttribute('aria-label',(hasSelection?(mixed?'Reset rotation (mixed)':`Reset rotation (${rots[0]}°)`):'Reset rotation')+(readout.id.startsWith('layout-')?' · Layout Controls':''));
  readout.disabled=off||(!mixed&&!rots[0]);
 }
 for(const b of document.querySelectorAll('[data-rotate]'))b.disabled=off;
}
function resetRotation(){const fixtures=selectedFixtures();if(!fixtures.length||state.layoutLocked)return;remember();fixtures.forEach(f=>{delete f.rotation});updateDetails();renderFixtures();announce(`${fixtures.length} selected unit(s) rotation reset to 0°.`)}
// Build a rotate control trio (⟲ 5° · readout · 5° ⟳); the Layout panel carries a second set wired to the same actions.
function makeRotateControls(prefix){
 const suffix=prefix?' · Layout Controls':'';
 const group=document.createElement('span');group.className='rotate-tools';group.setAttribute('role','group');group.setAttribute('aria-label','Rotate selected fixtures');
 const ccw=document.createElement('button');ccw.type='button';ccw.id=`${prefix}rotate-ccw`;ccw.dataset.rotate='ccw';ccw.disabled=true;ccw.title='Rotate selected 5° counter-clockwise ([ key). Hold to keep turning.';ccw.setAttribute('aria-label','Rotate selected −5°'+suffix);ccw.innerHTML='<span aria-hidden="true">⟲</span> 5°';
 const readout=document.createElement('button');readout.type='button';readout.id=`${prefix}rotate-readout`;readout.className='rotate-readout';readout.disabled=true;readout.setAttribute('aria-label','Reset rotation');readout.textContent='—';
 const cw=document.createElement('button');cw.type='button';cw.id=`${prefix}rotate-cw`;cw.dataset.rotate='cw';cw.disabled=true;cw.title='Rotate selected 5° clockwise (] key). Hold to keep turning.';cw.setAttribute('aria-label','Rotate selected +5°'+suffix);cw.innerHTML='5° <span aria-hidden="true">⟳</span>';
 group.append(ccw,readout,cw);
 holdToRotate(ccw,-ROTATE_STEP);holdToRotate(cw,ROTATE_STEP);readout.onclick=resetRotation;
 return group;
}
function rotateSelection(delta,snapshot=true){
 const fixtures=selectedFixtures();if(!fixtures.length||state.layoutLocked)return false;
 if(snapshot)remember();
 fixtures.forEach(f=>{const next=(((rotationOf(f)+delta)%360)+360)%360;if(next)f.rotation=next;else delete f.rotation});
 updateDetails();renderFixtures();return true;
}
function announceRotation(){
 const rots=selectedFixtures().map(rotationOf);if(!rots.length)return;
 const mixed=rots.some(r=>r!==rots[0]);
 announce(`${rots.length} selected unit(s) rotated${mixed?' (different rotations)':` to ${rots[0]}°`}. Undo restores the previous rotation.`);
}
function holdToRotate(button,delta){
 let timer=0,ticker=0,active=false,pointerAt=-1e9;
 const stop=()=>{clearTimeout(timer);clearInterval(ticker);if(active){active=false;announceRotation()}};
 button.addEventListener('pointerdown',e=>{if(e.button!==0||button.disabled)return;e.preventDefault();pointerAt=performance.now();active=rotateSelection(delta,true);timer=setTimeout(()=>{ticker=setInterval(()=>{if(!rotateSelection(delta,false))stop()},90)},450)});
 for(const type of ['pointerup','pointerleave','pointercancel'])button.addEventListener(type,stop);
 button.addEventListener('click',()=>{if(performance.now()-pointerAt<1500||button.disabled)return;if(rotateSelection(delta,true))announceRotation()});
}
$('#rotate-tools-slot').replaceWith(makeRotateControls(''));
document.addEventListener('keydown',e=>{
 if(!['[',']'].includes(e.key)||e.ctrlKey||e.metaKey||e.altKey||document.querySelector('dialog[open]')||e.target.closest?.('input,textarea,select,[contenteditable="true"]'))return;
 if(rotateSelection(e.key===']'?ROTATE_STEP:-ROTATE_STEP,!e.repeat)){e.preventDefault();if(!e.repeat)announceRotation()}
});
document.addEventListener('keydown',e=>{
 if(e.key!=='Delete'||e.repeat||e.ctrlKey||e.metaKey||e.altKey||document.querySelector('dialog[open]')||e.target.closest?.('input,textarea,select,[contenteditable="true"]'))return;
 e.preventDefault();deleteSelectedFixtures();
});
$('#remove-fixture').onclick=deleteSelectedFixtures;
$('#arrange').onclick=()=>{
 if(state.layoutLocked)return;
 remember();arrangeFixtureRow();
 fitFlameView(false);
 renderFixtures();announce('Fixtures arranged in a row. Drag any fixture to fine-tune.');
};
$('#undo-layout').onclick=()=>{
 const previous=history.pop();if(!previous)return;
 const {playback,fuelBeforeLoad,preferences,...layout}=previous;Object.assign(state,layout);
 if(preferences)applyPreferences(preferences);
 syncLock();
 if(fuelBeforeLoad)fuel.restore(fuelBeforeLoad,state.fixtures);
 if(playback&&JSON.stringify(playback)!==JSON.stringify(playbackUI.serialize()))playbackUI.restore(playback);
 dmxEngine.clear();$('#undo-layout').disabled=!history.length;refreshStage();announce('Last layout or preset change undone. Live triggers must be reset.');
};
$('#apply-all').onclick=()=>{
 remember();const id=state.preset.id;resumeUnits(state.fixtures.map(f=>f.id));state.fixtures.forEach(f=>f.presetId=id);state.time=0;refreshStage();announce(`Preset ${pad(id)} applied to all ${state.fixtures.length} flamers.`);
};
$('#fixture-invert').onchange=e=>{
 const value=e.target.checked;editSelection(f=>f.inverted=value,`Invert ${value?'on':'off'}. Playback timing unchanged.`);
};
$('#stage-scale').onchange=e=>{const value=+e.target.value;editSelection(f=>f.bodyScale=value,'fixture scale updated.')};
for(const edge of ['min','max']){
 const input=$(`#fixture-${edge}-angle`);
 input.innerHTML=Array.from({length:15},(_,i)=>{const a=(i-7)*15;return `<option value="${a}">${fmt(a)} · Pos ${i+1}</option>`}).join('');
 input.onchange=()=>{
  const value=Number(input.value),invalid=selectedFixtures().some(f=>{const next={...angleLimits(f),[edge]:value};return next.min>next.max});
  if(invalid){renderFixtures();announce('Minimum angle would exceed maximum on a selected unit. No settings changed.');return;}
  editSelection(f=>f[edge==='min'?'minAngle':'maxAngle']=value,`${edge} angle set to ${fmt(value)}.`);
 };
}
$('#reset-angle-limits').onclick=()=>{
 editSelection(f=>Object.assign(f,{minAngle:-105,maxAngle:105}),'angle limits reset to full range.');
};
$('#copy-angle-limits').onclick=()=>{
 if(state.fixtures.length<2)return;
 const source=selectedFixture(),{min,max}=angleLimits(source);
 remember();
 state.fixtures.forEach(f=>{f.minAngle=min;f.maxAngle=max});
 updateDetails();renderFixtures();
 announce(`Copied Flamer ${String(source.id).padStart(2,'0')} angle limits (${fmt(min)} to ${fmt(max)}) to all ${state.fixtures.length} units. Other settings unchanged. Undo restores previous limits.`);
};
for(const axis of ['x','y'])$(`#fixture-${axis}`).onchange=e=>{
 if(state.layoutLocked)return;
 const n=Number(e.target.value);
 if(e.target.value===''||!Number.isFinite(n)){renderFixtures();return}
 remember();const delta=clamp(n/100,-100,100)-selectedFixture()[axis];translateSelection(selectionPositions(),axis==='x'?delta:0,axis==='y'?delta:0);renderFixtures();announce('Selected group position updated; spacing preserved.');
};
function capturePreferences(){
 return {recording:stageRecorder?.serialize()??{...recordingDefaults},theme:document.documentElement.dataset.theme??'light',layoutChase:{bpm:layoutChase.bpm,direction:layoutChase.direction},snap:state.snapToGrid,selectMultiple:state.selectMultiple,layoutPinned:state.layoutPinned,workspace:workspaceUI?.serialize()??freshWorkspace(),loop:$('#loop').checked,autoNext:$('#tour').checked,guides:$('#guides').checked,path:$('#path').checked,macroKeys:$('#macro-keys').checked,mobileFaders:state.mobileFaders??6,masterVisible:state.masterVisible??true,targetTime:state.targetTime,libraryTab:state.libraryTab,filter:state.filter,autosave:sessions?.getPreferences()??{enabled:true,minutes:5}};
}
function validatePreferences(p){
 if(p===undefined)return null;
 if(!p||!['dark','light'].includes(p.theme)||!['catalog','favorites'].includes(p.libraryTab)||!['all','single','step','wave'].includes(p.filter))throw Error('Invalid preferences.');
 for(const k of ['snap','loop','autoNext','guides','path','macroKeys'])if(typeof p[k]!=='boolean')throw Error('Invalid preference flag.');
 if(!Number.isInteger(p.mobileFaders)||p.mobileFaders<1||p.mobileFaders>20||(p.targetTime!==null&&(!Number.isFinite(p.targetTime)||p.targetTime<.01||p.targetTime>10))||typeof p.autosave?.enabled!=='boolean'||!Number.isFinite(p.autosave.minutes)||p.autosave.minutes<.1||p.autosave.minutes>1440)throw Error('Invalid preference value.');
 for(const k of ['selectMultiple','layoutPinned'])if(p[k]!==undefined&&typeof p[k]!=='boolean')throw Error('Invalid layout screen preference.');
 if(p.masterVisible!==undefined&&typeof p.masterVisible!=='boolean')throw Error('Invalid master visibility.');
 if(p.layoutChase){const test=new LayoutChase();test.setRate(p.layoutChase.bpm);test.setDirection(p.layoutChase.direction)}
 return {...Object.fromEntries(['theme','snap','loop','autoNext','guides','path','macroKeys','mobileFaders','targetTime','libraryTab','filter','autosave'].map(k=>[k,structuredClone(p[k])])),recording:validateRecording(p.recording),layoutChase:p.layoutChase??{bpm:120,direction:'forward'},masterVisible:p.masterVisible??!matchMedia('(max-width:700px)').matches,selectMultiple:p.selectMultiple??false,layoutPinned:p.layoutPinned??true,workspace:validateWorkspace(p.workspace)};
}
function applyPreferences(p){
 stageRecorder?.restore(p.recording);
 stopLayoutChase();layoutChase.setRate(p.layoutChase?.bpm??120);layoutChase.setDirection(p.layoutChase?.direction??'forward');syncLayoutChase();
 themeOverridden=true;document.documentElement.dataset.theme=p.theme;
 state.snapToGrid=p.snap;$('#snap-grid').setAttribute('aria-pressed',String(p.snap));
 state.selectMultiple=p.selectMultiple;state.layoutPinned=p.layoutPinned;syncMultiple();syncLayoutPinned();
 workspaceUI?.restore(p.workspace);
 for(const [key,id] of [['loop','loop'],['autoNext','tour'],['guides','guides'],['path','path'],['macroKeys','macro-keys']])$(`#${id}`).checked=p[key];
 state.libraryTab=p.libraryTab;state.filter=p.filter;state.targetTime=p.targetTime;state.mobileFaders=p.mobileFaders;
 document.querySelectorAll('[data-filter]').forEach(b=>b.classList.toggle('active',b.dataset.filter===state.filter));
 document.dispatchEvent(new CustomEvent('wave-mobile-faders',{detail:p.mobileFaders}));sessions?.restorePreferences(p.autosave);
 document.dispatchEvent(new CustomEvent('wave-master-visible',{detail:p.masterVisible}));
}
function exportLayout(){
 return {format:'wave-studio-layout',version:5,fixtures:structuredClone(state.fixtures),fuel:fuel.serialize(state.fixtures),selectedId:state.selectedId,selectedIds:[...state.selectedIds],layoutLocked:state.layoutLocked,sceneScale:state.sceneScale,view:{zoom:state.zoom,panX:state.panX,panY:state.panY},favorites:[...state.favorites],favoriteTiming:structuredClone(state.favoriteTiming),playback:playbackUI.serialize(),preferences:capturePreferences()};
}
mountSaveOptions({button:$('#save-layout'),capture:exportLayout,onSaved:result=>announce(result.message+' Load Layout Can Open This File Without Replacing Unchecked Sections.')});
const consoleCapture=()=>({fixtures:structuredClone(state.fixtures),playback:playbackUI.serialize()});
const vistaExport=mountVistaExport({after:$('#load-layout'),capture:consoleCapture,version:BUILD_VERSION,announce});
mountGrandMAExport({after:vistaExport.button,capture:consoleCapture,version:BUILD_VERSION,announce});
const resetLayoutButton=document.createElement('button');resetLayoutButton.id='reset-layout';resetLayoutButton.type='button';resetLayoutButton.textContent='Reset Layout';$('#load-layout').after(resetLayoutButton);
const defaultLayoutButton=document.createElement('button');defaultLayoutButton.id='default-layout';defaultLayoutButton.textContent='Default Layout';resetLayoutButton.before(defaultLayoutButton);
defaultLayoutButton.type='button';
defaultLayoutButton.title='Save The Current Fixture Layout As Your Reset Default';
const defaultQuick=document.createElement('div');defaultQuick.className='layout-quick-defaults';defaultQuick.innerHTML='<button type="button" id="stage-default-layout">New Default Layout</button><button type="button" id="stage-load-default-layout">Load Default Layout</button><button type="button" id="stage-reset-layout">Reset Layout</button><output id="default-layout-status" role="status"></output>';$('.layout-tools .view-actions').append(defaultQuick);
const chaseControls=document.createElement('span');chaseControls.className='layout-chase-controls';
chaseControls.innerHTML='<button type="button" id="layout-chase" aria-pressed="false" title="Virtual Chase Of Selected Units. Switches To Presets. 0 BPM Pauses. No Hardware Output.">Chase</button><span class="chase-rate"><button type="button" id="chase-slower" aria-label="Decrease Chase BPM">−</button><input id="layout-chase-bpm" type="number" min="0" max="480" step="1" value="120" aria-label="Layout Chase BPM"><span>BPM</span><button type="button" id="chase-faster" aria-label="Increase Chase BPM">+</button></span><span class="chase-directions" role="group" aria-label="Chase Direction"><label><input type="checkbox" data-layout-direction="forward" checked>Forward</label><label><input type="checkbox" data-layout-direction="backward">Backward</label><label><input type="checkbox" data-layout-direction="random">Random</label></span><button type="button" id="select-odd-even" title="Select Odd Fixture IDs, Then Even Fixture IDs">Odd / Even</button>';
$('#stage-reset-layout').after(chaseControls);
function syncLayoutChase(){if(!$('#layout-chase-bpm'))return;$('#layout-chase-bpm').value=layoutChase.bpm;document.querySelectorAll('[data-layout-direction]').forEach(e=>e.checked=e.dataset.layoutDirection===layoutChase.direction)}
$('#layout-chase').onclick=()=>{
 if(layoutChase.running){stopLayoutChase();announce('Layout Chase Stopped. Preset Playback Remains Paused.');return}
 if(state.live||!state.selectedIds.length)return;
 $('#mode-preview').click();timecode.chase(false);state.playing=false;state.time=stageDuration();syncPlay();
 resumeUnits(state.selectedIds);layoutChase.start(state.fixtures,state.selectedIds);$('#layout-chase').textContent='Stop Chase';$('#layout-chase').setAttribute('aria-pressed','true');
 announce('Visual Chase Started For Selected Units, Left To Right. Assigned Presets Are Gated To 60% Of Each Beat. 0 BPM Pauses; No Hardware Output.');
};
$('#layout-chase-bpm').onchange=e=>{const value=Number(e.target.value);if(e.target.value!==''&&Number.isFinite(value))layoutChase.setRate(clamp(value,0,480));syncLayoutChase()};
for(const [id,delta]of [['chase-slower',-1],['chase-faster',1]])$(`#${id}`).onclick=e=>{layoutChase.setRate(clamp(layoutChase.bpm+delta*(e.shiftKey?10:1),0,480));syncLayoutChase()};
document.querySelectorAll('[data-layout-direction]').forEach(e=>e.onchange=()=>{layoutChase.setDirection(e.dataset.layoutDirection);syncLayoutChase()});
let selectEvenNext=false;
$('#select-odd-even').onclick=()=>{const parity=selectEvenNext?0:1;setSelection(state.fixtures.filter(f=>f.id%2===parity).map(f=>f.id));selectEvenNext=!selectEvenNext;$('#select-odd-even').textContent=parity?'Odd Selected':'Even Selected';announce(`${parity?'Odd':'Even'} Fixture IDs Selected. Click Again For ${parity?'Even':'Odd'} Units.`)};
for(const id of ['play','restart','mode-preview','mode-faders','mode-dmx','bank-release','focus-release','stage-load-default-layout','stage-reset-layout'])$(`#${id}`)?.addEventListener('click',stopLayoutChase,true);
document.addEventListener('visibilitychange',()=>{if(document.hidden)stopLayoutChase()});
const fixtureNameLabel=document.createElement('label');fixtureNameLabel.className='fixture-name-field';fixtureNameLabel.textContent='Fixture Name';
const fixtureNameInput=document.createElement('input');fixtureNameInput.id='fixture-name';fixtureNameInput.maxLength=48;fixtureNameInput.placeholder='Use Default Fixture Name';fixtureNameInput.setAttribute('aria-label','Fixture Name');fixtureNameLabel.append(fixtureNameInput);$('.fixture-editor-title').after(fixtureNameLabel);
fixtureNameInput.onchange=()=>{if(!state.selectedIds.length)return;const name=fixtureNameInput.value.trim();if(!validFixtureName(name)){renderFixtures();return}remember();selectedFixture().name=name;renderFixtures();announce('Active Fixture Name Updated. Other Selected Fixtures Keep Their Names.')};
fixtureNameInput.onkeydown=e=>{e.stopPropagation();if(e.key==='Enter'){e.preventDefault();fixtureNameInput.blur()}};
$('#fit-view').after($('#arrange'));
const invertPanel=document.createElement('section');invertPanel.className='invert-panel';$('.fixture-editor').after(invertPanel);invertPanel.append($('.invert-setting'));
const controlsInvert=document.createElement('button');controlsInvert.type='button';controlsInvert.id='controls-invert';controlsInvert.textContent='Invert';controlsInvert.onclick=()=>$('#fixture-invert').click();$('#undo-layout').before(controlsInvert);
const controlsHome=document.createElement('button');controlsHome.type='button';controlsHome.id='controls-home';controlsHome.textContent='Home';controlsHome.title='Park Selected Heads At Their Home Angle And Release Their Cues (H)';$('#undo-layout').before(controlsHome);
// Home: park the selected heads at their home angle, release any fader, flash or chase that reaches them, and stop the layout chase.
function homeSelected(){
 if(state.live){announce('Live Input owns the heads. Leave Live Input to use Home.');return}
 const group=selectedFixtures();if(!group.length){announce('Select units to send home.');return}
 const now=performance.now()/1000;
 for(const f of group)parkedUnits.set(f.id,{from:lastDrawnAngles.get(f.id)??homeAngleFor(f),at:now});
 const released=playbackUI?.releaseTargeting(group.map(f=>f.id))??0;
 if(layoutChase.running)stopLayoutChase();
 const angles=[...new Set(group.map(homeAngleFor))];
 announce(`${group.length} unit(s) homed to ${angles.length===1?fmt(angles[0]):'their home angles'}${released?` · ${released} running fader(s) released`:''}. Choose a look, raise a fader or press Restart to resume.`);
 homeReadoutKey='';sessions?.record('Home Selected Units');
}
controlsHome.onclick=homeSelected;
$('#home-selected').onclick=homeSelected;
$('#home-angle').onchange=e=>{
 const raw=e.target.value.trim();if(raw==='')return;
 const value=clamp(Math.round(Number(raw)||0),-105,105);e.target.value=String(value);
 editSelection(f=>f.homeAngle=value,`Home angle set to ${fmt(value)} for the selected units.`);
 homeReadoutKey='';
};
$('#home-angle').onkeydown=e=>{e.stopPropagation();if(e.key==='Enter'){e.preventDefault();e.target.blur()}};
document.addEventListener('wave-home-selected',homeSelected);
document.addEventListener('keydown',e=>{
 if(e.key!=='h'&&e.key!=='H'||e.repeat||e.ctrlKey||e.metaKey||e.altKey||document.querySelector('dialog[open]')||e.target.closest?.('input,textarea,select,[contenteditable="true"]'))return;
 e.preventDefault();homeSelected();
});
let defaultNoticeAnchor=$('#stage-default-layout');
function defaultNotice(text){showDefaultFeedback(text,defaultNoticeAnchor);document.dispatchEvent(new CustomEvent('wave-default-updated',{detail:{text}}))}
$('#default-layout-status').remove();
let savedDefault=null,defaultRevision=0;
const DEFAULT_PORT='__PORT_8093__',DEFAULT_API=DEFAULT_PORT.startsWith('__')?'http://127.0.0.1:8093':DEFAULT_PORT;
const defaultHeaders={'Content-Type':'application/json',...(['127.0.0.1','localhost'].includes(location.hostname)?{'X-Wave-Dev-Visitor':'local-development'}:{})};
function validateDefault(d){
 if(d?.format!=='wave-studio-default'||d.version!==1)throw Error('Invalid Default');
 // Keep only the normalized fixtures the validator returns, never the raw server object.
 const checked=applyLayoutDocument({...exportLayout(),fixtures:d.fixtures,sceneScale:d.sceneScale,selectedId:d.fixtures?.[0]?.id,selectedIds:d.fixtures?.map(f=>f.id),fuel:undefined,preferences:undefined},true);
 return {format:d.format,version:d.version,fixtures:checked.fixtures,sceneScale:checked.sceneScale};
}
fetch(`${DEFAULT_API}/api/default-layout`,{headers:defaultHeaders}).then(r=>{if(!r.ok)throw Error();return r.json()}).then(d=>{if(d&&!defaultRevision)savedDefault=validateDefault(d)}).catch(()=>{});
defaultLayoutButton.onclick=async e=>{
 if(e.isTrusted)defaultNoticeAnchor=defaultLayoutButton;
 if(savedDefault&&!confirm('Replace Your Saved Default With The Current Fixture Layout?'))return;
 const candidate=validateDefault({format:'wave-studio-default',version:1,fixtures:structuredClone(state.fixtures),sceneScale:state.sceneScale});defaultRevision++;
 try{const r=await fetch(`${DEFAULT_API}/api/default-layout`,{method:'PUT',headers:defaultHeaders,body:JSON.stringify(candidate),signal:AbortSignal.timeout(8000)});if(!r.ok)throw Error();savedDefault=candidate;defaultNotice('Default Layout Has Been Updated');announce('Current Layout Saved As Your Default For This Visitor. Reset Layout Will Restore It.')}
 catch{savedDefault=candidate;defaultNotice('Default Layout Updated · This Visit Only');announce('Default Set For This Visit Only. Online Save Failed; Download Your Layout For Backup.')}
};
$('#stage-default-layout').onclick=()=>{defaultNoticeAnchor=$('#stage-default-layout');defaultLayoutButton.click()};$('#stage-reset-layout').onclick=()=>resetLayoutButton.click();
$('#stage-load-default-layout').onclick=()=>resetLayoutButton.click();
$('#stage-default-layout').title=defaultLayoutButton.title;
const resetDialog=document.createElement('dialog');resetDialog.className='save-options-dialog';resetDialog.id='reset-layout-dialog';
resetDialog.innerHTML='<h2>Reset Layout?</h2><p></p><div class="session-buttons"><button data-reset-cancel>Cancel</button><button data-reset-confirm class="primary">Reset Layout</button></div>';document.body.append(resetDialog);
resetLayoutButton.onclick=()=>{resetDialog.querySelector('p').textContent=(savedDefault?'Restore Your Saved Default Fixture Layout.':'No Saved Default Yet. Restore The Factory Six-Unit Layout.')+' Playback Stops And Live Input Disconnects. Existing Fuel Estimates And Other Preferences Are Preserved. Undo Restores The Previous Layout.';resetDialog.showModal()};resetDialog.querySelector('[data-reset-cancel]').onclick=()=>resetDialog.close();
resetDialog.querySelector('[data-reset-confirm]').onclick=()=>{
 stopLayoutChase();
 cancelGesture();remember();leaveDmx();playbackUI.restore(playbackUI.serialize());
 state.fixtures=savedDefault?structuredClone(savedDefault.fixtures):createDefaultFixtures();state.selectedId=state.fixtures[0].id;state.selectedIds=state.fixtures.map(f=>f.id);state.nextId=Math.max(...state.selectedIds)+1;state.sceneScale=savedDefault?.sceneScale??1;state.time=0;state.playing=false;state.layoutLocked=false;state.panX=0;state.panY=0;
 timecode.chase(false);fitFlameView();syncLock();refreshStage();resetDialog.close();announce('Default Layout Restored. Playback Paused; Fuel Estimates Preserved. Undo Restores The Previous Layout.');
};
$('#load-layout').onclick=()=>$('#layout-file').click();
// Ready-made Vista 3 show file (static asset, free): the Explo X2 Wave Flame layout patched for the receiver.
$('#vista-layout-download').onclick=()=>{const a=document.createElement('a');a.href='./files/Vista-3-Explo-Layout.v3s';a.download='Vista-3-Explo-Layout.v3s';a.rel='noopener';document.body.append(a);a.click();a.remove();announce('Downloading Vista 3 Explo Layout (.v3s). Open It In Vista 3 With File → Open.')};
$('#layout-file').onchange=async e=>{
 const file=e.target.files[0];if(!file)return;
 try{
  if(file.size>2000000)throw Error('file too large');
  const data=JSON.parse(await file.text());
  applyLayoutDocument(data.format==='wave-studio-save'?mergeSaveBundle(data,exportLayout()):data,false,data.format!=='wave-studio-save');
 }catch(error){announce('Could not load this layout. Choose a valid Wave Studio JSON file (1–40 fixtures). Your stage is unchanged.')}
 e.target.value='';
};
function applyLayoutDocument(data,validateOnly=false,applyDefaults=false){
  if(data.format!=='wave-studio-layout'||![1,2,3,4,5].includes(data.version)||!Array.isArray(data.fixtures)||data.fixtures.length<1||data.fixtures.length>40||![1,.8,.65,.45,.3].includes(data.sceneScale))throw Error('invalid layout');
  const ids=new Set();
  const fixtures=data.fixtures.map(f=>{
   if(!Number.isSafeInteger(f.id)||f.id<1||f.id>999999||ids.has(f.id)||!Number.isInteger(f.presetId)||f.presetId<1||f.presetId>88||!Number.isFinite(f.x)||!Number.isFinite(f.y)||Math.abs(f.x)>100||Math.abs(f.y)>100)throw Error('invalid fixture');
   if((data.version>=2||f.inverted!==undefined)&&typeof f.inverted!=='boolean')throw Error('invalid invert setting');
   if(data.version>=3&&!validPatch(f.patch))throw Error('invalid patch');
   if(data.version>=4&&!validAngles(f))throw Error('invalid angle limits');
   if(f.virtualArmed!==undefined&&typeof f.virtualArmed!=='boolean')throw Error('invalid virtual arm state');
   if(f.nozzle!==undefined&&!['indoor','outdoor'].includes(f.nozzle))throw Error('invalid nozzle');
   if(f.flameScale!==undefined&&(!Number.isFinite(f.flameScale)||f.flameScale<50||f.flameScale>400))throw Error('invalid flame scale');
   if(f.bodyScale!==undefined&&![1,.8,.65,.45,.3].includes(f.bodyScale))throw Error('invalid body scale');
   if(f.homeAngle!==undefined&&(!Number.isInteger(f.homeAngle)||Math.abs(f.homeAngle)>105))throw Error('invalid home angle');
   if(f.rotation!==undefined&&(!Number.isInteger(f.rotation)||f.rotation<0||f.rotation>355||f.rotation%5))throw Error('invalid rotation');
   if(!validFixtureName(f.name))throw Error('invalid fixture name');
   ids.add(f.id);return {id:f.id,x:f.x,y:f.y,...(f.name!==undefined?{name:f.name}:{}),presetId:f.presetId,inverted:f.inverted??false,...(f.nozzle!==undefined?{nozzle:f.nozzle}:{}),...(f.virtualArmed!==undefined?{virtualArmed:f.virtualArmed}:{}),...(f.flameScale!==undefined?{flameScale:f.flameScale}:{}),...(f.bodyScale!==undefined?{bodyScale:f.bodyScale}:{}),...(f.rotation!==undefined&&f.rotation?{rotation:f.rotation}:{}),...(f.homeAngle!==undefined?{homeAngle:f.homeAngle}:{}),minAngle:data.version>=4?f.minAngle:-105,maxAngle:data.version>=4?f.maxAngle:105,...(data.version>=3?{patch:{universe:f.patch.universe,address:f.patch.address}}:{})};
  });
  if(data.version>=3&&fixtures.some((f,i)=>fixtures.slice(i+1).some(g=>f.patch.universe===g.patch.universe&&f.patch.address<=g.patch.address+5&&f.patch.address+5>=g.patch.address)))throw Error('overlapping patches');
  const favorites=data.favorites??[];
  if(!Array.isArray(favorites)||favorites.length>88||new Set(favorites).size!==favorites.length||favorites.some(id=>!Number.isInteger(id)||id<1||id>88))throw Error('invalid favorites');
  const favoriteTiming=data.favoriteTiming??{};
  if(typeof favoriteTiming!=='object'||Array.isArray(favoriteTiming)||favoriteTiming===null||Object.entries(favoriteTiming).some(([id,t])=>!favorites.includes(Number(id))||String(Number(id))!==id||!Number.isFinite(t?.duration)||t.duration<.01||t.duration>10||!Number.isFinite(t?.gap)||t.gap<0||t.gap>60))throw Error('invalid favorite timing');
  const view=data.view??{zoom:.55,panX:0,panY:0};
  if(!Number.isFinite(view.zoom)||view.zoom<0||view.zoom>2.5||!Number.isFinite(view.panX)||Math.abs(view.panX)>100||!Number.isFinite(view.panY)||Math.abs(view.panY)>100)throw Error('invalid view');
  const playbackData=PlaybackBank.validate(data.playback);
  const fuelData=FuelLedger.validate(data.fuel,fixtures);
  const preferences=validatePreferences(data.preferences);
  if(data.layoutLocked!==undefined&&typeof data.layoutLocked!=='boolean')throw Error('Invalid lock state');
  if(data.selectedIds!==undefined&&(!Array.isArray(data.selectedIds)||data.selectedIds.length>40||new Set(data.selectedIds).size!==data.selectedIds.length||data.selectedIds.some(id=>!ids.has(id))))throw Error('Invalid selection');
  if(validateOnly)return {fixtures:structuredClone(fixtures),sceneScale:data.sceneScale};
  // Everything is validated above. If a restore step still fails, the previous stage is put back so the message stays true.
  const before=exportLayout();
  try{commitLayout()}catch(error){try{commitLayoutFrom(before)}catch{}throw error}
  return true;
  function commitLayoutFrom(snapshot){applyLayoutDocument(snapshot,false,false)}
  function commitLayout(){
  stopLayoutChase();
  cancelGesture();remember().fuelBeforeLoad=fuel.serialize(state.fixtures);leaveDmx();state.fixtures=fixtures;state.selectedId=ids.has(data.selectedId)?data.selectedId:fixtures[0].id;state.selectedIds=[state.selectedId];state.nextId=Math.max(...ids)+1;state.sceneScale=data.sceneScale;state.time=0;state.playing=false;
  fuel.restore(fuelData,fixtures);
  if(data.selectedIds)state.selectedIds=[...data.selectedIds];
  state.layoutLocked=data.layoutLocked??false;syncLock();
  state.favorites=[...favorites];state.favoriteTiming=Object.fromEntries(Object.entries(favoriteTiming).map(([id,t])=>[id,{duration:t.duration,gap:t.gap}]));
  fitFlameView();state.panX=view.panX;state.panY=view.panY;setZoom(data.version>=5?view.zoom:1);playbackUI.restore(playbackData,applyDefaults);
  if(preferences)applyPreferences(preferences);
  refreshStage();if(preferences){state.targetTime=preferences.targetTime;$('#speed').value=state.effectiveTime.toFixed(2)}announce(`Loaded ${fixtures.length} flamers. Press Play to preview the stage.`);
  }
}
const notes=$('#notes');
function openNotes(help=false){
 $('#notes-title').textContent=help?'How to explore':'Reference & rendering notes';
 $('#notes-content').innerHTML=help?`<p>Select a preset in the sequence library, then use <strong>Play</strong> to preview it. Search by preset number, name or angle, or filter by Bursts, Steps and Waves.</p><p>Time is an absolute duration from 0.01 to 10.00 seconds. Minus/plus changes it by 0.01 s; hold Shift while clicking for 0.10 s. You can also type a value. New sequence selections default to their native time; sequence 046 starts at 0.99 s. Reset restores native timing. The manual decay/gap stays 1.10 s. Manual fixtures share the selected sequence's clock ratio. Cue timing uses the captured sequence duration as its reference and scales the shared cue clock; timeline values remain source time. Very short previews are display-refresh limited. Live Input and virtual DMX are not retimed.</p><p>Drag the timeline to examine any moment. Loop repeats one preset; Auto-next moves through the full catalog and takes priority over Loop. Each preview includes a 1.10-second visual decay and loop gap after the documented duration.</p><p>Hold Ctrl and scroll the mouse wheel over the layout to zoom. The minus/plus buttons offer the same control. Fit view restores 55%, with outdoor-flame headroom in the default layout; zoom never changes fixture positions or DMX values. Save frame downloads the viewport as a PNG.</p><p>Space plays or pauses when you are not editing a control. Left and right arrow keys select the adjacent preset. On mobile, the library sits below the preview.</p>`:
 `<p>This independent simulator includes all <strong>88 entries</strong> in Explo’s <a href="${SOURCE}" target="_blank" rel="noopener">X2 Wave Flame Sequences & DMX Values</a> sheet. That sheet provides positions, sequence families and total durations. Entries 71–88 are identified there as DMX-only.</p><h3>What is documented</h3><p>Preset numbers, position order, the −105° to +105° angle mapping, short/long classification and displayed total duration follow the manufacturer’s sequence sheet. The <a href="https://explo.at/product/x2-wave-flame/" target="_blank" rel="noopener">manufacturer’s product page</a> describes a wave as a continuous flame moving across the arc.</p><h3>What is approximated</h3><p>Flame shape, colour, turbulence, particle lifetime, height and head movement are artistic approximations. Steps use nominal 0.11 / 0.41-second bursts with the remaining time distributed evenly between positions. Waves use uniform angular motion. These are visualization assumptions, not measured device motion.</p><p>The 1.10-second tail after each sequence is a preview-only decay and loop gap. The size slider changes the artwork, not a physical nozzle or height. Angles are shown in a schematic front view with negative angles on screen-left.</p><h3>Version and timing differences</h3><p>The <a href="https://explo.at/wp-content/uploads/2025/06/X2-Wave-Flamer-v2.0-ENG-2.pdf" target="_blank" rel="noopener">v2.0 manual (December 2018, software v1.59)</a> differs from the separate sequence sheet in some durations: 41–42, 49–50 and 65–66. This preview consistently uses the separate sequence sheet, including 1.08 seconds for 65–66. It is not a guarantee of behavior for every firmware or custom program.</p><p><strong>Visualization only.</strong> No DMX, radio, network-control output, firing exports or hardware integration. Do not use this preview for operational decisions or safety distances. The fixture illustration is schematic, not a dimensional model.</p>`;
 $('#notes-content').innerHTML=$('#notes-content').innerHTML.replace('No DMX, radio, network-control output, firing exports or hardware integration.','The optional local Windows receiver accepts Art-Net or sACN for visualization. There is no DMX or firing-command output.');
 $('#notes-content').insertAdjacentHTML('afterbegin','<h3>Live input: sACN or Art-Net</h3><p>Use <strong>Vista / Windows setup</strong> for the local receiver package. The sACN launcher listens on UDP 5568 and leaves Vista’s Art-Net port untouched. Select the same multicast interface as Vista. It does not appear as an Art-Net node. The Art-Net launcher retains discovery replies for a separate receiver PC.</p><p>Standard six-channel Explo DMX512 with CH5 “new” is supported. Live mode uses independent fixture trigger clocks. sACN universes are displayed one-based; existing layout slot 0 maps to sACN universe 1. Layout files retain zero-based slots for compatibility.</p><p>sACN accepts null-start-code level data, including preview data. Highest universe priority takes over; equal-priority competing sources are ignored. Stream termination clears the affected universe. Per-address priority, HTP/LTP merging and synchronized playback are not supported. Pressure, mechanical travel and safety interlocks are not simulated. This is not verification of a physical firing system.</p>');
 if(help){
  $('#notes-content').innerHTML=$('#notes-content').innerHTML.replace('Loop repeats one preset; Auto-next moves through the full catalog and takes priority over Loop.','Loop repeats the stage; Auto-next advances every fixture through the catalog and takes priority over Loop.').replace('after the documented duration','after the longest documented duration on the stage');
  $('#notes-content').insertAdjacentHTML('afterbegin','<h3>Build your stage</h3><p>Use <strong>+ Add flamer</strong> to add up to 16 fixtures. Click a fixture to select it; <strong>Ctrl-click</strong> (or Command-click) toggles individual units. Selected units have orange borders and check marks. The F01 / F02 chips also support Ctrl-click, useful for overlapping units.</p><p>Drag any highlighted fixture to move the group with spacing preserved. Drag a box on empty stage space to select the units it touches; Ctrl-drag toggles those units. Click empty space or Clear selection to deselect all. Select all includes every unit. Escape cancels a drag; Undo reverses one completed group move.</p><p>Presets, Invert, nozzle, virtual arm, angle limits and visual scales edit all selected units. Mixed Invert shows a mixed-state checkbox. X/Y edits translate the group while preserving spacing. Patch edits shift start addresses together and apply the universe, preserving address offsets; overlapping or invalid group patches are rejected atomically. Remove deletes the selection, keeping one fixture. Arrange row arranges all units.</p><p>Multiple selected units are captured as the target group on the next fader/flash operation. Cue playback repeats the cue look for the active selected unit (or its first look) on every selected unit in sync. DMX faders mirror the assigned channel’s parameter offset to selected fixture patches, even across universes. A channel must fall within an existing fixture patch to identify its parameter. Selection alone does not rewrite running cues or saved assignments. Single/no selection retains recorded cue targets and ordinary channel addressing. Live Input remains independent of selection.</p><p>Save layout stores fixture settings, not temporary selection or raised playback levels. Loading selects one active fixture with outputs released. Changes are not automatically saved when the page closes.</p>');
 }
 $('#notes-content').insertAdjacentHTML('afterbegin',`<h3>Individual Invert parameter</h3><p>Select a fixture, then toggle <strong>Invert</strong> in its inspector. This models the position mapping in <a href="https://explo.at/wp-content/uploads/2025/06/X2-Wave-Flamer-v2.0-ENG-2.pdf" target="_blank" rel="noopener">Explo’s manual, §4.2.14 (page 21)</a>: 1 ↔ 15, 2 ↔ 14, 3 ↔ 13, 4 ↔ 12, 5 ↔ 11, 6 ↔ 10, 7 ↔ 9; 8 stays centred. It is a left/right position mirror, not an upside-down mounting option.</p><p>The preview applies this mapping to bursts, steps and waves. The head, flame direction, movement path and output readouts mirror; the original catalog preset number, step order in time and emission timing stay unchanged. Catalog library entries remain unmodified; the inspector shows transformed output positions and angles.</p><p>Invert affects only the selected fixture, does not move its stage position, and supports Undo. New fixtures start with Invert off. Apply this preset to all changes only presets, preserving each fixture’s Invert state. Saved layouts include Invert; older layout files load with Invert off. The flame rendering remains an artistic approximation.</p>`);
 $('#notes-content').insertAdjacentHTML('beforeend','<h3>Flame width and burst separation</h3><p>The flame artwork uses a slimmer plume, reduced lateral spread and tighter glow. Bursts use shorter-lived particles and a quick fade during the existing off interval so successive jets remain visually separate. Continuous waves keep their flowing trail.</p><p>These are rendering choices, not changes to the catalog emission timing, sequence duration or playback speed. The preview is still an artistic approximation, not a measured flame envelope.</p>');
 notes.showModal();
}
$('#sources').onclick=()=>openNotes();$('#help').onclick=()=>openNotes(true);$('#close-notes').onclick=()=>notes.close();
{const manual=$('#manual-dialog'),frame=$('#manual-frame'),autoBox=$('#manual-auto');
 // The hosted site sends X-Frame-Options: DENY / frame-ancestors 'none' on every page, so a plain
 // <iframe src> of the manual is blocked. Instead the page is fetched (same origin) and shown through
 // srcdoc with a <base> for its images; a tiny bridge script posts in-manual link clicks back here.
 // The frame is sandboxed without allow-same-origin, so manual pages run in an opaque origin and cannot
 // read the studio's storage. Messages therefore use '*' and are trusted only from this frame (e.source).
 frame.setAttribute('sandbox','allow-scripts allow-popups allow-popups-to-escape-sandbox');
 const MANUAL_BASE=new URL('./manual/',location.href).href;let manualLoaded='';
 // The bridge is a static same-origin file: the frame inherits the studio's Content-Security-Policy, which allows no inline script.
 const bridge=`<script src="${new URL('bridge.js?v=v0340-20261007f',MANUAL_BASE).href}"><\/script>`;
 async function loadManual(href){
  const url=new URL(href,MANUAL_BASE);const key=url.pathname+url.search;
  // Only pages inside ./manual/ on this origin are ever fetched or rendered.
  if(url.origin!==location.origin||!url.pathname.startsWith(new URL(MANUAL_BASE).pathname)||!/\.html?$/i.test(url.pathname))return;
  if(manualLoaded===key){if(url.hash)frame.contentWindow?.postMessage({type:'wave-manual-hash',hash:url.hash},'*');return}
  try{
   const r=await fetch(url.pathname+url.search,{cache:'no-store',signal:AbortSignal.timeout(8000)});if(!r.ok)throw Error(String(r.status));
   let html=await r.text();const base=`<base href="${url.href.replace(/#.*$/,'').replace(/["<>&]/g,c=>encodeURIComponent(c))}">`;
   // Function replacers: a '$&' or '$1' in a hash or URL is inserted literally, never expanded.
   html=/<head[^>]*>/i.test(html)?html.replace(/<head[^>]*>/i,m=>m+base):base+html;
   html=/<\/body>/i.test(html)?html.replace(/<\/body>/i,()=>bridge+'</body>'):html+bridge;
   if(url.hash){const meta=`<meta name="wave-manual-hash" content="${url.hash.replace(/[&"<>]/g,c=>({'&':'&amp;','"':'&quot;','<':'&lt;','>':'&gt;'}[c]))}">`;html=/<head[^>]*>/i.test(html)?html.replace(/<head[^>]*>/i,m=>m+meta):meta+html}
   frame.removeAttribute('src');frame.srcdoc=html;manualLoaded=key;
  }catch{
   // Fallback for file:// or offline copies where fetch is unavailable: try the frame directly.
   manualLoaded='';frame.removeAttribute('srcdoc');frame.src=url.href;
  }
 }
 addEventListener('message',e=>{if(e.source===frame.contentWindow&&e.data?.type==='wave-manual-nav'&&typeof e.data.href==='string')loadManual(e.data.href)});
 const openManual=()=>{if(!manualLoaded&&!frame.getAttribute('src'))loadManual('index.html');if(!manual.open)manual.showModal()};
 $('#manual-open').onclick=openManual;$('#close-manual').onclick=()=>manual.close();
 // AI Assist, tutorials and Information mode ask for a specific manual section through this event.
 document.addEventListener('wave-open-manual',e=>{const href=e.detail?.href;if(typeof href!=='string')return;document.querySelectorAll('dialog[open]').forEach(d=>{if(d!==manual)d.close()});loadManual(href);if(!manual.open)manual.showModal()});
 manual.addEventListener('click',e=>{if(e.target===manual)manual.close()});
 // The First Guide opens by itself when the full studio starts, until the reader unticks the box.
 const AUTO_KEY='vsl-manual-on-start';
 const autoOn=()=>{try{return localStorage.getItem(AUTO_KEY)!=='off'}catch{return true}};
 if(autoBox){autoBox.checked=autoOn();autoBox.onchange=()=>{try{localStorage.setItem(AUTO_KEY,autoBox.checked?'on':'off')}catch{}}}
 if(autoOn()&&!document.documentElement.classList.contains('trial-locked')&&!new URLSearchParams(location.search).has('no-guide'))setTimeout(()=>{if(!document.documentElement.classList.contains('trial-locked')&&!$('#trial-lock')?.open)openManual()},900);}
mountPresence($('#visitors'));
recordVisit('studio');

notes.addEventListener('click',e=>{if(e.target===notes){const r=notes.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)notes.close()}});
document.addEventListener('keydown',e=>{if(state.live||playbackUI?.bank.enabled||document.querySelector('dialog[open]')||['INPUT','SELECT','BUTTON','TEXTAREA','A'].includes(document.activeElement.tagName))return;if(e.code==='Space'){e.preventDefault();$('#play').click()}if(e.code==='ArrowRight'){e.preventDefault();$('#next').click()}if(e.code==='ArrowLeft'){e.preventDefault();$('#prev').click()}});
function patchDescription(p){return `${dmxProtocol==='sACN'?`sACN universe ${p.universe+1}`:`Net ${p.universe>>8} / Sub-Net ${(p.universe>>4)&15} / Universe ${p.universe&15}`} · Channels ${p.address}–${p.address+5}`;}
function configureReceiver(info){
 receiverConfig=info;dmxProtocol=info.protocol==='sACN'?'sACN':'Art-Net';dmxDiscoveryConfig=info.discovery??null;
 {const preset=$('#receiver-preset');if(preset){const label=typeof info.consoleLabel==='string'?info.consoleLabel.slice(0,40):'';preset.hidden=!label;
   if(label)preset.textContent=`Local receiver running: ${label} preset · ${dmxProtocol} · ${dmxProtocol==='sACN'?'universes':'port addresses'} ${(info.universes||[]).join(', ')} · interface ${info.interface||'default'}${info.desktopVersion?` · desktop ${info.desktopVersion}`:''}`;
   if(typeof info.consoleTab==='string')pickConsoleTab(info.consoleTab)}}
 for(const id of ['windows-download','macos-download']){
  const link=$(`#${id}`);if(link)link.parentElement.hidden=true;
 }
 $('#patch-heading').textContent=`${dmxProtocol} PATCH / 6 CHANNELS`;
 $('#dmx-universe-label').textContent=dmxProtocol==='sACN'?'sACN universe (1-based)':'Port-address (0-based)';
 $('#dmx-universe').min=universeOffset();$('#dmx-universe').max=32767+universeOffset();
 $('#dmx-universe').value=selectedFixture().patch.universe+universeOffset();
 $('#dmx-patch-status').textContent=patchDescription(selectedFixture().patch);
 $('#dmx-stage-note').innerHTML=`LIVE ${dmxProtocol} · Independent fixture triggers<br><span>Drop the trigger below 254, then raise it to trigger again. A lost input clears the virtual effect after 2.5 seconds.</span>`;
 $('#dmx-output-note').textContent=dmxProtocol==='sACN'?'sACN input only on UDP 5568; no DMX or discovery output. Live mode ignores manual playback speed and loop.':'DMX input only; network output is limited to discovery replies. Live mode ignores manual playback speed and loop.';
 syncDmxMode();
}
function syncDmxMode(){
 document.body.classList.toggle('live-mode',state.live);
 $('.library').inert=state.live;
 const manual=!state.live&&!playbackUI?.bank.enabled;
 $('#mode-preview').classList.toggle('active',manual);$('#mode-preview').setAttribute('aria-pressed',manual);
 const faders=!state.live&&!!playbackUI?.bank.enabled;
 $('#mode-faders').classList.toggle('active',faders);$('#mode-faders').setAttribute('aria-pressed',faders);
 $('#mode-dmx').classList.toggle('active',state.live);$('#mode-dmx').setAttribute('aria-pressed',state.live);
 $('#dmx-monitor').hidden=!state.live;$('#dmx-stage-note').hidden=!state.live;
 $('#mode-dmx').textContent=state.live&&!dmxConnected?`Reconnect ${dmxProtocol}`:receiverConfig?`Live ${dmxProtocol}`:'Live input';
}
function leaveDmx(){
 if(dmxStream)dmxStream.close();dmxStream=null;dmxConnected=false;dmxEngine.clear();state.live=false;state.playing=false;
 $('#dmx-status').textContent='Preset playback · no live input';syncPlay();syncDmxMode();
}
$('#mode-preview').onclick=()=>{playbackUI.disconnect();leaveDmx();playbackUI.bank.enabled=false;playbackUI.bank.releaseAll();document.body.classList.remove('bank-mode');$('.transport').inert=false;syncPlay();syncDmxMode()};
$('#dmx-setup').onclick=()=>$('#dmx-help').showModal();
let pickConsoleTab=()=>{};
{const KEY='vsl-console-tab',tabs=[...document.querySelectorAll('#dmx-help .console-tabs [data-console]')],panes=[...document.querySelectorAll('#dmx-help .console-pane')];
 const pick=id=>{if(!tabs.some(t=>t.dataset.console===id))id='vista';tabs.forEach(t=>t.setAttribute('aria-selected',String(t.dataset.console===id)));panes.forEach(p=>p.hidden=p.dataset.console!==id);try{localStorage.setItem(KEY,id)}catch{}};
 pickConsoleTab=pick;tabs.forEach(t=>t.onclick=()=>pick(t.dataset.console));let saved='vista';try{saved=localStorage.getItem(KEY)||'vista'}catch{}pick(saved)}
$('#close-dmx-help').onclick=()=>$('#dmx-help').close();
$('#mode-dmx').onclick=async()=>{
 if(dmxConnecting||(state.live&&dmxConnected))return;
 if(location.protocol!=='http:'||!['localhost','127.0.0.1'].includes(location.hostname)){
  $('#dmx-help').showModal();return;
 }
 dmxConnecting=true;$('#mode-dmx').disabled=true;$('#mode-preview').disabled=true;$('#mode-faders').disabled=true;$('#enable-virtual-faders').disabled=true;
 $('#dmx-status').textContent='Checking local receiver…';
 try{
  playbackUI.disconnect();
  const response=await fetch('/api/info',{signal:AbortSignal.timeout(3000)});
  if(!response.ok)throw Error('Local receiver unavailable');
  const info=await response.json();if(info.app!=='wave-studio-receiver')throw Error('Wrong server');
  if(info.preview||info.protocol==='none')throw Error('The desktop launcher is running without a receiver (Skip for now). In the Virtual SFX Lab window click Stop, choose sACN or Art-Net, then Start receiver.');
  configureReceiver(info);
  $('#windows-download').parentElement.hidden=true;
  if(dmxStream)dmxStream.close();dmxEngine.clear();state.live=true;state.playing=false;dmxConnected=false;
  syncPlay();syncDmxMode();
  const stream=new EventSource('/api/events');dmxStream=stream;
  stream.onopen=()=>{if(dmxStream!==stream)return;dmxConnected=true;syncDmxMode();$('#dmx-status').textContent='Receiver connected · waiting for your patched universe'};
  stream.onmessage=e=>{
   if(dmxStream!==stream)return;
   try{
    const message=JSON.parse(e.data);
    if(message.kind==='dmx'){dmxEngine.ingest(message,state.fixtures,performance.now()/1000);playbackUI?.followLive?.(message);document.dispatchEvent(new CustomEvent('wave-dmx-frame',{detail:{universe:message.universe,values:message.values,source:message.source}}))}
    else if(message.kind==='status')dmxStats=message;
    else if(message.kind==='universe_reset'){
     state.fixtures.filter(f=>f.patch.universe===message.universe).forEach(f=>{
      dmxEngine.reset(f.id);dmxEngine.record(f).status=message.reason;
     });
    }
    else if(message.kind==='reset'){dmxEngine.clear();playbackUI?.liveFollowReset?.();$('#dmx-status').textContent=message.reason}
   }catch(error){dmxEngine.clear();$('#dmx-status').textContent='Invalid receiver data; effects cleared'}
  };
  stream.onerror=()=>{
   if(dmxStream!==stream)return;
   stream.close();dmxStream=null;dmxConnected=false;dmxEngine.clear();playbackUI?.liveFollowReset?.();
   $('#dmx-status').textContent='Receiver disconnected. Restart the Windows receiver, then reconnect.';syncDmxMode();
  };
 }catch(error){
  $('#dmx-status').textContent=/Skip for now/.test(error?.message||'')?error.message:'Local receiver not found. Start the receiver in the Virtual SFX Lab desktop window (or Start-Wave-Studio-sACN.cmd for the Python package).';
  $('#dmx-help').showModal();
 }finally{dmxConnecting=false;$('#mode-dmx').disabled=false;$('#mode-preview').disabled=false;$('#mode-faders').disabled=false;$('#enable-virtual-faders').disabled=false}
};
$('#dmx-patch').onclick=()=>{
 const patch={universe:Number($('#dmx-universe').value)-universeOffset(),address:Number($('#dmx-address').value)};
 if($('#dmx-universe').value===''||$('#dmx-address').value===''||!validPatch(patch)){
  $('#dmx-patch-status').textContent=`Use a whole ${dmxProtocol==='sACN'?'sACN universe 1–32768':'port-address 0–32767'} and start address 1–507. Patch unchanged.`;return;
 }
 const result=updateGroupPatch(patch);if(!result.ok)$('#dmx-patch-status').textContent=result.message;
};
function updateGroupPatch(patch){
 const group=selectedFixtures(),delta=patch.address-selectedFixture().patch.address;
 if(!group.length)return {ok:false,message:'Select fixtures first.'};
 const changes=new Map(group.map(f=>[f.id,{universe:patch.universe,address:f.patch.address+delta}]));
 const proposed=state.fixtures.map(f=>({id:f.id,patch:changes.get(f.id)??f.patch}));
 const invalid=proposed.some((f,i)=>!validPatch(f.patch)||proposed.slice(i+1).some(g=>f.patch.universe===g.patch.universe&&f.patch.address<=g.patch.address+5&&f.patch.address+5>=g.patch.address));
 if(invalid)return {ok:false,message:'Group patch would overlap or exceed available channels. No patches changed.'};
 remember();group.forEach(f=>{f.patch=changes.get(f.id);dmxEngine.reset(f.id)});playbackUI.bank.clearVirtual();renderFixtures();announce(`${group.length} selected unit(s) patched; address offsets preserved. Reset live triggers low.`);
 return {ok:true,message:'Virtual start address saved. Group patch spacing preserved; reset triggers low.'};
}
const channelNames=['Angle','Speed','Trigger','Open time','Program','Mode'];
$('#dmx-values').innerHTML=channelNames.map((name,i)=>`<div class="dmx-channel"><span>CH${i+1} · ${name}</span><strong id="dmx-ch${i}">—</strong></div>`).join('');
function renderDmxMonitor(){
 const f=selectedFixture(),r=dmxEngine.record(f),fresh=state.liveTime-r.last<=dmxEngine.timeout;
 $('#dmx-patch-label').textContent=`F${String(f.id).padStart(2,'0')} · ${patchDescription(f.patch)}`;
 $('#dmx-source').textContent=r.source?`${r.source} · ${fresh?'receiving':`last frame ${Math.max(0,state.liveTime-r.last).toFixed(1)}s ago`}`:`Waiting for ${dmxProtocol==='sACN'?'sACN data':'ArtDmx'}`;
 channelNames.forEach((_,i)=>$('#dmx-ch'+i).textContent=r.values?r.values[i]:'—');
 const selected=r.values?decodeProgram(r.values[4]):null;
 $('#dmx-effect').textContent=`${r.status}${selected===null?'':selected>0?` · CH5 selects preset ${pad(selected)}`:selected===0?' · Direct control':' · CH5 outside supported range'}${f.inverted?' · INVERT ON':''}`;
 $('#dmx-packets').textContent=`${dmxStats.received} DMX packets · ${dmxStats.rejected} rejected · ${dmxStats.conflicts} source conflicts · ${dmxProtocol==='sACN'?`${dmxStats.datagrams??0} UDP received · ${dmxStats.ignored??0} filtered · ${dmxStats.terminations??0} terminated${dmxStats.drafts?` · ${dmxStats.drafts} Draft format`:''}`:`${dmxStats.discoveryReplies??0} discovery replies`}`;
 const discovery=dmxDiscoveryConfig;
 $('#dmx-discovery').textContent=!discovery?'Legacy receiver: update the Windows package to enable discovery.':!discovery.enabled?'Discovery disabled; use broadcast or explicit unicast.':`Node: ${discovery.name} · Advertised port-addresses: ${discovery.universes.join(', ')}${discovery.universes.includes(f.patch.universe)?'':` · This fixture’s port-address is not advertised. Relaunch with --universes including ${f.patch.universe} for node patching.`}${dmxStats.discoveryErrors?` · ${dmxStats.discoveryErrors} reply errors`:''}`;
 if(dmxProtocol==='sACN')$('#dmx-discovery').textContent=`sACN · UDP 5568 · Interface: ${receiverConfig.interface==='0.0.0.0'?'system default':receiverConfig.interface} · Subscribed universes: ${receiverConfig.universes.join(', ')}. No Art-Net node discovery.${receiverConfig.universes.includes(f.patch.universe+1)?'':` This fixture’s universe is not subscribed; restart the receiver with --universes including ${f.patch.universe+1}.`}`;
 if(dmxConnected)$('#dmx-status').textContent=fresh?'Live input · receiver only, no hardware output':r.last===-Infinity?'Connected · waiting for this fixture’s universe':'Signal lost on selected universe · virtual output cleared';
}
if(location.protocol==='file:')for(const id of ['windows-download','macos-download']){
 const link=$(`#${id}`);if(link)link.onclick=e=>{e.preventDefault();$('#dmx-status').textContent='Download the receiver package from the Wave Studio conversation or hosted preview.';$('#dmx-help').close()};
}
playbackUI=mountPlayback({state,onLeaveLive:leaveDmx,onSelection:ids=>setSelection(ids),onModeChange:enabled=>{
 document.body.classList.toggle('bank-mode',enabled);
 $('.transport').inert=state.live;
 if(enabled){if(favouritePriority()){state.libraryTab='catalog';state.targetTime=null;renderList()}state.playing=false;syncPlay()}
 if(!state.live)$('#dmx-status').textContent=enabled?'Local fader playback · no hardware output':'Preset playback · no live input';
 syncDmxMode();
}});
cueStack=mountCueStack({root:$('#cue-stack'),bank:playbackUI.bank,playback:playbackUI,state,timecode,getFixtures:()=>state.fixtures,announce});
// MA panel (Beta 0.33): grandMA2 / grandMA3 command section driving selection, programs, homes, cues, executors and the stack.
maEngine=createMAEngine({state,playback:playbackUI,stack:()=>cueStack,stackRoot:()=>$('#cue-stack'),
 select:(ids,active)=>{if(state.live){announce('Live Input owns the heads.');return}setSelection(ids,active??ids.at(-1));announceSelection()},
 applyPreset:id=>{if(state.live)return;if(!state.selectedIds.length)setSelection(state.fixtures.map(f=>f.id));select(id)},
 setHome:entries=>{
  if(state.live)return;remember();
  for(const {id,angle} of entries){const f=state.fixtures.find(f=>f.id===id);if(!f)continue;const limits=angleLimits(f);f.homeAngle=clamp(Math.round(angle),limits.min,limits.max)}
  updateDetails();homeSelected();
 },
 rename:(ids,name)=>{if(!validFixtureName(name))return;remember();for(const f of state.fixtures)if(ids.includes(f.id))f.name=name;refreshStage()},
 click:sel=>$(sel)?.click(),announce,macro:(i,pressed)=>playbackUI.macro(i,pressed,`ma-macro-${i}`)});
playbackUI.onMaKey((id,down)=>maEngine.press(id,down));
rearPanel=mountRearPanel({state,readArmed:f=>fixtureIndicator(f).armed,apply:(key,value)=>{
 if(state.live||!selectedFixtures().length)return {ok:false,message:'Select fixtures and leave Live Input before editing virtual settings.'};
 if(key==='address')return updateGroupPatch({...selectedFixture().patch,address:value});
 if(key==='mode'){
  if(value==='Sleep')return {ok:false,message:'Sleep is a hardware function and is not modelled. Choose Test or Armed; nothing changed.'};
  if(selectedFixtures().some(f=>playbackUI.bank.virtualOwns(f)))return {ok:false,message:'Virtual DMX owns the mode channel. Release DMX priority to use the local menu.'};
  editSelection(f=>f.virtualArmed=value==='Armed',`virtual mode ${value}.`);
 }else if(key==='invert')editSelection(f=>f.inverted=value==='ON',`Invert ${value}.`);
 else if(key==='min'||key==='max'){
  const degrees=(value-8)*15;
  if(selectedFixtures().some(f=>{const next={...angleLimits(f),[key]:degrees};return next.min>next.max}))return {ok:false,message:'Minimum would exceed maximum on a selected unit. No settings changed.'};
  editSelection(f=>f[key==='min'?'minAngle':'maxAngle']=degrees,`POS ${key.toUpperCase()} ${value}.`);
 }else return {ok:false,message:'This setting is not modelled.'};
 return {ok:true,message:`Saved to ${selectedFixtures().length} selected virtual unit(s). No hardware changed.`};
}});
// Mobile navigation changes presentation only: no playback or fixture state is reset.
function mountMobileWorkspace(){
 const media=matchMedia('(max-width:700px)'),positions={},labels={stage:'Stage',sequences:'Sequences',faders:'Faders',setup:'Settings'};
 let panel='stage';try{const saved=sessionStorage.getItem('wave-mobile-panel');if(labels[saved])panel=saved}catch{}
 let mobileFaders=6;
 const bankTools=document.createElement('div');
 bankTools.className='mobile-only mobile-bank-tools';
 bankTools.innerHTML='<div><h2>Virtual faders</h2><span id="mobile-fader-count" role="status" aria-live="polite"></span></div><button type="button" id="mobile-fader-minus" aria-label="Remove fader">−</button><button type="button" id="mobile-fader-plus" aria-label="Add fader">+</button><button type="button" id="mobile-fader-assignments" aria-expanded="false">Assignments</button>';
 $('.bank-scroll').before(bankTools);
 const syncFaders=()=>{
  state.mobileFaders=mobileFaders;
  $('#fader-grid').style.setProperty('--mobile-faders',mobileFaders);
  $('#fader-grid').style.setProperty('--mobile-bank-width',`${Math.max(1,mobileFaders/6)*100}%`);
  document.querySelectorAll('.fader-strip[data-fader]').forEach((row,i)=>row.classList.toggle('mobile-fader-hidden',i>=mobileFaders));
  $('#mobile-fader-count').textContent=`${mobileFaders} fader${mobileFaders===1?'':'s'}${mobileFaders>6?' · swipe for more':''}`;
  $('#mobile-fader-minus').disabled=mobileFaders===1;
  $('#mobile-fader-plus').disabled=mobileFaders===playbackUI.bank.slots.length;
 };
 $('#mobile-fader-plus').onclick=()=>{if(mobileFaders<playbackUI.bank.slots.length){mobileFaders++;syncFaders()}};
 $('#mobile-fader-minus').onclick=()=>{
  if(mobileFaders>1){mobileFaders--;playbackUI.releaseSlot(mobileFaders);syncFaders()}
 };
 $('#mobile-fader-assignments').onclick=e=>{
  const expanded=document.body.classList.toggle('mobile-fader-details');
  e.currentTarget.setAttribute('aria-expanded',String(expanded));
 };
 syncFaders();
 document.addEventListener('wave-mobile-faders',e=>{mobileFaders=e.detail;syncFaders()});
 const more=document.createElement('button');
 more.className='mobile-only mobile-more';more.type='button';more.textContent='More';more.setAttribute('aria-expanded','false');
 $('.play-controls').after(more);
 more.onclick=()=>{const open=document.body.classList.toggle('mobile-options-open');more.textContent=open?'Less':'More';more.setAttribute('aria-expanded',String(open))};
 const actions=document.createElement('div');
 actions.className='mobile-only mobile-stage-actions';
 actions.innerHTML='<div class="mobile-stage-library-heading"><h2 id="mobile-stage-library-title">Sequence library</h2><span>88 sequences</span></div><div id="mobile-stage-sequences" role="group" aria-labelledby="mobile-stage-library-title"></div><button data-mobile-go="setup">Edit fixtures</button>';
 $('.stage-live').after(actions);
 // Beta 0.20: sequence picker and zoom slider live directly under the phone layout.
 const quick=document.createElement('div');quick.className='mobile-only mobile-under-layout';
 quick.innerHTML=`<label class="mobile-quick-sequence" for="mobile-sequence-select"><span>Sequence</span><select id="mobile-sequence-select" aria-label="Sequence for the selected units"><option value="" disabled>Direct DMX</option>${presets.map(p=>`<option value="${p.id}">${pad(p.id)} · ${p.name}</option>`).join('')}</select></label><label class="mobile-quick-zoom" for="mobile-zoom-range"><span>Zoom</span><input id="mobile-zoom-range" type="range" min="10" max="250" step="1" value="${Math.round(state.zoom*100)}" aria-label="Layout zoom"><output id="mobile-zoom-output">${Math.round(state.zoom*100)}%</output></label>`;
 $('#viewport').after(quick);
 $('#mobile-sequence-select').onchange=e=>{const id=Number(e.target.value);if(id)select(id);followLibrary(true)};
 // Keep the original change handler/model, but never depend on a native
 // select popover inside the mobile app's embedded browser.
 const sequenceSelect=$('#mobile-sequence-select');
 studioSequencePicker=mountMobileSequencePicker(sequenceSelect,{buttonId:'studio-sequence-open',title:'Fixture Sequence'});
 sequenceSelect.hidden=true;
 sequenceSelect.closest('label').htmlFor='studio-sequence-open';
 $('#mobile-zoom-range').oninput=e=>setZoom(Number(e.target.value)/100);
 const invert=$('#controls-invert');
 invert.type='button';invert.id='mobile-stage-invert';invert.textContent='Invert';invert.setAttribute('aria-pressed','false');
 invert.onclick=()=>$('#fixture-invert').click();
 $('#undo-layout').before(invert);
 function showPanel(next,restore=true){
  if(!media.matches)return;
  if(document.body.dataset.mobilePanel)positions[panel]=window.scrollY;
  panel=next;document.body.dataset.mobilePanel=panel;try{sessionStorage.setItem('wave-mobile-panel',panel)}catch{}
  $('#mobile-section-title').textContent=labels[panel];
  document.querySelectorAll('[data-mobile-view]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.mobileView===panel)));
  requestAnimationFrame(()=>{resize();window.scrollTo({top:restore?(positions[panel]||0):0,behavior:'instant'});if(['sequences','stage','faders'].includes(panel))followLibrary(true)});
 }
 document.querySelectorAll('[data-mobile-view]').forEach(b=>b.onclick=()=>showPanel(b.dataset.mobileView));
 actions.querySelectorAll('[data-mobile-go]').forEach(b=>b.onclick=()=>showPanel(b.dataset.mobileGo));
 function syncSize(){
  applyDefaultTheme();
  if(media.matches)showPanel(panel,false);
  else{delete document.body.dataset.mobilePanel;document.body.classList.remove('mobile-options-open');more.textContent='More';more.setAttribute('aria-expanded','false')}
 }
 media.addEventListener('change',syncSize);syncSize();
}
mountMobileWorkspace();
const fuelPanel=document.createElement('div');fuelPanel.className='fuel-panel';fuelPanel.id='selection-fuel';fuelPanel.setAttribute('aria-label','Selected Unit Fuel Estimates');
function placeFuelPanel(){if(document.body.classList.contains('custom-workspace-mode')||document.body.classList.contains('workspace-focus-mode'))return;if(matchMedia('(max-width:700px)').matches)$('.stage-actions').append(fuelPanel);else $('.selection-tools').after(fuelPanel)}
placeFuelPanel();matchMedia('(max-width:700px)').addEventListener('change',placeFuelPanel);
document.addEventListener('wave-workspace-layout',placeFuelPanel);
fuelUI=mountFuelUI({ledger:fuel,container:$('#fixture-handles'),selector:'[data-fixture]',idOf:el=>+el.dataset.fixture,findFixture:id=>state.fixtures.find(f=>f.id===id),getFixtures:()=>state.fixtures,getSelected:()=>state.selectedIds,panel:fuelPanel,onOpen:cancelGesture,onRefill:()=>{draw();sessions?.record('Fuel Settings / Refill')},bindContext:false});
$('#zoom-value').value=Math.round(state.zoom*100);
renderList();updateDetails();resize();renderFixtures();requestAnimationFrame(animate);
window.waveStudio={presets,sample,state,stageDuration,geometry,flameRadius,fixtureSample,fixtureIndicator,outputPositions,flameProfile,dmxEngine,decodeProgram,playback:playbackUI.bank,fuel,layoutChase};
workspaceUI=mountWorkspace({onChange:()=>sessions?.record('Workspace Preferences'),onResize:resize,cancelGesture,isLive:()=>state.live,timecode,ma:()=>createMAPanel(maEngine,{mapping:{patchKeys:start=>playbackUI.patchMaKeys(start),clearKeys:()=>playbackUI.clearMaKeys()}}),timing:()=>{
 const bank=playbackUI?.bank;if(state.live)return {nextCue:null,label:'Live Input: Cue Time Unavailable'};
 if(layoutChase.running){const beat=layoutChase.at();return {nextCue:beat?beat.beat-beat.within:null,label:beat?'Until Next Layout Chase Unit':'Layout Chase Paused At 0 BPM'}}
 if(bank?.enabled){const t=playbackUI.transportState();return {nextCue:Math.max(0,t.total-t.time),label:'Fader Cue Remaining'}}
 const end=stageDuration()-stageGap(),remaining=state.time<end?(end-state.time)/state.speed+stageGap():stageDuration()-state.time;
 return {nextCue:Math.max(0,remaining),label:!state.playing?'Paused':$('#tour').checked?'Until Auto-Next Cue':'Auto-Next Off'};
}});
sessions=mountSessions({capture:exportLayout,apply:applyLayoutDocument,host:$('.layout-files')});
mountSupport({workspace:workspaceUI,state});
mountMobileStagePanels({workspace:workspaceUI});
mountMobileMaPanel();
// Layout panel copy of the rotate controls, beside Select Multiple / Undo.
($('.layout-selection-actions')||$('.zoom-controls')).append(makeRotateControls('layout-'));syncRotationControls(state.selectedIds.length>0);
function runningSequences(){
 const bank=playbackUI?.bank,groups=new Map(),direct=[];
 for(const f of state.fixtures){
  let p=null;
  try{p=state.live?dmxEngine.view(f,state.liveTime)?.preset:bank?.enabled?bank.view(f,state.fixtures,state.selectedIds)?.preset:null}catch{}
  if(!p&&!state.live)p=presets[f.presetId-1];
  if(!p||!Number.isInteger(p.id)){direct.push(f.id);continue}
  if(!groups.has(p.id))groups.set(p.id,{id:p.id,name:p.name,units:[]});
  groups.get(p.id).units.push(f.id);
 }
 const look=state.live?'Live Input':layoutChase.running?'Layout Chase':bank?.enabled?'Fader Playback':'';
 const info=describeSequences([...groups.values()],{look,total:state.fixtures.length});
 if(direct.length){info.detail=(groups.size?info.detail+'  ·  ':'')+`Direct Control (${direct.length} Unit${direct.length===1?'':'s'})`;info.key+=`|d${direct.join('.')}`}
 return info;
}
stageRecorder=mountStageRecorder({canvas,host:$('.layout-files'),overlay:$('.view-top'),onChange:()=>sessions?.record('Recording Preferences'),getSequence:runningSequences});
mountSettingsHub({workspace:workspaceUI,capture:exportLayout,saveSession:()=>sessions.saveNow()});
const quickActions=mountQuickActions({state,actions:{
 home:homeSelected,invert:()=>$('#fixture-invert').click(),applyAll:()=>$('#apply-all').click(),selectAll:()=>$('#select-all-fixtures').click(),fitView:()=>fitFlameView(),remove:deleteSelectedFixtures,
 select:id=>activateFixture(id),cancelGesture,
 fuel:(id,el)=>fuelUI.open(id,el),
 rename:()=>{const input=$('#fixture-name');input?.scrollIntoView({block:'center',behavior:'smooth'});input?.focus({preventScroll:true});input?.select()}
}});
$('#shortcuts').onclick=()=>quickActions.toggleShortcuts();
for(const axis of ['x','y']){const input=$(`#fixture-${axis}`);input.min='-10000';input.max='10000'}
if(location.protocol==='http:'&&['localhost','127.0.0.1'].includes(location.hostname)){
 fetch('/api/info',{signal:AbortSignal.timeout(2500)}).then(r=>r.ok?r.json():null).then(info=>{
  if(info?.app==='wave-studio-receiver'&&!info.preview&&info.protocol!=='none'&&!dmxConnecting&&!state.live)configureReceiver(info);
 }).catch(()=>{});
}
