import {presets, sample} from './presets.js?v=v0340-20261007f';
import {limitSample,DMXEngine} from './dmx.js?v=v0340-20261007f';
import {defaultMapping,validateMapping} from './control-map.js?v=v0340-20261007f';

const bounded=(v,a,b)=>Math.max(a,Math.min(b,v));
const integer=(v,a,b)=>Number.isInteger(v)&&v>=a&&v<=b;
const finite=(v,a,b)=>Number.isFinite(v)&&v>=a&&v<=b;
export const channelNames=['Angle','Speed','Ignition','Open Time','Program','Arm (50%)'];
const defaultLabel=i=>i<6?`Fader ${i+1} - ${channelNames[i]}`:'DMX Channel';
const freshSlot=i=>({kind:'cue',cueId:null,dmxPriority:i<6,flashLevel:100,loop:true,cueLabel:'Cue',dmxLabel:defaultLabel(i),wheelStep:i===5?50:1,defaultCueLabel:'Cue',defaultDmxLabel:defaultLabel(i),defaultMode:i<6?'dmx':'cue'});
const freshRuntime=i=>({level:0,held:new Set(),started:0,flashStarted:0,stamp:0});
const freshTiming=()=>({delay:0,fadeIn:0,hold:0,fadeOut:0});
export const MACRO_ACTIONS=[['none','Unassigned'],['level','Set Fader Level'],['flash','Hold Fader Flash'],['flashAll','Hold All Fader Flashes'],['release','Release Fader'],['releaseAll','Release All'],['master','Set Bank Master'],['blackout','Blackout Bank'],['restoreMaster','Restore Bank Master'],['playPause','Play / Pause'],['restart','Restart Current Cue'],['previousCue','Previous Cue'],['nextCue','Next Cue'],['firstCue','First Cue In List'],['lastCue','Last Cue In List'],['toggleLoop','Toggle Loop'],['toggleAutoNext','Toggle Auto-Next'],['selectAll','Select All Units'],['home','Home Selected Units'],['clearSelection','Clear Selection'],['invertSelected','Invert Selected Units'],['fitView','Fit Layout View'],['toggleLock','Lock / Unlock Layout']];
// Names: control characters, zero-width and bidi-override characters are removed when typed and cleaned when files are read.
const HIDDEN=/[\u0000-\u001f\u007f\u200b-\u200d\u202a-\u202e\u2066-\u2069\ufeff]/g;
const cleanText=v=>String(v??'').replace(HIDDEN,' ').replace(/\s+/g,' ').trim();
const freshStack=(id,name)=>({id,name:cleanText(name??(id===1?'Main Stack':`Stack ${id}`)).slice(0,48)||`Stack ${id}`,loop:false,entries:[]});
const freshMacros=()=>Array.from({length:12},(_,i)=>({name:i===0?'Release All':i===1?'Flash All':`Macro ${i+1}`,action:i===0?'releaseAll':i===1?'flashAll':'none',target:2,value:100}));

// Local visual playback only. No network API, hardware output or DMX transmission.
export class PlaybackBank {
 constructor(){
  this.enabled=false;this.time=0;this.serial=0;this.cues=[];this.nextId=1;
  this.grandMaster=100;this.macros=freshMacros();
  this.selection={ids:[],activeId:null};
  this.virtualEngine=new DMXEngine();this.virtualTime=0;this.virtualValues=Array(512).fill(0);this.virtualIds=new Set();this.virtualSignature='';
  this.controlMapping=defaultMapping();
  this.slots=Array.from({length:20},(_,i)=>freshSlot(i));
  this.runtime=Array.from({length:20},(_,i)=>freshRuntime(i));
  this.chase={targets:[],all:true,presetId:8,bpm:120,direction:'forward',width:1,duty:60,loop:true};
  this.stacks=[freshStack(1)];
 }
 // Cue stacks (Beta 0.30): ordered cuelists that step through recorded cues with Go, Follow or Timecode triggers.
 stack(id){return this.stacks.find(s=>s.id===id)}
 addStack(name){if(this.stacks.length>=16)throw Error('Use up to 16 cue stacks.');const id=Math.max(0,...this.stacks.map(s=>s.id))+1;const st=freshStack(id,name);this.stacks.push(st);return st}
 renameStack(id,name){const st=this.stack(id);if(!st)throw Error('Stack not found.');const n=cleanText(name);if(!n||n.length>48)throw Error('Stack names use 1–48 characters.');st.name=n}
 deleteStack(id){if(this.stacks.length<=1)throw Error('Keep at least one cue stack.');this.stacks=this.stacks.filter(s=>s.id!==id)}
 addStackEntry(stackId,cueId,at=null){
  const st=this.stack(stackId),cue=this.cues.find(c=>c.id===cueId);if(!st||!cue)throw Error('Choose a recorded cue first.');
  if(st.entries.length>=200)throw Error('Use up to 200 entries per stack.');
  const entry={cueId,trigger:'go',wait:0,timecode:'',notes:''};
  st.entries.splice(at==null?st.entries.length:Math.max(0,Math.min(st.entries.length,at)),0,entry);return entry;
 }
 updateStackEntry(stackId,index,change){
  const st=this.stack(stackId),e=st?.entries[index];if(!e)throw Error('Stack entry not found.');
  const next={...e,...change};PlaybackBank.validateStacks([{...st,entries:st.entries.map((x,i)=>i===index?next:x)}],new Set(this.cues.map(c=>c.id)));st.entries[index]=next;return next;
 }
 moveStackEntry(stackId,from,to){const st=this.stack(stackId);if(!st||from<0||from>=st.entries.length||to<0||to>=st.entries.length)return;const [e]=st.entries.splice(from,1);st.entries.splice(to,0,e)}
 removeStackEntry(stackId,index){const st=this.stack(stackId);if(st)st.entries.splice(index,1)}
 static validateStacks(stacks,ids){
  if(stacks===undefined)return [freshStack(1)];
  if(!Array.isArray(stacks)||!stacks.length||stacks.length>16)throw Error('Invalid cue stacks');
  const seen=new Set();
  const out=stacks.map(s=>{
   if(!integer(s?.id,1,999999)||seen.has(s.id)||typeof s.name!=='string'||!s.name.trim()||s.name.length>48||!Array.isArray(s.entries)||s.entries.length>200)throw Error('Invalid cue stack');
   seen.add(s.id);
   if(s.loop!==undefined&&typeof s.loop!=='boolean')throw Error('Invalid cue stack');
   return {id:s.id,name:cleanText(s.name).slice(0,48)||`Stack ${s.id}`,loop:s.loop??false,entries:s.entries.map(e=>{
    if(!ids.has(e?.cueId)||!['go','follow','timecode'].includes(e.trigger)||!finite(e.wait??0,0,600))throw Error('Invalid stack entry');
    const timecode=e.timecode??'',notes=e.notes??'';
    if(typeof timecode!=='string'||(timecode&&!/^\d{2}:\d{2}:\d{2}[:;]\d{2}$/.test(timecode))||typeof notes!=='string'||notes.length>200||/[\r\n]/.test(notes))throw Error('Invalid stack entry');
    return {cueId:e.cueId,trigger:e.trigger,wait:e.wait??0,timecode,notes};
   })};
  });
  return out;
 }
 tick(dt,rate=1){this.time+=bounded(dt,0,.1)*bounded(rate,0,1000000)}
 lookTiming(c,i){return c.sequenceTiming?.[i]??{duration:presets[c.sequenceOrder[i]-1].duration,gap:1.1}}
 cueDuration(c){return Math.round((c.sequenceOrder?c.sequenceOrder.reduce((sum,id,i)=>{const t=this.lookTiming(c,i);return sum+t.duration+t.gap},0):Math.max(...c.looks.map(l=>presets[l.presetId-1].duration))+1.1)*100)/100}
 sequenceStep(c,elapsed){
  let at=((elapsed%this.cueDuration(c))+this.cueDuration(c))%this.cueDuration(c);
  for(let i=0;i<c.sequenceOrder.length;i++){
   const id=c.sequenceOrder[i],timing=this.lookTiming(c,i),duration=timing.duration+timing.gap;
   if(at<duration-1e-9||i===c.sequenceOrder.length-1)return {presetId:id,time:Math.max(0,at<timing.duration?at*presets[id-1].duration/timing.duration:presets[id-1].duration+at-timing.duration),index:i};
   at=Math.max(0,at-duration);
  }
 }
 selectGroup(ids,activeId){this.selection={ids:[...ids],activeId}}
 captureGroup(){return this.selection.ids.length>1?structuredClone(this.selection):null}
 level(i){const r=this.runtime[i];return r.held.size?this.slots[i].flashLevel:r.level}
 setLevel(i,value){
  const r=this.runtime[i],n=bounded(Number(value)||0,0,100);
  if(n===r.level)return;
  if(n>0)r.group=this.captureGroup();
  if(!this.slots[i].dmxPriority&&this.slots[i].kind==='cue'&&r.level>0&&n===0){
   const current=this.timed(i),cue=this.cues.find(c=>c.id===this.slots[i].cueId);
   r.release=current.level>0&&cue?.timing?.fadeOut>0?{at:this.time,level:current.level,elapsed:current.elapsed,duration:cue.timing.fadeOut}:null;
  }
  if(r.level===0&&n>0){r.started=this.time;r.stamp=++this.serial}
  if(n>0)r.release=null;
  r.level=n;
 }
 timed(i,clock=this.time){
  const r=this.runtime[i],s=this.slots[i],c=this.cues.find(c=>c.id===s.cueId);
  if(s.dmxPriority||s.kind!=='cue'||!c)return {level:r.level,elapsed:clock-r.started};
  if(r.release&&r.level===0){
   const age=clock-r.release.at;
   return {level:r.release.level*bounded(1-age/r.release.duration,0,1),elapsed:r.release.elapsed+age};
  }
  const t=c.timing??freshTiming(),elapsed=clock-r.started-t.delay;
  if(elapsed<0)return {level:0,elapsed:0};
  const hold=t.hold||this.cueDuration(c);
  const total=t.fadeIn+hold+t.fadeOut;
  if(!s.loop&&elapsed>=total)return {level:0,elapsed};
  const at=elapsed%total;
  const envelope=at<t.fadeIn?at/t.fadeIn:at<t.fadeIn+hold?1:t.fadeOut?1-(at-t.fadeIn-hold)/t.fadeOut:0;
  return {level:r.level*envelope,elapsed:at};
 }
 hold(i,key){
  const r=this.runtime[i];
  if(!r.held.size){r.flashStarted=this.time;r.stamp=++this.serial;r.flashGroup=this.captureGroup()}
  r.held.add(key);
 }
 unhold(i,key){this.runtime[i].held.delete(key)}
 releaseHolds(){this.runtime.forEach(r=>r.held.clear())}
 // Release every running fader or flash whose output reaches any of `ids`. Used by Home. Returns the count released.
 releaseTargeting(ids,fixtures){
  const wanted=new Set(ids);let count=0;
  this.runtime.forEach((r,i)=>{
   if(r.level<=0&&!r.held.size)return;
   const s=this.slots[i],group=r.held.size?r.flashGroup:r.group;
   let targets;
   if(s.dmxPriority)targets=group?group.ids:[...this.virtualIds];
   else if(s.kind==='chase')targets=group?group.ids:this.chaseTargets(fixtures);
   else{const cue=this.cues.find(c=>c.id===s.cueId);targets=group?group.ids:(cue?.looks.map(l=>l.fixtureId)??[])}
   if(!targets.some(id=>wanted.has(id)))return;
   r.level=0;r.held.clear();r.release=null;r.started=this.time;count++;
  });
  if(count)this.clearVirtual();
  return count;
 }
 releaseAll(){this.runtime.forEach(r=>{r.level=0;r.held.clear();r.started=this.time;r.release=null;r.group=null;r.flashGroup=null});this.clearVirtual()}
 master(){return 1}
 clearVirtual(){this.virtualEngine.clear();this.virtualValues.fill(0);this.virtualIds.clear();this.virtualSignature=''}
 playable(i){const s=this.slots[i];return s.dmxPriority?this.controlMapping.bindings[i].address>0:s.kind==='chase'||s.cueId!==null}
 setPriority(i,enabled){this.resetSlot(i);this.runtime[i].group=this.captureGroup();this.slots[i].dmxPriority=!!enabled;this.clearVirtual()}
 updateVirtual(fixtures,dt){
  this.virtualTime+=bounded(dt,0,.1);
  if(!this.enabled){this.clearVirtual();return}
  const slots=this.slots.map((s,i)=>({s,i,address:this.controlMapping.bindings[i].address,universe:(this.controlMapping.bindings[i].universe??this.controlMapping.universe)-1})).filter(x=>x.s.dmxPriority&&x.address);
  const universe=this.controlMapping.universe-1;
  const frames=new Map(),targetIds=new Set(),routes=[];
  const write=(u,address,value)=>{if(!frames.has(u))frames.set(u,Array(512).fill(0));const frame=frames.get(u);frame[address-1]=Math.max(frame[address-1],value)};
  for(const {i,address,universe:slotUniverse} of slots){
   const r=this.runtime[i],group=r.held.size?r.flashGroup:r.group;
   const source=fixtures.find(f=>f.patch.universe===slotUniverse&&address>=f.patch.address&&address<f.patch.address+6);
   const recipients=source?(group?fixtures.filter(f=>group.ids.includes(f.id)):[source]):[];
   const value=Math.round(this.level(i)*255/100);
   if(!recipients.length)write(slotUniverse,address,value);
   for(const f of recipients){const targetAddress=f.patch.address+address-source.patch.address;write(f.patch.universe,targetAddress,value);targetIds.add(f.id);routes.push([i,f.id,f.patch.universe,targetAddress])}
  }
  const targets=fixtures.filter(f=>targetIds.has(f.id));
  const signature=JSON.stringify([universe,routes]);
  if(signature!==this.virtualSignature){this.virtualEngine.clear();this.virtualSignature=signature}
  this.virtualIds=targetIds;this.virtualValues=frames.get(universe)??Array(512).fill(0);
  // A complete in-memory frame only: never sent over a socket, USB or network.
  for(const [u,values] of frames)this.virtualEngine.ingest({universe:u,values,source:'Virtual faders',sourceId:'virtual-bank'},targets,this.virtualTime);
  this.virtualEngine.tick(targets,this.virtualTime);
 }
 virtualOwns(f){return this.enabled&&this.virtualIds.has(f.id)}
 record(name,fixtures,ids){
  if(this.cues.length>=64)throw Error('The cue library is full (64 cues). Delete an unused cue first.');
  const looks=fixtures.filter(f=>ids.includes(f.id)).map(f=>({fixtureId:f.id,presetId:f.presetId}));
  if(!looks.length)throw Error('Select at least one fixture before recording.');
  if(this.nextId>999999){this.nextId=1;while(this.cues.some(c=>c.id===this.nextId))this.nextId++}
  const cue={id:this.nextId++,name:cleanText(name).slice(0,48)||`Cue ${this.nextId-1}`,looks,timing:freshTiming()};
  this.cues.push(cue);return cue;
 }
 recordSequence(name,fixtures,ids,order,timing){
  if(!Array.isArray(order)||!order.length||order.length>88||order.some(id=>!integer(id,1,88)))throw Error('Star at least one valid sequence first.');
  const times=timing??order.map(id=>({duration:presets[id-1].duration,gap:1.1}));
  if(times.length!==order.length||times.some(t=>!finite(t?.duration,.01,10)||!finite(t?.gap,0,60)))throw Error('Use look durations 0.01–10 s and gaps 0–60 s.');
  const cue=this.record(name||'Favorites chase',fixtures,ids);
  cue.sequenceOrder=[...order];cue.sequenceTiming=times.map(t=>({duration:t.duration,gap:t.gap}));
  return cue;
 }
 updateCue(id,name,fixtures,ids){
  const c=this.cues.find(c=>c.id===id);
  if(!c)throw Error('Choose an existing cue.');
  const looks=fixtures.filter(f=>ids.includes(f.id)).map(f=>({fixtureId:f.id,presetId:f.presetId}));
  if(!looks.length)throw Error('Select fixtures before updating this cue.');
  c.name=cleanText(name).slice(0,48)||c.name;c.looks=looks;
  this.slots.forEach((s,i)=>{if(s.cueId===id)this.resetSlot(i)});
 }
 deleteCue(id){
  this.cues=this.cues.filter(c=>c.id!==id);
  for(const st of this.stacks)st.entries=st.entries.filter(e=>e.cueId!==id);
  this.slots.forEach((s,i)=>{if(s.cueId===id){s.cueId=null;this.resetSlot(i)}});
 }
 resetSlot(i){this.runtime[i]=freshRuntime(i)}
 assign(i,cueId){this.slots[i].kind=cueId==='chase'?'chase':'cue';this.slots[i].cueId=cueId==='chase'?null:cueId;this.resetSlot(i)}
 chaseTargets(fixtures){
  return this.chase.all?[...fixtures].sort((a,b)=>a.x-b.x||a.id-b.id).map(f=>f.id):this.chase.targets.filter(id=>fixtures.some(f=>f.id===id));
 }
 chaseStep(fixtures,elapsed,held=false){
  const ids=this.chaseTargets(fixtures),n=ids.length;
  if(!n)return null;
  const seconds=60/this.chase.bpm,step=Math.floor(elapsed/seconds),within=elapsed%seconds;
  const cycle=this.chase.direction==='bounce'&&n>1?2*n-2:n;
  if(!held&&!this.chase.loop&&step>=cycle)return null;
  let index=step%cycle;
  if(this.chase.direction==='reverse')index=n-1-index;
  else if(this.chase.direction==='bounce'&&index>=n)index=cycle-index;
  const active=Array.from({length:Math.min(n,this.chase.width)},(_,j)=>ids[(index+j)%n]);
  return {active,within,gate:within<seconds*this.chase.duty/100,step,index};
 }
 view(fixture,fixtures,selection,clock=this.time){
  if(this.virtualOwns(fixture)){
   const view=this.virtualEngine.view(fixture,this.virtualTime),r=this.virtualEngine.record(fixture);
   const armed=r.values?.[5]>=50&&r.values?.[5]<=200;
   return {...view,intensity:armed?this.grandMaster/100:0,slot:null,virtualDmx:true};
  }
  const candidates=[],master=this.master(fixture,selection);
  for(let i=0;i<20;i++){
   const r=this.runtime[i],slot=this.slots[i];
   if(slot.dmxPriority)continue;
   for(const flash of [false,true]){
    if(!flash&&r.held.size)continue;
    const timed=this.timed(i,clock);
    const level=flash?(r.held.size?slot.flashLevel:0):timed.level;
    if(level<=0)continue;
    const elapsed=flash?clock-r.flashStarted:timed.elapsed;
    const group=flash?r.flashGroup:r.group;
    if(group&&!group.ids.includes(fixture.id))continue;
    let presetId,time,gate=true,windowLength=Infinity;
    if(slot.kind==='chase'){
     const step=this.chaseStep(fixtures,elapsed,flash);
     if(!step||(!group&&!step.active.includes(fixture.id)))continue;
     presetId=this.chase.presetId;time=step.within;gate=step.gate;windowLength=60/this.chase.bpm*this.chase.duty/100;
    }else{
     const cue=this.cues.find(c=>c.id===slot.cueId),look=group?(cue?.looks.find(l=>l.fixtureId===group.activeId)??cue?.looks[0]):cue?.looks.find(l=>l.fixtureId===fixture.id);
     if(!look)continue;
     if(cue.sequenceOrder){
      const step=this.sequenceStep(cue,elapsed);presetId=step.presetId;time=step.time;
     }else{
      presetId=look.presetId;
      // Whole cue uses a shared duration so fixtures stay in sync.
      time=elapsed%this.cueDuration(cue);
     }
    }
    const intensity=level/100*(flash?1:master);
    candidates.push({presetId,time,intensity,gate,windowLength,stamp:r.stamp+(flash?.5:0),slot:i});
   }
  }
  candidates.sort((a,b)=>b.intensity-a.intensity||b.stamp-a.stamp||b.slot-a.slot);
  const win=candidates[0],p=presets[(win?.presetId??fixture.presetId)-1];
  const intensity=(win?.intensity??0)*this.grandMaster/100;
  return {preset:p,time:win?.time??0,intensity,slot:win?.slot??null,
   sample:t=>{
    const s=limitSample(fixture,sample(p,t));
    return {...s,on:s.on&&intensity>0&&!!win?.gate&&t<win.windowLength};
   }};
 }
 serialize(){return {version:2,cues:structuredClone(this.cues),slots:structuredClone(this.slots),chase:structuredClone(this.chase),macros:structuredClone(this.macros),controlMapping:structuredClone(this.controlMapping),stacks:structuredClone(this.stacks)}}
 static validate(data){
  if(data===undefined)return new PlaybackBank().serialize();
  if(![1,2].includes(data?.version)||!Array.isArray(data.cues)||data.cues.length>64||!Array.isArray(data.slots)||![10,20].includes(data.slots.length))throw Error('Invalid playback bank');
  const ids=new Set();
  for(const c of data.cues){
   if(c.sequenceOrder!==undefined&&(!Array.isArray(c.sequenceOrder)||!c.sequenceOrder.length||c.sequenceOrder.length>88||c.sequenceOrder.some(id=>!integer(id,1,88))))throw Error('Invalid sequence chase');
   if(c.sequenceTiming!==undefined&&(!c.sequenceOrder||!Array.isArray(c.sequenceTiming)||c.sequenceTiming.length!==c.sequenceOrder.length||c.sequenceTiming.some(t=>!finite(t?.duration,.01,10)||!finite(t?.gap,0,60))))throw Error('Invalid look timing');
   if(!integer(c.id,1,999999)||ids.has(c.id)||typeof c.name!=='string'||!c.name.trim()||c.name.length>48||!Array.isArray(c.looks)||!c.looks.length||c.looks.length>40)throw Error('Invalid cue');
   ids.add(c.id);const seen=new Set();
   const timing=c.timing??freshTiming();
   for(const key of ['delay','fadeIn','hold','fadeOut'])if(!finite(timing[key],0,600))throw Error('Invalid cue timing');
   for(const l of c.looks){if(!integer(l.fixtureId,1,999999)||seen.has(l.fixtureId)||!integer(l.presetId,1,88))throw Error('Invalid cue look');seen.add(l.fixtureId)}
  }
  data.slots.forEach((s,i)=>{
   if(s.wheelStep!==undefined&&!finite(s.wheelStep,.1,100))throw Error('Invalid wheel increment');
   if(s.defaultMode!==undefined&&!['dmx','cue'].includes(s.defaultMode))throw Error('Invalid default mode');
   for(const key of ['cueLabel','dmxLabel','defaultCueLabel','defaultDmxLabel'])if(s[key]!==undefined&&(typeof s[key]!=='string'||!s[key].trim()||s[key].length>32||/[\r\n]/.test(s[key])))throw Error('Invalid fader label');
   const validKind=data.version===1?s.kind===(i===0?'intensity':i===1?'chase':'cue'):['cue','chase'].includes(s.kind);
   if(!validKind||(data.version===2&&typeof s.dmxPriority!=='boolean')||!finite(s.flashLevel,0,100)||typeof s.loop!=='boolean'||(s.cueId!==null&&!ids.has(s.cueId)))throw Error('Invalid fader');
  });
  const c=data.chase;
  if(!c||!Array.isArray(c.targets)||c.targets.length>40||new Set(c.targets).size!==c.targets.length||c.targets.some(id=>!integer(id,1,999999))||typeof c.all!=='boolean'||typeof c.loop!=='boolean'||!integer(c.presetId,1,88)||!finite(c.bpm,20,300)||!integer(c.width,1,40)||!finite(c.duty,5,100)||!['forward','reverse','bounce'].includes(c.direction))throw Error('Invalid chase');
  // Whitelist fields rather than restoring arbitrary imported object keys.
  const macros=data.macros??freshMacros();
  if(!Array.isArray(macros)||macros.length!==12||macros.some(m=>typeof m.name!=='string'||m.name.length>32||!MACRO_ACTIONS.some(([id])=>id===m.action)||!integer(m.target,0,19)||!finite(m.value,0,100)))throw Error('Invalid macros');
  const stacks=PlaybackBank.validateStacks(data.stacks,ids);
  return {version:2,stacks,cues:data.cues.map(c=>({id:c.id,name:cleanText(c.name).slice(0,48)||`Cue ${c.id}`,looks:c.looks.map(l=>({fixtureId:l.fixtureId,presetId:l.presetId})),timing:{...freshTiming(),...c.timing},...(c.sequenceOrder?{sequenceOrder:[...c.sequenceOrder],sequenceTiming:c.sequenceOrder.map((id,i)=>({duration:c.sequenceTiming?.[i].duration??presets[id-1].duration,gap:c.sequenceTiming?.[i].gap??1.1}))}:{})})),slots:[...data.slots,...Array.from({length:20-data.slots.length},(_,i)=>freshSlot(data.slots.length+i))].map(s=>({kind:s.kind==='intensity'?'cue':s.kind,cueId:s.cueId,dmxPriority:data.version===1?false:s.dmxPriority,flashLevel:s.flashLevel,loop:s.loop,cueLabel:s.cueLabel??'Cue',dmxLabel:s.dmxLabel??'DMX channel',wheelStep:s.wheelStep??1,defaultCueLabel:s.defaultCueLabel??s.cueLabel??'Cue',defaultDmxLabel:s.defaultDmxLabel??s.dmxLabel??'DMX channel',defaultMode:s.defaultMode??(data.version===2&&s.dmxPriority?'dmx':'cue')})),chase:{targets:[...c.targets],all:c.all,presetId:c.presetId,bpm:c.bpm,direction:c.direction,width:c.width,duty:c.duty,loop:c.loop},macros:macros.map((m,i)=>({name:cleanText(m.name).slice(0,32)||`Macro ${i+1}`,action:m.action,target:m.target,value:m.value})),controlMapping:validateMapping(data.controlMapping)};
 }
 restore(data,applyDefaults=false){
  const v=PlaybackBank.validate(data);
  this.cues=v.cues;this.slots=v.slots;this.chase=v.chase;this.macros=v.macros;this.stacks=v.stacks;this.grandMaster=100;
  if(applyDefaults)this.slots.forEach(s=>{s.dmxPriority=s.defaultMode==='dmx';s.cueLabel=s.defaultCueLabel;s.dmxLabel=s.defaultDmxLabel});
  this.controlMapping=v.controlMapping;
  this.nextId=Math.max(0,...this.cues.map(c=>c.id))+1;
  this.runtime=Array.from({length:20},(_,i)=>freshRuntime(i));
  this.clearVirtual();
  this.enabled=false;
 }
}
