/* Studio-only Pete behaviours, layered on the shared widget (pete/vls-avatar.js stays untouched so it
 * remains identical to the extension copy):
 *  1. Hands: with Always on top off and Pete tucked in behind a panel, his hands hang over its top edge.
 *  2. Quiet bubbles: unprompted remarks shrink to a small note. The question box only shows when he
 *     needs an answer (you opened him, you are asking, or his line ends in a question).
 *  3. Placement: the bubble goes on the side of him with the most open space on screen.
 *  4. Gravity: let go anywhere other than a panel and he falls to the bottom of the screen looking
 *     worried, then stumbles on landing. A fast scroll down knocks him down too. It can be turned off
 *     in his settings (Look tab, Moving around).
 *  5. Talk to Pete: a small red dot in his icon bar. Press it and speak; the browser's own speech
 *     service turns the words into text, which is asked like a typed question.
 *  6. Settings: a Pete Browser Extension download row under Open Pete. */
(function () {
  'use strict';
  var A = window.VLSAvatar;
  var root = document.querySelector('.vls-av-root');
  if (!A || !root) return;
  var stage = root.querySelector('.vls-av-stage'), svg = root.querySelector('.vls-av-svg'), bubble = root.querySelector('.vls-av-bubble');
  if (!stage || !svg || !bubble) return;
  var NS = 'http://www.w3.org/2000/svg';
  function reduced() { return !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches); }
  function has(c) { return root.classList.contains(c); }
  function flag(c, on) { if (has(c) !== !!on) root.classList.toggle(c, !!on); }

  var css =
    // hands over the panel edge
    '.vls-av-root .sp-hands{position:absolute;left:0;top:0;width:150px;height:30px;pointer-events:none;display:none;z-index:3}' +
    '.vls-av-root.vls-tucked:not(.vls-tuck-off):not(.vls-dragging):not(.vls-hidden) .sp-hands{display:block}' +
    '.vls-av-root .sp-hands svg{display:block;width:100%;height:100%;overflow:visible}' +
    '.vls-av-root .sp-hands .sp-hand{transform-box:fill-box;transform-origin:50% 0}' +
    '@media (prefers-reduced-motion:no-preference){.vls-av-root .sp-hands .sp-hand-l{animation:sp-grip 6s ease-in-out infinite}.vls-av-root .sp-hands .sp-hand-r{animation:sp-grip 6s ease-in-out -2.9s infinite}}' +
    '@keyframes sp-grip{0%,84%,100%{transform:none}89%{transform:translateY(-1.2px) scaleY(.94)}94%{transform:translateY(.4px)}}' +
    // quiet (unprompted) bubbles
    '.vls-av-root.sp-quiet .vls-av-bubble{padding:7px 26px 7px 11px!important;border-radius:12px!important;box-shadow:0 6px 18px rgba(0,0,0,.22),0 0 0 1px rgba(0,0,0,.05)!important}' +
    '@media (min-width:641px){.vls-av-root.sp-quiet .vls-av-bubble{max-width:min(250px,calc(100vw - 40px))!important}}' +
    '.vls-av-root.sp-quiet .vls-av-bubble.vls-on{opacity:.94}' +
    '.vls-av-root.sp-quiet .vls-av-text{font-size:12.5px!important;line-height:1.35;max-height:96px}' +
    '.vls-av-root.sp-quiet .vls-av-name{font-size:10px;margin-bottom:2px;padding-right:8px}' +
    '.vls-av-root.sp-quiet .vls-av-sources{display:none}' +
    '.vls-av-root.sp-quiet .vls-av-close{top:3px!important;right:4px!important;font-size:13px!important}' +
    '.vls-av-root.sp-noask .vls-av-ask{display:none!important}' +
    // open-space placement (desktop); the tail points back at Pete
    '.vls-av-root.sp-bplace .vls-av-bubble{position:absolute!important;left:var(--sp-bx,0px)!important;top:var(--sp-by,0px)!important;right:auto!important;bottom:auto!important;margin:0!important;width:max-content!important}' +
    '.vls-av-root.sp-bplace .vls-av-bubble::after{display:block!important;content:"";position:absolute;width:0;height:0;border-style:solid}' +
    '.vls-av-root.sp-bplace.sp-side-right .vls-av-bubble::after{left:-10px!important;right:auto!important;top:var(--sp-tail,24px)!important;bottom:auto!important;margin-top:-8px;border-width:8px 10px 8px 0!important;border-color:transparent var(--vls-paper) transparent transparent!important}' +
    '.vls-av-root.sp-bplace.sp-side-left .vls-av-bubble::after{right:-10px!important;left:auto!important;top:var(--sp-tail,24px)!important;bottom:auto!important;margin-top:-8px;border-width:8px 0 8px 10px!important;border-color:transparent transparent transparent var(--vls-paper)!important}' +
    '.vls-av-root.sp-bplace.sp-side-above .vls-av-bubble::after{bottom:-10px!important;top:auto!important;left:var(--sp-tail,24px)!important;right:auto!important;margin-left:-8px;border-width:10px 8px 0 8px!important;border-color:var(--vls-paper) transparent transparent transparent!important}' +
    '.vls-av-root.sp-bplace.sp-side-below .vls-av-bubble::after{top:-10px!important;bottom:auto!important;left:var(--sp-tail,24px)!important;right:auto!important;margin-left:-8px;border-width:0 8px 10px 8px!important;border-color:transparent transparent var(--vls-paper) transparent!important}' +
    // falling: worried face, arms up, no bubble or icon bar
    '.vls-av-root.sp-falling .vls-av-bubble,.vls-av-root.sp-falling .vls-av-minibar{opacity:0!important;pointer-events:none!important}' +
    '.vls-av-root.sp-falling .vls-av-svg .vls-av-pupil{transform:translate(0,-3px) scale(.8)!important;transition:none!important}' +
    '.vls-av-root.sp-falling .vls-av-arm-left{animation:sp-flailL .28s ease-in-out infinite alternate!important;opacity:1!important}' +
    '.vls-av-root.sp-falling .vls-av-arm-right{animation:sp-flailR .28s ease-in-out infinite alternate!important;opacity:1!important}' +
    '@keyframes sp-flailL{from{transform:rotate(118deg)}to{transform:rotate(150deg)}}' +
    '@keyframes sp-flailR{from{transform:rotate(-118deg)}to{transform:rotate(-150deg)}}' +
    '.vls-av-root.sp-stumble .vls-av-svg{animation:sp-stumble .8s cubic-bezier(.3,.7,.4,1) 1!important;transform-origin:50% 97%!important}' +
    // red dot: talk to Pete
    '.vls-av-root .vls-av-minibar button.sp-mic .sp-dot{display:block;width:9px;height:9px;border-radius:50%;background:#e23a2e;box-shadow:0 0 0 1.5px rgba(255,255,255,.18)}' +
    '.vls-av-root .vls-av-minibar button.sp-mic:hover .sp-dot,.vls-av-root .vls-av-minibar button.sp-mic:focus-visible .sp-dot{background:#b3170d}' +
    '.vls-av-root .vls-av-minibar button.sp-mic.sp-on{opacity:1!important;background:rgba(226,58,46,.28)!important}' +
    '.vls-av-root .vls-av-minibar button.sp-mic.sp-on .sp-dot{background:#ff3b2f}' +
    '@media (prefers-reduced-motion:no-preference){.vls-av-root .vls-av-minibar button.sp-mic.sp-on .sp-dot{animation:sp-rec 1s ease-in-out infinite}}' +
    '@keyframes sp-rec{0%,100%{box-shadow:0 0 0 0 rgba(255,59,47,.55)}50%{box-shadow:0 0 0 5px rgba(255,59,47,0)}}' +
    '.vls-av-root.sp-listening .vls-av-svg .vls-av-head{transform:rotate(-7deg)!important;transition:none!important}' +
    '@media (prefers-reduced-motion:no-preference){.vls-av-root.sp-listening .vls-av-svg .vls-av-head{transition:transform .25s ease!important}}' +
    '.sp-live{position:absolute!important;width:1px!important;height:1px!important;margin:-1px!important;padding:0!important;overflow:hidden!important;clip:rect(0 0 0 0)!important;white-space:nowrap!important;border:0!important}' +
    '.vls-av-settings .sp-set-note small{max-width:none}' +
    '.vls-av-settings .sp-set-ext{padding:8px 0;border-bottom:1px solid #eadfd0}' +
    '.vls-av-settings .sp-ext-links{display:flex;flex-direction:column;align-items:flex-end;gap:4px;flex:0 0 auto}' +
    '.vls-av-settings .sp-ext-links .vls-av-btn{text-decoration:none;display:inline-block}' +
    '.vls-av-settings .sp-ext-how{font-size:11.5px;color:var(--vls-orange-deep,#c4560f);text-decoration:underline}' +
    '@keyframes sp-stumble{0%{transform:translateY(5px) scale(1.06,.86)}16%{transform:translate(9px,0) rotate(10deg)}34%{transform:translate(-4px,0) rotate(-7deg)}52%{transform:translate(3px,0) rotate(4deg)}72%{transform:rotate(-1.5deg)}100%{transform:none}}';
  var st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);

  /* ---------- 1. hands over the panel edge ---------- */
  // Drawn in Pete's own SVG units (220 wide, the same scale as his figure). The panel edge is y=16:
  // knuckles rest on top of it and the fingers hang over the front.
  var EDGE = 16, HV = 44;
  function hand(cx, cls, mirror) {
    var g = document.createElementNS(NS, 'g'); g.setAttribute('class', 'sp-hand ' + cls);
    var s = mirror ? -1 : 1, fingers = [[-14, 11], [-6.5, 14], [1, 14], [8.5, 11.5]];   // offset, length (pinky on the outside)
    var shadow = '', fill = '';
    fingers.forEach(function (f) {
      var x = cx + s * f[0] - (mirror ? 7 : 0);
      shadow += '<rect x="' + (x + 1.2) + '" y="' + (EDGE + 1) + '" width="7" height="' + (f[1] + 1.5) + '" rx="3.5" fill="rgba(0,0,0,.28)"/>';
      fill += '<rect x="' + x + '" y="' + (EDGE - 3) + '" width="7" height="' + (f[1] + 3) + '" rx="3.5" fill="#f1c9a2" stroke="#c99a72" stroke-width="1.1"/>';
    });
    var knuckles = '<rect x="' + (cx - 17) + '" y="' + (EDGE - 10) + '" width="34" height="12" rx="6" fill="#f1c9a2" stroke="#c99a72" stroke-width="1.1"/>' +
      '<path d="M' + (cx - 15) + ' ' + (EDGE + 0.6) + ' h30" stroke="#f1c9a2" stroke-width="2.4"/>';
    g.innerHTML = shadow + knuckles + fill;
    return g;
  }
  var hands = document.createElement('div'); hands.className = 'sp-hands'; hands.setAttribute('aria-hidden', 'true');
  var hsvg = document.createElementNS(NS, 'svg'); hsvg.setAttribute('viewBox', '0 0 220 ' + HV); hsvg.setAttribute('focusable', 'false');
  hsvg.appendChild(hand(44, 'sp-hand-l', false)); hsvg.appendChild(hand(176, 'sp-hand-r', true));
  hands.appendChild(hsvg); root.appendChild(hands);
  var handKey = '';
  function layoutHands() {
    if (!has('vls-tucked')) return;
    var sw = stage.offsetWidth, sh = stage.offsetHeight; if (!sw || !sh) return;
    var cut = parseFloat(root.style.getPropertyValue('--vls-tuck-cut')); if (!Number.isFinite(cut)) cut = Math.round(sh * 0.54);
    var k = sw / 220, top = stage.offsetTop + (sh - cut) - EDGE * k;
    var key = sw + ',' + stage.offsetLeft + ',' + top.toFixed(1);
    if (key === handKey) return; handKey = key;
    hands.style.width = sw + 'px'; hands.style.height = (HV * k).toFixed(1) + 'px';
    hands.style.left = stage.offsetLeft + 'px'; hands.style.top = top.toFixed(1) + 'px';
  }

  /* ---------- 2. quiet bubbles ---------- */
  var kind = 'say', marks = {}, studioOpenAt = 0;
  function mark(k) { marks[k] = Date.now(); }
  function recent(k, ms) { return marks[k] && Date.now() - marks[k] < ms; }
  A.on('bubble', function (d) { if (!d) return; if (d.open && d.user) { kind = 'open'; mark('open'); } else if (d.open === false) kind = 'say'; queue(true); });
  A.on('ask', function () { kind = 'ask'; mark('ask'); queue(true); });
  A.on('answer', function () { kind = 'answer'; mark('answer'); queue(true); });
  A.on('tip', function () { if (kind !== 'open') kind = 'tip'; mark('tip'); queue(true); });
  A.on('tour', function () { kind = 'tour'; mark('tour'); queue(true); });
  A.on('say', function () {
    if (Date.now() - studioOpenAt < 1600 || recent('open', 350)) kind = 'open';
    else if (recent('answer', 350)) kind = 'answer';
    else if (recent('tip', 350)) kind = 'tip';
    else if (recent('tour', 350)) kind = 'tour';
    else if (kind === 'ask' && recent('ask', 60000) && !(marks.answer > marks.ask)) kind = 'ask';
    else kind = 'say';
    queue(true);
  });
  function classify() {
    if (bubble.classList.contains('vls-settings-on')) return { quiet: false, ask: true };
    var inp = bubble.querySelector('.vls-av-ask input');
    var typing = inp && (document.activeElement === inp || inp.value);
    var t = (bubble.querySelector('.vls-av-text') || {}).textContent || '';
    var asks = /\?["'\u201d\u2019)\]]*\s*$/.test(t.trim());
    var acts = bubble.querySelector('.vls-av-actions'); acts = !!(acts && acts.children.length);
    if (kind === 'open' || kind === 'ask' || typing || asks) return { quiet: false, ask: true };
    if (kind === 'answer' || kind === 'tip' || kind === 'tour' || acts) return { quiet: false, ask: false };
    return { quiet: true, ask: false };
  }

  /* ---------- 3. open-space placement ---------- */
  var CONTENT = /^(BUTTON|INPUT|SELECT|TEXTAREA|A|LABEL|CANVAS|VIDEO|IMG|svg|path|rect|circle|text|H1|H2|H3|H4|H5|P|LI|TD|TH|SPAN|STRONG|EM|B|CODE|OPTION|SUMMARY|LEGEND)$/i;
  function busyAt(x, y) {
    var list; try { list = document.elementsFromPoint(x, y); } catch (e) { return false; }
    for (var i = 0; i < list.length; i++) {
      var el = list[i]; if (root.contains(el)) continue;
      if (el === document.documentElement || el === document.body) return false;
      if (CONTENT.test(el.tagName)) return true;
      if (el.closest && el.closest('button,input,select,textarea,a,canvas,[role=slider],[role=button]')) return true;
      for (var n = el.firstChild; n; n = n.nextSibling) if (n.nodeType === 3 && n.nodeValue.trim()) return true;
      return false;
    }
    return false;
  }
  function busyScore(r) {
    var hits = 0, total = 0;
    for (var i = 0; i < 6; i++) for (var j = 0; j < 4; j++) { total++; if (busyAt(r.x + r.w * (i + 0.5) / 6, r.y + r.h * (j + 0.5) / 4)) hits++; }
    return hits / total;
  }
  function figureRect() {
    var r = stage.getBoundingClientRect(), top = r.top, bottom = r.bottom;
    if (has('vls-tucked')) { var cut = parseFloat(root.style.getPropertyValue('--vls-tuck-cut')) || 0; bottom -= cut; top -= 36; }  // icon bar sits above him when tucked
    return { left: r.left, right: r.right, top: top, bottom: bottom, headY: r.top + r.height * 0.24, cx: r.left + r.width / 2, w: r.width };
  }
  function candidate(side, S, bw, bh) {
    var vw = window.innerWidth, vh = window.innerHeight, M = 8, G = 14, x, y, room;
    if (side === 'right' || side === 'left') {
      x = side === 'right' ? S.right + G : S.left - G - bw;
      y = Math.max(M, Math.min(vh - bh - M, S.headY - bh * 0.45));
      room = side === 'right' ? vw - S.right - G - M : S.left - G - M;
      return { side: side, x: x, y: y, w: bw, h: bh, fits: room >= bw, room: room / bw, tail: Math.max(14, Math.min(bh - 14, S.headY - y)) };
    }
    x = Math.max(M, Math.min(vw - bw - M, S.cx - bw / 2));
    y = side === 'above' ? S.top - G - bh : S.bottom + G;
    room = side === 'above' ? S.top - G - M : vh - S.bottom - G - M;
    return { side: side, x: x, y: y, w: bw, h: bh, fits: room >= bh, room: room / bh, tail: Math.max(16, Math.min(bw - 16, S.cx - x)) };
  }
  var cur = null, lastScore = 0;   // { side, text, cx, cy }; time of the last four-side scoring
  function clearPlace() { flag('sp-bplace', false); ['right', 'left', 'above', 'below'].forEach(function (s) { flag('sp-side-' + s, false); }); cur = null; }
  function place(fresh) {
    if (!bubble.classList.contains('vls-on') || window.innerWidth <= 640 || !has('vls-placed')) { clearPlace(); return; }
    if (has('vls-dragging') || has('sp-falling')) return;
    flag('sp-bplace', true);
    var bw = bubble.offsetWidth, bh = bubble.offsetHeight; if (!bw || !bh) return;
    var S = figureRect(), text = (bubble.querySelector('.vls-av-text') || {}).textContent || '';
    // one side per message: the bubble types out, so a growing line is still the same message
    var moved = !cur || Math.hypot(S.cx - cur.cx, S.headY - cur.cy) > 40;
    var same = cur && (text.indexOf(cur.text) === 0 || cur.text.indexOf(text) === 0);
    var pick = null, now = performance.now();
    // while he walks the bubble follows on its current side; sides are re-scored at most every 150 ms
    // (the scoring hit-tests 96 points, far too much for every animation frame)
    var keep = cur && ((!fresh && !moved && same) || has('vls-walking') || now - lastScore < 150);
    if (keep) { pick = candidate(cur.side, S, bw, bh); if (!pick.fits && !has('vls-walking')) pick = null; }
    if (!pick) {
      lastScore = now;
      var best = null;
      ['right', 'left', 'above', 'below'].forEach(function (side) {
        var c = candidate(side, S, bw, bh);
        // lower is better: share of the area covered by controls and text, then a nudge for roominess and for staying put
        c.score = (c.fits ? 0 : 2 + Math.max(0, 1 - c.room)) + busyScore(c) - Math.min(0.15, (c.room - 1) * 0.03) - (cur && cur.side === side ? 0.08 : 0);
        if (!best || c.score < best.score) best = c;
      });
      pick = best;
    }
    var vw = window.innerWidth, vh = window.innerHeight;
    var x = Math.max(8, Math.min(vw - bw - 8, pick.x)), y = Math.max(8, Math.min(vh - bh - 8, pick.y));
    var rr = root.getBoundingClientRect();
    var bx = Math.round(x - rr.left) + 'px', by = Math.round(y - rr.top) + 'px', tl = Math.round(pick.side === 'left' || pick.side === 'right' ? pick.tail + pick.y - y : pick.tail + pick.x - x) + 'px';
    if (bubble.style.getPropertyValue('--sp-bx') !== bx) bubble.style.setProperty('--sp-bx', bx);
    if (bubble.style.getPropertyValue('--sp-by') !== by) bubble.style.setProperty('--sp-by', by);
    if (bubble.style.getPropertyValue('--sp-tail') !== tl) bubble.style.setProperty('--sp-tail', tl);
    ['right', 'left', 'above', 'below'].forEach(function (s) { flag('sp-side-' + s, s === pick.side); });
    cur = { side: pick.side, text: text, cx: S.cx, cy: S.headY };
  }

  var raf = 0, freshNext = false;
  function queue(fresh) { if (fresh) freshNext = true; if (!raf) raf = requestAnimationFrame(run); }
  function run() {
    raf = 0; var fresh = freshNext; freshNext = false;
    var c = classify(); flag('sp-quiet', c.quiet); flag('sp-noask', !c.ask);
    layoutHands();
    place(fresh);
  }
  new MutationObserver(function (list) {
    var opened = list.some(function (m) { return m.type === 'attributes' && m.target === bubble; });
    queue(opened);
  }).observe(bubble, { attributes: true, attributeFilter: ['class'], childList: true, subtree: true, characterData: true });
  new MutationObserver(function () { queue(false); }).observe(root, { attributes: true, attributeFilter: ['style', 'class'] });
  window.addEventListener('resize', function () { handKey = ''; queue(true); }, { passive: true });
  bubble.addEventListener('focusout', function () { setTimeout(function () { queue(false); }, 0); });
  A.on('tuck', function () { handKey = ''; queue(false); });

  /* ---------- 4. gravity ---------- */
  var MOUTH_SCARED = 'M97 116 q4 -5 8 0 q5 5 10 0 q5 -5 8 0 q-13 12 -26 0z', MOUTH_CLOSED = 'M96 120 q14 6 28 0';
  var fall = null, stumbleTimer = 0, worried = false;
  function floorTop() { return window.innerHeight - stage.offsetHeight - 4; }
  var GKEY = 'vsl-pete-gravity';
  function gravityOn() { try { return localStorage.getItem(GKEY) !== '0'; } catch (e) { return true; } }
  function canFall() {
    if (!gravityOn() || fall || !has('vls-placed') || has('vls-hidden') || has('vls-dragging') || has('vls-tucked') || has('vls-walking')) return false;
    if (rec) return false;                                                             // never while the red dot is listening
    if (bubble.classList.contains('vls-settings-on') && bubble.classList.contains('vls-on')) return false;   // or with settings open
    try { var st = A.getState(); if (st.tucked || st.tour) return false; } catch (e) {}   // or during a tour
    return stage.getBoundingClientRect().top < floorTop() - 6;
  }
  function setWorried(on) {
    worried = on; svg.classList.toggle('vls-av-scared', on);
    var m = svg.querySelector('.vls-av-mouth'); var speaking = false; try { speaking = A.getState().speaking; } catch (e) {}
    if (m && !speaking) m.setAttribute('d', on ? MOUTH_SCARED : MOUTH_CLOSED);
  }
  function startFall() {
    if (!canFall()) return;
    var r = stage.getBoundingClientRect(), x = r.left, y0 = r.top, y1 = floorTop();
    if (reduced()) { A.moveTo(x, y1); return; }
    fall = { x: x, y0: y0, y1: y1, y: y0, v: 0, last: 0, id: 0 };
    flag('sp-falling', true); setWorried(true);
    fall.id = requestAnimationFrame(tick);
  }
  function tick(ts) {
    if (!fall) return;
    var dt = fall.last ? Math.min(0.04, (ts - fall.last) / 1000) : 1 / 60; fall.last = ts;
    fall.v += 3400 * dt; fall.y += fall.v * dt;
    if (fall.y >= fall.y1) return land();
    root.style.transform = 'translateY(' + (fall.y - fall.y0).toFixed(1) + 'px)';
    fall.id = requestAnimationFrame(tick);
  }
  function land() {
    var f = fall; fall = null;
    root.style.transform = '';
    A.moveTo(f.x, f.y1);
    flag('sp-falling', false);
    flag('sp-stumble', true);
    clearTimeout(stumbleTimer);
    stumbleTimer = setTimeout(function () { flag('sp-stumble', false); setWorried(false); queue(true); }, 820);
  }
  function cancelFall() {
    if (fall) { cancelAnimationFrame(fall.id); fall = null; root.style.transform = ''; }
    clearTimeout(stumbleTimer); flag('sp-falling', false); flag('sp-stumble', false);
    if (worried) setWorried(false);   // restores the mouth too; the widget's own grab face takes over while dragging
  }
  A.on('grab', cancelFall);
  // the widget decides whether he tucks in behind a panel before it announces the drop
  A.on('drop', function () { setTimeout(startFall, 40); });
  A.on('visible', function (d) { if (d && d.visible === false) cancelFall(); });

  // a quick scroll down (about 450px inside 150ms in a large scrolling area) knocks him off his feet
  var trail = [], tops = new WeakMap();
  document.addEventListener('scroll', function (e) {
    var el = e.target === document ? (document.scrollingElement || document.documentElement) : e.target;
    if (!el || el.nodeType !== 1 || root.contains(el) || el.clientHeight < window.innerHeight * 0.4) return;
    var now = performance.now(), top = el.scrollTop, prev = tops.get(el);
    tops.set(el, top);
    if (prev == null || top <= prev) { if (top < prev) trail = []; return; }
    trail.push([now, top - prev]);
    while (trail.length && now - trail[0][0] > 150) trail.shift();
    var sum = 0; trail.forEach(function (t) { sum += t[1]; });
    if (sum >= 450) { trail = []; startFall(); }
  }, { capture: true, passive: true });

  /* ---------- settings: Gravity switch and a note about the red dot ---------- */
  var EXT_VERSION = '0.3.2', EXT_ZIP = './pete/Pyro-Pete-Extension-0.3.2.zip';
  function row(label, note) {
    var r = document.createElement('div'); r.className = 'vls-av-set-row';
    var l = document.createElement('label'); l.textContent = label;
    var sm = document.createElement('small'); sm.textContent = note; l.appendChild(sm); r.appendChild(l);
    return r;
  }
  function addSettingsRows() {
    var el = root.querySelector('.vls-av-settings'); if (!el) return;
    var drag = el.querySelector('[data-sw="draggable"]');
    if (drag && !el.querySelector('[data-sp-sw="gravity"]')) {
      var on = gravityOn();
      var r = row('Gravity', 'Let go anywhere but a panel and he falls to the bottom of the screen. A fast scroll knocks him down too.');
      var b = document.createElement('button'); b.type = 'button'; b.className = 'vls-av-switch' + (on ? ' vls-on' : '');
      b.setAttribute('data-sp-sw', 'gravity'); b.setAttribute('role', 'switch'); b.setAttribute('aria-checked', on ? 'true' : 'false'); b.setAttribute('aria-label', 'Gravity');
      b.addEventListener('click', function () {
        var next = !gravityOn();
        try { localStorage.setItem(GKEY, next ? '1' : '0'); } catch (e) {}
        b.classList.toggle('vls-on', next); b.setAttribute('aria-checked', next ? 'true' : 'false');
      });
      r.appendChild(b);
      var after = drag.closest('.vls-av-set-row'); if (after) after.after(r);
    }
    var openRow = el.querySelector('.vls-av-set-open');
    if (openRow && !el.querySelector('.sp-set-ext')) {
      var x = row('Pete Browser Extension', 'Take Pete to any page. Version ' + EXT_VERSION + ' for Comet, Chrome, Edge and Brave, installed unpacked.');
      x.classList.add('sp-set-ext');
      var wrap = document.createElement('span'); wrap.className = 'sp-ext-links';
      var dl = document.createElement('a'); dl.className = 'vls-av-btn vls-primary'; dl.href = EXT_ZIP; dl.setAttribute('download', EXT_ZIP.split('/').pop()); dl.textContent = 'Download';
      var how = document.createElement('a'); how.className = 'sp-ext-how'; how.href = './pete/index.html#extension'; how.target = '_blank'; how.rel = 'noopener'; how.textContent = 'How To Install';
      wrap.appendChild(dl); wrap.appendChild(how); x.appendChild(wrap);
      openRow.after(x);
    }
    var voice = el.querySelector('[data-sw="voice"]');
    if (voice && !el.querySelector('.sp-set-note')) {
      var n = row('Talk to Pete', SR ? 'Press the red dot under him and speak. Your browser\u2019s speech service turns your words into text (Chrome, Edge and Safari may use their makers\u2019 online services), and Pete then asks it like a typed question, so it goes to your own AI provider or the site assistant. Wave Studio does not record audio.' : 'The red dot under him needs a browser with speech input, such as Chrome, Edge or Safari.');
      n.classList.add('sp-set-note');
      var after2 = voice.closest('.vls-av-set-row'); if (after2) after2.after(n);
    }
  }
  var setEl = root.querySelector('.vls-av-settings');
  if (setEl) new MutationObserver(addSettingsRows).observe(setEl, { childList: true });

  /* ---------- talk to Pete (red dot) ---------- */
  var SR = window.SpeechRecognition || window.webkitSpeechRecognition || null;
  var bar = root.querySelector('.vls-av-minibar'), mic = null, rec = null, heard = '', heardFinal = '', micPlaceholder = '', micErr = false;
  function askInput() { return bubble.querySelector('.vls-av-ask input'); }
  function micState(on) {
    if (!mic) return;
    mic.classList.toggle('sp-on', on); mic.setAttribute('aria-pressed', on ? 'true' : 'false');
    mic.title = on ? 'Listening. Press to stop' : (micErr && mic.title !== 'Listening. Press to stop' ? mic.title : 'Talk to Pete');   // keep an error shown on the dot until the next press
    flag('sp-listening', on);
    if (on) announce('Listening'); else if (!micErr) announce('Stopped listening');   // an error message already said why it stopped
    var inp = askInput();
    if (inp) { if (on) { micPlaceholder = inp.placeholder; inp.placeholder = 'Listening\u2026'; } else if (micPlaceholder) { inp.placeholder = micPlaceholder; micPlaceholder = ''; } }
  }
  var live = document.createElement('span'); live.className = 'sp-live'; live.setAttribute('role', 'status'); live.setAttribute('aria-live', 'polite'); root.appendChild(live);
  function announce(t) { live.textContent = ''; setTimeout(function () { live.textContent = t; }, 30); }
  function peteSays(t) {
    announce(t);
    // the widget keeps quiet while settings are open, so the message goes on the red dot instead
    if (bubble.classList.contains('vls-settings-on') && bubble.classList.contains('vls-on')) { if (mic) mic.title = t; return; }
    try { A.say(t, { speak: false, autoHideMs: 6000, mood: 'thinking' }); } catch (e) {}
  }
  function stopListening(abort) { if (!rec) return; try { abort ? rec.abort() : rec.stop(); } catch (e) {} }
  function startListening() {
    if (rec) { stopListening(false); return; }
    if (!SR || !window.isSecureContext) { peteSays('I can only hear you in a browser with speech input, such as Chrome, Edge or Safari.'); return; }
    try { A.stop(); } catch (e) {}                       // so he does not hear himself
    var r; try { r = new SR(); } catch (e) { peteSays('Speech input is not available here.'); return; }
    rec = r; heard = ''; heardFinal = ''; micErr = false;
    r.lang = navigator.language || 'en-US'; r.interimResults = true; r.continuous = false; r.maxAlternatives = 1;
    if (window.VLSPeteStudio) window.VLSPeteStudio.opened();
    try { A.open(); } catch (e) {}
    r.onstart = function () { if (rec === r) micState(true); };
    r.onresult = function (ev) {
      if (rec !== r) return;
      // the input shows everything heard so far; only finished (final) phrases are ever sent
      var t = '', f = ''; for (var i = 0; i < ev.results.length; i++) { t += ev.results[i][0].transcript; if (ev.results[i].isFinal) f += ev.results[i][0].transcript; }
      heard = t.replace(/\s+/g, ' ').trim().slice(0, 500);
      heardFinal = f.replace(/\s+/g, ' ').trim().slice(0, 500);
      var inp = askInput(); if (inp) inp.value = heard;
    };
    r.onerror = function (ev) {
      if (rec !== r) return;
      var c = ev && ev.error;
      micErr = c !== 'aborted';
      if (c === 'not-allowed' || c === 'service-not-allowed') peteSays('I cannot hear you yet. Allow the microphone for this site in your browser, then press the red dot again.');
      else if (c === 'no-speech') peteSays('I did not catch anything. Press the red dot and try again.');
      else if (c === 'network') peteSays('Speech input needs an internet connection.');
      else if (c === 'audio-capture') peteSays('I cannot find a microphone on this device.');
      else if (c !== 'aborted') peteSays('Speech input stopped. Press the red dot to try again.');
      heard = ''; heardFinal = '';
    };
    r.onend = function () {
      if (rec !== r) return;
      rec = null; micState(false);
      var shown = heard, q = heardFinal; heard = ''; heardFinal = '';
      var inp = askInput(); if (inp && inp.value === shown) inp.value = '';
      if (q) { try { A.ask(q); } catch (e) {} }
      else if (shown) peteSays('I only caught part of that. Press the red dot and try again.');
    };
    try { r.start(); } catch (e) { rec = null; micState(false); peteSays('Speech input could not start. Press the red dot to try again.'); }
  }
  if (bar) {
    mic = document.createElement('button'); mic.type = 'button'; mic.className = 'vls-av-mini sp-mic';
    mic.title = 'Talk to Pete'; mic.setAttribute('aria-label', 'Talk to Pete'); mic.setAttribute('aria-pressed', 'false');
    var dot = document.createElement('span'); dot.className = 'sp-dot'; dot.setAttribute('aria-hidden', 'true'); mic.appendChild(dot);
    mic.addEventListener('click', function (e) { e.stopPropagation(); if (e.isTrusted === false) return; startListening(); });   // a real press only, never a scripted click
    var hide = bar.querySelector('.vls-av-mini-hide'); if (hide) bar.insertBefore(mic, hide); else bar.appendChild(mic);
  }
  A.on('visible', function (d) { if (d && d.visible === false) stopListening(true); });
  document.addEventListener('visibilitychange', function () { if (document.hidden) stopListening(true); });
  A.on('grab', function () { stopListening(true); });

  window.VLSPeteStudio = { opened: function () { studioOpenAt = Date.now(); kind = 'open'; mark('open'); queue(true); } };
  queue(true);
})();
