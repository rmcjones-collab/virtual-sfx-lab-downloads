// Wave Studio manual bridge. Runs inside the studio's sandboxed manual viewer (opaque origin):
// in-manual page links are handed to the studio, outside links open in a new tab, and the
// requested section anchor (from a meta tag the studio adds) is applied once the page loads.
(()=>{
 const page=new URL(document.baseURI),base=new URL('./',page).href;
 document.addEventListener('click',e=>{
  const a=e.target.closest('a[href]');if(!a||e.defaultPrevented)return;
  const u=new URL(a.getAttribute('href'),document.baseURI);
  if(u.href.startsWith(base)&&/\.html?$/i.test(u.pathname)){e.preventDefault();parent.postMessage({type:'wave-manual-nav',href:u.href},'*')}
  else if(u.origin!==page.origin){a.target='_blank';a.rel='noopener'}
 });
 addEventListener('message',e=>{if(e.source===parent&&e.data?.type==='wave-manual-hash'&&typeof e.data.hash==='string')location.hash=e.data.hash});
 const hash=document.querySelector('meta[name="wave-manual-hash"]')?.content;
 if(hash&&hash.startsWith('#'))addEventListener('load',()=>{location.hash=hash});
})();
