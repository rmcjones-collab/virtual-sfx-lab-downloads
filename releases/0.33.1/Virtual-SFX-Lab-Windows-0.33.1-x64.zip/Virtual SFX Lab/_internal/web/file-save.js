let openSave=null;
export function fileNameFor(value,extension){
 let name=String(value??'').trim();
 if(!name||/^[.\s]+$/.test(name))throw Error('Enter a file name.');
 if(name.length>160||/[<>:"/\\|?*\u0000-\u001f\u007f\u200b-\u200d\u202a-\u202e\u2066-\u2069\ufeff]/.test(name)||/[. ]$/.test(name))throw Error('Use a file name without folder paths, reserved characters, or trailing dots. Maximum 160 characters.');
 if(/^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(name))throw Error('That name is reserved by some devices. Please choose another name.');
 if(extension&&!name.toLowerCase().endsWith('.'+extension.toLowerCase()))name+='.'+extension;
 return name;
}
// Always called from a manual file action. The picker/share call runs directly
// in the Save button handler, retaining browser user activation.
export function requestFileSave(blob,suggestedName='wave-file.txt'){
 if(openSave)return Promise.resolve(null);
 if(!(blob instanceof Blob))return Promise.reject(Error('No file is ready to save.'));
 const extension=suggestedName.match(/\.([a-z0-9]{1,16})$/i)?.[1]??'',mime=blob.type.split(';')[0]||'application/octet-stream';
 const dialog=document.createElement('dialog');dialog.className='file-save-dialog';dialog.setAttribute('aria-label','Save As');
 dialog.innerHTML='<form><h2>Save As</h2><label>File Name<input name="filename" aria-label="File Name" maxlength="160" required autocomplete="off" spellcheck="false"></label><p data-format></p><label>Destination<select name="destination" aria-label="Save Destination"></select></label><p data-help></p><p data-message role="status" aria-live="polite"></p><div class="file-save-actions"><button type="button" data-cancel>Cancel</button><button type="submit" class="primary">Save</button></div></form>';
 const form=dialog.querySelector('form'),input=form.elements.filename,select=form.elements.destination,message=dialog.querySelector('[data-message]'),save=form.querySelector('[type=submit]'),cancel=form.querySelector('[data-cancel]');
 input.value=suggestedName;dialog.querySelector('[data-format]').textContent=extension?`File format: ${extension.toUpperCase()}. The .${extension} extension is kept automatically.`:'';
 let picker=typeof window.showSaveFilePicker==='function'&&window.isSecureContext&&window.top===window.self,share=false,busy=false,result=null;
 try{share=!!navigator.canShare?.({files:[new File([blob],suggestedName,{type:mime})]})}catch{}
 if(picker)select.add(new Option('Choose a folder on this device…','picker'));
 if(share)select.add(new Option('Device share sheet / Save to Files…','share'));
 select.add(new Option('Browser Downloads','download'));
 function help(){
  dialog.querySelector('[data-help]').textContent=select.value==='picker'?'Choose the folder and confirm the file name in your device’s Save As window. Existing-file overwrite confirmation is handled there.':select.value==='share'?'Your device will show its available destinations. Choose Save to Files if offered, or another destination you intend to use.':'This browser controls the download folder. To choose it each time, enable its “Ask where to save each file” setting if available. Direct folder selection may require opening the app in a supported standalone browser.';
  save.textContent=select.value==='picker'?'Choose Location & Save':select.value==='share'?'Choose Destination…':'Download';
 }
 help();select.onchange=help;
 document.body.append(dialog);
 return new Promise(resolve=>{
  openSave=dialog;
  dialog.addEventListener('close',()=>{openSave=null;dialog.remove();resolve(result)},{once:true});
  dialog.addEventListener('cancel',e=>{if(busy)e.preventDefault()});
  cancel.onclick=()=>{if(!busy)dialog.close()};
  form.onsubmit=async e=>{
   e.preventDefault();if(busy)return;let name;
   try{name=fileNameFor(input.value,extension)}catch(error){message.textContent=error.message;input.focus({preventScroll:true});return}
   busy=true;save.disabled=cancel.disabled=true;input.disabled=select.disabled=true;message.textContent='';
   try{
    if(select.value==='picker'){
     const handle=await window.showSaveFilePicker({id:'wave-studio-files',suggestedName:name,...(extension?{types:[{description:extension.toUpperCase()+' file',accept:{[mime]:['.'+extension]}}]}:{})});
     const writable=await handle.createWritable();
     try{await writable.write(blob);await writable.close()}catch(error){try{await writable.abort()}catch{}throw error}
     result={method:'picker',name:handle.name||name,message:`Saved ${handle.name||name}.`};
    }else if(select.value==='share'){
     await navigator.share({files:[new File([blob],name,{type:mime})],title:name});
     result={method:'share',name,message:`Share sheet completed for ${name}. Check your chosen destination.`};
    }else{
     const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);
     result={method:'download',name,message:`Download requested: ${name}. Check your browser’s downloads.`};
    }
    dialog.close();
   }catch(error){
    if(error.name==='AbortError')message.textContent='Save cancelled. No fallback download was started.';
    else if(['SecurityError','NotAllowedError'].includes(error.name)){
     message.textContent='That destination is blocked in this browser or embedded view. Choose another destination and try again.';
     if(select.value==='picker'){const option=[...select.options].find(o=>o.value==='picker');option.disabled=true;select.value=share?'share':'download';help()}
    }else message.textContent='Could not save the file: '+(error.message||'Try another destination.');
   }finally{busy=false;save.disabled=cancel.disabled=false;input.disabled=select.disabled=false}
  };
  dialog.showModal();input.focus({preventScroll:true});input.select();
 });
}
