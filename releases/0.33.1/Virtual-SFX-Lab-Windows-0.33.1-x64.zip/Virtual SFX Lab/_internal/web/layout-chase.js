// Local visual rehearsal only. Does not produce DMX, network or firing output.
export class LayoutChase {
 constructor(){this.running=false;this.time=0;this.bpm=120;this.direction='forward';this.targets=[];this.seed=1}
 start(fixtures,ids){this.targets=fixtures.filter(f=>ids.includes(f.id)).sort((a,b)=>a.x-b.x||a.id-b.id).map(f=>f.id);this.time=0;this.seed=(this.seed+1)>>>0;this.running=this.targets.length>0}
 stop(){this.running=false;this.time=0}
 setRate(bpm){if(!Number.isFinite(bpm)||bpm<0||bpm>480)throw Error('Use 0–480 BPM');this.bpm=bpm;this.time=0}
 setDirection(value){if(!['forward','backward','random'].includes(value))throw Error('Invalid Chase Direction');this.direction=value;this.time=0}
 tick(dt){if(this.running&&this.bpm>0)this.time+=Math.max(0,Math.min(.1,dt))}
 target(step){
  const n=this.targets.length;if(!n)return null;
  if(this.direction==='forward')return this.targets[step%n];
  if(this.direction==='backward')return this.targets[n-1-step%n];
  // Deterministic shuffled rounds: replayable sample history for flame decay.
  const round=Math.floor(step/n),order=[...this.targets];let seed=(this.seed+round*2654435761)>>>0;
  const random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296};
  for(let i=n-1;i>0;i--){const j=Math.floor(random()*(i+1));[order[i],order[j]]=[order[j],order[i]]}
  return order[step%n];
 }
 at(time=this.time){
  if(!this.running||!this.bpm||time<0||!this.targets.length)return null;
  const beat=60/this.bpm,step=Math.floor(time/beat),within=time-step*beat;
  return {id:this.target(step),step,within,gate:within<beat*.6,beat};
 }
 sample(fixture,preset,sampler,time=this.time){
  const step=this.at(time),within=step?.within??0,result=sampler(fixture,within);
  return {...result,on:!!step&&step.id===fixture.id&&step.gate&&within<preset.duration&&result.on};
 }
}
export function fixtureName(f){return f.name?.trim()||`Flamer ${String(f.id).padStart(2,'0')}`}
export function validFixtureName(name){return name===undefined||typeof name==='string'&&name.length<=48&&!/[\r\n\x00-\x1f\x7f\u200b-\u200d\u202a-\u202e\u2066-\u2069\ufeff]/.test(name)}
export function nextFixturePosition(fixtures){
 const candidates=[.75,.5,.25,.9].flatMap(y=>[.5,.2,.8,.05,.95,.35,.65].map(x=>({x,y})));
 return candidates.find(p=>fixtures.every(f=>Math.hypot(f.x-p.x,f.y-p.y)>.1))??{x:.5,y:.5};
}
