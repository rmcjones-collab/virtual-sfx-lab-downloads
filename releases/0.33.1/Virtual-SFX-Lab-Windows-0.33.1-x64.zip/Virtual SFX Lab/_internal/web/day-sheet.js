// Day Sheet panel. Two sources:
// 1. Screenshots of day sheets: images stay in this browser (IndexedDB), never uploaded.
// 2. Master Tour: the user's own Master Tour API key and secret. Requests are signed here (OAuth 1.0a,
//    HMAC-SHA1, WebCrypto); the Wave Studio server only forwards the already-signed read request to
//    Eventric because Master Tour does not allow direct browser calls. The secret never leaves the browser.
const DB='vsl-daysheet',STORE='images',MAX_IMAGES=24,MAX_BYTES=12*1024*1024;
const MT_KEY='vsl-mastertour';
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function db(){return new Promise((ok,fail)=>{const r=indexedDB.open(DB,1);r.onupgradeneeded=()=>r.result.createObjectStore(STORE,{keyPath:'id'});r.onsuccess=()=>ok(r.result);r.onerror=()=>fail(r.error)})}
async function tx(mode,fn){const d=await db();return new Promise((ok,fail)=>{const t=d.transaction(STORE,mode),s=t.objectStore(STORE);const out=fn(s);t.oncomplete=()=>{d.close();ok(out?.result??out)};t.onerror=()=>{d.close();fail(t.error)}})}
const enc=s=>encodeURIComponent(s).replace(/[!'()*]/g,c=>'%'+c.charCodeAt(0).toString(16).toUpperCase());
async function sign(url,params,key,secret){
 const o={...params,oauth_consumer_key:key,oauth_nonce:[...crypto.getRandomValues(new Uint8Array(16))].map(b=>b.toString(16).padStart(2,'0')).join(''),oauth_signature_method:'HMAC-SHA1',oauth_timestamp:String(Math.floor(Date.now()/1000)),oauth_version:'1.0'};
 const base=['GET',enc(url),enc(Object.keys(o).sort().map(k=>`${enc(k)}=${enc(o[k])}`).join('&'))].join('&');
 const k=await crypto.subtle.importKey('raw',new TextEncoder().encode(`${enc(secret)}&`),{name:'HMAC',hash:'SHA-1'},false,['sign']);
 const sig=new Uint8Array(await crypto.subtle.sign('HMAC',k,new TextEncoder().encode(base)));
 o.oauth_signature=btoa(String.fromCharCode(...sig));return o;
}
export {sign as signMasterTour};
const fmtTime=v=>{const d=new Date(v);return Number.isNaN(+d)?'':d.toLocaleTimeString([],{hour:'numeric',minute:'2-digit'})};
const fmtDate=v=>{const d=new Date(String(v).length===10?`${v}T12:00:00`:v);return Number.isNaN(+d)?String(v??''):d.toLocaleDateString([],{weekday:'long',month:'long',day:'numeric',year:'numeric'})};
const dayKey=v=>String(v??'').slice(0,10);
export function createDaySheet({key,api,headers}){
 const el=document.createElement('section');el.className='day-sheet';
 el.innerHTML=`<div class="ds-tabs" role="tablist"><button type="button" role="tab" data-ds-tab="shots" aria-selected="true">Screenshots</button><button type="button" role="tab" data-ds-tab="mt" aria-selected="false">Master Tour</button></div>
<div class="ds-pane" data-ds-pane="shots"><div class="ds-shot-bar"><button type="button" data-ds-add>Add Screenshots</button><input type="file" accept="image/png,image/jpeg,image/webp,image/gif" multiple hidden data-ds-file><button type="button" data-ds-prev aria-label="Previous Screenshot">◀</button><span class="ds-count"></span><button type="button" data-ds-next aria-label="Next Screenshot">▶</button><button type="button" data-ds-fit aria-pressed="true">Fit</button><button type="button" data-ds-remove>Remove</button></div>
<p class="widget-hint ds-shot-hint">Add Or Paste Day Sheet Screenshots. They Stay In This Browser.</p><div class="ds-viewer" tabindex="0" aria-label="Day Sheet Screenshot"></div><div class="ds-thumbs"></div></div>
<div class="ds-pane" data-ds-pane="mt" hidden><form class="ds-connect" autocomplete="off"><p class="widget-hint">Use Your Own Master Tour API Key And Secret (In Master Tour: Account Settings, Then API Key). Requests Are Signed In This Browser; The Secret Is Never Sent To Wave Studio.</p>
<label>API Key <input data-ds-mt-key autocomplete="off" spellcheck="false" maxlength="200"></label><label>API Secret <input data-ds-mt-secret type="password" autocomplete="off" spellcheck="false" maxlength="200"></label>
<label class="ds-remember"><input type="checkbox" data-ds-mt-remember> Remember On This Device</label><button type="submit" class="primary">Connect Master Tour</button></form>
<div class="ds-mt" hidden><div class="ds-mt-bar"><select data-ds-tour aria-label="Tour"></select><button type="button" data-ds-day-prev aria-label="Previous Day">◀</button><select data-ds-day aria-label="Day"></select><button type="button" data-ds-day-next aria-label="Next Day">▶</button><button type="button" data-ds-today>Today</button><button type="button" data-ds-refresh>Refresh</button><button type="button" data-ds-mt-disconnect>Disconnect</button></div><div class="ds-day" aria-live="polite"></div></div>
<p class="ds-message widget-hint" role="status" aria-live="polite"></p></div>`;
 const $=s=>el.querySelector(s),viewer=$('.ds-viewer'),thumbs=$('.ds-thumbs');
 let images=[],index=0,fit=true,urls=new Map(),creds=null,tours=[],days=[],refreshTimer=null,loaded=false;
 const say=t=>{$('.ds-message').textContent=t};
 // ---- Tabs ----
 const showTab=t=>{for(const b of el.querySelectorAll('[data-ds-tab]'))b.setAttribute('aria-selected',String(b.dataset.dsTab===t));for(const p of el.querySelectorAll('[data-ds-pane]'))p.hidden=p.dataset.dsPane!==t;if(t==='mt')startMT()};
 for(const b of el.querySelectorAll('[data-ds-tab]'))b.onclick=()=>showTab(b.dataset.dsTab);
 // ---- Screenshots ----
 async function load(){try{images=(await tx('readonly',s=>s.getAll())).filter(i=>i.panel===key).sort((a,b)=>a.added-b.added)}catch{images=[]}index=Math.min(index,Math.max(0,images.length-1));draw()}
 function urlFor(img){if(!urls.has(img.id))urls.set(img.id,URL.createObjectURL(img.blob));return urls.get(img.id)}
 function draw(){
  const img=images[index];viewer.replaceChildren();thumbs.replaceChildren();
  $('.ds-count').textContent=images.length?`${index+1} / ${images.length}`:'0 / 0';
  for(const s of ['[data-ds-prev]','[data-ds-next]','[data-ds-remove]','[data-ds-fit]'])$(s).disabled=!images.length;
  $('.ds-shot-hint').hidden=images.length>0;
  if(img){const i=document.createElement('img');i.src=urlFor(img);i.alt=img.name||'Day Sheet';i.className=fit?'ds-fit':'ds-full';viewer.append(i)}
  images.forEach((m,n)=>{const b=document.createElement('button');b.type='button';b.className='ds-thumb';b.setAttribute('aria-label',`Show ${m.name||`Screenshot ${n+1}`}`);b.setAttribute('aria-current',String(n===index));const t=document.createElement('img');t.src=urlFor(m);t.alt='';b.append(t);b.onclick=()=>{index=n;draw()};thumbs.append(b)});
 }
 async function add(files){
  let added=0;
  for(const f of files){
   if(!/^image\/(png|jpeg|webp|gif)$/.test(f.type)){say('Only PNG, JPEG, WebP Or GIF Images Can Be Added.');continue}
   if(f.size>MAX_BYTES){say(`${f.name||'That Image'} Is Over 12 MB.`);continue}
   if(images.length+added>=MAX_IMAGES){say(`Up To ${MAX_IMAGES} Screenshots Per Panel.`);break}
   const item={id:`${key}:${crypto.randomUUID()}`,panel:key,name:String(f.name||'Pasted Screenshot').slice(0,120),added:Date.now()+added,blob:f.slice(0,f.size,f.type)};
   try{await tx('readwrite',s=>s.put(item));added++}catch{say('This Browser Could Not Store The Screenshot.')}
  }
  await load();if(added){index=images.length-1;draw()}
 }
 $('[data-ds-add]').onclick=()=>$('[data-ds-file]').click();
 $('[data-ds-file]').onchange=e=>{const f=[...e.target.files];e.target.value='';add(f)};
 el.addEventListener('paste',e=>{const f=[...(e.clipboardData?.files||[])].filter(x=>x.type.startsWith('image/'));if(f.length){e.preventDefault();showTab('shots');add(f)}});
 viewer.addEventListener('dragover',e=>e.preventDefault());viewer.addEventListener('drop',e=>{e.preventDefault();add([...(e.dataTransfer?.files||[])])});
 $('[data-ds-prev]').onclick=()=>{if(images.length){index=(index-1+images.length)%images.length;draw()}};
 $('[data-ds-next]').onclick=()=>{if(images.length){index=(index+1)%images.length;draw()}};
 $('[data-ds-fit]').onclick=()=>{fit=!fit;$('[data-ds-fit]').setAttribute('aria-pressed',String(fit));$('[data-ds-fit]').textContent=fit?'Fit':'Actual Size';draw()};
 $('[data-ds-remove]').onclick=async()=>{const img=images[index];if(!img||!confirm('Remove This Screenshot From The Panel?'))return;await tx('readwrite',s=>s.delete(img.id)).catch(()=>{});URL.revokeObjectURL(urls.get(img.id));urls.delete(img.id);await load()};
 viewer.addEventListener('keydown',e=>{if(e.key==='ArrowLeft'){e.preventDefault();$('[data-ds-prev]').click()}else if(e.key==='ArrowRight'){e.preventDefault();$('[data-ds-next]').click()}});
 // ---- Master Tour ----
 function readCreds(){for(const s of [sessionStorage,localStorage]){try{const c=JSON.parse(s.getItem(MT_KEY)||'null');if(c&&typeof c.key==='string'&&typeof c.secret==='string')return c}catch{}}return null}
 async function mt(path){
  if(!creds)throw Error('Connect Master Tour First.');
  const url=`https://my.eventric.com/portal/api/v5/${path}`,params=await sign(url,{version:'10'},creds.key,creds.secret);
  let r;try{r=await fetch(`${api}/api/mastertour`,{method:'POST',headers,body:JSON.stringify({path,params}),signal:AbortSignal.timeout(25000)})}
  catch{throw Error(location.protocol==='file:'||/^(127\.0\.0\.1|localhost)$/.test(location.hostname)&&!api.startsWith('http')?'Master Tour Needs The Online Studio.':'Could Not Reach The Wave Studio Server For Master Tour. The Desktop App Works Offline, So Use The Online Studio For Master Tour.')}
  const d=await r.json().catch(()=>null);
  if(!r.ok)throw Error(d?.detail||d?.message||`Master Tour Error ${r.status}`);
  if(d?.success===false)throw Error(String(d.message||'Master Tour Refused The Request.').slice(0,200));
  return d?.data??{};
 }
 function persist(remember){const v=JSON.stringify(creds);sessionStorage.setItem(MT_KEY,v);if(remember)localStorage.setItem(MT_KEY,v);else localStorage.removeItem(MT_KEY)}
 $('.ds-connect').onsubmit=async e=>{
  e.preventDefault();const k=$('[data-ds-mt-key]').value.trim(),s=$('[data-ds-mt-secret]').value.trim();
  if(!k||!s||/\s/.test(k+s)){say('Enter The API Key And Secret Exactly As Master Tour Shows Them.');return}
  creds={key:k,secret:s,tour:''};say('Connecting To Master Tour…');
  try{await loadTours();persist($('[data-ds-mt-remember]').checked);$('[data-ds-mt-secret]').value='';showMT(true);say('')}catch(err){creds=null;say(err.message)}
 };
 function showMT(on){$('.ds-connect').hidden=on;$('.ds-mt').hidden=!on}
 async function loadTours(){
  const d=await mt('tours');tours=(Array.isArray(d.tours)?d.tours:[]).map(t=>({id:String(t.tourId??t.id??''),name:[t.artistName,t.tourName,t.legName].filter(Boolean).join(' · ')||'Tour'})).filter(t=>/^[A-Za-z0-9_-]{1,64}$/.test(t.id));
  const sel=$('[data-ds-tour]');sel.replaceChildren(...tours.map(t=>new Option(t.name,t.id)));
  if(!tours.length)throw Error('No Tours Were Found On This Master Tour Account.');
  sel.value=tours.some(t=>t.id===creds.tour)?creds.tour:tours[0].id;await loadTour(sel.value,true);
 }
 async function loadTour(id,today){
  creds.tour=id;persist(!!localStorage.getItem(MT_KEY));
  const d=await mt(`tour/${id}`),tour=d.tour??d;days=(Array.isArray(tour.days)?tour.days:[]).map(x=>({id:String(x.id??''),date:dayKey(x.dayDate??x.date),name:x.name||x.dayType||'',city:[x.city,x.state].filter(Boolean).join(', ')})).filter(x=>/^[A-Za-z0-9_-]{1,64}$/.test(x.id)).sort((a,b)=>a.date.localeCompare(b.date));
  const sel=$('[data-ds-day]');sel.replaceChildren(...days.map(x=>new Option(`${x.date} · ${x.city||x.name}`,x.id)));
  if(!days.length){$('.ds-day').innerHTML='<p class="widget-hint">This Tour Has No Days Yet.</p>';return}
  const now=new Date(),local=`${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}-${String(now.getDate()).padStart(2,'0')}`;
  const pick=today?(days.find(x=>x.date===local)??days.find(x=>x.date>local)??days[days.length-1]):days.find(x=>x.id===sel.value)??days[0];
  sel.value=pick.id;await loadDay(pick.id);
 }
 async function loadDay(id){
  const box=$('.ds-day');box.setAttribute('aria-busy','true');
  try{
   const [d,ev]=await Promise.all([mt(`day/${id}`),mt(`day/${id}/events`).catch(()=>({}))]);
   renderDay(d.day??d,ev);say(`Updated ${new Date().toLocaleTimeString([],{hour:'numeric',minute:'2-digit'})}`);
  }catch(e){say(e.message)}finally{box.removeAttribute('aria-busy')}
 }
 function list(v){return Array.isArray(v)?v:v&&typeof v==='object'?Object.values(v).find(Array.isArray)??[]:[]}
 function renderDay(day,events){
  const shows=list(events.events??events.shows??events),schedule=list(day.scheduleItems??day.schedule).slice().sort((a,b)=>String(a.startDatetime??'').localeCompare(String(b.startDatetime??'')));
  const hotels=list(day.hotels),contacts=shows.flatMap(s=>list(s.venueContacts)).slice(0,20);
  const section=(title,body)=>body?`<section class="ds-card"><h4>${esc(title)}</h4>${body}</section>`:'';
  const notes=(t,v)=>v?section(t,`<p class="ds-notes">${esc(v).replace(/\n/g,'<br>')}</p>`):'';
  box().innerHTML=`<header class="ds-day-head"><span class="ds-date">${esc(fmtDate(day.dayDate??day.date))}</span><strong>${esc([day.city,day.state,day.country].filter(Boolean).join(', ')||day.name||'Day')}</strong><span class="ds-type">${esc(day.dayType||day.name||'')}${day.timeZone?` · ${esc(day.timeZone)}`:''}</span></header>
${section('Schedule',schedule.length?`<ol class="ds-schedule">${schedule.map(i=>`<li><time>${esc(fmtTime(i.startDatetime))}${i.endDatetime&&i.endDatetime!==i.startDatetime?`–${esc(fmtTime(i.endDatetime))}`:''}</time><span><b>${esc(i.title||'Item')}</b>${i.details?`<small>${esc(i.details)}</small>`:''}</span></li>`).join('')}</ol>`:'<p class="widget-hint">No Schedule Items.</p>')}
${shows.map(s=>section(s.eventName||'Show',`<p><b>${esc(s.venueName||'')}</b><br>${esc([s.venueAddressLine1,s.venueCity,s.venueState,s.venueZip,s.venueCountry].filter(Boolean).join(', '))}${s.venueCapacity?`<br>Capacity ${esc(s.venueCapacity)}`:''}</p>`)).join('')}
${hotels.length?section('Hotel',hotels.map(h=>`<p><b>${esc(h.name||h.hotelName||'Hotel')}</b><br>${esc([h.address,h.addressLine1,h.city,h.phone].filter(Boolean).join(' · '))}</p>`).join('')):''}
${contacts.length?section('Contacts',`<ul class="ds-contacts">${contacts.map(c=>`<li><b>${esc(c.name||[c.firstName,c.lastName].filter(Boolean).join(' ')||'Contact')}</b> ${esc(c.title||c.role||'')}<br><small>${esc([c.phone,c.email].filter(Boolean).join(' · '))}</small></li>`).join('')}</ul>`):''}
${notes('Day Notes',day.generalNotes)}${notes('Hotel Notes',day.hotelNotes)}${notes('Travel Notes',day.travelNotes)}`;
 }
 const box=()=>$('.ds-day');
 $('[data-ds-tour]').onchange=e=>loadTour(e.target.value,true).catch(err=>say(err.message));
 $('[data-ds-day]').onchange=e=>loadDay(e.target.value);
 const step=n=>{const sel=$('[data-ds-day]'),i=days.findIndex(x=>x.id===sel.value)+n;if(days[i]){sel.value=days[i].id;loadDay(days[i].id)}};
 $('[data-ds-day-prev]').onclick=()=>step(-1);$('[data-ds-day-next]').onclick=()=>step(1);
 $('[data-ds-today]').onclick=()=>loadTour($('[data-ds-tour]').value,true).catch(err=>say(err.message));
 $('[data-ds-refresh]').onclick=()=>{const id=$('[data-ds-day]').value;if(id)loadDay(id)};
 $('[data-ds-mt-disconnect]').onclick=()=>{creds=null;sessionStorage.removeItem(MT_KEY);localStorage.removeItem(MT_KEY);tours=[];days=[];box().replaceChildren();showMT(false);say('Disconnected. The Key And Secret Were Removed From This Browser.')};
 let mtStarted=false;
 function startMT(){if(mtStarted)return;mtStarted=true;creds=readCreds();if(creds){showMT(true);loadTours().catch(e=>say(e.message))}}
 el.addEventListener('keydown',e=>{if(e.target.matches('input,select,textarea'))e.stopPropagation()});
 el.addEventListener('pointerdown',e=>{if(e.target.matches('input'))e.stopPropagation()});
 return {el,render(){if(!loaded&&el.isConnected){loaded=true;load()}},tick(){
  if(!loaded&&el.isConnected){loaded=true;load()}
  if(creds&&!$('.ds-mt').hidden&&el.getClientRects().length){const now=Date.now();if(!refreshTimer||now-refreshTimer>300000){if(refreshTimer){const id=$('[data-ds-day]').value;if(id)loadDay(id)}refreshTimer=now}}
 }};
}
