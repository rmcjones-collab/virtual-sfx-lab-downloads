// Vista panel: the right-hand section of a Chroma-Q Vista EX, mirrored on screen.
// Labels follow the Vista 3 user guide and are approximate.
// The EX talks to Vista over USB with no published protocol, so a browser cannot read it directly.
// Physical moves reach this panel as DMX (through the desktop receiver: Live Input or Control
// Mapping) or as MIDI (Web MIDI, e.g. a MIDI interface or bridge). Visual only; it never fires anything.
const STORE='vsl-vista-map:';
// Layout follows the photo of the EX's right-hand section: five encoders, two rows of six LED keys
// with side keys, fixture arrows, three wheels, colour modifiers, two faders, the transport cluster,
// the Grand Master and the F1-F12 column. Key styling matches the MA panel.
const SVG=d=>`<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">${d}</svg>`;
const ICON={
 mode:SVG('<path d="M12 4v16M5 8l14 8M19 8L5 16" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>'),
 rel:SVG('<path d="M6 6l12 12M18 6L6 18" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>'),
 menu:SVG('<path d="M6 7h12M6 12h12M6 17h12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>'),
 left:SVG('<path d="M10 6l-6 6 6 6M4 12h16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>'),
 right:SVG('<path d="M14 6l6 6-6 6M20 12H4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>'),
 skipback:SVG('<path d="M6 5v14" stroke="currentColor" stroke-width="2"/><path d="M19 5l-11 7 11 7z" fill="currentColor"/>'),
 skipfwd:SVG('<path d="M18 5v14" stroke="currentColor" stroke-width="2"/><path d="M5 5l11 7-11 7z" fill="currentColor"/>'),
 rew:SVG('<path d="M12 6l-8 6 8 6zM21 6l-8 6 8 6z" fill="currentColor"/>'),
 ff:SVG('<path d="M3 6l8 6-8 6zM12 6l8 6-8 6z" fill="currentColor"/>'),
 pause:SVG('<path d="M7 5h3v14H7zM14 5h3v14h-3z" fill="currentColor"/>'),
 play:SVG('<path d="M8 5l11 7-11 7z" fill="currentColor"/>'),
 stop:SVG('<circle cx="12" cy="12" r="7" fill="none" stroke="currentColor" stroke-width="2"/><path d="M7 17L17 7" stroke="currentColor" stroke-width="2"/>')
};
const K=(id,label,o={})=>({id,label,kind:'button',...o});
const CONTROLS=[
 ...[1,2,3,4,5].map(n=>({id:`e${n}`,label:`Encoder ${n}`,kind:'encoder',size:'small'})),
 {id:'e6',label:'Encoder 6',kind:'encoder',size:'small'},
 K('mode','Mode',{icon:'mode'}),K('rel','Release',{icon:'rel'}),K('menu','Menu',{icon:'menu'}),
 ...[1,2,3,4,5,6].map(n=>K(`b${n}`,`Key ${n}`,{led:true})),
 ...[1,2,3,4,5,6].map(n=>K(`k${n}`,`Key ${n+6}`,{led:true})),
 K('prevfix','Previous Fixture',{icon:'left'}),K('nextfix','Next Fixture',{icon:'right'}),
 ...[1,2,3].map(n=>({id:`w${n}`,label:`Wheel ${n}`,kind:'encoder',size:'large'})),
 K('red','Red · Shift',{led:'red',short:'Shift'}),K('yellow','Yellow · Ctrl',{led:'yellow',short:'Ctrl'}),K('green','Green · Alt',{led:'green',short:'Alt'}),K('blue','Blue · Ctrl+Alt',{led:'blue',short:'Ctrl+Alt'}),
 {id:'fint',label:'Cuelist Intensity',kind:'fader'},{id:'fxf',label:'Crossfade',kind:'fader'},
 K('tstart','Skip Back',{icon:'skipback'}),K('tend','Skip Forward',{icon:'skipfwd'}),K('tstop','Stop',{icon:'stop'}),
 K('tback','Rewind',{icon:'rew'}),K('tfwd','Fast Forward',{icon:'ff'}),K('pause','Pause',{icon:'pause'}),K('play','Go',{icon:'play',cls:'vx-go'}),
 {id:'fgm',label:'Grand Master',kind:'fader'},
 ...Array.from({length:12},(_,i)=>K(`f${i+1}`,`F${i+1}`,{cls:'vx-f'}))
];
const BY_ID=new Map(CONTROLS.map(c=>[c.id,c]));
// The upper LED row changes with the mode: master-playback keys in Play, attribute keys in Programming.
const UPPER={play:['Control','Chase','SmartFX','Load','Lock','Select'],ipcg:['I/Pos','Color','Gobo','Beam','Custom','>>']};
const PLAY_KEYS=['control','chase','smartfx'],PROG_KEYS=['ipos','color','gobo','beam','custom'];
const PLAY_NAMES={control:'Control',chase:'Chase',smartfx:'SmartFX'},PROG_NAMES={ipos:'I/Pos',color:'Color',gobo:'Gobo',beam:'Beam',custom:'Custom'};
const LOWER={
 control:['Rate','100%','Jump','Shuttle','Release','Select'],
 chase:['Rate','Sync','Forward','Reverse','Bounce','Random'],
 smartfx:['Enabled','Reset','Scope','Direction','Sync','—'],
 ipcg:['Home 1','Full 1','Home 2','Full 2','Home 3','Full 3']
};
const WHEELS={control:['Rate','Shuttle','—'],chase:['Rate','—','—'],smartfx:['Size','Rate','Offset'],ipos:['Intensity','Pan','Tilt'],color:['Color 1','Color 2','Color 3'],gobo:['Gobo','Rotate','Index'],beam:['Zoom','Focus','Iris'],custom:['Param 1','Param 2','Param 3']};
const ID=/^[a-z0-9]{1,12}$/;
function validMap(raw){
 const out={};if(!raw||typeof raw!=='object')return out;
 for(const [id,m] of Object.entries(raw)){
  if(!BY_ID.has(id)||!m||typeof m!=='object')continue;
  if(m.src==='dmx'&&Number.isInteger(m.u)&&m.u>=1&&m.u<=63999&&Number.isInteger(m.ch)&&m.ch>=1&&m.ch<=512)out[id]={src:'dmx',u:m.u,ch:m.ch};
  else if(m.src==='midi'&&['note','cc'].includes(m.kind)&&Number.isInteger(m.channel)&&m.channel>=0&&m.channel<=15&&Number.isInteger(m.n)&&m.n>=0&&m.n<=127)out[id]={src:'midi',kind:m.kind,channel:m.channel,n:m.n};
 }
 return out;
}
const describe=m=>!m?'Not Mapped':m.src==='dmx'?`DMX U${m.u} Ch ${m.ch}`:`MIDI ${m.kind==='note'?'Note':'CC'} ${m.n} · Ch ${m.channel+1}`;
export function createVistaPanel({key}){
 const SKEY=STORE+key;
 let saved={};try{saved=JSON.parse(localStorage.getItem(SKEY)||'{}')}catch{}
 const settings={map:validMap(saved.map),encoder:saved.encoder==='absolute'?'absolute':'relative',sendOut:!!saved.sendOut,outId:typeof saved.outId==='string'?saved.outId.slice(0,200):''};
 const state={mode:'play',play:'control',ipcg:'ipos',values:new Map(),pressed:new Set(),angles:new Map(),lastRaw:new Map(),lastActivity:0,source:''};
 let learning=false,learnTarget=null,baseline=null,midi=null,lastTap=0;const bound=new WeakSet();
 const save=()=>{try{localStorage.setItem(SKEY,JSON.stringify(settings))}catch{}};
 const el=document.createElement('section');el.className='vista-panel';
 el.innerHTML=`<div class="vx-bar"><span class="vx-mode-label" aria-live="polite"></span><span class="vx-activity" title="Console Input Activity"></span>
<button type="button" data-vx-learn aria-pressed="false">Learn</button><button type="button" data-vx-midi>Enable MIDI</button><details class="vx-settings"><summary>Mapping</summary>
<p class="widget-hint">Layout Follows The Vista EX Right-Hand Section; Key Labels Follow The Vista 3 User Guide And Are Approximate. The EX Connects To Vista Over USB With No Published Protocol, So This Panel Listens For DMX From The Desktop Receiver (Live Input Or Control Mapping) Or MIDI. Visual Only.</p>
<label>Encoder Messages <select data-vx-encoder><option value="relative">Relative (MIDI 1–63 / 65–127)</option><option value="absolute">Absolute (Value Changes)</option></select></label>
<label><input type="checkbox" data-vx-send> Send On-Screen Presses As MIDI</label><label>MIDI Output <select data-vx-out><option value="">None</option></select></label>
<div class="vx-map-actions"><button type="button" data-vx-clear-one>Clear Selected Mapping</button><button type="button" data-vx-clear-all>Clear All Mappings</button><button type="button" data-vx-export>Export Mapping</button><button type="button" data-vx-import>Import Mapping</button><input type="file" accept="application/json,.json" data-vx-file hidden></div>
<p class="vx-map-summary widget-hint"></p></details></div>
<p class="vx-message widget-hint" role="status" aria-live="polite"></p><div class="vx-board"></div>`;
 const $=s=>el.querySelector(s),board=$('.vx-board'),message=$('.vx-message'),nodes=new Map();
 const say=t=>{message.textContent=t};
 function make(c){
  let n;
  if(c.kind==='button'){
   n=document.createElement('button');n.type='button';n.className=`ma-key vx-key${c.cls?` ${c.cls}`:''}${c.icon?' vx-icon-key':''}`;
   n.innerHTML=`${c.led?`<span class="vx-led${typeof c.led==='string'?` vx-led-${c.led}`:''}"></span>`:''}${c.icon?`<span class="vx-ico">${ICON[c.icon]}</span>`:''}<span class="vx-label"></span>`;
  }else if(c.kind==='fader'){n=document.createElement('div');n.className='vx-fader';n.tabIndex=0;n.setAttribute('role','slider');n.setAttribute('aria-valuemin','0');n.setAttribute('aria-valuemax','100');n.innerHTML='<div class="vx-scale"><div class="vx-track"><div class="vx-fill"></div><div class="vx-cap"></div></div></div><span class="vx-value">0%</span><span class="vx-label"></span>'}
  else{n=document.createElement('div');n.className=`vx-encoder vx-${c.size}`;n.tabIndex=0;n.setAttribute('role','slider');n.innerHTML='<div class="vx-knob"><span class="vx-tick"></span></div><span class="vx-label"></span>'}
  n.dataset.vx=c.id;nodes.set(c.id,n);return n;
 }
 const box=(cls,ids)=>{const d=document.createElement('div');d.className=cls;for(const id of ids)d.append(typeof id==='string'?make(BY_ID.get(id)):id);return d};
 const gap=cls=>{const d=document.createElement('span');d.className=cls;d.setAttribute('aria-hidden','true');return d};
 const main=document.createElement('div');main.className='vx-main';
 main.append(
  box('vx-encoders',['e1','e2','e3','e4','e5']),
  box('vx-keyrow',['mode','b1','b2','b3','b4','b5','b6','e6']),
  box('vx-keyrow',['rel','k1','k2','k3','k4','k5','k6','menu']),
  box('vx-arrows',[gap('vx-sp'),gap('vx-sp'),'prevfix',gap('vx-sp'),gap('vx-sp'),'nextfix',gap('vx-sp'),gap('vx-sp')]),
  box('vx-wheels',['w1','w2','w3']),
  box('vx-lower',[box('vx-mods',['red','yellow','green','blue']),box('vx-fader-pair',['fint','fxf']),box('vx-transport',['tstart','tend','tstop','tback','tfwd',gap('vx-sp'),'pause',gap('vx-sp'),gap('vx-sp'),'play']),box('vx-master',['fgm'])])
 );
 const fcol=box('vx-fcol',['f1','f2','f3','f4','f5','f6',gap('vx-fgap'),'f7','f8','f9','f10','f11','f12']);
 const brand=document.createElement('div');brand.className='vx-plate';brand.innerHTML='<span>VISTA</span><i></i><span>EX</span>';brand.setAttribute('aria-hidden','true');
 board.append(main,fcol,brand);
 // ---- Mode logic (mirrors what the console's mode keys do to the lower six keys and the wheels) ----
 function labels(){
  const lower=state.mode==='ipcg'?LOWER.ipcg:LOWER[state.play],wheels=state.mode==='ipcg'?WHEELS[state.ipcg]:WHEELS[state.play],upper=UPPER[state.mode];
  for(let i=0;i<6;i++){BY_ID.get(`k${i+1}`).current=lower[i];BY_ID.get(`b${i+1}`).current=upper[i]}
  for(let i=0;i<3;i++)BY_ID.get(`w${i+1}`).current=wheels[i];
  $('.vx-mode-label').textContent=state.mode==='ipcg'?`Programming · ${PROG_NAMES[state.ipcg]}`:`Play · ${PLAY_NAMES[state.play]}`;
  const lit=state.mode==='ipcg'?PROG_KEYS.indexOf(state.ipcg):PLAY_KEYS.indexOf(state.play);
  for(let i=0;i<6;i++)nodes.get(`b${i+1}`).classList.toggle('lit',i===lit);
  nodes.get('mode').classList.toggle('lit',state.mode==='ipcg');nodes.get('menu').classList.toggle('lit',state.mode==='ipcg');
  for(const c of CONTROLS){const n=nodes.get(c.id),label=c.current??c.label;n.querySelector('.vx-label').textContent=c.kind==='encoder'&&c.size==='small'?'':(c.short??label);n.title=`${label} · ${describe(settings.map[c.id])}`;n.setAttribute('aria-label',`${label}, ${describe(settings.map[c.id])}`);n.classList.toggle('vx-mapped',!!settings.map[c.id])}
  $('.vx-map-summary').textContent=`${Object.keys(settings.map).length} Of ${CONTROLS.length} Controls Mapped. Mappings Are Saved In This Browser.`;
 }
 function press(id){
  const b=/^b([1-6])$/.exec(id);
  if(b){const i=Number(b[1])-1;if(state.mode==='ipcg'){if(PROG_KEYS[i])state.ipcg=PROG_KEYS[i]}else if(PLAY_KEYS[i])state.play=PLAY_KEYS[i]}
  else if(id==='mode')state.mode=state.mode==='ipcg'?'play':'ipcg';
  else if(id==='menu'){const now=performance.now();if(now-lastTap<400)state.mode=state.mode==='ipcg'?'play':'ipcg';lastTap=now}
  labels();
 }
 function setButton(id,down,from='screen'){
  const n=nodes.get(id);if(!n)return;const was=state.pressed.has(id);
  if(down)state.pressed.add(id);else state.pressed.delete(id);
  n.classList.toggle('held',down);if(down&&!was){press(id);if(from==='console'){n.classList.remove('console-hit');void n.offsetWidth;n.classList.add('console-hit')}}
  if(from==='screen')send(id,down?127:0);
 }
 function setFader(id,v,from='screen'){
  v=Math.max(0,Math.min(1,v));state.values.set(id,v);const n=nodes.get(id);if(!n)return;
  n.style.setProperty('--vx-level',v);n.querySelector('.vx-value').textContent=`${Math.round(v*100)}%`;n.setAttribute('aria-valuenow',String(Math.round(v*100)));
  if(from==='screen')send(id,Math.round(v*127));
 }
 function turn(id,delta,from='screen'){
  const a=(state.angles.get(id)??0)+delta*6;state.angles.set(id,a);nodes.get(id)?.style.setProperty('--vx-angle',`${a}deg`);
  const n=nodes.get(id);n?.classList.add('vx-moving');clearTimeout(n?._t);if(n)n._t=setTimeout(()=>n.classList.remove('vx-moving'),180);
  if(from==='screen')send(id,delta>0?Math.min(63,delta):Math.max(65,128+delta));
 }
 // ---- On-screen interaction ----
 board.addEventListener('pointerdown',e=>{
  const n=e.target.closest('[data-vx]');if(!n)return;const id=n.dataset.vx,c=BY_ID.get(id);
  if(learning){e.preventDefault();pickLearn(id);return}
  e.preventDefault();try{n.setPointerCapture(e.pointerId)}catch{}
  if(c.kind==='button'){setButton(id,true);const up=()=>{setButton(id,false);n.removeEventListener('pointerup',up);n.removeEventListener('pointercancel',up)};n.addEventListener('pointerup',up);n.addEventListener('pointercancel',up);return}
  if(c.kind==='fader'){const track=n.querySelector('.vx-track'),at=ev=>{const r=track.getBoundingClientRect();setFader(id,1-(ev.clientY-r.top)/r.height)};at(e);const move=ev=>at(ev),end=()=>{n.removeEventListener('pointermove',move);n.removeEventListener('pointerup',end)};n.addEventListener('pointermove',move);n.addEventListener('pointerup',end);return}
  let y=e.clientY;const move=ev=>{const d=Math.round((y-ev.clientY)/4);if(d){turn(id,d);y=ev.clientY}},end=()=>{n.removeEventListener('pointermove',move);n.removeEventListener('pointerup',end)};n.addEventListener('pointermove',move);n.addEventListener('pointerup',end);
 });
 board.addEventListener('wheel',e=>{const n=e.target.closest('.vx-encoder,.vx-fader');if(!n||learning)return;e.preventDefault();const id=n.dataset.vx;if(BY_ID.get(id).kind==='fader')setFader(id,(state.values.get(id)??0)-Math.sign(e.deltaY)*0.05);else turn(id,-Math.sign(e.deltaY))},{passive:false});
 board.addEventListener('keydown',e=>{
  const n=e.target.closest('.vx-encoder,.vx-fader');if(!n)return;const id=n.dataset.vx,step={ArrowUp:1,ArrowRight:1,ArrowDown:-1,ArrowLeft:-1}[e.key];if(!step)return;
  e.preventDefault();e.stopPropagation();if(BY_ID.get(id).kind==='fader')setFader(id,(state.values.get(id)??0)+step*0.05);else turn(id,step);
 });
 // ---- Learn ----
 function setLearning(on){learning=on;learnTarget=null;baseline=null;$('[data-vx-learn]').setAttribute('aria-pressed',String(on));$('[data-vx-learn]').textContent=on?'Stop Learning':'Learn';el.classList.toggle('vx-learning',on);nodes.forEach(n=>n.classList.remove('vx-learn-target'));say(on?'Learn: Click A Control On Screen, Then Move Or Press It On The Console.':'')}
 function pickLearn(id){learnTarget=id;baseline=new Map();nodes.forEach(n=>n.classList.toggle('vx-learn-target',n.dataset.vx===id));say(`Learning ${BY_ID.get(id).current??BY_ID.get(id).label}: Move Or Press It On The Console Now.`)}
 function assign(m){
  const id=learnTarget;if(!id)return;
  for(const [k,v] of Object.entries(settings.map))if(JSON.stringify(v)===JSON.stringify(m))delete settings.map[k];
  settings.map[id]=m;save();labels();say(`Mapped ${BY_ID.get(id).current??BY_ID.get(id).label} To ${describe(m)}. Click The Next Control, Or Stop Learning.`);
  learnTarget=null;baseline=null;nodes.forEach(n=>n.classList.remove('vx-learn-target'));
 }
 $('[data-vx-learn]').onclick=()=>setLearning(!learning);
 // ---- DMX input (from the desktop receiver's live stream) ----
 function activity(source){state.lastActivity=performance.now();state.source=source}
 document.addEventListener('wave-dmx-frame',e=>{
  const {universe,values}=e.detail||{};if(!Array.isArray(values)||!Number.isInteger(universe))return;const u=universe+1;activity('DMX');
  if(learning&&learnTarget){
   if(!baseline.has(u)){baseline.set(u,values.slice());return}
   const base=baseline.get(u);let best=-1,diff=0;for(let i=0;i<values.length;i++){const d=Math.abs((values[i]??0)-(base[i]??0));if(d>diff){diff=d;best=i}}
   if(diff>=24)assign({src:'dmx',u,ch:best+1});
   return;
  }
  for(const [id,m] of Object.entries(settings.map)){
   if(m.src!=='dmx'||m.u!==u)continue;const raw=values[m.ch-1];if(!Number.isInteger(raw))continue;const c=BY_ID.get(id),k=`${id}`;
   if(c.kind==='button'){const down=raw>=128;if(down!==state.pressed.has(id))setButton(id,down,'console')}
   else if(c.kind==='fader')setFader(id,raw/255,'console');
   else{const last=state.lastRaw.get(k);state.lastRaw.set(k,raw);if(last!==undefined&&raw!==last){let d=raw-last;if(d>128)d-=256;if(d<-128)d+=256;turn(id,Math.max(-12,Math.min(12,d)),'console')}}
  }
 });
 // ---- MIDI input / optional output ----
 function onMidi(e){
  const [status,a=0,b=0]=e.data||[];const type=status&0xF0,channel=status&0x0F;if(![0x80,0x90,0xB0].includes(type))return;activity('MIDI');
  const kind=type===0xB0?'cc':'note',on=type===0x90&&b>0;
  if(learning&&learnTarget){if(kind==='cc'||on)assign({src:'midi',kind,channel,n:a});return}
  for(const [id,m] of Object.entries(settings.map)){
   if(m.src!=='midi'||m.kind!==kind||m.channel!==channel||m.n!==a)continue;const c=BY_ID.get(id);
   if(c.kind==='button')setButton(id,kind==='cc'?b>=64:on,'console');
   else if(c.kind==='fader')setFader(id,b/127,'console');
   else if(settings.encoder==='relative'){const d=b<64?b:b-128;if(d)turn(id,Math.max(-12,Math.min(12,d)),'console')}
   else{const last=state.lastRaw.get(id);state.lastRaw.set(id,b);if(last!==undefined&&b!==last)turn(id,Math.max(-12,Math.min(12,b-last)),'console')}
  }
 }
 function bindMidi(){
  // addEventListener (not onmidimessage) so the Timecode panel can share the same MIDI input.
  if(!midi)return;for(const input of midi.inputs.values())if(!bound.has(input)){bound.add(input);input.addEventListener('midimessage',onMidi)}
  const out=$('[data-vx-out]');out.replaceChildren(new Option('None',''));for(const o of midi.outputs.values())out.append(new Option(o.name||o.id,o.id));out.value=[...midi.outputs.values()].some(o=>o.id===settings.outId)?settings.outId:'';
  $('[data-vx-midi]').textContent=`MIDI: ${midi.inputs.size} In`;
 }
 function send(id,value){
  if(!settings.sendOut||!midi||!settings.outId)return;const m=settings.map[id];if(!m||m.src!=='midi')return;const out=midi.outputs.get(settings.outId);if(!out)return;
  try{out.send(m.kind==='note'?[(value>0?0x90:0x80)|m.channel,m.n,value>0?127:0]:[0xB0|m.channel,m.n,Math.max(0,Math.min(127,value))])}catch{}
 }
 $('[data-vx-midi]').onclick=async()=>{
  if(!navigator.requestMIDIAccess){say('This Browser Has No Web MIDI. Use Chrome Or Edge, Or Map Controls Through DMX.');return}
  try{midi=await navigator.requestMIDIAccess({sysex:false});midi.onstatechange=bindMidi;bindMidi();say(midi.inputs.size?'MIDI Enabled. Use Learn To Map Console Controls.':'MIDI Enabled, But No MIDI Inputs Were Found.')}
  catch{say('MIDI Access Was Blocked. Allow MIDI For This Site In The Browser Settings.')}
 };
 // ---- Settings ----
 $('[data-vx-encoder]').value=settings.encoder;$('[data-vx-encoder]').onchange=e=>{settings.encoder=e.target.value;save()};
 $('[data-vx-send]').checked=settings.sendOut;$('[data-vx-send]').onchange=e=>{settings.sendOut=e.target.checked;save()};
 $('[data-vx-out]').onchange=e=>{settings.outId=e.target.value;save()};
 let selected=null;board.addEventListener('focusin',e=>{selected=e.target.closest('[data-vx]')?.dataset.vx??selected});
 $('[data-vx-clear-one]').onclick=()=>{if(!selected||!settings.map[selected]){say('Select A Mapped Control First.');return}delete settings.map[selected];save();labels();say('Mapping Cleared.')};
 $('[data-vx-clear-all]').onclick=()=>{if(!confirm('Clear Every Vista Mapping In This Panel?'))return;settings.map={};save();labels();say('All Mappings Cleared.')};
 $('[data-vx-export]').onclick=()=>{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify({app:'wave-studio-vista-map',version:1,map:settings.map,encoder:settings.encoder},null,1)],{type:'application/json'}));a.download='vista-ex-mapping.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),2000)};
 $('[data-vx-import]').onclick=()=>$('[data-vx-file]').click();
 $('[data-vx-file]').onchange=async e=>{const f=e.target.files[0];e.target.value='';if(!f)return;if(f.size>200000){say('That File Is Too Large For A Mapping.');return}try{const d=JSON.parse(await f.text());if(d.app!=='wave-studio-vista-map')throw 0;settings.map=validMap(d.map);if(['relative','absolute'].includes(d.encoder))settings.encoder=d.encoder;$('[data-vx-encoder]').value=settings.encoder;save();labels();say(`Imported ${Object.keys(settings.map).length} Mappings.`)}catch{say('That Is Not A Vista Mapping File.')}};
 el.addEventListener('keydown',e=>{if(e.target.matches('input,select'))e.stopPropagation()});
 for(const c of CONTROLS)if(c.kind==='fader')setFader(c.id,c.id==='fgm'?1:0,'init');
 labels();
 return {el,render:labels,tick(){const live=performance.now()-state.lastActivity<600;const a=$('.vx-activity');a.classList.toggle('vx-live',live);a.textContent=live?`${state.source} In`:'No Input'}};
}
export const VISTA_CONTROLS=CONTROLS.map(c=>c.id);
