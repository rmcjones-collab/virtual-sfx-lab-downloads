/* Pete in the studio: he peeks over the bottom edge next to "How to explore" (eyes only, no mouth).
 * Click him and he jumps out, ready to help with the Wave Studio tip pack, the site assistant and
 * the studio voice. Hide him with his dash button and he goes back to peeking.
 * The widget files live in ./pete/; if they are missing (desktop packages) the peek simply stays hidden. */
(function () {
  'use strict';
  var peek = document.getElementById('pete-peek');
  if (!peek) return;
  var PORT = '__PORT_8093__';
  var API = PORT.indexOf('__') === 0 ? null : (/^(https?:\/\/|\/)/.test(PORT) ? PORT : '/' + PORT);
  var V = 'v=070';
  function load(src) {
    return new Promise(function (resolve, reject) {
      var s = document.createElement('script'); s.src = src; s.async = false; s.onload = resolve; s.onerror = reject; document.head.appendChild(s);
    });
  }
  // Studio controls → tip contexts (keys of WAVE_STUDIO_TIPS)
  var CONTEXTS = [['.simulator', 'stage', 'Stage'], ['.dmx-console', 'faders', 'Control source'], ['.fixture-editor', 'fixture', 'Fixture editor'], ['#flash-level', 'flash', 'Flash'],
    ['#home-selected', 'home', 'Home'], ['#record-cue', 'record', 'Record cue'], ['#cue-stack', 'record', 'Cue stack'], ['#save-layout', 'save', 'Save layout'], ['#guide-panel', 'chat', 'AI Assist'],
    ['.layout-screen-settings', 'workspace', 'Workspace'], ['#manual-open', 'shortcuts', 'Manual']];
  function tagContexts() {
    CONTEXTS.forEach(function (c) {
      document.querySelectorAll(c[0]).forEach(function (el) { if (!el.hasAttribute('data-vls-context')) { el.setAttribute('data-vls-context', c[1]); el.setAttribute('data-vls-label', c[2]); } });
    });
  }
  var pupils = [], peekSvg = null, out = false;
  function buildPeek(svg) {
    var head = svg.querySelector('.vls-av-head');
    if (!head) return false;
    var ns = 'http://www.w3.org/2000/svg';
    peekSvg = document.createElementNS(ns, 'svg');
    peekSvg.setAttribute('viewBox', '50 28 120 76');          // cap, brows, glasses and eyes; the crop stops above the mouth
    peekSvg.setAttribute('aria-hidden', 'true'); peekSvg.setAttribute('focusable', 'false');
    var clone = head.cloneNode(true);
    clone.removeAttribute('class'); clone.removeAttribute('style');
    clone.querySelectorAll('[class]').forEach(function (n) { n.removeAttribute('style'); });
    var mouth = clone.querySelector('.vls-av-mouth-g'); if (mouth) mouth.remove();
    var beard = clone.querySelector('[clip-path]'); if (beard) beard.remove();   // below the crop; avoids a cross-SVG clipPath reference
    peekSvg.appendChild(clone);
    peek.replaceChildren(peekSvg);
    pupils = Array.prototype.slice.call(peekSvg.querySelectorAll('.vls-av-pupil'));
    pupils.forEach(function (p) { p.style.transition = 'transform .25s ease'; });
    return true;
  }
  var lookRaf = 0, lookAt = null, openTimer = 0;
  function queueLook(x, y) { // at most once per frame
    if (!peekSvg || out || peek.hidden) return;
    lookAt = [x, y];
    if (!lookRaf) lookRaf = requestAnimationFrame(function () { lookRaf = 0; if (lookAt) look(lookAt[0], lookAt[1]); });
  }
  function look(x, y) {
    if (!peekSvg || out) return;
    var r = peek.getBoundingClientRect(); if (!r.width) return;
    var cx = r.left + r.width / 2, cy = r.bottom + 4;
    var ang = Math.atan2(y - cy, x - cx), dist = Math.hypot(x - cx, y - cy), reach = Math.min(1, dist / 240);
    var dx = Math.cos(ang) * 4 * reach, dy = Math.min(1.5, Math.sin(ang) * 3 * reach);
    pupils.forEach(function (p) { p.style.transform = 'translate(' + dx.toFixed(2) + 'px,' + dy.toFixed(2) + 'px)'; });
  }
  function jumpOut(quiet) {
    if (out) return;
    out = true;
    var hadFocus = document.activeElement === peek;
    var r = peek.getBoundingClientRect();
    peek.classList.add('is-out'); peek.tabIndex = -1;
    tagContexts();
    if (window.VLSPeteStudio) window.VLSPeteStudio.opened();   // his hello is an invitation, so it keeps the question box
    var vh = window.innerHeight;
    if (quiet === true) { VLSAvatar.jumpIn({ x: r.left + r.width / 2, y: vh - 130, gesture: 'wave' }); peek.setAttribute('aria-hidden', 'true'); return; }   // opened from the Pete settings button
    VLSAvatar.jumpIn({ x: r.left + r.width / 2, y: vh - 130, text: 'Pete here. Ask me anything about the studio, or hover a panel and I will drop a tip. Press my dash when you want me out of the way.', gesture: 'wave', speak: true });
    // keep keyboard focus: move it onto Pete straight away, then into his question box once he is open
    var openBtn = document.querySelector('.vls-av-open');
    if (hadFocus && openBtn) openBtn.focus({ preventScroll: true });
    peek.setAttribute('aria-hidden', 'true');
    clearTimeout(openTimer);
    openTimer = setTimeout(function () {
      if (!out) return;
      VLSAvatar.open();
      var inp = document.querySelector('.vls-av-ask input');
      if (hadFocus && inp) inp.focus({ preventScroll: true });
    }, 1200);
  }
  function backToPeek() {
    out = false;
    clearTimeout(openTimer); clearTimeout(setTimer);   // a pending Pete Settings open is cancelled when he goes back
    var a = document.activeElement, root = document.querySelector('.vls-av-root');
    var focusWasInPete = !a || a === document.body || (root && root.contains(a));
    peek.classList.remove('is-out'); peek.removeAttribute('aria-hidden'); peek.tabIndex = 0;
    if (focusWasInPete) peek.focus({ preventScroll: true });
  }
  // Hovering Pete in the studio changes nothing on screen: the widget's own hover rules (bar highlight,
  // faster head bob) are removed here, and the studio's button hover colour is kept off his invisible
  // click target, which covers his whole figure. Keyboard focus styles stay. The widget file itself is
  // untouched so it stays identical to the extension copy.
  function calmHover() {
    Array.prototype.forEach.call(document.styleSheets, function (sheet) {
      var rules; try { rules = sheet.cssRules; } catch (e) { return; }
      if (!rules) return;
      for (var i = rules.length - 1; i >= 0; i--) {
        var sel = rules[i].selectorText;
        if (!sel || sel.indexOf('.vls-av-stage:hover') < 0) continue;
        var keep = sel.split(',').map(function (x) { return x.trim(); }).filter(function (x) { return x.indexOf(':hover') < 0; });
        var body = rules[i].style.cssText;
        sheet.deleteRule(i);
        if (keep.length) try { sheet.insertRule(keep.join(',') + '{' + body + '}', i); } catch (e) {}
      }
    });
    var st = document.createElement('style');
    st.textContent = '.vls-av-root .vls-av-open,.vls-av-root .vls-av-open:hover,.vls-av-root .vls-av-open:active{background:transparent!important;border:0!important;box-shadow:none!important;transform:none!important;filter:none!important;color:inherit!important}' +
      '.vls-av-root .vls-av-stage,.vls-av-root .vls-av-stage:hover{cursor:grab}' +
      // Icon bar: the studio's global button padding squeezed the 26px round buttons and pushed each
      // icon off centre. Zero it and centre the glyphs. Icons sit 25% more transparent while the
      // pointer is away from Pete, and the button under the pointer lights up.
      '.vls-av-root .vls-av-minibar{opacity:1!important;background:rgba(28,26,24,.33);transition:background .2s ease}' +
      '.vls-av-root .vls-av-stage:hover .vls-av-minibar{background:rgba(28,26,24,.4)}' +
      '.vls-av-root .vls-av-minibar button.vls-av-mini{padding:0!important;min-height:0!important;min-width:0!important;display:grid!important;place-items:center;text-align:center;line-height:1!important;letter-spacing:0;text-indent:0;opacity:.45;transition:opacity .15s ease,background .15s ease,color .15s ease}' +
      '.vls-av-root .vls-av-minibar button.vls-av-mini svg{margin:auto}' +
      '.vls-av-root .vls-av-stage:hover .vls-av-minibar button.vls-av-mini,.vls-av-root .vls-av-minibar:focus-within button.vls-av-mini{opacity:.6}' +
      '.vls-av-root .vls-av-minibar button.vls-av-mini:hover,.vls-av-root .vls-av-minibar button.vls-av-mini:focus-visible{opacity:1!important;background:var(--vls-orange,#f07a22)!important;color:#1a1206!important}' +
      '.vls-av-root.vls-dragging .vls-av-minibar{opacity:0!important}' +
      // While Pete is being dragged his eyes relax to straight ahead instead of staying locked on the
      // pointer; tracking resumes as soon as he is dropped.
      '.vls-av-root.vls-dragging .vls-av-svg .vls-av-pupil{transform:none!important;transition:transform .2s ease!important}';
    document.head.appendChild(st);
  }
  // Square Pete button beside the VSL Info Mode link in the header: opens his settings (jumping out first
  // if he is peeking).
  var setTimer = 0;
  function openPeteSettings() {
    clearTimeout(setTimer);
    if (!out) {
      jumpOut(true);
      setTimer = setTimeout(function () {
        var r = document.querySelector('.vls-av-root');
        if (out && r && !r.classList.contains('vls-hidden')) { VLSAvatar.openSettings(); focusSettings(); }   // only if he is still out
      }, 900);
    }
    else { VLSAvatar.openSettings(); focusSettings(); }
  }
  function focusSettings() {   // keyboard users land on the first control instead of hunting for the panel
    var f = document.querySelector('.vls-av-root .vls-av-settings button,.vls-av-root .vls-av-settings input,.vls-av-root .vls-av-settings select,.vls-av-root .vls-av-settings [tabindex="0"]');
    if (f) try { f.focus({ preventScroll: true }); } catch (e) {}
  }
  function mountSettingsButton() {
    var tries = 0;
    (function place() {
      if (document.getElementById('pete-settings-btn')) return;
      var dl = document.getElementById('info-mode-download');
      if (!dl) { if (++tries < 60) setTimeout(place, 250); return; }
      var b = document.createElement('button');
      b.type = 'button'; b.id = 'pete-settings-btn'; b.title = 'Pete Settings';
      b.setAttribute('aria-label', 'Open Pete settings');
      var im = document.createElement('img'); im.src = './pete/icons/pete-48.png'; im.alt = ''; im.width = 22; im.height = 22;
      b.appendChild(im);
      b.addEventListener('click', openPeteSettings);
      dl.after(b);
    })();
  }
  var base = './pete/';
  load(base + 'vls-avatar.js?' + V).then(function () { return load(base + 'wave-studio-tips.js?' + V); }).then(function () { return load(base + 'wave-studio-fifty.js?' + V); }).then(function () {
    if (!window.VLSAvatar) throw new Error('no widget');
    VLSAvatar.init({
      name: 'Pete',
      tips: window.WAVE_STUDIO_TIPS || {},
      recital: window.WAVE_STUDIO_FIFTY || null,
      knowledge: window.WAVE_STUDIO_KNOWLEDGE || [],
      tours: window.WAVE_STUDIO_TOURS || {},
      mode: 'chill',
      rude: false,
      greet: false,
      askEndpoint: API ? API + '/api/agent/ask' : null,
      narrationEndpoint: API ? API + '/api/narrate' : null,
      postMessageOrigins: [location.origin]
    });
    VLSAvatar.hide();
    calmHover();
    load('./studio-pete-extras.js?v=006').catch(function () {});   // hands, quiet bubbles, open-space placement, gravity
    var svg = document.querySelector('.vls-av-svg');
    if (!svg || !buildPeek(svg)) throw new Error('no head');
    peek.hidden = false;
    peek.addEventListener('click', jumpOut);
    mountSettingsButton();
    peek.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); jumpOut(); } });
    document.addEventListener('pointermove', function (e) { queueLook(e.clientX, e.clientY); }, { passive: true });
    VLSAvatar.on('visible', function (d) {
      if (d && d.visible === false) backToPeek();
      else if (d && d.visible) { out = true; peek.classList.add('is-out'); peek.setAttribute('aria-hidden', 'true'); peek.tabIndex = -1; }   // same as jumpOut: the hidden peek is not focusable
    });
  }).catch(function () { peek.remove(); });
})();
