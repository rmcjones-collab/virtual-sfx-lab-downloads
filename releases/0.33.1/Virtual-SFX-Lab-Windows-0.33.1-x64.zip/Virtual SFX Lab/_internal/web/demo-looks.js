import {presets,sample} from './presets.js?v=v0340-20261007f';
// Internal-look tour; entries 71–88 are the catalog's DMX-only extension.
const internalLooks=presets.filter(p=>p.id<=70);
export function demoLookAt(time,index){
 const start=[50,51,42,43][index%4];
 const cycle=internalLooks.reduce((sum,p)=>sum+p.duration+1.1,0);
 let remaining=Math.max(0,time)%cycle;
 for(let k=0;k<internalLooks.length;k++){
  const preset=internalLooks[(start+k)%internalLooks.length];
  if(remaining<preset.duration+1.1){
   const profile={travel:preset.type==='wave'?.22:preset.long?.19:.14,life:preset.type==='wave'?.66:preset.long?.64:.59};
   return {preset,time:remaining,profile,sampleAt:t=>sample(preset,t)};
  }
  remaining-=preset.duration+1.1;
 }
}
