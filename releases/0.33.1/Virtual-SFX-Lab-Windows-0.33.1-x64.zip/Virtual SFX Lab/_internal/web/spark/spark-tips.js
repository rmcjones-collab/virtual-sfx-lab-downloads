/* Spark Studio — Pete's tips, knowledge and lines for a younger crowd (early teens).
 * Short sentences, no jargon without a translation, zero safety jokes about real fire.
 */
window.SPARK_TIPS = {
  stage: [
    { text: 'Click a flame unit to select it. Shift-click to grab a few. Selected ones get an orange ring.', setting: 'Stage → click / Shift-click', keywords: ['select', 'click', 'unit'] },
    { text: 'The little number on each base is the unit number. Addresses start at 1 and go up by 6, because each unit uses 6 channels.', keywords: ['number', 'address', 'base'] },
    { level: 'pro', text: 'Nothing on this stage is real fire. It\'s a simulator, like a flight sim for flame effects. Real shows have trained techs and a lot of rules.', keywords: ['real', 'safe', 'fire'] },
  ],
  select: [
    { text: 'Click empty stage to deselect everything. Select all grabs the whole row.', setting: 'Stage → Select all', keywords: ['deselect', 'all'] },
  ],
  rotate: [
    { text: 'Turn left and Turn right rotate the selected units 5° each click. Try making every other one lean the opposite way.', setting: 'Stage → Turn left / right', keywords: ['rotate', 'turn', 'lean'] },
    { level: 'pro', text: 'Rotation gets saved inside a cue too. So one cue can have flames crossed and the next one can have them straight.', keywords: ['rotation', 'cue', 'saved'] },
  ],
  'flame-scale': [
    { text: 'Flame Scale makes every flame look bigger or smaller, from 0 to 400 percent. It only changes the picture, not the fader numbers or your cues.', setting: 'Stage → Flame Scale', keywords: ['scale', 'size', 'bigger'] },
  ],
  home: [
    { text: 'Home puts everything back to the start: flames off, angle straight, units in their default lean. Press H on the keyboard for the same thing.', setting: 'Stage → Home (or H)', keywords: ['home', 'reset', 'start'] },
  ],
  'fader-height': [
    { text: 'Height is the main one. Up means bigger flame. The number under it, 0 to 255, is exactly what a real console sends.', setting: 'Faders → Height', keywords: ['height', 'big', 'intensity', '255'] },
    { level: 'pro', text: 'Consoles call this "intensity" or "dimmer". Same idea: how much of the effect you get.', keywords: ['intensity', 'dimmer'] },
  ],
  'fader-angle': [
    { text: 'Angle tilts every flame. 50% is straight up. Low leans one way, high leans the other.', setting: 'Faders → Angle', keywords: ['angle', 'tilt', 'lean'] },
    { level: 'pro', text: 'Angle is what moving-head fixtures call "tilt". The real X2 Wave Flame tilts about 210° in total.', keywords: ['tilt', 'moving head', 'x2'] },
  ],
  'fader-program': [
    { text: 'Program is a fader that picks instead of measures. Slide it and the pattern changes: Steady, Flicker, Pulse, Chase, Wave.', setting: 'Faders → Program', keywords: ['program', 'pattern', 'chase', 'wave', 'pulse'] },
    { level: 'pro', text: 'Lots of real fixtures work this way: one channel where ranges of numbers mean different modes. 0–50 might mean "steady", 51–100 "strobe", and so on.', keywords: ['mode', 'range', 'channel'] },
  ],
  'fader-master': [
    { text: 'Master scales everything. Master at 50% means every flame is half of what its Height says.', setting: 'Faders → Master', keywords: ['master', 'grand master', 'scale'] },
    { level: 'pro', text: 'On a real console the Grand Master is the fader you pull down when something goes wrong. Everything goes dark, instantly.', keywords: ['grand master', 'emergency', 'dark'] },
  ],
  flash: [
    { text: 'Hold FLASH to jump that fader to full. Let go and it drops back to where it was. Great for hitting a beat.', setting: 'Faders → FLASH', keywords: ['flash', 'bump', 'beat'] },
    { level: 'pro', text: 'Flash on Master makes the whole show slam to full for a moment. Operators call these "bump buttons".', keywords: ['bump', 'full'] },
  ],
  rename: [
    { text: 'Double-click a fader label to rename it. Call it whatever helps you remember what it does.', setting: 'Faders → double-click label', keywords: ['rename', 'label', 'name'] },
  ],
  cues: [
    { text: 'Each square is a cue slot. Filled ones are orange. Click a filled cue to play it; the little bars show its Height, Angle and Master.', setting: 'Cues → click a slot', keywords: ['cue', 'slot', 'play'] },
    { level: 'pro', text: 'The cue that\'s currently playing glows. Changing a fader by hand takes you "out" of the cue, which is also how real consoles behave.', keywords: ['live', 'glow', 'out of cue'] },
  ],
  'save-look': [
    { text: 'Save look, then pick a slot. A look is just all four fader values plus the unit angles and colors, frozen in time.', setting: 'Cues → Save look to…', keywords: ['save', 'look', 'snapshot', 'record'] },
    { level: 'pro', text: 'Saving into a slot that already has a cue overwrites it. No undo, so maybe pick an empty one unless you mean it.', keywords: ['overwrite', 'replace'] },
  ],
  go: [
    { text: 'GO plays the next cue. Back plays the previous one. Space bar is GO too, Backspace is Back. That\'s how operators run a whole show.', setting: 'Cues → GO / Back (Space / Backspace)', keywords: ['go', 'next', 'space', 'back'] },
    { level: 'pro', text: 'A show file is basically a list of cues and someone pressing GO at the right moment. Timing is the whole art.', keywords: ['show', 'timing', 'operator'] },
  ],
  'fade-time': [
    { text: 'Fade time is how long a cue takes to arrive. 0 is a snap. 4 seconds is a slow, dramatic swell.', setting: 'Cues → Fade time', keywords: ['fade', 'time', 'snap', 'slow'] },
  ],
  'clear-cue': [
    { text: 'Clear wipes the cue that\'s currently playing. Play it first, then Clear.', setting: 'Cues → Clear', keywords: ['clear', 'delete', 'remove cue'] },
  ],
  notes: [
    { text: 'Use Notes to write what each cue is for. "Cue 3 = big wave for the chorus" kind of thing. Future you will say thanks.', setting: 'Notes panel', keywords: ['notes', 'write', 'remember'] },
  ],
  color: [
    { text: 'Colors apply to the selected units, or everyone if nothing is selected. Real flame units don\'t really change color, but this is a sim, so go nuts.', setting: 'Flame color panel', keywords: ['color', 'colour', 'blue', 'green'] },
  ],
  values: [
    { text: 'Live values shows the actual numbers going out: channel, address, and 0–255. This is what the console sends, hundreds of times a second.', setting: 'Live values panel', keywords: ['values', 'dmx', 'numbers', 'channel'] },
    { level: 'pro', text: 'DMX has 512 channels per "universe". Six units × 6 channels = 36 channels. Plenty of room left.', keywords: ['universe', '512', 'channels'] },
  ],
  glossary: [
    { text: 'Words to know is the cheat sheet. If I use a word you don\'t know, it\'s probably in there. Or just ask me.', keywords: ['glossary', 'words', 'meaning'] },
  ],
  customize: [
    { text: 'You\'re in Customize mode. Drag any panel by its header into another column. Drag the thin lines between panels to resize. Esc or Done when you\'re happy.', setting: 'Top bar → Customize Workspace', keywords: ['customize', 'drag', 'resize', 'panel'] },
    { text: 'Entering Customize saved a checkpoint. Revert takes you right back to it, no matter how wild things got.', setting: 'Customize bar → Revert', keywords: ['revert', 'checkpoint', 'undo'] },
    { level: 'pro', text: 'The ⇄ button on a panel moves it to any dock or floats it as a window you can drag anywhere and resize from the corner.', setting: 'Panel header → ⇄ → Float as window', keywords: ['float', 'window', 'dock'] },
    { level: 'pro', text: '＋ and － on a panel header change how much of the column it takes. Same as dragging the divider, just more precise.', setting: 'Panel header → ＋ / －', keywords: ['bigger', 'smaller', 'size'] },
  ],
  'add-panel': [
    { text: 'Add panel lists everything that\'s not open yet: Notes, Flame color, Live values, Words to know. Each one can be open once.', setting: 'Customize bar → Add panel', keywords: ['add', 'panel', 'notes', 'color'] },
  ],
  'move-panel': [
    { text: 'Drop a panel on a column and it slides in where your cursor is. Drop it on the bottom dock for a wide strip.', keywords: ['move', 'drop', 'bottom'] },
  ],
  'save-layout': [
    { text: 'Save layout as… keeps your arrangement with a name. Operators often have one layout for building and another for running the show.', setting: 'Customize bar → Save layout as…', keywords: ['save layout', 'name', 'arrangement'] },
    { level: 'pro', text: 'Export downloads your layout, cues and notes as one JSON file. Import brings it back on another computer.', setting: 'Customize bar → Export / Import', keywords: ['export', 'import', 'json', 'backup'] },
  ],
  patch: [
    { text: 'The Patch panel is where every unit gets its address. Think of it like house numbers on a street: the console needs to know where each unit lives.', setting: 'Patch panel', keywords: ['patch', 'address', 'house'] },
    { level: 'pro', text: 'On a real console this is called "patching". It\'s the first thing you do on a new show, before any cue exists.', keywords: ['patching', 'first'] },
  ],
  address: [
    { text: 'Each unit uses 6 channels, so if unit 1 is at 1, unit 2 should be at 7. Overlaps turn red because both units would react to the same fader.', setting: 'Patch → Address', keywords: ['address', 'overlap', 'red', 'six'] },
    { level: 'pro', text: 'The highest useful start address here is 507, because 507 + 5 = 512, the last channel in the universe.', keywords: ['507', 'highest', 'last'] },
  ],
  'patch-order': [
    { text: 'Patch in order does the math for you: 1, 7, 13, 19, 25, 31. Try saying those out loud, techs memorise them.', setting: 'Patch → Patch in order', keywords: ['order', 'auto', 'math'] },
  ],
  universe: [
    { text: 'A universe is 512 channels on one cable. Two units can share address 7 if they\'re on different universes. Different cable, no clash.', setting: 'Patch → Universe', keywords: ['universe', '512', 'cable', 'share'] },
    { level: 'pro', text: 'Consoles write it as universe.address, like 2.7. Over a network, each universe gets its own stream, which is what sACN does.', keywords: ['2.7', 'sacn', 'network'] },
  ],
  music: [
    { text: 'The beat loop is here so you can practise timing. Four dots, four beats in a bar. The first one is brighter: that\'s the downbeat.', setting: 'Music panel', keywords: ['beat', 'bar', 'downbeat', 'music'] },
  ],
  'music-play': [
    { text: 'Play beat starts the loop. Everything else in this panel needs it running.', setting: 'Music → Play beat', keywords: ['play', 'start', 'loop'] },
  ],
  bpm: [
    { text: 'BPM is beats per minute. 110 is a comfy walking pace, 140 is a fast song. Slow it down while you\'re learning to hit the beat.', setting: 'Music → Tempo', keywords: ['bpm', 'tempo', 'fast', 'slow'] },
  ],
  'music-record': [
    { text: 'Record GOs clears the old timeline and stamps every GO you press with the time. Press it, then play your cues on the beats.', setting: 'Music → Record GOs', keywords: ['record', 'stamp', 'timeline'] },
    { level: 'pro', text: 'Stop recording by clicking the button again. The green "on the beat" tag means you were within a tenth of a second.', keywords: ['stop', 'on the beat', 'tenth'] },
  ],
  'music-show': [
    { text: 'Play timed show restarts the beat and fires your recorded GOs by itself, exactly when you pressed them. That\'s timecode, basically.', setting: 'Music → Play timed show', keywords: ['timed', 'playback', 'timecode', 'automatic'] },
  ],
  timeline: [
    { text: 'The timed show list is your recording: which cue, at what second. Clear it and record again if the timing was off.', setting: 'Music → Timed show', keywords: ['timeline', 'list', 'clear'] },
  ],
  classroom: [
    { text: 'Classroom button: pick your name so your missions and cues save under it. Sharing a computer? Everyone gets their own.', setting: 'Classroom → Students', keywords: ['classroom', 'name', 'student', 'share'] },
    { level: 'pro', text: 'Teachers: the Teacher tab has reset, CSV export and a class backup. The PIN keeps curious hands out, mostly.', keywords: ['teacher', 'pin', 'export', 'reset'] },
  ],
  missions: [
    { text: 'Missions are little lessons with goals. I walk you through, then you do it for real. Goals tick off by themselves when you do them.', setting: 'Missions panel', keywords: ['mission', 'lesson', 'goal', 'xp'] },
  ],
};

window.SPARK_KNOWLEDGE = [
  { title: 'Pete settings', keywords: ['settings', 'size', 'bigger', 'smaller', 'resize', 'api key', 'api', 'connect', 'provider', 'openai', 'perplexity', 'gemini', 'claude', 'voice speed', 'other corner', 'gear'], answer: 'Hover over me and press the gear in my little toolbar. Six tabs: Look (size, corner, bubble beside or above, Always on top, eye tracking, moving and walking), Voice (read aloud, speed, pitch, voice source and sound effects), Behavior (mood, humor, greeting, idle remarks, bubble time, memory), Tips (hover tips, delay, spacing, level and the tips I recite), Gestures (every move I can make, with Play and a tick to allow it as a fidget; silly humor off is classroom-safe) and AI connection, where your own provider key (Perplexity, OpenAI, Anthropic, Gemini or an OpenAI-compatible server) lets me answer anything, not just my notes. The key stays in this browser and goes only to that provider.' },
  { title: 'Classroom mode', keywords: ['classroom', 'class', 'student', 'students', 'teacher', 'pin', 'export', 'reset', 'csv', 'switch user', 'my name'], answer: 'Click Classroom in the top bar. Students pick or add their name and get their own missions, XP, cues and layout on this computer. The Teacher tab (4-digit PIN) can reset one student or everyone, export a progress CSV, and download or import a class backup.' },
  { title: 'Addresses', keywords: ['address', 'addresses', 'patch', 'start channel', 'overlap', 'conflict'], answer: 'Every unit has a start address: the first channel it listens on. Each unit here uses 6 channels, so if unit 1 is at 1, unit 2 goes at 7, unit 3 at 13, and so on. If two units overlap in the same universe, they both react to the same fader and the Patch panel turns red. Patch in order fixes it instantly.' },
  { title: 'Universes', keywords: ['universe', 'universes', '512', 'second universe', 'cable'], answer: 'A universe is 512 channels, originally one cable. When you run out of channels, you add another universe. Address 7 on universe 1 and address 7 on universe 2 are different places, so there\'s no conflict. Consoles write it as 2.7. 85 six-channel units fit in one universe.' },
  { title: 'Timing to music', keywords: ['music', 'beat', 'tempo', 'bpm', 'timing', 'rhythm', 'timecode', 'on the beat', 'record'], answer: 'Open the Music panel and press Play beat. Press GO (Space) on the beats; within a tenth of a second counts as on the beat. Record GOs stamps each press with its time, and Play timed show replays them automatically. That\'s how real shows sync effects to songs, usually with timecode from the music.' },
  { title: 'What is a fader', keywords: ['what is a fader', 'fader', 'slider'], answer: 'A fader is a slider that sets one value from 0 to 255. On a lighting or effects console, almost everything starts as a fader: how bright, how big, what angle, which pattern. Push it up, the number goes up, the thing you control does more.' },
  { title: 'What is a cue', keywords: ['what is a cue', 'cue', 'cues'], answer: 'A cue is a saved look with a number. You build the look with your faders, save it into a cue slot, and later play it back by clicking it or pressing GO. A whole show is just a list of cues played in order.' },
  { title: 'What is DMX', keywords: ['dmx', 'what is dmx', 'protocol', '512'], answer: 'DMX is the language consoles use to talk to lights and effects. One DMX "universe" has 512 channels and each channel carries a number from 0 to 255. Each fixture listens from its address onward. Here, unit 1 starts at address 1 and uses 6 channels.' },
  { title: 'What is a look', keywords: ['look', 'snapshot', 'what is a look'], answer: 'A look is a snapshot of all your fader values (plus unit angles and colors) at one moment. Save a look into a cue so you can get back to it later.' },
  { title: 'What is GO', keywords: ['go button', 'what does go do', 'go'], answer: 'GO plays the next cue in order. Back plays the previous one. Space bar is GO, Backspace is Back. Real operators run entire concerts by pressing GO at exactly the right moments.' },
  { title: 'Master fader', keywords: ['master', 'grand master'], answer: 'Master scales everything. Master at 50% means every flame is half of its Height. On a real console the Grand Master is the emergency "everything off" fader.' },
  { title: 'Is this real fire', keywords: ['real', 'fire', 'dangerous', 'safe', 'burn', 'actually'], answer: 'No. Spark Studio is a simulator. Nothing here connects to real equipment. Real flame effects are run by trained, licensed technicians with a lot of safety rules, and that\'s a good thing. This is where you learn the console part.' },
  { title: 'Programs', keywords: ['program', 'pattern', 'chase', 'wave', 'pulse', 'flicker', 'steady'], answer: 'The Program fader picks a pattern: Steady, Flicker, Pulse, Chase (one after another) and Wave (a rolling sway). It\'s a fader that chooses a mode instead of measuring an amount. Many real fixtures have channels like this.' },
  { title: 'Fade time', keywords: ['fade', 'fade time', 'how long', 'smooth'], answer: 'Fade time is how long a cue takes to arrive. Set it to 0 for an instant snap, or a few seconds for a smooth swell. It\'s in the Cues panel.' },
  { title: 'Customize workspace', keywords: ['customize', 'workspace', 'panel', 'move', 'layout', 'rearrange'], answer: 'Click Customize Workspace in the top bar. Then drag panels by their headers into other columns, use ⇄ to dock or float them, drag the thin dividers to resize, Add panel for more tools, and Save layout as… to keep it. Revert undoes everything back to when you started customizing.' },
  { title: 'Saving', keywords: ['save', 'saved', 'lose', 'progress', 'where'], answer: 'Everything saves automatically in this browser: your faders, cues, notes, layout and mission progress. Export in the Customize bar downloads it all as one file if you want to move computers.' },
  { title: 'XP and missions', keywords: ['xp', 'points', 'mission', 'missions', 'level'], answer: 'Missions are mini lessons with goals that tick off by themselves when you do them. Each finished mission gives XP. Four missions, 300 XP total. Start one from the Missions panel and I\'ll walk you through it.' },
  { title: 'Wave Studio', keywords: ['wave studio', 'grown up', 'real version', 'pro version', 'next'], answer: 'When you\'ve outgrown this, Wave Studio is the full version: real fixture profiles, console input over sACN, exports for Vista and grandMA. Same ideas, way more knobs.' },
];

window.SPARK_LINES = {
  greet: [
    "Hey. I'm {name}. I hang out down here. Click me if anything is confusing.",
    "Yo, I'm {name}. Chill guide. Ask me anything, I don't do judgement.",
  ],
  idle: [
    "No rush. Faders don't have feelings.",
    "Hot tip: Space bar is GO. Backspace is Back. You're basically an operator now.",
    "If you get stuck, click me. That's literally the whole reason I exist.",
    "Random fact: a real console sends those 0–255 numbers about 44 times every second.",
    "I'd high-five you but I'm made of vectors.",
  ],
  jokes: [
    "Why did the fader go to therapy? It had trouble letting go. Full to zero takes time.",
    "I asked the stage for its best look. It said 'depends on the angle.' Which, fair. That's literally a fader.",
    "What's a flame's favourite button? FLASH. Obviously. It's the only one that shouts.",
    "My favourite cue is Home. Zero drama. Everything goes back to where it started.",
    "I tried to tell a DMX joke but it had 512 parts and nobody made it to the end.",
  ],
  thinking: ["Lemme check...", "One sec, flipping through my notes...", "Good question. Hang on."],
  noAnswer: [
    "Honestly, not sure about that one. Try asking it a different way, or check Words to know.",
    "That one's above my pay grade. Which is zero. Ask me about faders, cues or the workspace and I'm your guy.",
  ],
  encourage: ["Nice. That's exactly how it's done.", "Clean. You're getting good at this.", "Look at you, operating like a pro."],
  tourStart: ["Cool, quick walkthrough. I'll point, you look. Hit Start when you're ready."],
  tourEnd: ["That's the tour. Now the goals in the Missions panel are yours. Go.", "Done talking. Your turn. Finish the goals and I'll hand over the XP."],
};

window.SPARK_REACTIONS = {
  'first-flash': { lines: ['FLASH. See how it drops back when you let go? Operators call that a bump button.', 'That\'s FLASH. Hold for full, release to drop. Drummers love it.'], mood: 'laugh', gesture: 'bounce' },
  saved: { lines: ['Look saved. Congrats, that\'s a cue now. Change the faders and click it to bring it back.', 'Saved. That snapshot is a cue. Future you can replay it any time.'], mood: 'happy', gesture: 'thumbs' },
  collision: { lines: ['Red means two units share channels. Move one fader and they\'d both jump. Give one of them a new address.', 'Collision. Same channels, same universe. Change an address, or hit Patch in order.'], mood: 'thinking', gesture: 'point' },
  'tour-complete': { lines: ['Tour done. Now the goals are yours. I\'ll tick them off as you go.'], mood: 'happy', gesture: 'thumbs' },
};
