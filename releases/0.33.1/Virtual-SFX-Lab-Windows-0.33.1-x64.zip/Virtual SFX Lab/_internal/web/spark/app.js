/* Spark Studio — a Virtual SFX Lab learning app for early teens.
 * Faders, looks, cues and a customizable workspace, with Pete as guide.
 * Vanilla JS, no build step. Everything saves in this browser.
 */
(() => {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  // Classroom: when enabled, per-student keys live under spark.s.<name>.<key>
  const CLASS = (() => { try { return Object.assign({ enabled: false, pin: '', students: {}, current: null }, JSON.parse(localStorage.getItem('spark.class')) || {}); } catch (e) { return { enabled: false, pin: '', students: {}, current: null }; } })();
  const STUDENT_KEYS = new Set(['progress', 'show', 'layout', 'layouts', 'activeMission', 'welcomed']);
  const nsKey = (k) => (CLASS.enabled && CLASS.current && STUDENT_KEYS.has(k)) ? `spark.s.${CLASS.current}.${k}` : 'spark.' + k;
  const LS = { get(k, d) { try { const v = localStorage.getItem(nsKey(k)); return v == null ? d : JSON.parse(v); } catch (e) { return d; } }, set(k, v) { try { localStorage.setItem(nsKey(k), JSON.stringify(v)); } catch (e) {} }, del(k) { try { localStorage.removeItem(nsKey(k)); } catch (e) {} } };

  // --------------------------------------------------------------------------
  // Event bus
  // --------------------------------------------------------------------------
  const bus = { h: {}, on(t, f) { (this.h[t] = this.h[t] || []).push(f); return () => this.off(t, f); }, off(t, f) { this.h[t] = (this.h[t] || []).filter((x) => x !== f); }, emit(t, d) { (this.h[t] || []).forEach((f) => f(d)); (this.h['*'] || []).forEach((f) => f(t, d)); } };

  // --------------------------------------------------------------------------
  // Show state: six units, four faders, eight cues
  // --------------------------------------------------------------------------
  const COLORS = {
    orange: { c1: '#fff2b0', c2: '#ffb03b', c3: '#ff6a1a' },
    blue: { c1: '#e6f7ff', c2: '#7ad0ff', c3: '#2a6cff' },
    green: { c1: '#f0ffd6', c2: '#9ee86a', c3: '#1f9d4a' },
    purple: { c1: '#f6e8ff', c2: '#c79bff', c3: '#7a3cff' },
    pink: { c1: '#ffe9f3', c2: '#ff8fc2', c3: '#ff2f7a' },
    white: { c1: '#ffffff', c2: '#e8e8ff', c3: '#a8b4ff' },
  };
  const PROGRAMS = ['Steady', 'Flicker', 'Pulse', 'Chase', 'Wave'];
  const PROGRAM_CLASS = ['', 'flick', 'pulse', 'chase', 'wave'];

  const show = LS.get('show', null) || {
    units: Array.from({ length: 6 }, (_, i) => ({ id: i + 1, rot: 0, color: 'orange', addr: 1 + i * 6, uni: 1 })),   // units start straight up
    faders: { height: 25, angle: 50, program: 1, master: 100 },
    labels: { height: 'Height', angle: 'Angle', program: 'Program', master: 'Master' },
    selected: [],
    cues: Array(8).fill(null),
    fadeMs: 800,
    liveCue: null,
    notes: '',
  };
  show.units.forEach((u) => { if (!u.uni) u.uni = 1; });
  // Units now start straight up. A saved show still on the old untouched fan (+14 / -14) is straightened once.
  if (!show.v || show.v < 2) {
    if (show.units.every((u, i) => u.rot === (i % 2 ? -14 : 14))) show.units.forEach((u) => { u.rot = 0; });
    show.v = 2;
  }
  // Visual flame scale (0 to 400 %), display only: it never changes fader values or cues.
  if (!Number.isFinite(show.flameScale)) show.flameScale = 100;
  show.flameScale = clamp(Math.round(show.flameScale), 0, 400);
  if (!show.music) show.music = { bpm: 110, timeline: [] };
  function saveShow() { LS.set('show', show); }
  const FOOT = 6; // channels per unit
  function conflicts() {
    const bad = new Set();
    show.units.forEach((a) => show.units.forEach((b) => { if (a.id < b.id && a.uni === b.uni && a.addr < b.addr + FOOT && b.addr < a.addr + FOOT) { bad.add(a.id); bad.add(b.id); } }));
    return bad;
  }

  let flashing = {};
  const live = { height: show.faders.height, angle: show.faders.angle }; // animated values used for rendering

  function effective(f) {
    const v = show.faders[f];
    if (f === 'height') return clamp((flashing.height ? 100 : v) * (flashing.master ? 1 : show.faders.master / 100), 0, 100);
    return flashing[f] ? 100 : v;
  }

  // --------------------------------------------------------------------------
  // Panel registry
  // --------------------------------------------------------------------------
  const PANELS = {
    stage: {
      title: 'Stage', protected: true,
      render(el) {
        el.innerHTML = `<div class="stage" data-tour="stage">
          <div class="stage-floor" tabindex="0" aria-label="Virtual stage with six flame units" data-vls-context="stage"></div>
          <div class="stage-toolbar">
            <button class="chip" data-act="rotL" data-tour="rotate" data-vls-context="rotate" title="Turn selected units left">⟲ Turn left</button>
            <button class="chip" data-act="rotR" data-vls-context="rotate" title="Turn selected units right">Turn right ⟳</button>
            <button class="chip" data-act="all" data-vls-context="select">Select all</button>
            <button class="chip" data-act="home" data-tour="home" data-vls-context="home">Home</button>
            <label class="chip flame-scale" data-vls-context="flame-scale" title="Visual flame size, 0 to 400 percent. Display only: faders and cues are not changed.">Flame Scale <input type="range" min="0" max="400" step="5" value="${show.flameScale}" aria-label="Flame scale"><output>${show.flameScale}%</output></label>
            <span class="sel"></span>
          </div></div>`;
        const floor = $('.stage-floor', el);
        show.units.forEach((u) => {
          const d = document.createElement('div');
          d.className = 'unit'; d.dataset.id = u.id; d.title = `Unit ${u.id} · address ${u.addr}`;
          d.innerHTML = `<div class="flame-wrap"><div class="flame"></div></div><div class="head"></div><div class="base">${escapeHtml(u.id)}</div>`;
          d.addEventListener('click', (e) => { e.stopPropagation(); selectUnit(u.id, e.shiftKey || e.ctrlKey || e.metaKey); });
          floor.appendChild(d);
        });
        floor.addEventListener('click', () => { show.selected = []; bus.emit('select', show.selected); });
        const fs = $('.flame-scale input', el);
        fs.addEventListener('input', () => { show.flameScale = clamp(Math.round(Number(fs.value) || 0), 0, 400); $('.flame-scale output', el).textContent = show.flameScale + '%'; render(); });
        fs.addEventListener('change', saveShow);
        fs.addEventListener('click', (e) => e.stopPropagation());
        el.addEventListener('click', (e) => {
          const b = e.target.closest('[data-act]'); if (!b) return;
          const act = b.dataset.act;
          if (act === 'all') { show.selected = show.units.map((u) => u.id); bus.emit('select', show.selected); }
          if (act === 'rotL' || act === 'rotR') rotateSelected(act === 'rotL' ? -5 : 5);
          if (act === 'home') home();
        });
        this.update(el);
      },
      update(el) {
        const h = effective('height') / 100, a = live.angle, prog = PROGRAM_CLASS[Math.round(show.faders.program / 25)];
        const fsv = show.flameScale / 100;   // height follows the slider; width grows more gently so big flames stay apart
        el.style.setProperty('--fs', fsv.toFixed(2)); el.style.setProperty('--fsx', (fsv <= 1 ? fsv : 1 + (fsv - 1) * 0.3).toFixed(2));
        const fsIn = $('.flame-scale input', el); if (fsIn && document.activeElement !== fsIn && Number(fsIn.value) !== show.flameScale) { fsIn.value = show.flameScale; $('.flame-scale output', el).textContent = show.flameScale + '%'; }
        $$('.unit', el).forEach((d, i) => {
          const u = show.units[i];
          const c = COLORS[u.color] || COLORS.orange;
          d.style.setProperty('--lvl', h.toFixed(3));
          d.style.setProperty('--rot', (u.rot + (a - 50) * 0.9) + 'deg');
          d.style.setProperty('--col1', c.c1); d.style.setProperty('--col2', c.c2); d.style.setProperty('--col3', c.c3);
          d.classList.toggle('selected', show.selected.includes(u.id));
          PROGRAM_CLASS.forEach((k) => k && d.classList.remove(k));
          if (prog && h > 0.02) { d.classList.add(prog); $('.flame', d).style.animationDelay = prog === 'chase' ? (i * 0.3) + 's' : prog === 'wave' ? (i * 0.25) + 's' : (i * 0.17) + 's'; }
        });
        const sel = $('.sel', el); if (sel) sel.textContent = show.selected.length ? `${show.selected.length} selected` : 'Click a unit · Shift-click for more';
      },
    },

    faders: {
      title: 'Faders',
      render(el) {
        el.innerHTML = `<div class="faders" data-tour="faders">${['height', 'angle', 'program', 'master'].map((f) => `
          <div class="fader ${f}" data-f="${f}" data-vls-context="fader-${f}" ${f === 'height' ? 'data-tour="fader-height"' : f === 'master' ? 'data-tour="fader-master"' : ''}>
            <label title="Double-click to rename" data-vls-context="rename">${escapeHtml(show.labels[f])}</label>
            <div class="track"><input type="range" min="0" max="100" step="1" value="${Number(show.faders[f]) || 0}" aria-label="${escapeHtml(show.labels[f])}"></div>
            <div class="val"></div>
            <button class="flash" data-vls-context="flash" ${f === 'height' ? 'data-tour="flash"' : ''} ${f === 'program' ? 'disabled title="Program has no flash"' : ''}>FLASH</button>
          </div>`).join('')}</div>
          <div class="hint">Faders are just numbers from 0 to 255. Push one up and watch the stage. <span class="key">Shift</span>+drag moves all of them.</div>`;
        $$('.fader', el).forEach((fd) => {
          const f = fd.dataset.f; const inp = $('input', fd); const flash = $('.flash', fd); const lab = $('label', fd);
          inp.addEventListener('input', (e) => { setFader(f, +inp.value, e.shiftKey); });
          inp.addEventListener('pointerdown', (e) => { if (e.shiftKey) shiftBase = { ...show.faders, start: +inp.value }; else shiftBase = null; });
          const down = (e) => { e.preventDefault(); flashing[f] = true; flash.classList.add('on'); bus.emit('flash', { fader: f, on: true }); render(); };
          const up = () => { if (!flashing[f]) return; flashing[f] = false; flash.classList.remove('on'); bus.emit('flash', { fader: f, on: false }); render(); };
          flash.addEventListener('pointerdown', down); flash.addEventListener('pointerup', up); flash.addEventListener('pointerleave', up); flash.addEventListener('pointercancel', up);
          flash.addEventListener('keydown', (e) => { if (e.key === ' ' || e.key === 'Enter') down(e); }); flash.addEventListener('keyup', up);
          lab.addEventListener('dblclick', () => { const n = prompt('Name this fader', show.labels[f]); if (n && n.trim()) { show.labels[f] = n.trim().slice(0, 14); saveShow(); bus.emit('rename', { fader: f, name: show.labels[f] }); renderAll(); } });
        });
        this.update(el);
      },
      update(el) {
        $$('.fader', el).forEach((fd) => {
          const f = fd.dataset.f; const v = show.faders[f]; const inp = $('input', fd);
          if (document.activeElement !== inp && +inp.value !== v) inp.value = v;
          const val = $('.val', fd);
          if (f === 'program') val.innerHTML = `${PROGRAMS[Math.round(v / 25)]}`;
          else val.innerHTML = `${Math.round(v * 2.55)} <small>/ ${v}%</small>`;
          fd.classList.toggle('hot', !!flashing[f]);
          $('label', fd).textContent = show.labels[f];
        });
      },
    },

    cues: {
      title: 'Cues',
      render(el) {
        el.innerHTML = `<div class="cues-grid" data-tour="cues"></div>
          <div class="cue-row">
            <button class="btn sm primary" data-act="save" data-tour="save-look" data-vls-context="save-look">Save look to…</button>
            <button class="btn sm go" data-act="go" data-tour="go" data-vls-context="go">GO ▸</button>
            <button class="btn sm" data-act="back" data-vls-context="go">◂ Back</button>
            <button class="btn sm" data-act="clear" data-vls-context="clear-cue">Clear</button>
          </div>
          <div class="fade-ctl" data-vls-context="fade-time"><span>Fade time</span><input type="range" min="0" max="4000" step="100" value="${show.fadeMs}"><b class="fade-v">${(show.fadeMs / 1000).toFixed(1)}s</b></div>
          <div class="hint">A <b>look</b> is a snapshot of all your faders. Save it into a cue, then hit GO to play cues in order.</div>`;
        const grid = $('.cues-grid', el);
        show.cues.forEach((c, i) => {
          const b = document.createElement('button'); b.className = 'cue'; b.dataset.i = i;
          b.innerHTML = `<b>${i + 1}</b><span class="lbl"></span><span class="mini"></span>`;
          b.addEventListener('click', () => { if (arming) { saveLook(i); arming = false; } else if (show.cues[i]) playCue(i); else { arming = true; saveLook(i); arming = false; } this.update(el); });
          grid.appendChild(b);
        });
        let arming = false;
        el.addEventListener('click', (e) => {
          const b = e.target.closest('[data-act]'); if (!b) return;
          const act = b.dataset.act;
          if (act === 'save') { arming = !arming; toast(arming ? 'Pick a cue slot to save this look into' : 'Cancelled'); this.update(el); }
          if (act === 'go') go(1); if (act === 'back') go(-1);
          if (act === 'clear') { if (show.liveCue != null) { show.cues[show.liveCue] = null; show.liveCue = null; saveShow(); bus.emit('cue-clear'); this.update(el); toast('Cue cleared'); } else toast('Play a cue first, then Clear removes it'); }
        });
        $('.fade-ctl input', el).addEventListener('input', (e) => { show.fadeMs = +e.target.value; $('.fade-v', el).textContent = (show.fadeMs / 1000).toFixed(1) + 's'; saveShow(); bus.emit('fade-time', show.fadeMs); });
        this.update = (el2) => {
          $$('.cue', el2).forEach((b, i) => {
            const c = show.cues[i];
            b.classList.toggle('filled', !!c); b.classList.toggle('live', show.liveCue === i); b.classList.toggle('arm', arming);
            $('.lbl', b).textContent = c ? PROGRAMS[Math.round(c.faders.program / 25)] : 'empty';
            $('.mini', b).innerHTML = c ? ['height', 'angle', 'master'].map((f) => `<i style="transform:scaleY(${(c.faders[f] / 100).toFixed(2)})"></i>`).join('') : '';
          });
          $('[data-act="save"]', el2).classList.toggle('primary', !arming);
          $('[data-act="save"]', el2).textContent = arming ? 'Click a slot…' : 'Save look to…';
        };
        this.update(el);
      },
      update() {},
    },

    missions: {
      title: 'Missions',
      render(el) { this.update(el); },
      update(el) {
        el.innerHTML = MISSIONS.map((m) => {
          const prog = missionProgress(m);
          const done = prog.every(Boolean);
          return `<div class="mission ${done ? 'done' : ''} ${activeMission === m.id ? 'active' : ''}" data-tour="mission-${m.id}">
            <h3><span class="badge">${done ? '✓' : m.n}</span>${m.title}<span style="margin-left:auto;font-size:11px;color:var(--dim)">${m.xp} XP</span></h3>
            <p>${m.blurb}</p>
            <ul>${m.goals.map((g, i) => `<li class="${prog[i] ? 'ok' : ''}${g.quiz && !prog[i] ? ' has-quiz' : ''}">${g.quiz && !prog[i] ? `<span>${g.text}</span><span class="quiz"><input type="text" inputmode="numeric" data-q="${g.quiz.id}" placeholder="?" aria-label="Answer"><button class="btn sm" data-check="${g.quiz.id}">Check</button></span>` : g.text}</li>`).join('')}</ul>
            <button class="btn sm ${done ? '' : 'primary'}" data-m="${m.id}">${done ? 'Replay with Pete' : activeMission === m.id ? 'Pete, explain again' : 'Start with Pete'}</button>
          </div>`;
        }).join('');
        $$('[data-m]', el).forEach((b) => b.addEventListener('click', () => startMission(b.dataset.m)));
        $$('[data-check]', el).forEach((b) => b.addEventListener('click', () => { const id = b.dataset.check; const q = MISSIONS.flatMap((m) => m.goals).find((g) => g.quiz && g.quiz.id === id).quiz; answerQuiz(q, $(`[data-q="${id}"]`, el).value); }));
        $$('[data-q]', el).forEach((i) => i.addEventListener('keydown', (e) => { if (e.key === 'Enter') $(`[data-check="${i.dataset.q}"]`, el).click(); }));
      },
    },

    notes: {
      title: 'Notes',
      render(el) {
        el.innerHTML = `<div class="notes" style="height:100%" data-vls-context="notes"><textarea placeholder="Write down what each cue does, ideas for a show, things Pete said…">${escapeHtml(show.notes)}</textarea></div>`;
        $('textarea', el).addEventListener('input', (e) => { show.notes = e.target.value; saveShow(); bus.emit('notes'); });
      },
      update() {},
    },

    color: {
      title: 'Flame color',
      render(el) {
        el.innerHTML = `<div class="swatches" data-vls-context="color">${Object.entries(COLORS).map(([k, c]) => `<button class="swatch" data-c="${k}" style="--c1:${c.c1};--c2:${c.c2};--c3:${c.c3}"><i></i>${k}</button>`).join('')}</div>
          <div class="hint">Colors apply to the <b>selected</b> units (or all, if none are selected). Real flame units don't change color, but imagining is allowed.</div>`;
        $$('.swatch', el).forEach((b) => b.addEventListener('click', () => { const ids = show.selected.length ? show.selected : show.units.map((u) => u.id); show.units.forEach((u) => { if (ids.includes(u.id)) u.color = b.dataset.c; }); saveShow(); bus.emit('color', b.dataset.c); render(); }));
      },
      update() {},
    },

    values: {
      title: 'Live values',
      render(el) { el.innerHTML = '<div class="values" data-vls-context="values"></div>'; this.update(el); },
      update(el) {
        const rows = [['Height', effective('height')], ['Angle', effective('angle')], ['Program', show.faders.program], ['Master', show.faders.master]];
        const u = show.units.find((x) => x.id === show.selected[0]) || show.units[0];
        $('.values', el).innerHTML = `<table><tr><th>Channel</th><th>Addr</th><th>Level</th><th style="text-align:right">DMX</th></tr>
          ${rows.map(([n, v], i) => `<tr><td>${escapeHtml(n)}</td><td class="addr">${Number(u.uni)}.${Number(u.addr) + i}</td><td><div class="bar"><i style="width:${Number(v) || 0}%"></i></div></td><td class="num">${Math.round((Number(v) || 0) * 2.55)}</td></tr>`).join('')}</table>
          <div class="hint">Showing unit ${escapeHtml(u.id)} (universe ${Number(u.uni)}, address ${Number(u.addr)}). Every fader becomes a number 0–255 on a channel. A console just sends these numbers really fast.</div>`;
      },
    },


    patch: {
      title: 'Patch',
      render(el) {
        el.innerHTML = `<div class="patch" data-tour="patch" data-vls-context="patch">
          <table><thead><tr><th>Unit</th><th>Universe</th><th>Address</th><th>Uses</th></tr></thead><tbody></tbody></table>
          <div class="patch-side"><div class="cue-row">
            <button class="btn sm" data-act="inorder" data-tour="patch-order" data-vls-context="patch-order">Patch in order</button>
            <button class="btn sm" data-act="split" data-vls-context="universe">Split across 2 universes</button>
          </div>
          <div class="patch-status"></div>
          <div class="hint">Each unit listens on <b>6 channels</b> starting at its address. Two units can't share channels in the same universe. A universe has 512 channels.</div></div></div>`;
        const tb = $('tbody', el);
        show.units.forEach((u) => {
          const tr = document.createElement('tr'); tr.dataset.id = u.id;
          tr.innerHTML = `<td><b>${escapeHtml(u.id)}</b></td>
            <td><select data-f="uni" data-vls-context="universe" aria-label="Unit ${escapeHtml(u.id)} universe"><option value="1">1</option><option value="2">2</option></select></td>
            <td><input type="number" data-f="addr" min="1" max="${512 - FOOT + 1}" step="1" data-vls-context="address" aria-label="Unit ${escapeHtml(u.id)} address"></td>
            <td class="range"></td>`;
          tb.appendChild(tr);
          $('[data-f="uni"]', tr).addEventListener('change', (e) => setPatch(u.id, { uni: +e.target.value }));
          $('[data-f="addr"]', tr).addEventListener('change', (e) => setPatch(u.id, { addr: clamp(parseInt(e.target.value, 10) || 1, 1, 512 - FOOT + 1) }));
        });
        el.addEventListener('click', (e) => {
          const b = e.target.closest('[data-act]'); if (!b) return;
          if (b.dataset.act === 'inorder') { show.units.forEach((u, i) => { u.uni = 1; u.addr = 1 + i * FOOT; }); saveShow(); bus.emit('patch', { auto: true }); render(); toast('Patched 1, 7, 13, 19, 25, 31 in universe 1'); }
          if (b.dataset.act === 'split') { show.units.forEach((u, i) => { u.uni = i < 3 ? 1 : 2; u.addr = 1 + (i % 3) * FOOT; }); saveShow(); bus.emit('patch', { split: true }); render(); toast('Units 1–3 on universe 1, units 4–6 on universe 2, same addresses'); }
        });
        this.update(el);
      },
      update(el) {
        const bad = conflicts();
        $$('tbody tr', el).forEach((tr) => {
          const u = show.units.find((x) => x.id === +tr.dataset.id);
          const sel = $('[data-f="uni"]', tr), inp = $('[data-f="addr"]', tr);
          if (document.activeElement !== sel) sel.value = u.uni; if (document.activeElement !== inp) inp.value = u.addr;
          $('.range', tr).innerHTML = `<span class="addr">${Number(u.uni)}.${Number(u.addr)}–${Number(u.addr) + FOOT - 1}</span>`;
          tr.classList.toggle('conflict', bad.has(u.id));
        });
        const st = $('.patch-status', el);
        st.innerHTML = bad.size ? `<span class="warn">⚠ Conflict: units ${escapeHtml([...bad].join(', '))} overlap. They'd all react to the same fader moves.</span>` : `<span class="good">✓ No conflicts. ${new Set(show.units.map((u) => u.uni)).size} universe(s) in use.</span>`;
      },
    },

    music: {
      title: 'Music & timing',
      render(el) {
        el.innerHTML = `<div class="music" data-tour="music" data-vls-context="music">
          <div class="beat-row"><span class="beats">${[0, 1, 2, 3].map((i) => `<i data-b="${i}"></i>`).join('')}</span><span class="bar-count">bar 0</span><span class="clock">0.0s</span></div>
          <div class="cue-row">
            <button class="btn sm primary" data-act="play" data-tour="music-play" data-vls-context="music-play">▶ Play beat</button>
            <button class="btn sm" data-act="rec" data-tour="music-rec" data-vls-context="music-record">● Record GOs</button>
            <button class="btn sm go" data-act="show" data-tour="music-show" data-vls-context="music-show">▶ Play timed show</button>
          </div>
          <div class="fade-ctl" data-vls-context="bpm" data-tour="bpm"><span>Tempo</span><input type="range" min="70" max="160" step="1" value="${show.music.bpm}"><b class="bpm-v">${show.music.bpm} BPM</b></div>
          <div class="timeline" data-vls-context="timeline"><div class="tl-head">Timed show <button class="btn sm" data-act="clear">Clear</button></div><ol class="tl-list"></ol></div>
          <div class="hint">Press <b>Play beat</b>, then hit <b>GO</b> (Space) on the beat. In <b>Record</b> mode every GO is stamped with its time so the show can replay itself.</div></div>`;
        $('.fade-ctl input', el).addEventListener('input', (e) => { show.music.bpm = +e.target.value; $('.bpm-v', el).textContent = show.music.bpm + ' BPM'; saveShow(); music.setBpm(show.music.bpm); bus.emit('bpm', show.music.bpm); });
        el.addEventListener('click', (e) => {
          const b = e.target.closest('[data-act]'); if (!b) return;
          const act = b.dataset.act;
          if (act === 'play') music.toggle();
          if (act === 'rec') music.toggleRecord();
          if (act === 'show') music.playShow();
          if (act === 'clear') { show.music.timeline = []; saveShow(); this.update(el); toast('Timed show cleared'); }
        });
        this.update(el);
      },
      update(el) {
        const st = music.state();
        $('[data-act="play"]', el).textContent = st.playing ? '■ Stop beat' : '▶ Play beat';
        $('[data-act="play"]', el).classList.toggle('primary', !st.playing);
        $('[data-act="rec"]', el).classList.toggle('rec-on', st.recording);
        $('[data-act="rec"]', el).textContent = st.recording ? '● Recording… (GO to stamp)' : '● Record GOs';
        $('[data-act="show"]', el).disabled = !show.music.timeline.length;
        $('.tl-list', el).innerHTML = show.music.timeline.length ? show.music.timeline.map((t, i) => `<li class="${st.fired > i ? 'fired' : ''}"><span>cue ${t.cue + 1}</span><span class="addr">${t.t.toFixed(2)}s</span><span class="onbeat">${t.onBeat ? 'on the beat' : ''}</span></li>`).join('') : '<li class="empty">No GOs recorded yet.</li>';
      },
    },

    glossary: {
      title: 'Words to know',
      render(el) {
        el.innerHTML = `<dl class="gloss" data-vls-context="glossary">
          <dt>Fader</dt><dd>A slider that sets one value from 0 to 255 (shown as 0–100%).</dd>
          <dt>Look</dt><dd>A snapshot of all fader values at once.</dd>
          <dt>Cue</dt><dd>A saved look with a number, so you can play it back in order.</dd>
          <dt>GO</dt><dd>The button that plays the next cue. The most important button on any console.</dd>
          <dt>Fade time</dt><dd>How long it takes to move from one cue to the next.</dd>
          <dt>Master</dt><dd>A fader that scales everything. Master at 50% means every flame is half height.</dd>
          <dt>Flash</dt><dd>Hold to jump a fader to full, release to drop back.</dd>
          <dt>DMX</dt><dd>The language consoles use to talk to lights and effects: 512 channels, each 0–255.</dd>
          <dt>Address</dt><dd>The first channel a unit listens on. Unit 1 here starts at address 1 and uses 6 channels, so unit 2 starts at 7.</dd>
          <dt>Universe</dt><dd>512 channels on one cable or network stream. Address 7 on universe 1 and 7 on universe 2 are different places.</dd>
          <dt>Patch</dt><dd>Telling the console which unit lives at which universe and address.</dd>
          <dt>BPM</dt><dd>Beats per minute: the speed of the music. 110 is walking pace, 140 is fast.</dd>
          <dt>Timecode</dt><dd>A clock that runs with the music so cues fire at the exact same moment every show.</dd>
          <dt>Home</dt><dd>Resets everything to its starting position. Zero drama.</dd>
        </dl>`;
      },
      update() {},
    },
  };

  // --------------------------------------------------------------------------
  // Show actions
  // --------------------------------------------------------------------------
  let shiftBase = null;
  function setFader(f, v, shift) {
    v = clamp(Math.round(v), 0, 100);
    if (shift && shiftBase) { const d = v - shiftBase.start; ['height', 'angle', 'master'].forEach((k) => { show.faders[k] = clamp(shiftBase[k] + d, 0, 100); }); show.faders[f] = v; }
    else show.faders[f] = v;
    show.liveCue = null;
    saveShow(); bus.emit('fader', { fader: f, value: v }); render();
  }
  function selectUnit(id, add) {
    if (add) show.selected = show.selected.includes(id) ? show.selected.filter((x) => x !== id) : [...show.selected, id];
    else show.selected = show.selected.length === 1 && show.selected[0] === id ? [] : [id];
    bus.emit('select', show.selected); render();
  }
  function rotateSelected(deg) {
    const ids = show.selected.length ? show.selected : [];
    if (!ids.length) { toast('Select a unit first (click one on the stage)'); return; }
    show.units.forEach((u) => { if (ids.includes(u.id)) u.rot = ((u.rot + deg + 180) % 360 + 360) % 360 - 180; });
    saveShow(); bus.emit('rotate', deg); render();
  }
  function home() {
    show.faders.height = 0; show.faders.angle = 50; show.liveCue = null;
    show.units.forEach((u) => { u.rot = 0; });
    saveShow(); bus.emit('home'); render(); toast('Home: everything back to start');
  }
  function saveLook(i) {
    show.cues[i] = { faders: { ...show.faders }, units: show.units.map((u) => ({ rot: u.rot, color: u.color })), at: Date.now() };
    show.liveCue = i; saveShow(); bus.emit('save-look', { cue: i }); render(); toast(`Look saved to cue ${i + 1}`);
  }
  let fadeTimer = null;
  function playCue(i) {
    const c = show.cues[i]; if (!c) return;
    clearInterval(fadeTimer);
    const from = { ...show.faders }, start = performance.now(), dur = show.fadeMs;
    show.units.forEach((u, k) => { if (c.units && c.units[k]) { u.rot = c.units[k].rot; u.color = c.units[k].color; } });
    show.liveCue = i;
    const step = () => {
      const t = dur ? clamp((performance.now() - start) / dur, 0, 1) : 1;
      const e = t < .5 ? 2 * t * t : -1 + (4 - 2 * t) * t;
      ['height', 'angle', 'program', 'master'].forEach((f) => { show.faders[f] = Math.round(from[f] + (c.faders[f] - from[f]) * e); });
      render();
      if (t >= 1) { clearInterval(fadeTimer); saveShow(); }
    };
    fadeTimer = setInterval(step, 30); step();
    bus.emit('play-cue', { cue: i }); 
  }
  function go(dir) {
    const filled = show.cues.map((c, i) => c ? i : -1).filter((i) => i >= 0);
    if (!filled.length) { toast('No cues yet. Save a look first.'); return; }
    let idx = filled.indexOf(show.liveCue);
    idx = idx < 0 ? (dir > 0 ? 0 : filled.length - 1) : (idx + dir + filled.length) % filled.length;
    playCue(filled[idx]); bus.emit('go', { dir, cue: filled[idx] });
  }


  function setPatch(id, patch) {
    const u = show.units.find((x) => x.id === id); if (!u) return;
    Object.assign(u, patch); saveShow(); bus.emit('patch', { id, ...patch }); render();
  }

  // --------------------------------------------------------------------------
  // Music: a tiny WebAudio beat loop + GO recorder + timed playback
  // --------------------------------------------------------------------------
  const music = (() => {
    let ctx = null, playing = false, recording = false, startAt = 0, nextBeat = 0, beatIndex = 0, timer = null, uiTimer = null, bpm = show.music.bpm, showMode = false, fired = 0;
    const spb = () => 60 / bpm;
    function ensure() { if (!ctx) ctx = new (window.AudioContext || window.webkitAudioContext)(); if (ctx.state === 'suspended') ctx.resume(); }
    function kick(t) { const o = ctx.createOscillator(), g = ctx.createGain(); o.frequency.setValueAtTime(150, t); o.frequency.exponentialRampToValueAtTime(45, t + .12); g.gain.setValueAtTime(.9, t); g.gain.exponentialRampToValueAtTime(.001, t + .25); o.connect(g).connect(ctx.destination); o.start(t); o.stop(t + .3); }
    function hat(t, loud) { const buf = ctx.createBuffer(1, ctx.sampleRate * .05, ctx.sampleRate); const d = buf.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / d.length); const src = ctx.createBufferSource(); src.buffer = buf; const f = ctx.createBiquadFilter(); f.type = 'highpass'; f.frequency.value = 6000; const g = ctx.createGain(); g.gain.value = loud ? .25 : .12; src.connect(f).connect(g).connect(ctx.destination); src.start(t); }
    function bass(t, n) { const notes = [55, 55, 65.4, 49]; const o = ctx.createOscillator(), g = ctx.createGain(); o.type = 'sawtooth'; o.frequency.value = notes[n % 4]; const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 400; g.gain.setValueAtTime(.18, t); g.gain.exponentialRampToValueAtTime(.001, t + spb() * .9); o.connect(f).connect(g).connect(ctx.destination); o.start(t); o.stop(t + spb()); }
    function schedule() {
      while (nextBeat < ctx.currentTime + 0.12) {
        const b = beatIndex % 4; kick(nextBeat); hat(nextBeat, false); hat(nextBeat + spb() / 2, true); if (b === 0 || b === 2) bass(nextBeat, Math.floor(beatIndex / 2));
        const idx = beatIndex, at = nextBeat;
        setTimeout(() => flashBeat(idx), Math.max(0, (at - ctx.currentTime) * 1000));
        nextBeat += spb(); beatIndex++;
      }
      if (showMode) { const el = elapsed(); while (fired < show.music.timeline.length && show.music.timeline[fired].t <= el) { playCue(show.music.timeline[fired].cue); fired++; renderPanel('music'); } if (fired >= show.music.timeline.length && el > (show.music.timeline.at(-1)?.t || 0) + 2) { showMode = false; toast('Timed show finished'); bus.emit('show-played'); stop(); } }
    }
    function flashBeat(i) { const m = panelEls.music; if (!m) return; $$('.beats i', m).forEach((d, k) => d.classList.toggle('on', k === i % 4)); $('.bar-count', m).textContent = 'bar ' + (Math.floor(i / 4) + 1); }
    function elapsed() { return ctx ? ctx.currentTime - startAt : 0; }
    function start() { ensure(); playing = true; startAt = ctx.currentTime + 0.1; nextBeat = startAt; beatIndex = 0; timer = setInterval(schedule, 25); uiTimer = setInterval(() => { const m = panelEls.music; if (m) $('.clock', m).textContent = elapsed().toFixed(1) + 's'; }, 100); bus.emit('music', true); renderPanel('music'); }
    function stop() { playing = false; recording = false; showMode = false; clearInterval(timer); clearInterval(uiTimer); const m = panelEls.music; if (m) $$('.beats i', m).forEach((d) => d.classList.remove('on')); bus.emit('music', false); renderPanel('music'); }
    function onGo(cue) {
      if (!playing) return;
      const t = elapsed(); const phase = t % spb(); const dist = Math.min(phase, spb() - phase) * 1000; const onBeat = dist <= 120;
      bus.emit('go-timed', { t, onBeat, dist });
      if (onBeat) toast(dist <= 60 ? 'Perfect. Right on the beat.' : 'On the beat.');
      if (recording) { show.music.timeline.push({ cue, t: +t.toFixed(3), onBeat }); show.music.timeline.sort((a, b) => a.t - b.t); saveShow(); renderPanel('music'); }
    }
    return {
      state: () => ({ playing, recording, showMode, fired }),
      setBpm(v) { bpm = v; },
      toggle() { playing ? stop() : start(); },
      toggleRecord() { if (!playing) start(); recording = !recording; if (recording) { show.music.timeline = []; saveShow(); toast('Recording. Hit GO on the beats.'); bus.emit('record', true); } else { toast(`Recorded ${show.music.timeline.length} GOs`); bus.emit('record', false); } renderPanel('music'); },
      playShow() { if (!show.music.timeline.length) return; if (playing) stop(); fired = 0; showMode = true; recording = false; show.liveCue = null; start(); toast('Timed show running. Hands off.'); },
      onGo, stop,
    };
  })();
  bus.on('go', ({ cue }) => music.onGo(cue));

  // --------------------------------------------------------------------------
  // Missions (Pete tours + auto-checked goals)
  // --------------------------------------------------------------------------
  const progress = LS.get('progress', { done: {}, xp: 0, flags: {} });
  const flags = progress.flags;
  function setFlag(k) { if (!flags[k]) { flags[k] = true; LS.set('progress', progress); checkMissions(); } }
  const MISSIONS = [
    { id: 'faders', n: 1, title: 'Meet the faders', xp: 50, blurb: 'Every console starts here. Learn what a fader is and make a flame move.', panels: ['stage', 'faders'],
      goals: [
        { text: 'Push Height above 80%', test: () => flags.heightHigh },
        { text: 'Tilt the flames with Angle', test: () => flags.angleMoved },
        { text: 'Hold a FLASH button', test: () => flags.flashed },
        { text: 'Pull Master down below 50%', test: () => flags.masterLow },
      ],
      tour: { title: 'Mission 1 · Meet the faders', steps: [
        { selector: '[data-tour="stage"]', context: 'stage', text: 'This is your stage. Six flame units. They\'re small right now because the Height fader is low. Let\'s fix that.', mood: 'happy' },
        { selector: '[data-tour="fader-height"]', context: 'fader-height', text: 'Grab Height and drag it up. That number under it is what a real console sends: 0 to 255.', setting: 'Faders → Height' },
        { selector: '[data-tour="faders"]', context: 'fader-angle', text: 'Angle tilts the flames left and right. 50% is straight up. Try the extremes.', setting: 'Faders → Angle' },
        { selector: '[data-tour="flash"]', context: 'flash', text: 'Hold FLASH to slam a fader to full, let go to drop back. Drummers love this one.', setting: 'Faders → FLASH' },
        { selector: '[data-tour="fader-master"]', context: 'fader-master', text: 'Master scales everything. It\'s the "how big is the whole show" fader. Pull it down and watch all six shrink together.', setting: 'Faders → Master' },
        { text: 'Your turn. Finish the four goals in the Missions panel and I\'ll give you the XP. No pressure.', mood: 'happy', gesture: 'thumbs' },
      ] } },
    { id: 'look', n: 2, title: 'Your first look', xp: 75, blurb: 'A look is a snapshot of your faders. Save one, change things, bring it back.', panels: ['stage', 'faders', 'cues'],
      goals: [
        { text: 'Select two or more units', test: () => flags.multiSelect },
        { text: 'Turn a selected unit', test: () => flags.rotated },
        { text: 'Save a look into a cue', test: () => flags.savedLook },
        { text: 'Play a cue back', test: () => flags.playedCue },
      ],
      tour: { title: 'Mission 2 · Your first look', steps: [
        { selector: '[data-tour="stage"]', context: 'select', text: 'Click a unit to select it. Shift-click to grab more. Selected units get the orange ring.', setting: 'Stage → click / Shift-click' },
        { selector: '[data-tour="rotate"]', context: 'rotate', text: 'Turn left and right rotate the selected units 5° at a time. Crossing flames look great.', setting: 'Stage → Turn left / right' },
        { selector: '[data-tour="save-look"]', context: 'save-look', text: 'Happy with it? Save look, then pick a slot. That snapshot is now a cue.', setting: 'Cues → Save look to…' },
        { selector: '[data-tour="cues"]', context: 'cues', text: 'Change your faders to something totally different, then click your saved cue. It fades back. Magic, but it\'s just numbers.', setting: 'Cues → click a slot' },
        { text: 'Go build it. Two selected, one turn, one save, one playback.', mood: 'happy', gesture: 'point' },
      ] } },
    { id: 'chase', n: 3, title: 'Build a mini show', xp: 100, blurb: 'Program three cues and run them with GO, like an operator.', panels: ['stage', 'faders', 'cues'],
      goals: [
        { text: 'Set Program to Chase or Wave', test: () => flags.programFun },
        { text: 'Save three different cues', test: () => show.cues.filter(Boolean).length >= 3 },
        { text: 'Change the fade time', test: () => flags.fadeChanged },
        { text: 'Press GO three times', test: () => (progress.goCount || 0) >= 3 },
      ],
      tour: { title: 'Mission 3 · Build a mini show', steps: [
        { selector: '[data-tour="faders"]', context: 'fader-program', text: 'The Program fader picks a pattern: Steady, Flicker, Pulse, Chase, Wave. It\'s a fader that chooses instead of measures.', setting: 'Faders → Program' },
        { selector: '[data-tour="cues"]', context: 'cues', text: 'Make three looks that feel different. Low and calm, big and wavy, a chase. Save each into its own cue.', setting: 'Cues → Save look to…' },
        { selector: '[data-tour="go"]', context: 'go', text: 'GO plays the next cue. Back goes to the previous one. That\'s how a real show runs: somebody presses GO on the beat.', setting: 'Cues → GO' },
        { selector: '[data-tour="cues"]', context: 'fade-time', text: 'Fade time is how long the move takes. Zero is a snap, four seconds is a slow swell.', setting: 'Cues → Fade time' },
        { text: 'Operator time. Three cues, a fade time you like, and GO GO GO.', mood: 'laugh', gesture: 'bounce' },
      ] } },
    { id: 'workspace', n: 4, title: 'Make it yours', xp: 75, blurb: 'Real operators arrange their screens the way they like. Learn Customize Workspace.', panels: ['stage', 'faders'],
      goals: [
        { text: 'Open Customize Workspace', test: () => flags.customized },
        { text: 'Move a panel somewhere else', test: () => flags.movedPanel },
        { text: 'Add a new panel (Notes, Color, Live values…)', test: () => flags.addedPanel },
        { text: 'Save your layout with a name', test: () => flags.savedLayout },
      ],
      tour: { title: 'Mission 4 · Make it yours', steps: [
        { selector: '[data-tour="customize"]', context: 'customize', text: 'Customize Workspace unlocks the panels. It also saves a checkpoint, so you can always Revert if it gets weird.', setting: 'Top bar → Customize Workspace' },
        { selector: '[data-tour="add-panel"]', context: 'add-panel', text: 'Add panel gives you more tools: Notes, Flame color, Live values, Words to know. Pop them in anywhere.', setting: 'Customize → Add panel' },
        { selector: '[data-tour="faders"]', context: 'move-panel', text: 'Drag a panel by its header into another column, or use its ⇄ menu to move or float it. Drag the thin dividers to resize.', setting: 'Panel header → drag / ⇄' },
        { selector: '[data-tour="save-layout"]', context: 'save-layout', text: 'Save layout as… keeps your arrangement with a name. Make one for building and one for running the show.', setting: 'Customize → Save layout as…' },
        { text: 'Go rearrange. Stage can\'t be removed, everything else is fair game.', mood: 'happy', gesture: 'thumbs' },
      ] } },

    { id: 'addresses', n: 5, title: 'Addresses', xp: 100, blurb: 'Every unit needs a home on the wire. Learn why unit 2 starts at 7, and what happens when two units collide.', panels: ['stage', 'faders', 'patch', 'values'],
      goals: [
        { text: 'Open the Patch panel and change any address', test: () => flags.addrChanged },
        { text: 'Make two units overlap on purpose (see the warning)', test: () => flags.sawConflict },
        { text: 'Fix every conflict', test: () => flags.sawConflict && flags.fixedConflict },
        { text: 'Quiz: if unit 1 is at address 1 and each unit uses 6 channels, where does unit 4 start?', quiz: { id: 'addr4', a: '19', hint: 'Unit 1 uses 1–6, unit 2 uses 7–12, unit 3 uses 13–18… so unit 4 starts at?', why: '1, 7, 13, 19: each one jumps by six.' } },
      ],
      tour: { title: 'Mission 5 · Addresses', steps: [
        { selector: '[data-tour="patch"]', context: 'patch', text: 'This is the Patch panel. Every unit gets a start address. It listens on that channel plus the next five. Six channels total.', setting: 'Patch panel' },
        { selector: '[data-tour="values"]', context: 'values', text: 'Live values shows it in action: unit 1\'s Height is channel 1, Angle is channel 2, and so on. The console just sends numbers to those slots.', setting: 'Live values panel' },
        { selector: '[data-tour="patch"]', context: 'address', text: 'Type a new address for unit 2 that overlaps unit 1, like 4. Watch the red warning. Overlapping units can\'t be controlled separately.', setting: 'Patch → Address' },
        { selector: '[data-tour="patch-order"]', context: 'patch-order', text: 'Patch in order fixes everything the lazy way: 1, 7, 13, 19, 25, 31. Real techs do this math in their head all day.', setting: 'Patch → Patch in order' },
        { text: 'Your turn: change an address, cause a conflict, fix it, then answer the quiz in the Missions panel.', mood: 'happy', gesture: 'point' },
      ] } },
    { id: 'universes', n: 6, title: 'Universes', xp: 100, blurb: 'A universe is 512 channels. When you run out, you start a second one, and addresses can repeat.', panels: ['stage', 'patch', 'values'],
      goals: [
        { text: 'Put at least one unit on universe 2', test: () => flags.usedUni2 },
        { text: 'Give two units the same address in different universes, with no conflict', test: () => flags.sameAddrTwoUni },
        { text: 'Quiz: how many channels are in one DMX universe?', quiz: { id: 'uni512', a: '512', hint: 'It\'s in Words to know. Starts with a 5.', why: 'Half a kilobyte of numbers, 44 times a second.' } },
        { text: 'Quiz: how many 6-channel units fit in one universe?', quiz: { id: 'uni85', a: '85', hint: '512 divided by 6, rounded down.', why: '85 × 6 = 510, with two channels left over.' } },
      ],
      tour: { title: 'Mission 6 · Universes', steps: [
        { selector: '[data-tour="patch"]', context: 'universe', text: 'See the Universe column? A universe is one cable\'s worth of channels: 512 of them. Big shows use dozens of universes.', setting: 'Patch → Universe' },
        { selector: '[data-tour="patch"]', context: 'universe', text: 'Address 1 on universe 1 and address 1 on universe 2 are different places. Same number, different cable. No conflict.', setting: 'Patch → Universe + Address' },
        { selector: '[data-tour="values"]', context: 'values', text: 'Live values writes it as universe.address, like 2.7. That\'s how most consoles show it too.', setting: 'Live values panel' },
        { text: 'Go: move some units to universe 2, reuse an address, and answer the two quizzes. Split across 2 universes is a shortcut if you get stuck.', mood: 'happy', gesture: 'nod' },
      ] } },
    { id: 'music', n: 7, title: 'Time a show to music', xp: 150, blurb: 'The real job: pressing GO at exactly the right moment. Record your GOs to a beat, then let the show run itself.', panels: ['stage', 'faders', 'cues', 'music'],
      goals: [
        { text: 'Play the beat and change the tempo', test: () => flags.playedBeat && flags.bpmChanged },
        { text: 'Hit GO on the beat three times', test: () => (progress.onBeat || 0) >= 3 },
        { text: 'Record a timed show with at least 4 GOs', test: () => flags.recorded4 },
        { text: 'Play the timed show back', test: () => flags.playedShow },
      ],
      tour: { title: 'Mission 7 · Time a show to music', steps: [
        { selector: '[data-tour="music-play"]', context: 'music-play', text: 'Play beat starts a loop: kick, hats, a little bass. Those four dots are the beats in a bar. Count them: one, two, three, four.', setting: 'Music → Play beat' },
        { selector: '[data-tour="bpm"]', context: 'bpm', text: 'Tempo is beats per minute. Slow it down while you learn, speed it up when you\'re cocky.', setting: 'Music → Tempo' },
        { selector: '[data-tour="go"]', context: 'go', text: 'Now press GO (or Space) right on a beat. If you\'re within a tenth of a second, I\'ll tell you. Three in a row is the goal.', setting: 'Cues → GO / Space' },
        { selector: '[data-tour="music-rec"]', context: 'music-record', text: 'Record GOs stamps the time of every GO you press. Make a mini show: four or more GOs across a few bars.', setting: 'Music → Record GOs' },
        { selector: '[data-tour="music-show"]', context: 'music-show', text: 'Play timed show replays your GOs automatically, in time with the beat. That\'s a timecoded show. Real tours run like this.', setting: 'Music → Play timed show' },
        { text: 'Make sure you have at least two cues saved, then go. Feel the beat, press GO, record it, play it back.', mood: 'laugh', gesture: 'bounce' },
      ] } },
  ];
  let activeMission = LS.get('activeMission', null);
  function missionProgress(m) { return m.goals.map((g) => g.quiz ? !!flags['quiz:' + g.quiz.id] : !!g.test()); }
  function answerQuiz(q, value) {
    const ok = String(value).trim().toLowerCase() === String(q.a).toLowerCase();
    if (ok) { VLSAvatar.say(pickOne(['Correct. See, you get it.', 'Yep. Nailed it.', 'That\'s the one.']) + (q.why ? ' ' + q.why : ''), { mood: 'happy', gesture: 'thumbs', speak: false, priority: 8000 }); setFlag('quiz:' + q.id); }
    else VLSAvatar.say(q.hint || 'Not quite. Think about how many channels each unit uses.', { mood: 'thinking', gesture: 'shrug', speak: false, priority: 8000 });
    renderPanel('missions');
    return ok;
  }
  const pickOne = (a) => a[Math.floor(Math.random() * a.length)];
  function checkMissions() {
    let changed = false;
    MISSIONS.forEach((m) => {
      if (progress.done[m.id]) return;
      if (missionProgress(m).every(Boolean)) {
        progress.done[m.id] = Date.now(); progress.xp += m.xp; changed = true;
        if (activeMission === m.id) activeMission = null;
        window.VLSAvatar && VLSAvatar.say(`Mission ${m.n} done. ${m.title}, complete. That's ${m.xp} XP. ${nextMissionLine(m)}`, { mood: 'laugh', gesture: 'bounce', sticky: true, priority: true, actions: nextMission(m) ? [{ label: `Start Mission ${nextMission(m).n}`, primary: true, onClick: () => startMission(nextMission(m).id) }] : [] });
      }
    });
    LS.set('progress', progress); LS.set('activeMission', activeMission);
    updateXP(); renderPanel('missions');
    return changed;
  }
  function nextMission(m) { return MISSIONS.find((x) => x.n === m.n + 1 && !progress.done[x.id]); }
  function nextMissionLine(m) { const n = nextMission(m); return n ? `Next up: ${n.title}.` : 'That was the last one. You officially know more about consoles than most adults.'; }
  function startMission(id) {
    const m = MISSIONS.find((x) => x.id === id); if (!m) return;
    activeMission = id; LS.set('activeMission', id);
    m.panels.forEach((p) => ensurePanel(p));
    if (id === 'workspace') { /* keep customize closed so the tour can point at the button */ }
    renderPanel('missions');
    VLSAvatar.registerTours({ [id]: m.tour });
    VLSAvatar.tour(id);
  }
  function updateXP() {
    const total = MISSIONS.reduce((a, m) => a + m.xp, 0);
    $('#xp-bar i').style.width = (progress.xp / total * 100) + '%';
    $('#xp-text').textContent = `${progress.xp} / ${total} XP`;
  }

  // goal detectors
  bus.on('fader', ({ fader, value }) => {
    if (fader === 'height' && value >= 80) setFlag('heightHigh');
    if (fader === 'angle' && (value <= 20 || value >= 80)) setFlag('angleMoved');
    if (fader === 'master' && value < 50) setFlag('masterLow');
    if (fader === 'program' && value >= 63) setFlag('programFun');
  });
  bus.on('flash', ({ on }) => { if (on) { if (!flags.firstFlashReact) { flags.firstFlashReact = true; VLSAvatar.react('first-flash'); } setFlag('flashed'); } });
  bus.on('select', (sel) => { if (sel.length >= 2) setFlag('multiSelect'); });
  bus.on('rotate', () => setFlag('rotated'));
  bus.on('save-look', () => { if (!flags.firstSaveReact) { flags.firstSaveReact = true; VLSAvatar.react('saved'); } setFlag('savedLook'); checkMissions(); });
  bus.on('play-cue', () => setFlag('playedCue'));
  bus.on('go', () => { progress.goCount = (progress.goCount || 0) + 1; LS.set('progress', progress); checkMissions(); });
  bus.on('fade-time', () => setFlag('fadeChanged'));
  bus.on('customize', (on) => { if (on) setFlag('customized'); });
  bus.on('panel-moved', () => setFlag('movedPanel'));
  bus.on('panel-added', () => setFlag('addedPanel'));
  bus.on('layout-saved', () => setFlag('savedLayout'));
  bus.on('patch', (p) => {
    if (p && p.addr != null) setFlag('addrChanged');
    const bad = conflicts();
    if (bad.size) { flags.sawConflict = true; flags.fixedConflict = false; if (!flags.conflictReact) { flags.conflictReact = true; VLSAvatar.react('collision'); } }
    else if (flags.sawConflict) setFlag('fixedConflict');
    if (show.units.some((u) => u.uni === 2)) setFlag('usedUni2');
    if (show.units.some((a) => show.units.some((b) => a.id !== b.id && a.uni !== b.uni && a.addr === b.addr)) && !bad.size) setFlag('sameAddrTwoUni');
    LS.set('progress', progress); checkMissions();
  });
  bus.on('music', (on) => { if (on) setFlag('playedBeat'); });
  bus.on('bpm', () => setFlag('bpmChanged'));
  bus.on('go-timed', ({ onBeat }) => { if (onBeat) { progress.onBeat = (progress.onBeat || 0) + 1; LS.set('progress', progress); checkMissions(); if (progress.onBeat === 3 && !flags.beatReact) { flags.beatReact = true; VLSAvatar.say('Three on the beat. You have rhythm. Operators would hire you.', { mood: 'laugh', gesture: 'bounce', speak: false }); } } });
  bus.on('record', (on) => { if (!on && show.music.timeline.length >= 4) setFlag('recorded4'); });
  bus.on('show-played', () => setFlag('playedShow'));

  // --------------------------------------------------------------------------
  // Workspace layout engine
  // --------------------------------------------------------------------------
  const DEFAULT_LAYOUT = {
    cols: { left: 230, right: 320 }, bottomH: 220,
    docks: { left: [{ id: 'missions', grow: 1 }], center: [{ id: 'stage', grow: 1 }], right: [{ id: 'faders', grow: 1.3 }, { id: 'cues', grow: 1 }], bottom: [] },
    floating: [],
  };
  let layout = LS.get('layout', null) || clone(DEFAULT_LAYOUT);
  let checkpoint = null;
  const panelEls = {}; // id -> element
  const ws = $('#workspace');

  function clone(o) { return JSON.parse(JSON.stringify(o)); }
  function saveLayout() { LS.set('layout', layout); }
  function allPlaced() { return [...Object.values(layout.docks).flat().map((p) => p.id), ...layout.floating.map((p) => p.id)]; }
  function findPanel(id) {
    for (const [dock, list] of Object.entries(layout.docks)) { const i = list.findIndex((p) => p.id === id); if (i >= 0) return { dock, i, entry: list[i] }; }
    const fi = layout.floating.findIndex((p) => p.id === id); if (fi >= 0) return { dock: 'float', i: fi, entry: layout.floating[fi] };
    return null;
  }

  function buildPanel(id) {
    if (panelEls[id]) return panelEls[id];
    const def = PANELS[id];
    const el = document.createElement('section');
    el.className = 'panel'; el.dataset.panel = id;
    el.innerHTML = `<header class="panel-head"><span class="ph-title">${def.title}</span>
      <span class="panel-tools">
        <button class="ptool only-custom" data-t="grow" title="Bigger">＋</button>
        <button class="ptool only-custom" data-t="shrink" title="Smaller">－</button>
        <button class="ptool" data-t="move" title="Move / float">⇄</button>
        <button class="ptool danger" data-t="close" title="Remove panel" ${def.protected ? 'disabled' : ''}>×</button>
      </span></header><div class="panel-body"></div>`;
    def.render($('.panel-body', el));
    el.addEventListener('click', (e) => {
      const b = e.target.closest('.ptool'); if (!b) return;
      const t = b.dataset.t;
      if (t === 'close') removePanel(id);
      if (t === 'move') openMoveMenu(id, b);
      if (t === 'grow' || t === 'shrink') { const f = findPanel(id); if (f && f.dock !== 'float') { f.entry.grow = clamp(+(f.entry.grow + (t === 'grow' ? .25 : -.25)).toFixed(2), .4, 4); applyLayout(); saveLayout(); } }
    });
    // drag (HTML5 DnD for docking)
    const head = $('.panel-head', el);
    head.draggable = true;
    head.addEventListener('dragstart', (e) => { if (!customizing && !el.classList.contains('floating')) { e.preventDefault(); return; } if (el.classList.contains('floating')) { e.preventDefault(); return; } dragId = id; el.classList.add('dragging'); e.dataTransfer.setData('text/plain', id); e.dataTransfer.effectAllowed = 'move'; });
    head.addEventListener('dragend', () => { el.classList.remove('dragging'); dragId = null; $$('.drop-target').forEach((d) => d.classList.remove('drop-target')); });
    // floating move
    head.addEventListener('pointerdown', (e) => {
      if (!el.classList.contains('floating') || e.target.closest('.ptool')) return;
      const f = findPanel(id); const r = ws.getBoundingClientRect(); const sx = e.clientX - el.offsetLeft, sy = e.clientY - el.offsetTop;
      const mv = (ev) => { f.entry.x = clamp(ev.clientX - sx, 0, r.width - 120); f.entry.y = clamp(ev.clientY - sy, 0, r.height - 60); el.style.left = f.entry.x + 'px'; el.style.top = f.entry.y + 'px'; };
      const up = () => { window.removeEventListener('pointermove', mv); window.removeEventListener('pointerup', up); saveLayout(); };
      window.addEventListener('pointermove', mv); window.addEventListener('pointerup', up);
    });
    new ResizeObserver(() => { if (!el.classList.contains('floating')) return; const f = findPanel(id); if (!f) return; f.entry.w = el.offsetWidth; f.entry.h = el.offsetHeight; saveLayout(); }).observe(el);
    panelEls[id] = el;
    return el;
  }

  let dragId = null;
  function applyLayout() {
    ws.style.setProperty('--col-left', layout.cols.left + 'px');
    ws.style.setProperty('--col-right', layout.cols.right + 'px');
    ws.style.setProperty('--bottom-h', layout.bottomH + 'px');
    ws.classList.toggle('no-left', !layout.docks.left.length);
    ws.classList.toggle('no-right', !layout.docks.right.length);
    const placed = new Set(allPlaced());
    // remove stray elements
    Object.keys(panelEls).forEach((id) => { if (!placed.has(id)) { panelEls[id].remove(); delete panelEls[id]; } });
    Object.entries(layout.docks).forEach(([dock, list]) => {
      const dockEl = $(`.dock[data-dock="${dock}"]`);
      dockEl.innerHTML = '';
      list.forEach((p, i) => {
        const el = buildPanel(p.id);
        el.classList.remove('floating'); el.style.cssText = ''; el.style.setProperty('--grow', p.grow || 1);
        if (i > 0 && dock !== 'bottom') { const hd = document.createElement('div'); hd.className = 'hdivider'; attachHDivider(hd, dock, i); dockEl.appendChild(hd); }
        dockEl.appendChild(el);
      });
    });
    layout.floating.forEach((p) => {
      const el = buildPanel(p.id);
      el.classList.add('floating');
      el.style.left = p.x + 'px'; el.style.top = p.y + 'px'; el.style.width = p.w + 'px'; el.style.height = p.h + 'px';
      ws.appendChild(el);
    });
    $('.bottom-divider').style.display = layout.docks.bottom.length ? 'block' : 'none';
    updateAddMenu();
    renderAll();
  }

  function movePanel(id, dock, index) {
    const f = findPanel(id); if (!f) return;
    const entry = f.dock === 'float' ? layout.floating.splice(f.i, 1)[0] : layout.docks[f.dock].splice(f.i, 1)[0];
    if (dock === 'float') {
      const r = ws.getBoundingClientRect();
      layout.floating.push({ id, x: entry.x ?? Math.round(r.width * .3), y: entry.y ?? 60, w: entry.w ?? 360, h: entry.h ?? 320 });
    } else {
      const list = layout.docks[dock];
      if (f.dock === dock && index > f.i) index -= 1;
      list.splice(index == null ? list.length : clamp(index, 0, list.length), 0, { id, grow: entry.grow || 1 });
    }
    applyLayout(); saveLayout(); bus.emit('panel-moved', { id, dock });
  }
  function removePanel(id) {
    if (PANELS[id].protected) { toast('The Stage is protected. It stays.'); return; }
    const f = findPanel(id); if (!f) return;
    if (f.dock === 'float') layout.floating.splice(f.i, 1); else layout.docks[f.dock].splice(f.i, 1);
    applyLayout(); saveLayout(); bus.emit('panel-removed', id);
  }
  function addPanel(id, dock) {
    if (allPlaced().includes(id)) { toast(`${PANELS[id].title} is already open`); return; }
    dock = dock || (layout.docks.right.length < 3 ? 'right' : layout.docks.left.length < 3 ? 'left' : 'bottom');
    layout.docks[dock].push({ id, grow: 1 });
    applyLayout(); saveLayout(); bus.emit('panel-added', id);
    toast(`${PANELS[id].title} added`);
  }
  function ensurePanel(id) { if (!allPlaced().includes(id)) { const dock = id === 'cues' ? 'right' : (id === 'patch' || id === 'music') ? 'center' : 'left'; layout.docks[dock].push({ id, grow: dock === 'center' ? 0.7 : 1 }); applyLayout(); saveLayout(); } }

  function openMoveMenu(id, anchor) {
    closeMenus();
    const f = findPanel(id);
    const m = document.createElement('div'); m.className = 'menu';
    const opts = [['left', 'Dock left'], ['center', 'Dock center'], ['right', 'Dock right'], ['bottom', 'Dock bottom'], ['float', 'Float as window']];
    m.innerHTML = opts.map(([d, l]) => `<button data-d="${d}" ${f && f.dock === d ? 'disabled' : ''}>${l}${f && f.dock === d ? '<small>here</small>' : ''}</button>`).join('') + '<div class="sep"></div><button data-d="reset-size">Reset size</button>';
    document.body.appendChild(m);
    const r = anchor.getBoundingClientRect(); m.style.left = Math.min(r.left, innerWidth - 210) + 'px'; m.style.top = (r.bottom + 6) + 'px';
    m.addEventListener('click', (e) => { const b = e.target.closest('button'); if (!b) return; if (b.dataset.d === 'reset-size') { if (f) { f.entry.grow = 1; f.entry.w = 360; f.entry.h = 320; applyLayout(); saveLayout(); } } else movePanel(id, b.dataset.d); closeMenus(); });
  }
  function closeMenus() { $$('.menu').forEach((m) => m.remove()); }
  document.addEventListener('pointerdown', (e) => { if (!e.target.closest('.menu') && !e.target.closest('[data-t="move"]') && !e.target.closest('#add-panel')) closeMenus(); });

  // drop zones
  $$('.dock').forEach((dockEl) => {
    dockEl.addEventListener('dragover', (e) => { if (!dragId) return; e.preventDefault(); e.dataTransfer.dropEffect = 'move'; dockEl.classList.add('drop-target'); });
    dockEl.addEventListener('dragleave', () => dockEl.classList.remove('drop-target'));
    dockEl.addEventListener('drop', (e) => {
      e.preventDefault(); dockEl.classList.remove('drop-target');
      const id = dragId || e.dataTransfer.getData('text/plain'); if (!id) return;
      const dock = dockEl.dataset.dock;
      const kids = $$('.panel', dockEl).filter((p) => p.dataset.panel !== id);
      let index = kids.length;
      const horiz = dock === 'bottom';
      kids.forEach((k, i) => { const r = k.getBoundingClientRect(); const mid = horiz ? r.left + r.width / 2 : r.top + r.height / 2; const pos = horiz ? e.clientX : e.clientY; if (pos < mid && index === kids.length) index = i; });
      movePanel(id, dock, index);
    });
  });

  // dividers
  function attachDivider(el, side) {
    el.addEventListener('pointerdown', (e) => {
      e.preventDefault(); el.classList.add('active'); const start = e.clientX; const base = layout.cols[side];
      const mv = (ev) => { const d = ev.clientX - start; layout.cols[side] = clamp(side === 'left' ? base + d : base - d, 160, 560); ws.style.setProperty('--col-' + side, layout.cols[side] + 'px'); };
      const up = () => { el.classList.remove('active'); window.removeEventListener('pointermove', mv); window.removeEventListener('pointerup', up); saveLayout(); };
      window.addEventListener('pointermove', mv); window.addEventListener('pointerup', up);
    });
  }
  attachDivider($('.divider[data-side="left"]'), 'left'); attachDivider($('.divider[data-side="right"]'), 'right');
  $('.bottom-divider').addEventListener('pointerdown', (e) => {
    e.preventDefault(); const start = e.clientY; const base = layout.bottomH;
    const mv = (ev) => { layout.bottomH = clamp(base - (ev.clientY - start), 120, innerHeight * .6); ws.style.setProperty('--bottom-h', layout.bottomH + 'px'); };
    const up = () => { window.removeEventListener('pointermove', mv); window.removeEventListener('pointerup', up); saveLayout(); };
    window.addEventListener('pointermove', mv); window.addEventListener('pointerup', up);
  });
  function attachHDivider(el, dock, i) {
    el.addEventListener('pointerdown', (e) => {
      e.preventDefault(); el.classList.add('active');
      const a = layout.docks[dock][i - 1], b = layout.docks[dock][i];
      const ea = panelEls[a.id], eb = panelEls[b.id]; const ha = ea.offsetHeight, hb = eb.offsetHeight; const total = (a.grow || 1) + (b.grow || 1); const start = e.clientY;
      const mv = (ev) => { const d = ev.clientY - start; const na = clamp(ha + d, 80, ha + hb - 80); const ra = na / (ha + hb); a.grow = +(total * ra).toFixed(3); b.grow = +(total * (1 - ra)).toFixed(3); ea.style.setProperty('--grow', a.grow); eb.style.setProperty('--grow', b.grow); };
      const up = () => { el.classList.remove('active'); window.removeEventListener('pointermove', mv); window.removeEventListener('pointerup', up); saveLayout(); };
      window.addEventListener('pointermove', mv); window.addEventListener('pointerup', up);
    });
  }

  // customize mode
  let customizing = false;
  const app = $('#app');
  function setCustomizing(on) {
    if (on && !customizing) { checkpoint = clone(layout); }
    customizing = on; app.classList.toggle('customizing', on);
    $('#customize-btn').textContent = on ? 'Done customizing' : 'Customize Workspace';
    $('#customize-btn').classList.toggle('primary', on);
    bus.emit('customize', on);
    if (on) VLSAvatar.setContext('customize');
  }
  $('#customize-btn').addEventListener('click', () => setCustomizing(!customizing));
  $('#revert-btn').addEventListener('click', () => { if (checkpoint) { layout = clone(checkpoint); applyLayout(); saveLayout(); toast('Reverted to the checkpoint'); } });
  // Reset All: wipes this learner's progress, show, looks, cues and layouts and reloads with the defaults.
  // In Classroom mode only the current student is reset; the class list and other students are kept.
  $('#reset-all-btn').addEventListener('click', () => {
    const who = CLASS.enabled && CLASS.current ? CLASS.current : null;
    if (!confirm(who ? `Reset all of ${who}'s progress, missions, cues, looks and layouts and go back to the defaults? This cannot be undone.` : 'Reset all progress, missions, cues, looks and layouts and go back to the defaults? This cannot be undone.')) return;
    STUDENT_KEYS.forEach((k) => LS.del(k));
    toast('Everything is back to the defaults');
    setTimeout(() => location.reload(), 400);
  });
  $('#reset-btn').addEventListener('click', () => { layout = clone(DEFAULT_LAYOUT); applyLayout(); saveLayout(); toast('Default layout restored'); });
  $('#save-layout-btn').addEventListener('click', () => {
    const name = prompt('Name this layout', 'My layout'); if (!name) return;
    const lib = LS.get('layouts', {}); lib[name.trim()] = clone(layout); LS.set('layouts', lib); refreshLayoutSelect(); $('#layout-select').value = name.trim();
    bus.emit('layout-saved', name); toast(`Layout "${name.trim()}" saved`);
  });
  $('#layout-select').addEventListener('change', (e) => { const lib = LS.get('layouts', {}); const l = lib[e.target.value]; if (l) { layout = clone(l); applyLayout(); saveLayout(); toast(`Loaded "${e.target.value}"`); } });
  $('#delete-layout-btn').addEventListener('click', () => { const n = $('#layout-select').value; if (!n) return; const lib = LS.get('layouts', {}); delete lib[n]; LS.set('layouts', lib); refreshLayoutSelect(); toast(`Deleted "${n}"`); });
  $('#export-btn').addEventListener('click', () => { const blob = new Blob([JSON.stringify({ layout, show, layouts: LS.get('layouts', {}) }, null, 2)], { type: 'application/json' }); const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'spark-workspace.json'; a.click(); });
  $('#import-input').addEventListener('change', async (e) => { const f = e.target.files[0]; if (!f) return; try { const d = JSON.parse(await f.text()); if (d.layout) { layout = d.layout; applyLayout(); saveLayout(); } if (d.layouts) { LS.set('layouts', d.layouts); refreshLayoutSelect(); } toast('Workspace imported'); } catch (err) { toast('That file didn\'t look right'); } e.target.value = ''; });
  function refreshLayoutSelect() { const sel = $('#layout-select'); const lib = LS.get('layouts', {}); sel.innerHTML = '<option value="">Saved layouts…</option>' + Object.keys(lib).map((k) => `<option>${escapeHtml(k)}</option>`).join(''); }
  refreshLayoutSelect();

  $('#add-panel').addEventListener('click', (e) => {
    closeMenus();
    const placed = allPlaced();
    const m = document.createElement('div'); m.className = 'menu';
    m.innerHTML = Object.entries(PANELS).map(([id, d]) => `<button data-id="${id}" ${placed.includes(id) ? 'disabled' : ''}>${d.title}${placed.includes(id) ? '<small>open</small>' : ''}</button>`).join('');
    document.body.appendChild(m);
    const r = e.currentTarget.getBoundingClientRect(); m.style.left = r.left + 'px'; m.style.top = (r.bottom + 6) + 'px';
    m.addEventListener('click', (ev) => { const b = ev.target.closest('button'); if (b && !b.disabled) addPanel(b.dataset.id); closeMenus(); });
  });
  function updateAddMenu() { /* menu is built on demand */ }

  // --------------------------------------------------------------------------
  // Rendering
  // --------------------------------------------------------------------------
  let raf = null;
  function render() { if (raf) return; raf = requestAnimationFrame(() => { raf = null; live.angle += (effective('angle') - live.angle) * 0.35; if (Math.abs(live.angle - effective('angle')) > 0.3) render(); Object.entries(panelEls).forEach(([id, el]) => { const d = PANELS[id]; if (d.update) d.update($('.panel-body', el)); }); }); }
  function renderAll() { Object.entries(panelEls).forEach(([id, el]) => { const d = PANELS[id]; if (d.update) d.update($('.panel-body', el)); }); }
  function renderPanel(id) { if (panelEls[id]) PANELS[id].update($('.panel-body', panelEls[id])); }
  function escapeHtml(s) { return String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }

  let toastTimer = null;
  function toast(msg) { const t = $('#toast'); t.textContent = msg; t.classList.add('on'); clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove('on'), 2200); }

  // keyboard: space = GO, backspace = Back, H = home, Esc = exit customize
  document.addEventListener('keydown', (e) => {
    if (e.target && e.target.matches && e.target.matches('input, textarea, select')) return;
    if (e.key === ' ') { e.preventDefault(); go(1); }
    if (e.key === 'Backspace') { e.preventDefault(); go(-1); }
    if (e.key.toLowerCase() === 'h') home();
    if (e.key === 'Escape' && customizing) setCustomizing(false);
  });

  // --------------------------------------------------------------------------
  // Pete
  // --------------------------------------------------------------------------
  VLSAvatar.init({
    name: 'Pete',
    side: 'left',
    size: 'sm',
    bubble: 'above',
    tips: window.SPARK_TIPS,
    knowledge: window.SPARK_KNOWLEDGE,
    lines: window.SPARK_LINES,
    reactions: window.SPARK_REACTIONS,
    humor: 0.4,
    chimeGapMs: 35000,
    tipDelayMs: 2000,
    idleGapMs: [90000, 150000],
    greet: false,
  });
  VLSAvatar.on('tour', ({ id, status, step }) => {
    if (status === 'complete' || status === 'skipped') renderPanel('missions');
    if (id === 'workspace' && status === 'step') { if (step >= 1 && step <= 3 && !customizing) setCustomizing(true); }
  });
  $('#ask-btn').addEventListener('click', () => { VLSAvatar.show(); VLSAvatar.openSettings(); });   // Ask Pete opens his settings; Open Pete inside starts the chat


  // --------------------------------------------------------------------------
  // Classroom mode: student profiles, teacher PIN, reset, progress export
  // --------------------------------------------------------------------------
  const classroom = (() => {
    let unlocked = false;
    const modal = $('#class-modal'), body = $('.cm-body', modal), tabs = $$('.cm-tab', modal);
    const saveClass = () => { try { localStorage.setItem('spark.class', JSON.stringify(CLASS)); } catch (e) {} };
    const readStudent = (name, k, d) => { try { const v = localStorage.getItem(`spark.s.${name}.${k}`); return v == null ? d : JSON.parse(v); } catch (e) { return d; } };
    const stats = (name) => {
      const p = readStudent(name, 'progress', { done: {}, xp: 0, flags: {} });
      const done = MISSIONS.filter((m) => p.done[m.id]);
      return { name, xp: p.xp || 0, done: done.length, doneIds: done.map((m) => m.n), dates: Object.fromEntries(MISSIONS.map((m) => [m.id, p.done[m.id] ? new Date(p.done[m.id]).toISOString() : ''])), onBeat: p.onBeat || 0, last: CLASS.students[name]?.lastActive || 0, created: CLASS.students[name]?.created || 0, progress: p };
    };
    const names = () => Object.keys(CLASS.students).sort((a, b) => a.localeCompare(b));
    const fmtAgo = (t) => { if (!t) return 'never'; const d = (Date.now() - t) / 60000; if (d < 1) return 'just now'; if (d < 60) return Math.round(d) + ' min ago'; if (d < 1440) return Math.round(d / 60) + ' h ago'; return new Date(t).toLocaleDateString(); };
    const wipeStudent = (name) => { const pre = `spark.s.${name}.`; Object.keys(localStorage).filter((k) => k.startsWith(pre)).forEach((k) => localStorage.removeItem(k)); };
    const download = (filename, text, type) => { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([text], { type })); a.download = filename; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 2000); };
    const csvCell = (v) => { v = String(v ?? ''); return /[",\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; };
    const stamp = () => new Date().toISOString().slice(0, 10);

    function exportCSV() {
      const head = ['student', 'xp', 'missions_done', 'missions_list', 'on_beat_hits', 'last_active', ...MISSIONS.map((m) => `m${m.n}_${m.id}_completed`)];
      const rows = names().map(stats).map((s) => [s.name, s.xp, s.done, s.doneIds.join(' '), s.onBeat, s.last ? new Date(s.last).toISOString() : '', ...MISSIONS.map((m) => s.dates[m.id])]);
      if (!CLASS.enabled || !rows.length) { const p = progress; rows.push(['(this computer)', p.xp, MISSIONS.filter((m) => p.done[m.id]).length, MISSIONS.filter((m) => p.done[m.id]).map((m) => m.n).join(' '), p.onBeat || 0, '', ...MISSIONS.map((m) => p.done[m.id] ? new Date(p.done[m.id]).toISOString() : '')]); }
      download(`spark-studio-progress-${stamp()}.csv`, [head, ...rows].map((r) => r.map(csvCell).join(',')).join('\n'), 'text/csv');
      toast('Progress CSV downloaded');
    }
    function exportJSON() {
      const data = { app: 'spark-studio', version: '0.3.0', exported: new Date().toISOString(), classroom: { enabled: CLASS.enabled, students: CLASS.students }, students: Object.fromEntries(names().map((n) => [n, { progress: readStudent(n, 'progress', null), show: readStudent(n, 'show', null), layout: readStudent(n, 'layout', null), layouts: readStudent(n, 'layouts', null) }])) };
      download(`spark-studio-class-${stamp()}.json`, JSON.stringify(data, null, 2), 'application/json');
      toast('Class backup downloaded');
    }
    function importJSON(file) {
      const r = new FileReader();
      r.onload = () => { try { const d = JSON.parse(r.result); if (d.app !== 'spark-studio' || !d.students) throw 0; let n = 0; Object.entries(d.students).forEach(([rawName, obj]) => { const name = String(rawName).replace(/[<>"&\u0000-\u001f]/g, '').trim().slice(0, 40); if (!name || !obj || typeof obj !== 'object') return; CLASS.students[name] = CLASS.students[name] || (d.classroom?.students?.[name]) || { created: Date.now(), lastActive: 0 }; const okShape = { progress: (v) => v && typeof v === 'object' && v.done && typeof v.done === 'object', show: (v) => v && typeof v === 'object' && v.faders && typeof v.faders === 'object', layout: (v) => v && typeof v === 'object', layouts: (v) => v && typeof v === 'object' }; ['progress', 'show', 'layout', 'layouts'].forEach((k) => { if (obj[k] != null && okShape[k](obj[k])) localStorage.setItem(`spark.s.${name}.${k}`, JSON.stringify(obj[k])); }); n++; }); CLASS.enabled = true; saveClass(); toast(`Imported ${n} student(s)`); render('teacher'); } catch (e) { toast('That file is not a Spark Studio class backup'); } };
      r.readAsText(file);
    }

    function render(tab) {
      tabs.forEach((t) => t.classList.toggle('on', t.dataset.tab === tab));
      if (tab === 'students') renderStudents(); else renderTeacher();
    }
    function renderStudents() {
      const list = names();
      body.innerHTML = `<div class="cm-intro">${CLASS.enabled ? 'Who\'s at the console? Pick your name. Your missions, cues and layout are saved under it on this computer.' : 'Classroom mode gives each student their own missions, cues and layout on this computer. Turn it on, then add names.'}</div>
        ${CLASS.enabled ? `<div class="cm-grid">${list.map((n) => { const s = stats(n); return `<button class="cm-student ${n === CLASS.current ? 'on' : ''}" data-pick="${escapeHtml(n)}"><b>${escapeHtml(n)}</b><span>${Number(s.xp) || 0} XP · ${s.done}/${MISSIONS.length} missions</span><small>${fmtAgo(s.last)}</small></button>`; }).join('') || '<div class="cm-empty">No students yet. Add the first name below.</div>'}</div>
        <form class="cm-add"><input type="text" maxlength="24" placeholder="Add a name (first name or nickname)" aria-label="Student name" required><button class="btn primary" type="submit">Add</button></form>` : `<div class="cm-actions"><button class="btn primary" data-act="enable">Turn on classroom mode</button></div>`}`;
      $$('[data-pick]', body).forEach((b) => b.addEventListener('click', () => pick(b.dataset.pick)));
      const f = $('.cm-add', body); if (f) f.addEventListener('submit', (e) => { e.preventDefault(); const n = $('input', f).value.trim().replace(/[.\s]+/g, ' '); if (!n) return; if (CLASS.students[n]) { toast('That name is taken. Add a last initial.'); return; } CLASS.students[n] = { created: Date.now(), lastActive: 0 }; saveClass(); pick(n); });
      const en = $('[data-act="enable"]', body); if (en) en.addEventListener('click', () => { CLASS.enabled = true; saveClass(); render('students'); });
    }
    function pick(name) { CLASS.current = name; CLASS.students[name].lastActive = Date.now(); saveClass(); toast(`Loading ${name}'s console…`); setTimeout(() => location.reload(), 350); }
    function renderTeacher() {
      if (!unlocked) {
        body.innerHTML = `<div class="cm-intro">${CLASS.pin ? 'Teacher area. Enter the PIN.' : 'First time here. Choose a 4-digit teacher PIN. It keeps students out of reset and export. It is a speed bump, not a vault: anything in this browser can be cleared from browser settings.'}</div>
          <form class="cm-pin"><input type="password" inputmode="numeric" pattern="[0-9]{4}" maxlength="4" placeholder="••••" aria-label="Teacher PIN" required autocomplete="off"><button class="btn primary" type="submit">${CLASS.pin ? 'Unlock' : 'Set PIN'}</button></form>
          ${CLASS.pin ? '<div class="cm-note">Forgot it? Open the browser console and run <code>Spark.classroom.forgotPin()</code> to clear the PIN (progress is kept).</div>' : ''}`;
        $('.cm-pin', body).addEventListener('submit', (e) => { e.preventDefault(); const v = $('input', body).value; if (!/^\d{4}$/.test(v)) { toast('Four digits, please'); return; } if (!CLASS.pin) { CLASS.pin = v; saveClass(); unlocked = true; toast('Teacher PIN set'); render('teacher'); } else if (v === CLASS.pin) { unlocked = true; render('teacher'); } else { toast('Wrong PIN'); $('input', body).value = ''; } });
        return;
      }
      const list = names().map(stats);
      body.innerHTML = `<div class="cm-intro">Classroom mode is <b>${CLASS.enabled ? 'on' : 'off'}</b>. ${list.length} student(s) on this computer. Everything lives in this browser; export before clearing it.</div>
        <div class="cm-actions">
          <button class="btn primary" data-act="csv">Export progress CSV</button>
          <button class="btn" data-act="json">Export class backup (JSON)</button>
          <label class="btn">Import backup<input type="file" accept="application/json" hidden></label>
          <button class="btn" data-act="toggle">${CLASS.enabled ? 'Turn classroom off' : 'Turn classroom on'}</button>
        </div>
        <table class="cm-table"><thead><tr><th>Student</th><th>XP</th><th>Missions</th><th>On beat</th><th>Last active</th><th></th></tr></thead><tbody>
        ${list.map((s) => `<tr><td><b>${escapeHtml(s.name)}</b>${s.name === CLASS.current ? ' <em>active</em>' : ''}</td><td>${Number(s.xp) || 0}</td><td>${s.done}/${MISSIONS.length} <small>${s.doneIds.join(' ')}</small></td><td>${Number(s.onBeat) || 0}</td><td>${fmtAgo(s.last)}</td><td class="cm-row-actions"><button class="btn sm" data-reset="${escapeHtml(s.name)}">Reset</button><button class="btn sm danger" data-remove="${escapeHtml(s.name)}">Remove</button></td></tr>`).join('') || `<tr><td colspan="6" class="cm-empty">No students yet.</td></tr>`}
        </tbody></table>
        <div class="cm-danger">
          <b>Reset</b>
          <button class="btn sm" data-act="reset-all">Reset all students' progress</button>
          <button class="btn sm" data-act="reset-solo">Reset this computer's solo progress</button>
          <button class="btn sm" data-act="pin">Change PIN</button>
          <span class="cm-note">Reset keeps names and clears missions, XP, cues, notes and layouts. Remove deletes the student too. Export first if you need the numbers.</span>
        </div>`;
      $('input[type=file]', body).addEventListener('change', (e) => { if (e.target.files[0]) importJSON(e.target.files[0]); });
    }
    function onTeacherClick(e) {
      const b = e.target.closest('button'); if (!b) return;
      if (b.dataset.act === 'csv') exportCSV();
      if (b.dataset.act === 'json') exportJSON();
      if (b.dataset.act === 'toggle') { CLASS.enabled = !CLASS.enabled; if (!CLASS.enabled) CLASS.current = null; saveClass(); toast(CLASS.enabled ? 'Classroom mode on' : 'Classroom mode off. Solo progress restored.'); setTimeout(() => location.reload(), 400); }
      if (b.dataset.act === 'pin') { const v = prompt('New 4-digit teacher PIN'); if (v && /^\d{4}$/.test(v)) { CLASS.pin = v; saveClass(); toast('PIN changed'); } else if (v != null) toast('Four digits, please'); }
      if (b.dataset.reset) { if (!confirm(`Reset ${b.dataset.reset}'s progress, cues and layout?`)) return; wipeStudent(b.dataset.reset); toast(`${b.dataset.reset} reset`); if (b.dataset.reset === CLASS.current) setTimeout(() => location.reload(), 400); else render('teacher'); }
      if (b.dataset.remove) { if (!confirm(`Remove ${b.dataset.remove} and delete their progress?`)) return; wipeStudent(b.dataset.remove); delete CLASS.students[b.dataset.remove]; if (CLASS.current === b.dataset.remove) CLASS.current = null; saveClass(); toast(`${b.dataset.remove} removed`); if (!CLASS.current) setTimeout(() => location.reload(), 400); else render('teacher'); }
      if (b.dataset.act === 'reset-all') { if (!confirm(`Reset progress for all ${names().length} students? Names are kept.`)) return; names().forEach(wipeStudent); toast('All students reset'); setTimeout(() => location.reload(), 400); }
      if (b.dataset.act === 'reset-solo') { if (!confirm('Reset the solo (non-classroom) progress, cues and layout on this computer?')) return; ['progress', 'show', 'layout', 'layouts', 'activeMission', 'welcomed'].forEach((k) => localStorage.removeItem('spark.' + k)); toast('Solo progress reset'); if (!CLASS.enabled || !CLASS.current) setTimeout(() => location.reload(), 400); }
    }
    function open(tab) { modal.hidden = false; render(tab || 'students'); $('.cm-tab.on', modal)?.focus(); }
    function close() { modal.hidden = true; }
    tabs.forEach((t) => t.addEventListener('click', () => render(t.dataset.tab)));
    body.addEventListener('click', (e) => { if (unlocked && $('.cm-tab.on', modal)?.dataset.tab === 'teacher') onTeacherClick(e); });
    $('.cm-close', modal).addEventListener('click', close);
    modal.addEventListener('click', (e) => { if (e.target === modal) close(); });
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !modal.hidden) close(); });
    $('#class-btn').addEventListener('click', () => open('students'));
    const label = () => { $('#class-btn').innerHTML = CLASS.enabled ? `<i class="dot"></i>${CLASS.current ? escapeHtml(CLASS.current) : 'Pick a student'}` : 'Classroom'; };
    label();
    if (CLASS.enabled && CLASS.current && CLASS.students[CLASS.current]) { CLASS.students[CLASS.current].lastActive = Date.now(); saveClass(); bus.on('*', () => { const s = CLASS.students[CLASS.current]; if (s && Date.now() - s.lastActive > 60000) { s.lastActive = Date.now(); saveClass(); } }); }
    return { open, close, exportCSV, exportJSON, stats: () => names().map(stats), forgotPin() { CLASS.pin = ''; unlocked = false; saveClass(); toast('Teacher PIN cleared'); }, get current() { return CLASS.enabled ? CLASS.current : null; }, get enabled() { return CLASS.enabled; } };
  })();

  // first run / welcome
  applyLayout();
  updateXP();
  setTimeout(() => {
    if (CLASS.enabled && !CLASS.current) { classroom.open('students'); VLSAvatar.say("Classroom mode is on. Pick your name first so your missions save under it.", { mood: 'chill', gesture: 'point', speak: false }); return; }
    const who = classroom.current ? `Hey ${classroom.current}. ` : 'Hey. ';
    const first = !progress.done.faders && !LS.get('welcomed', false);
    if (first) {
      LS.set('welcomed', true);
      VLSAvatar.say(who + "I'm Pete. This is Spark Studio: six flames, four faders, and nobody gets hurt because none of it is real. Want me to show you the faders first?", { mood: 'happy', gesture: 'wave', sticky: true, speak: false, actions: [{ label: 'Start Mission 1', primary: true, onClick: () => startMission('faders') }, { label: "I'll poke around", onClick: () => VLSAvatar.dismiss() }] });
    } else {
      const next = MISSIONS.find((m) => !progress.done[m.id]);
      VLSAvatar.say(next ? `Welcome back${classroom.current ? ', ' + classroom.current : ''}. ${progress.xp} XP so far. Next up: ${next.title}.` : `Welcome back${classroom.current ? ', ' + classroom.current : ''}, operator. All missions done. Build something ridiculous.`, { mood: 'happy', gesture: 'wave', speak: false, actions: next ? [{ label: `Continue Mission ${next.n}`, primary: true, onClick: () => startMission(next.id) }] : [] });
    }
  }, 900);

  // expose a tiny API for Pete / debugging
  window.Spark = { show, layout: () => layout, addPanel, removePanel, movePanel, startMission, setCustomizing, go, home, bus, classroom };
})();
