// MA panel (Beta 0.33): a grandMA2 / grandMA3 command section that drives Wave Studio with console syntax.
// Local visualization only. Keys can be pressed on screen, typed on the command line, or mapped to a physical
// grandMA console through the control universe (Bank & Mapping Controls → Console mapping). Nothing here
// transmits DMX; the console mapping listens, it never sends.
import {MA_KEYS,MA_KEY,MA_GROUPS,MA_WORDS} from './ma-keys.js?v=v0340-20261007f';

const OBJECTS=['fixture','channel','group','preset','cue','sequ','exec','page','macro','view','effect'];
const FUNCTIONS=['store','update','delete','edit','label','copy','move','assign','goto','select','time','go-plus','go-minus','pause','off','on','top','temp','toggle','full','step-back','step-fwd','learn','if','set'];
// Pressed on an empty line these act at once on the default object.
const IMMEDIATE=['go-plus','go-minus','pause','on','top','temp','toggle','full','step-back','step-fwd','learn'];
const PAGE_SIZE=10,PAGES=2,GROUP_KEY='vsl-ma-groups',KEYSET_KEY='vsl-ma-keyset';
const pad=n=>String(n).padStart(2,'0');
const clamp=(n,lo,hi)=>Math.max(lo,Math.min(hi,n));
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

function loadGroups(){
 try{
  const raw=JSON.parse(localStorage.getItem(GROUP_KEY)||'{}');const out={};
  for(const [n,g] of Object.entries(raw)){
   const id=Number(n);if(!Number.isInteger(id)||id<1||id>99||!g||!Array.isArray(g.ids))continue;
   out[id]={name:typeof g.name==='string'?g.name.slice(0,40):'',ids:g.ids.filter(x=>Number.isInteger(x)&&x>0).slice(0,200)};
  }
  return out;
 }catch{return {}}
}

export function createMAEngine({state,playback,stack,stackRoot,select,applyPreset,setHome,rename,click,announce=()=>{},macro}){
 const bank=playback.bank;
 const engine={
  line:[],feedback:'MA command section ready. Fixture 1 Thru 4 Please selects units; Go+ runs the cue stack.',
  page:1,selectedExec:0,held:new Set(),toggles:new Set(),groups:loadGroups(),labelPending:null,
  keyset:localStorage.getItem(KEYSET_KEY)||'ma3',listeners:new Set()
 };
 const notify=()=>{for(const fn of engine.listeners)try{fn()}catch{}};
 const say=(message)=>{engine.feedback=message;announce(message);notify()};
 const blocked=()=>playback.isBlocked();
 const saveGroups=()=>{try{localStorage.setItem(GROUP_KEY,JSON.stringify(engine.groups))}catch{}};
 const ids=()=>state.fixtures.map(f=>f.id).sort((a,b)=>a-b);
 const execIndex=n=>{ // "2.3" → page 2 exec 3; plain 1–20 → fader number.
  if(typeof n==='string'&&n.includes('.')){const [p,e]=n.split('.').map(Number);return (p-1)*PAGE_SIZE+e-1}
  const v=Number(n);return v<=PAGE_SIZE?(engine.page-1)*PAGE_SIZE+v-1:v-1;
 };
 const execName=i=>`Exec ${Math.floor(i/PAGE_SIZE)+1}.${i%PAGE_SIZE+1} (fader ${i+1})`;
 const cueAt=n=>bank.cues[n-1]??null;
 const faderCue=i=>bank.cues.find(c=>c.id===bank.slots[i]?.cueId)??null;

 // ----- command line ---------------------------------------------------------------------------------------
 const lineText=()=>engine.line.map(t=>t.t==='num'?t.text:MA_KEY[t.id]?.label??t.id).join(' ');
 function pushNumber(ch){
  const last=engine.line.at(-1);
  if(last?.t==='num'&&last.open){if(ch==='.'&&last.text.includes('.'))return;last.text+=ch}
  else engine.line.push({t:'num',text:ch==='.'?'0.':ch,open:true});
 }
 function closeNumber(){const last=engine.line.at(-1);if(last?.t==='num')last.open=false}
 function clearLine(){engine.line=[];engine.labelPending=null}

 function expand(items,max){ // [{from,to,op}] → sorted unique numbers
  const out=new Set();
  for(const it of items){
   const from=Number(it.from),to=it.to===null?max:it.to===undefined?from:Number(it.to);
   if(!Number.isFinite(from))continue;
   const lo=Math.min(from,to),hi=Math.max(from,to);
   if(hi-lo>1000)throw Error('Range too large.');
   for(let n=lo;n<=hi;n++)if(it.op==='minus')out.delete(n);else out.add(n);
  }
  return [...out].sort((a,b)=>a-b);
 }
 function parse(tokens){
  const cmd={fn:null,objects:[],at:null,atObjects:[],phase:'main'};
  let current=null,sign=1;
  const newObject=type=>{current={type,items:[]};(cmd.phase==='at'?cmd.atObjects:cmd.objects).push(current)};
  for(const tok of tokens){
   if(tok.t==='num'){
    const value=Number(tok.text)*sign;sign=1;
    if(!Number.isFinite(value))throw Error(`“${tok.text}” is not a number.`);
    if(cmd.phase==='at'&&!current){if(cmd.at!==null)throw Error('One value after At.');cmd.at=value;continue}
    if(!current)newObject(cmd.fn==='goto'?'entry':'fixture');
    const last=current.items.at(-1);
    if(last&&last.to===null&&last.openThru){last.to=tok.text.includes('.')?tok.text:value;last.openThru=false}
    else current.items.push({from:tok.text.includes('.')?tok.text:value,to:undefined,op:current.pendingOp??'plus'});
    current.pendingOp=null;continue;
   }
   const id=tok.id;
   if(OBJECTS.includes(id)){newObject(id==='channel'?'fixture':id);continue}
   if(id==='at'){if(cmd.phase==='at')throw Error('One At per command.');cmd.phase='at';current=null;continue}
   if(id==='thru'){if(!current||!current.items.length)throw Error('Thru needs a start number.');const last=current.items.at(-1);if(last.to!==undefined)throw Error('Thru already used.');last.to=null;last.openThru=true;continue}
   if(id==='plus'||id==='minus'){
    if(cmd.phase==='at'&&!current&&cmd.at===null){sign=id==='minus'?-1:1;continue}
    if(!current)throw Error(`${MA_KEY[id].label} needs an object first.`);
    current.pendingOp=id;continue;
   }
   if(FUNCTIONS.includes(id)){if(cmd.fn)throw Error('One function per command.');cmd.fn=id;continue}
   throw Error(`${MA_KEY[id]?.label??id} cannot be part of a command.`);
  }
  for(const o of [...cmd.objects,...cmd.atObjects])for(const it of o.items)if(it.openThru){it.to=null;it.openThru=false}
  return cmd;
 }
 const numbersOf=(obj,max)=>obj?expand(obj.items.map(it=>({...it,from:Number(it.from),to:typeof it.to==='string'?Number(it.to):it.to})),max):[];
 const execsOf=obj=>{
  if(!obj)return [];
  const out=new Set();
  for(const it of obj.items){
   const a=execIndex(it.from),b=it.to===null?engine.page*PAGE_SIZE-1:it.to===undefined?a:execIndex(it.to);
   for(let i=Math.min(a,b);i<=Math.max(a,b);i++){if(it.op==='minus')out.delete(i);else out.add(i)}
  }
  return [...out].filter(i=>Number.isInteger(i)&&i>=0&&i<20).sort((a,b)=>a-b);
 };

 // ----- executor helpers ------------------------------------------------------------------------------------
 function startExec(i,level=100){
  if(blocked()){say('Live Input owns playback. Leave Live Input to run executors.');return false}
  if(!bank.playable(i)){say(`${execName(i)} has no cue. Assign Cue n Exec ${i+1} first.`);return false}
  if(engine.toggles.has('solo'))for(let n=0;n<20;n++)if(n!==i)bank.setLevel(n,0);
  if(bank.level(i)>0)bank.runtime[i].started=bank.time;
  bank.setLevel(i,level);engine.selectedExec=i;playback.paint?.();return true;
 }
 function stackUI(){return stack?.()??null}
 function stackButton(name){const root=stackRoot?.();root?.querySelector(`[data-stack-${name}]`)?.click()}

 // ----- execution ---------------------------------------------------------------------------------------------
 function execute(cmd){
  const fn=cmd.fn,objs=cmd.objects,first=objs[0]??null,type=first?.type??null;
  const unitIds=()=>{
   if(!first||!['fixture','group'].includes(type))return state.selectedIds;
   const all=ids();
   if(type==='fixture')return numbersOf(first,all.at(-1)??0).filter(n=>all.includes(n));
   const list=[];for(const n of numbersOf(first,99)){const g=engine.groups[n];if(g)list.push(...g.ids.filter(id=>all.includes(id)))}
   return [...new Set(list)];
  };
  if(!fn){
   if(!first)return say('Nothing to execute.');
   if(cmd.phase==='at'&&cmd.at!==null){
    if(['fixture','group'].includes(type)){
     const list=unitIds();if(!list.length)return say('No units in that selection.');
     select(list);
     const v=clamp(cmd.at,-105,105),fan=engine.toggles.has('align')&&list.length>1;
     setHome(list.map((id,i)=>({id,angle:fan?-v+(2*v)*i/(list.length-1):v})));
     if(fan)engine.toggles.delete('align');
     return say(`${list.length} unit(s) parked at ${fan?`a fan from ${-v}° to ${v}°`:`${v}°`}. Raise a fader or press Go+ to resume.`);
    }
    if(type==='exec'){
     const list=execsOf(first);if(!list.length)return say('No executors in that range.');
     if(blocked())return say('Live Input owns playback.');
     const level=clamp(cmd.at,0,100);
     for(const i of list){if(bank.playable(i)){if(level>0&&engine.toggles.has('solo'))for(let n=0;n<20;n++)if(!list.includes(n))bank.setLevel(n,0);bank.setLevel(i,level)}}
     engine.selectedExec=list[0];playback.paint?.();return say(`${list.length} executor(s) at ${level} %.`);
    }
    if(type==='page')return say('Use Page n Please to change the executor page.');
    return say('At applies to Fixture, Group and Exec.');
   }
   switch(type){
    case 'fixture':case 'group':{const list=unitIds();if(!list.length)return say(type==='group'?'That group is empty or not stored. Store Group n saves the current selection.':'No units with those numbers.');select(list);return say(`${list.length} unit(s) selected: ${list.map(id=>`F${pad(id)}`).join(' ')}.`)}
    case 'preset':{const n=numbersOf(first,88)[0];if(!n||n>88)return say('Programs run 1–88.');applyPreset(n);return say(`Program ${String(n).padStart(3,'0')} applied to ${state.selectedIds.length?'the selected units':'all units'}.`)}
    case 'cue':{const n=numbersOf(first,999)[0],cue=cueAt(n);if(!cue)return say(`Cue ${n??'?'} is not recorded (${bank.cues.length} cue(s) in the library).`);if(blocked())return say('Live Input owns playback.');playback.playCueById(cue.id);return say(`Playing “${cue.name}” (cue ${n}).`)}
    case 'sequ':{const n=numbersOf(first,16)[0],st=bank.stacks[n-1];if(!st)return say(`Stack ${n??'?'} does not exist (${bank.stacks.length} stack(s)).`);const sel=stackRoot?.()?.querySelector('[data-stack-select]');if(sel){sel.value=String(st.id);sel.dispatchEvent(new Event('change'))}return say(`Cue stack “${st.name}” selected.`)}
    case 'exec':{const list=execsOf(first);if(!list.length)return say('No executors in that range.');engine.selectedExec=list[0];const c=faderCue(list[0]);return say(`${execName(list[0])} selected${c?` · “${c.name}”`:' · empty'}. Go+, Full, Temp, Up and Down now act on it.`)}
    case 'page':{const n=numbersOf(first,PAGES)[0];if(!n||n<1||n>PAGES)return say(`Pages run 1–${PAGES}.`);engine.page=n;return say(`Executor page ${n}: X1–X10 are faders ${(n-1)*PAGE_SIZE+1}–${n*PAGE_SIZE}.`)}
    case 'macro':{const n=numbersOf(first,12)[0];if(!n||n>12)return say('Macros run F1–F12.');macro(n-1,true);setTimeout(()=>macro(n-1,false),120);return say(`Macro F${n}: ${bank.macros[n-1]?.name??'unassigned'}.`)}
    case 'entry':{const n=numbersOf(first,999)[0];const st=stackUI();if(!st)return say('No cue stack.');st.go(n-1);return say(`Stack entry ${n}.`)}
    case 'view':return say('Views are the Layouts dialog in Wave Studio (Customize Workspace → Layouts). View n is not modelled.');
    case 'effect':return say('Effects are not modelled: the X2 runs library programs. Use Preset n for a program.');
   }
   return say('Nothing to execute.');
  }
  switch(fn){
   case 'go-plus':{
    if(type==='exec'){const list=execsOf(first);let n=0;for(const i of list)if(startExec(i))n++;return n?say(`Go+ on ${n} executor(s).`):undefined}
    if(type==='cue'){const cue=cueAt(numbersOf(first,999)[0]);if(!cue)return say('Cue not recorded.');if(blocked())return say('Live Input owns playback.');playback.playCueById(cue.id);return say(`Go+ “${cue.name}”.`)}
    if(type==='sequ'){execute({...cmd,fn:null});const st=stackUI();st?.go();return say(`Go+ on the selected cue stack.`)}
    if(type==='entry'){return execute({...cmd,fn:null})}
    const st=stackUI();
    if(st&&bank.stacks.some(s=>s.entries.length)){if(blocked())return say('Live Input owns playback.');st.go();return say(`GO: stack entry ${st.state.next||st.state.current+1}.`)}
    return startExec(engine.selectedExec)?say(`Go+ ${execName(engine.selectedExec)}.`):undefined;
   }
   case 'go-minus':{
    if(type==='exec'){const list=execsOf(first);for(const i of list)if(bank.level(i)>0)bank.runtime[i].started=bank.time;playback.paint?.();return say(`Go− restarted ${list.length} executor(s).`)}
    const st=stackUI();if(st){st.back();return say('Go−: previous stack entry.')}return say('No cue stack.');
   }
   case 'pause':{if(blocked())return say('Live Input owns playback.');playback.transport('play');return say(playback.transportState().paused?'Bank clock paused.':'Bank clock running.')}
   case 'off':{
    if(type==='exec'){const list=execsOf(first);for(const i of list)bank.setLevel(i,0);playback.paint?.();return say(`${list.length} executor(s) released.`)}
    if(type==='cue'){const cue=cueAt(numbersOf(first,999)[0]);let n=0;bank.slots.forEach((s,i)=>{if(cue&&s.cueId===cue.id&&bank.level(i)>0){bank.setLevel(i,0);n++}});playback.paint?.();return say(`${n} executor(s) running that cue released.`)}
    if(engine.toggles.has('ma')){engine.toggles.delete('ma');bank.releaseAll();document.dispatchEvent(new Event('wave-release-all'));playback.paint?.();return say('MA + Off: every playback released.')}
    const st=stackUI();
    if(st&&st.state.current>=0){st.release();return say('Cue stack released.')}
    if(bank.level(engine.selectedExec)>0){bank.setLevel(engine.selectedExec,0);playback.paint?.();return say(`${execName(engine.selectedExec)} released.`)}
    if(st){st.release();return say('Cue stack released.')}return say('Nothing to release.');
   }
   case 'on':case 'full':{const list=type==='exec'?execsOf(first):[engine.selectedExec];let n=0;for(const i of list)if(startExec(i))n++;return n?say(`${n} executor(s) at 100 %.`):undefined}
   case 'toggle':{const list=type==='exec'?execsOf(first):[engine.selectedExec];for(const i of list){if(bank.level(i)>0)bank.setLevel(i,0);else startExec(i)}playback.paint?.();return say(`Toggled ${list.length} executor(s).`)}
   case 'top':{stackButton('top');return say('Cue stack: Next points at entry 1.')}
   case 'goto':{
    if(type==='cue'){const cue=cueAt(numbersOf(first,999)[0]);if(!cue)return say('Cue not recorded.');if(blocked())return say('Live Input owns playback.');playback.playCueById(cue.id);return say(`Goto “${cue.name}”.`)}
    if(type==='entry'||type==='fixture'){const n=numbersOf(first,999)[0];const st=stackUI();if(!st)return say('No cue stack.');if(blocked())return say('Live Input owns playback.');st.go(n-1);return say(`Goto stack entry ${n}.`)}
    return say('Goto Cue n or Goto n (stack entry).');
   }
   case 'temp':{const list=type==='exec'?execsOf(first):[engine.selectedExec];if(blocked())return say('Live Input owns playback.');for(const i of list)if(bank.playable(i)){bank.hold(i,'ma-temp');setTimeout(()=>{bank.unhold(i,'ma-temp');playback.paint?.()},400)}playback.paint?.();return say(`Temp flash on ${list.length} executor(s).`)}
   case 'step-back':case 'step-fwd':{if(blocked())return say('Live Input owns playback.');playback.transport(fn==='step-back'?'prev':'next');return say(fn==='step-back'?'Previous recorded cue.':'Next recorded cue.')}
   case 'learn':return say('Learn (tap tempo) is not modelled: chase speed comes from the cue timing dialog (Time).');
   case 'time':{let cue=null;if(type==='cue')cue=cueAt(numbersOf(first,999)[0]);else cue=faderCue(type==='exec'?execsOf(first)[0]??engine.selectedExec:engine.selectedExec);if(!cue)return say('No cue there to time. Edit Cue n or assign a cue first.');playback.openTiming(cue.id);return say(`Timing for “${cue.name}”.`)}
   case 'select':{
    if(type==='exec'){const i=execsOf(first)[0];if(i===undefined)return say('No executor.');engine.selectedExec=i;return say(`${execName(i)} is the selected executor.`)}
    if(type==='sequ')return execute({...cmd,fn:null});
    const list=unitIds();select(list);return say(`${list.length} unit(s) selected.`);
   }
   case 'store':{
    if(blocked())return say('Leave Live Input before storing.');
    if(type==='group'){const n=numbersOf(first,99)[0];if(!n||n>99)return say('Groups run 1–99.');if(!state.selectedIds.length)return say('Select units first, then Store Group n.');engine.groups[n]={name:engine.groups[n]?.name??`Group ${n}`,ids:[...state.selectedIds]};saveGroups();return say(`Group ${n} stored with ${state.selectedIds.length} unit(s). Label Group ${n} names it.`)}
    if(type==='preset')return say('Programs are the fixed X2 library (1–88) and cannot be stored. Store Cue records the current look.');
    if(type==='exec'){const i=execsOf(first)[0];if(i===undefined)return say('No executor.');try{const c=bank.record(`Exec ${i+1}`,state.fixtures,state.selectedIds);bank.assign(i,c.id);playback.refreshCues?.();engine.selectedExec=i;return say(`Stored “${c.name}” on ${execName(i)} from ${c.looks.length} unit(s).`)}catch(e){return say(e.message)}}
    if(type==='cue'||!type){
     const n=type==='cue'?numbersOf(first,999)[0]:null,existing=n?cueAt(n):null;
     try{
      if(existing){bank.updateCue(existing.id,existing.name,state.fixtures,state.selectedIds);playback.refreshCues?.();return say(`Cue ${n} “${existing.name}” overwritten from the selected units.`)}
      if(n&&n!==bank.cues.length+1)return say(`Cue ${n} does not exist yet; the next cue is ${bank.cues.length+1}.`);
      const c=bank.record(n?`Cue ${n}`:'',state.fixtures,state.selectedIds);
      const free=bank.slots.findIndex(s=>!s.dmxPriority&&s.kind==='cue'&&s.cueId===null);if(free>=0)bank.assign(free,c.id);
      playback.refreshCues?.();return say(`Stored “${c.name}” as cue ${bank.cues.length}${free>=0?` on fader ${free+1}`:''}.`);
     }catch(e){return say(e.message)}
    }
    return say('Store Cue, Store Cue n, Store Group n or Store Exec n.');
   }
   case 'update':{
    if(blocked())return say('Leave Live Input before updating.');
    const cue=type==='cue'?cueAt(numbersOf(first,999)[0]):faderCue(type==='exec'?execsOf(first)[0]??engine.selectedExec:engine.selectedExec);
    if(!cue)return say('No cue to update.');
    try{bank.updateCue(cue.id,cue.name,state.fixtures,state.selectedIds);playback.refreshCues?.();return say(`“${cue.name}” updated from the selected units.`)}catch(e){return say(e.message)}
   }
   case 'delete':{
    if(type==='cue'){const n=numbersOf(first,999)[0],cue=cueAt(n);if(!cue)return say('Cue not recorded.');bank.deleteCue(cue.id);playback.refreshCues?.();return say(`Cue ${n} “${cue.name}” deleted.`)}
    if(type==='group'){let n=0;for(const g of numbersOf(first,99))if(engine.groups[g]){delete engine.groups[g];n++}saveGroups();return say(`${n} group(s) deleted.`)}
    if(type==='exec'){const list=execsOf(first);for(const i of list){bank.resetSlot(i);bank.assign(i,null)}playback.refreshCues?.();return say(`${list.length} executor(s) cleared.`)}
    if(type==='fixture')return say('Deleting units is a layout edit: select them and use Delete in Fixture & File Controls.');
    if(type==='sequ')return say('Delete stacks from the Cue Stack toolbar (it asks for confirmation).');
    return say('Del Cue n, Del Group n or Del Exec n.');
   }
   case 'edit':{
    if(type==='cue'){const cue=cueAt(numbersOf(first,999)[0]);if(!cue)return say('Cue not recorded.');playback.openTiming(cue.id);return say(`Editing “${cue.name}”.`)}
    if(type==='exec'){const i=execsOf(first)[0]??engine.selectedExec,cue=faderCue(i);if(!cue)return say(`${execName(i)} is empty.`);playback.openTiming(cue.id);return say(`Editing “${cue.name}” on ${execName(i)}.`)}
    if(type==='fixture'||type==='group'){const list=unitIds();if(!list.length)return say('No units.');select(list);document.querySelector('.fixture-editor')?.scrollIntoView({behavior:'smooth',block:'center'});return say(`${list.length} unit(s) selected for editing.`)}
    return say('Edit Cue n, Edit Exec n or Edit Fixture n.');
   }
   case 'label':{
    if(!['cue','group','fixture','exec'].includes(type))return say('Label Cue n, Group n, Fixture n or Exec n, then type the name and press Please.');
    const n=type==='exec'?execsOf(first)[0]:numbersOf(first,999)[0];
    if(type==='cue'&&!cueAt(n))return say('Cue not recorded.');
    if(type==='exec'&&!faderCue(n))return say('That executor is empty.');
    engine.labelPending={type,n,ids:type==='fixture'?unitIds():null};notify();return say(`Type the new name for ${type} ${type==='exec'?n+1:n} and press Please.`);
   }
   case 'copy':case 'move':{
    const target=cmd.atObjects[0];
    if(type==='cue'&&(!target||target.type==='cue')){
     const a=numbersOf(first,999)[0],b=target?numbersOf(target,999)[0]:cmd.at;const cue=cueAt(a);
     if(!cue||!Number.isInteger(b)||b<1)return say(`${fn==='copy'?'Copy':'Move'} Cue a At b with recorded cue numbers.`);
     if(fn==='move'){const [moved]=bank.cues.splice(a-1,1);bank.cues.splice(clamp(b-1,0,bank.cues.length),0,moved);playback.refreshCues?.();return say(`Cue ${a} moved to position ${Math.min(b,bank.cues.length)}.`)}
     if(bank.cues.length>=64)return say('The cue library is full (64 cues).');
     const copy=structuredClone(cue);copy.id=bank.nextId++;copy.name=`${cue.name} copy`.slice(0,48);bank.cues.splice(clamp(b-1,0,bank.cues.length),0,copy);playback.refreshCues?.();return say(`Cue ${a} copied to position ${Math.min(b,bank.cues.length)}.`);
    }
    if(type==='exec'){
     const a=execsOf(first)[0],b=target?.type==='exec'?execsOf(target)[0]:Number.isInteger(cmd.at)?execIndex(cmd.at):undefined;
     if(a===undefined||b===undefined)return say(`${fn==='copy'?'Copy':'Move'} Exec a At b.`);
     const src=bank.slots[a];bank.resetSlot(b);bank.assign(b,src.kind==='chase'?'chase':src.cueId);
     if(fn==='move'){bank.resetSlot(a);bank.assign(a,null)}
     playback.refreshCues?.();return say(`${execName(a)} ${fn==='copy'?'copied':'moved'} to ${execName(b)}.`);
    }
    return say(`${fn==='copy'?'Copy':'Move'} works on Cue a At b and Exec a At b.`);
   }
   case 'assign':{
    const cueObj=objs.find(o=>o.type==='cue'),execObj=objs.find(o=>o.type==='exec')??cmd.atObjects.find(o=>o.type==='exec');
    if(!cueObj||!execObj)return say('Assign Cue n Exec m (or Assign Cue n At Exec m).');
    const cue=cueAt(numbersOf(cueObj,999)[0]),i=execsOf(execObj)[0];
    if(!cue||i===undefined)return say('Cue or executor not found.');
    bank.resetSlot(i);bank.assign(i,cue.id);playback.refreshCues?.();engine.selectedExec=i;return say(`“${cue.name}” assigned to ${execName(i)}.`);
   }
   case 'if':return say('If (filters) is not modelled.');
   case 'set':return say('Set is not modelled: edit values in the Wave Studio panels.');
  }
  return say('Nothing to execute.');
 }

 function executeLine(){
  if(engine.labelPending)return say('Type the name, then Please.');
  closeNumber();
  try{const cmd=parse(engine.line);clearLine();execute(cmd)}
  catch(e){say(`Command error: ${e.message}`);}
  notify();
 }
 function finishLabel(text){
  const p=engine.labelPending;engine.labelPending=null;const name=String(text??'').trim().slice(0,48);
  if(!p||!name)return say('Label cancelled.');
  if(p.type==='cue'){const cue=cueAt(p.n);if(cue){cue.name=name;playback.refreshCues?.()}}
  else if(p.type==='exec'){const cue=faderCue(p.n);if(cue){cue.name=name;playback.refreshCues?.()}}
  else if(p.type==='group'){engine.groups[p.n]={name,ids:engine.groups[p.n]?.ids??[...state.selectedIds]};saveGroups()}
  else if(p.type==='fixture')rename(p.ids,name);
  say(`Labelled ${p.type} ${p.type==='exec'?p.n+1:p.n} “${name}”.`);
 }

 // ----- keys -----------------------------------------------------------------------------------------------------
 function press(id,down=true){
  const key=MA_KEY[id];if(!key)return;
  if(down)engine.held.add(id);else engine.held.delete(id);
  if(key.hold){ // Temp: flash while held
   const list=engine.line.length?(()=>{try{return execsOf(parse(engine.line).objects.find(o=>o.type==='exec'))}catch{return []}})():[engine.selectedExec];
   const targets=list.length?list:[engine.selectedExec];
   if(down){if(blocked()){say('Live Input owns playback.');return}let n=0;for(const i of targets)if(bank.playable(i)){bank.hold(i,'ma-temp');n++}if(n)say(`Temp: flashing ${n} executor(s).`)}
   else{for(const i of targets)bank.unhold(i,'ma-temp');for(let n=0;n<20;n++)bank.unhold(n,'ma-temp')}
   playback.paint?.();notify();return;
  }
  if(!down){notify();return}
  if(/^n\d$/.test(id)){pushNumber(id.slice(1));notify();return}
  if(id==='dot'){pushNumber('.');notify();return}
  if(/^x(\d+)$/.test(id)){const i=(engine.page-1)*PAGE_SIZE+Number(id.slice(1))-1;if(startExec(i))say(`X${id.slice(1)}: Go+ ${execName(i)}.`);return}
  closeNumber();
  switch(id){
   case 'please':return executeLine();
   case 'esc':{clearLine();document.querySelector('dialog[open]:not(#manual-dialog)')?.close();return say('Command line cleared.')}
   case 'clear':{
    if(engine.toggles.has('ma')){engine.toggles.delete('ma');bank.releaseAll();document.dispatchEvent(new Event('wave-release-all'));playback.paint?.();clearLine();return say('MA + Clear: every playback released.')}
    if(engine.line.length||engine.labelPending){clearLine();return say('Command line cleared.')}
    if(state.selectedIds.length){select([]);return say('Selection cleared.')}
    return say('Nothing to clear.');
   }
   case 'oops':{const b=document.querySelector('#undo-layout');if(b&&!b.disabled){b.click();return say('Oops: last change undone.')}return say('Nothing to undo.')}
   case 'blind':case 'freeze':case 'prvw':case 'highlt':case 'solo':case 'align':case 'ma':{
    const on=!engine.toggles.has(id);if(on)engine.toggles.add(id);else engine.toggles.delete(id);
    if(id==='blind'){click(on?'#mode-preview':'#mode-faders');return say(on?'Blind: playback source Presets — faders and the stack do not drive the stage.':'Blind off: Virtual faders drive the stage.')}
    if(id==='freeze'){click('#play');return say(on?'Freeze: stage animation paused.':'Stage animation running.')}
    if(id==='prvw'){const g=document.querySelector('#guides');if(g){g.checked=on;g.dispatchEvent(new Event('change',{bubbles:true}))}return say(on?'Angle guides shown.':'Angle guides hidden.')}
    if(id==='highlt'){if(blocked()){engine.toggles.delete(id);return say('Live Input owns playback.')}for(let n=0;n<20;n++){if(on&&bank.playable(n))bank.hold(n,'ma-highlt');else bank.unhold(n,'ma-highlt')}playback.paint?.();return say(on?'Highlt: every playable executor flashing.':'Highlt off.')}
    if(id==='solo')return say(on?'Solo: starting an executor releases the others.':'Solo off.');
    if(id==='align')return say(on?'Align: the next Fixture … At v fans the heads from −v to +v.':'Align off.');
    return say(on?'MA modifier held: MA + Clear or MA + Off releases every playback.':'MA modifier released.');
   }
   case 'backup':click('#save-layout');return say('Backup: Save Layout.');
   case 'setup':case 'menu':click('#app-settings');return say('Settings opened.');
   case 'help':click('#manual-open');return say('First Guide opened.');
   case 'tools':click('#wave-guide-open');return say('AI Assist opened.');
   case 'list':{document.querySelector('.fixture-strip')?.scrollIntoView({behavior:'smooth',block:'center'});return say('Unit List.')}
   case 'prev':case 'next':{
    const all=ids();if(!all.length)return say('No units.');
    const at=all.indexOf(state.selectedId),n=at<0?(id==='next'?0:all.length-1):(at+(id==='next'?1:-1)+all.length)%all.length;
    select([all[n]],all[n]);return say(`F${pad(all[n])} selected.`);
   }
   case 'up':case 'down':{if(blocked())return say('Live Input owns playback.');const i=engine.selectedExec;if(!bank.playable(i))return say(`${execName(i)} is empty.`);const level=clamp(Math.round(bank.level(i)+(id==='up'?10:-10)),0,100);bank.setLevel(i,level);playback.paint?.();return say(`${execName(i)} at ${level} %.`)}
   case 'page-plus':case 'page-minus':{engine.page=clamp(engine.page+(id==='page-plus'?1:-1),1,PAGES);return say(`Executor page ${engine.page}: X1–X10 are faders ${(engine.page-1)*PAGE_SIZE+1}–${engine.page*PAGE_SIZE}.`)}
  }
  // Objects, functions and operators join the command line. Immediate functions on an empty line act now;
  // a function pressed after objects executes the line (Exec 3 Full, Fixture 2 Please-less Select).
  if(IMMEDIATE.includes(id)&&!engine.line.length){engine.line.push({t:'fn',id});return executeLine()}
  if(FUNCTIONS.includes(id)&&engine.line.length&&!engine.line.some(t=>t.t==='fn')&&!['at','thru','plus','minus'].includes(id)&&engine.line.at(-1).t==='num'&&!['label','copy','move','assign','store','delete','edit','update','goto','select','time','if','set'].includes(id)){
   engine.line.push({t:'fn',id});return executeLine();
  }
  engine.line.push({t:'key',id});notify();
 }
 function typeLine(text){
  // Typed command line: words map to keys, numbers and ranges (1-4 or 1..4) to numbers and Thru.
  clearLine();
  const words=String(text).trim().split(/\s+/).filter(Boolean);
  for(const raw of words){
   const w=raw.toLowerCase();
   const range=/^(-?\d+(?:\.\d+)?)(?:-|\.\.|thru)(-?\d+(?:\.\d+)?)$/.exec(w);
   if(range){engine.line.push({t:'num',text:range[1]});engine.line.push({t:'key',id:'thru'});engine.line.push({t:'num',text:range[2]});continue}
   if(/^-?\d+(\.\d+)?$/.test(w)){if(w.startsWith('-'))engine.line.push({t:'key',id:'minus'});engine.line.push({t:'num',text:w.replace('-','')});continue}
   const id=Object.hasOwn(MA_WORDS,w)?MA_WORDS[w]:null;
   if(!id){say(`Unknown word “${raw}”.`);clearLine();return}
   if(['please','esc','clear','oops'].includes(id)||MA_KEY[id].toggle||MA_KEY[id].group==='system'||/^x\d+$/.test(id)){if(words.length===1){press(id);return}if(id==='please')continue;say(`“${raw}” is a key, not a command word.`);clearLine();return}
   engine.line.push(FUNCTIONS.includes(id)?{t:'fn',id}:{t:'key',id});
  }
  executeLine();
 }
 return Object.assign(engine,{press,typeLine,executeLine,finishLabel,lineText,clearLine,
  setKeyset(v){engine.keyset=['ma3','ma2','all'].includes(v)?v:'ma3';try{localStorage.setItem(KEYSET_KEY,engine.keyset)}catch{}notify()},
  subscribe(fn){engine.listeners.add(fn);return ()=>engine.listeners.delete(fn)},
  notify});
}

// ----- panel widget ---------------------------------------------------------------------------------------------------
export function createMAPanel(engine,{mapping}={}){
 const el=document.createElement('section');el.className='ma-panel';
 el.innerHTML=`
<h3 class="ma-title">MA · grandMA command section</h3>
<div class="ma-head">
 <label>Key set<select data-ma-keyset aria-label="Console key set"><option value="ma3">grandMA3</option><option value="ma2">grandMA2</option><option value="all">All keys</option></select></label>
 <span class="ma-page" data-ma-page></span>
 <span class="ma-exec" data-ma-exec></span>
</div>
<div class="ma-cmd"><span class="ma-prompt" aria-hidden="true">›</span><input type="text" class="ma-input" data-ma-input aria-label="MA command line" placeholder="Fixture 1 Thru 4 At 30 · Enter = Please" autocomplete="off" spellcheck="false"></div>
<div class="ma-feedback" data-ma-feedback aria-live="polite"></div>
<div class="ma-keys" data-ma-keys></div>
<details class="ma-map"><summary>Physical grandMA console</summary>
 <p>Patch a block of dimmer channels on the console in the control universe and give every key a channel here; a value of 128 or more presses the key. The Export For grandMA package lists the map in <code>06-ma-keys.csv</code>.</p>
 <div class="ma-map-row"><label>First channel<input type="number" min="1" max="512" value="101" data-ma-map-start></label><button type="button" data-ma-map-patch>Patch Keys In Order</button><button type="button" data-ma-map-clear>Clear Key Patch</button><span data-ma-map-status></span></div>
</details>`;
 const $=s=>el.querySelector(s);
 const keys=$('[data-ma-keys]'),input=$('[data-ma-input]'),feedback=$('[data-ma-feedback]');
 const buttons=new Map();
 function renderKeys(){
  keys.replaceChildren();buttons.clear();
  for(const [group,title] of MA_GROUPS){
   const list=MA_KEYS.filter(k=>k.group===group&&(engine.keyset==='all'||k.set==='both'||k.set===engine.keyset));
   if(!list.length)continue;
   const block=document.createElement('div');block.className=`ma-block ma-${group}`;block.setAttribute('role','group');block.setAttribute('aria-label',title);
   const head=document.createElement('span');head.className='ma-block-title';head.textContent=title;block.append(head);
   const grid=document.createElement('div');grid.className='ma-grid';block.append(grid);
   for(const k of list){
    const b=document.createElement('button');b.type='button';b.className=`ma-key ma-key-${k.id}`;b.dataset.maKey=k.id;b.textContent=k.label;
    b.title=`${k.label}${k.set!=='both'?` (${k.set==='ma3'?'grandMA3':'grandMA2'})`:''}${k.hint?` · ${k.hint}`:''}`;
    if(k.toggle)b.setAttribute('aria-pressed','false');
    let pointer=null;
    const down=()=>engine.press(k.id,true),up=()=>{pointer=null;if(k.hold)engine.press(k.id,false);else engine.held.delete(k.id)};
    b.onpointerdown=e=>{if(e.button!==0)return;e.preventDefault();pointer=e.pointerId;down();try{b.setPointerCapture(pointer)}catch{}};
    b.onpointerup=up;b.onpointercancel=up;b.onlostpointercapture=up;
    b.onkeydown=e=>{if([' ','Enter'].includes(e.key)){e.preventDefault();if(!e.repeat)down()}};
    b.onkeyup=e=>{if([' ','Enter'].includes(e.key)){e.preventDefault();up()}};
    grid.append(b);buttons.set(k.id,b);
   }
   keys.append(block);
  }
 }
 function paint(){
  const text=engine.lineText();
  const typing=document.activeElement===input&&input.dataset.fromKeys!=='1'&&input.value!=='';
  if(!typing&&!engine.labelPending){input.value=text;input.dataset.fromKeys=text?'1':''}
  input.placeholder=engine.labelPending?`Name for ${engine.labelPending.type} ${engine.labelPending.type==='exec'?engine.labelPending.n+1:engine.labelPending.n} · Enter`:'Fixture 1 Thru 4 At 30 · Enter = Please';
  feedback.textContent=engine.feedback;
  $('[data-ma-page]').textContent=`Page ${engine.page} · X1–X10 = faders ${(engine.page-1)*10+1}–${engine.page*10}`;
  $('[data-ma-exec]').textContent=`Selected: Exec ${Math.floor(engine.selectedExec/10)+1}.${engine.selectedExec%10+1}`;
  for(const [id,b] of buttons){
   const held=engine.held.has(id),on=engine.toggles.has(id);
   b.classList.toggle('held',held);b.classList.toggle('lit',on);
   if(b.hasAttribute('aria-pressed'))b.setAttribute('aria-pressed',String(on));
  }
  $('[data-ma-keyset]').value=engine.keyset;
 }
 $('[data-ma-keyset]').onchange=e=>{engine.setKeyset(e.target.value);renderKeys();paint()};
 input.onkeydown=e=>{
  e.stopPropagation();
  if(e.key==='Enter'){e.preventDefault();if(engine.labelPending){engine.finishLabel(input.value);input.value='';input.dataset.fromKeys='';paint();return}
   const typed=input.value.trim();if(typed&&input.dataset.fromKeys!=='1'){engine.typeLine(typed)}else engine.press('please');input.value='';input.dataset.fromKeys='';paint();return}
  if(e.key==='Escape'){e.preventDefault();engine.press('esc');input.value='';input.dataset.fromKeys='';paint();return}
  if(input.dataset.fromKeys==='1'&&e.key.length===1&&!e.ctrlKey&&!e.metaKey){input.dataset.fromKeys='';input.value='';engine.clearLine()}
 };
 input.oninput=()=>{if(!input.value){engine.clearLine();input.dataset.fromKeys=''}};
 const mapStatus=$('[data-ma-map-status]');
 $('[data-ma-map-patch]').onclick=()=>{
  const start=Number($('[data-ma-map-start]').value);
  if(!mapping)return;const r=mapping.patchKeys(start);mapStatus.textContent=r;
 };
 $('[data-ma-map-clear]').onclick=()=>{if(mapping)mapStatus.textContent=mapping.clearKeys()};
 if(!mapping)$('.ma-map').hidden=true;
 renderKeys();paint();
 const unsubscribe=engine.subscribe(paint);
 return {el,render:paint,tick(){if(!el.isConnected)return;const now=performance.now();if(now-(el._t??0)>250){el._t=now;paint()}},dispose:unsubscribe};
}
