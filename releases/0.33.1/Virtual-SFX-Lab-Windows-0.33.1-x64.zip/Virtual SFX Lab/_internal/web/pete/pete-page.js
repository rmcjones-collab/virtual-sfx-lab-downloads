/* Pete introduction page: run the live widget with his web tip pack. */
(function () {
  'use strict';
  if (!window.VLSAvatar) return;
  VLSAvatar.init({
    name: 'Pete',
    tips: window.PETE_WEB_TIPS || {},
    knowledge: window.PETE_WEB_KNOWLEDGE || [],
    tours: window.PETE_WEB_TOURS || {},
    mode: 'chill',
    rude: false,
    lines: {
      greet: [
        'Hi, I am Pete. Hover anything on this page and I will tell you about it, or click me and ask.',
        'Pete here. This page is about me, which is a little awkward. Hover around, or click me and ask something.'
      ]
    }
  });
  var note = document.querySelector('.hero-pete-note');
  VLSAvatar.on('ready', function () {
    if (note) note.textContent = 'He is already here: bottom right. Hover a section, or click him and ask.';
  });
})();
