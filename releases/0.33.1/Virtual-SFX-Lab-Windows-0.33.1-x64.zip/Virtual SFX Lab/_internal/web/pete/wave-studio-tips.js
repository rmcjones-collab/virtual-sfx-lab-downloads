/* Wave Studio tip, knowledge and tour pack for VLS Avatar.
 * Load after vls-avatar.js, then:
 *   VLSAvatar.init({ tips: WAVE_STUDIO_TIPS, knowledge: WAVE_STUDIO_KNOWLEDGE, tours: WAVE_STUDIO_TOURS })
 *
 * Context keys match data-vls-context="…" attributes on studio controls.
 * level: 'beginner' (default) tips are served before 'pro' tips in the same context.
 * manualUrl values are relative to the hosted studio; adjust to your manual anchors.
 */
window.WAVE_STUDIO_TIPS = {
  stage: [
    { text: 'Click a unit to select it. Shift-click adds more. Everything you change after that applies to the whole selection.', setting: 'Stage → click / Shift-click', manualUrl: './manual/#selection', keywords: ['select', 'multiple', 'shift'] },
    { text: 'Select a few X2 units and rotate them together. They turn around their own bases in 5° steps, all the way round.', setting: 'Stage → select units → rotate handle', manualUrl: './manual/#stage-rotation', keywords: ['rotate', 'mount', 'angle'] },
    { text: 'The default six-unit layout alternates inversion so flames cross. Great starting point for a chase.', setting: 'Layout Controls → Reset to default', manualUrl: './manual/#default-layout', keywords: ['default', 'layout', 'inversion'] },
    { text: 'Flame size and the fuel gauge are visual estimates, not measured effect envelopes. Treat them as a rehearsal aid.', manualUrl: './manual/#estimates', keywords: ['fuel', 'flame size', 'estimate'] },
    { level: 'pro', text: 'Mount rotation is saved into layouts and defaults, and it rides along in the Vista build-sheet export. Set it once, keep it everywhere.', setting: 'Stage → rotate → Save layout', manualUrl: './manual/#rotation-persist', keywords: ['rotation', 'persist', 'export'] },
    { level: 'pro', text: 'Double-click a unit to open the rear-display emulation. It mirrors what you would see on the real fixture\'s panel.', setting: 'Stage → double-click unit', manualUrl: './manual/#rear-display', keywords: ['rear display', 'panel', 'emulation'] },
  ],
  fixture: [
    { text: 'Indoor and outdoor nozzle artwork are both in here. Swap them per unit so the preview matches your actual kit.', setting: 'Fixture → Nozzle', manualUrl: './manual/#nozzle', keywords: ['nozzle', 'indoor', 'outdoor'] },
    { level: 'pro', text: 'Favourites can be played in order as a chase. Build three or four looks you like, then step through them from the Favourites strip.', setting: 'Fixture → Favourites → Play as chase', manualUrl: './manual/#favourites', keywords: ['favourite', 'favorite', 'chase'] },
  ],
  faders: [
    { text: 'Each fader can run in Cue mode or DMX mode. Right-click the label to rename it so your cue sheet reads like English.', setting: 'Fader → ⋯ → Mode / Label', manualUrl: './manual/#faders', keywords: ['cue mode', 'dmx mode', 'label', 'rename'] },
    { text: 'Drag to set a level, or tap the top and bottom of the track for full and zero. Flash fires at whatever the master is.', setting: 'Fader → drag / tap', manualUrl: './manual/#fader-basics', keywords: ['level', 'full', 'zero'] },
    { text: 'Addresses have to be unique within a universe. If a fader goes grey, it probably collided with another one.', setting: 'Fader → Universe / Address', manualUrl: './manual/#addressing', keywords: ['address', 'universe', 'collision'] },
    { level: 'pro', text: 'Hold the fader and roll your mouse wheel for fine steps. The increment is adjustable per fader.', setting: 'Fader → ⋯ → Wheel increment', manualUrl: './manual/#wheel', keywords: ['wheel', 'increment', 'fine'] },
    { level: 'pro', text: 'A fader can follow the bank universe or stay unassigned. Unassigned is handy for a scratch fader you don\'t want in the export.', setting: 'Fader → Universe → Follow bank / None', manualUrl: './manual/#bank-universe', keywords: ['bank', 'unassigned', 'scratch'] },
  ],
  flash: [
    { text: 'Flash buttons fire at the fader\'s master level. Set timing per button if you want a longer burst.', setting: 'Flash → Timing', manualUrl: './manual/#flash', keywords: ['flash', 'burst', 'timing'] },
    { level: 'pro', text: 'Flash, Release, Stop and Zero stay protected in Customize Workspace. You can move them, but you can\'t accidentally delete them.', manualUrl: './manual/#protected-controls', keywords: ['protected', 'release', 'stop', 'zero'] },
  ],
  home: [
    { text: 'Home releases cues on the selected heads and turns virtual emission off. It is disabled while the receiver owns Live Input.', setting: 'Fixture → Home angle', manualUrl: './manual/#home', keywords: ['home', 'release', 'live input'] },
    { level: 'pro', text: 'Home angles are per fixture. Set each one so a Home cue parks the whole rig in a tidy, repeatable position.', setting: 'Fixture → Home angle → Set', manualUrl: './manual/#home-angle', keywords: ['home angle', 'park'] },
  ],
  'live-input': [
    { text: 'Live Input follows mapped sACN from the local receiver. Nothing here transmits to a physical fixture, so rehearse freely.', setting: 'Live Input → Receiver preset', manualUrl: './manual/#live-input', keywords: ['sacn', 'receiver', 'live', 'console'] },
    { text: 'Using grandMA? Pick the MA2 or MA3 receiver preset first. It sets Final/Draft sACN and unicast for you.', setting: 'Live Input → Preset → grandMA2 / grandMA3', manualUrl: './manual/#ma-presets', keywords: ['grandma', 'ma2', 'ma3', 'preset'] },
    { level: 'pro', text: 'If the console says it\'s sending but nothing moves, check that only one thing is listening on the sACN port. Vista Check and the receiver can\'t share it.', setting: 'Receiver → Close before running Vista Check', manualUrl: './manual/#receiver-port', keywords: ['port', 'udp', 'datagram', 'vista check'] },
    { level: 'pro', text: 'The MA command panel is receive-only emulation. It shows what the console asked for; it never sends anything back.', setting: 'Live Input → MA command panel', manualUrl: './manual/#ma-command-panel', keywords: ['command panel', 'emulation'] },
  ],
  export: [
    { text: 'Export for Vista 3 gives you patch and cue CSVs plus a profile build sheet. Cue values still need programming in Vista. It\'s a handoff, not a ready-to-fire show.', setting: 'File → Export → Vista 3', manualUrl: './manual/#vista-export', keywords: ['vista', 'export', 'csv', 'build sheet'] },
    { text: 'MA exports are cue sheets and import aids, not native show files. Budget a few minutes to program cues on the console.', setting: 'File → Export → grandMA', manualUrl: './manual/#ma-export', keywords: ['ma', 'export', 'show file'] },
    { level: 'pro', text: 'Patch export converts Wave Studio\'s zero-based port to Vista\'s one-based universe. If your numbers look off by one, that\'s why.', manualUrl: './manual/#universe-offset', keywords: ['zero-based', 'one-based', 'offset'] },
    { level: 'pro', text: 'The build sheet proposes Angle as Position/Tilt over 210° and Program as a Gobo Wheel with 88 slots. Use it to author the fixture profile inside Vista.', manualUrl: './manual/#build-sheet', keywords: ['profile', 'gobo', 'tilt', 'build sheet'] },
  ],
  record: [
    { text: 'Recordings are MP4 or WebM without audio and stay in this tab until you download them. Don\'t close the tab before saving.', setting: 'Record → Download clip', manualUrl: './manual/#recording', keywords: ['record', 'clip', 'mp4', 'webm'] },
    { text: 'Every clip gets the small logo and build watermark bottom-left. Captions are optional.', setting: 'Record → Captions', manualUrl: './manual/#watermark', keywords: ['watermark', 'caption'] },
    { level: 'pro', text: 'Turn on the timestamped log when you record. You get a text file that lines up with the clip, which makes notes for the console programmer painless.', setting: 'Record → Timestamped log', manualUrl: './manual/#record-log', keywords: ['log', 'timestamp'] },
  ],
  workspace: [
    { text: 'Customize Workspace drops a revert checkpoint when you enter it. Go wild. You can always get back.', setting: 'View → Customize Workspace → Revert', manualUrl: './manual/#customize', keywords: ['customize', 'revert', 'checkpoint', 'panel'] },
    { text: 'Panels float, dock and duplicate. You can push up to three companion windows to other monitors and they stay in sync.', setting: 'Panel header → ⋯ → Duplicate / Pop out', manualUrl: './manual/#companion', keywords: ['companion', 'window', 'dock', 'float'] },
    { text: 'On a phone, long-press a panel to place it. No keyboard modifiers needed.', manualUrl: './manual/#mobile', keywords: ['mobile', 'long press'] },
    { level: 'pro', text: 'Named Customized Layouts are kept separately for desktop, mobile and full-screen view. Save one per situation and they won\'t fight each other.', setting: 'Customize Workspace → Save layout as…', manualUrl: './manual/#named-layouts', keywords: ['named layout', 'full screen', 'desktop', 'mobile'] },
    { level: 'pro', text: 'Shared-width rows let a group of buttons split a row evenly. Great for a flash bank that always needs to line up.', setting: 'Customize Workspace → Row → Shared width', manualUrl: './manual/#shared-width', keywords: ['shared width', 'row'] },
  ],
  save: [
    { text: 'Save As lets you name the file and pick a destination. Autosave is separate and won\'t overwrite your named saves.', setting: 'File → Save As', manualUrl: './manual/#save', keywords: ['save', 'autosave', 'filename'] },
    { text: 'Download Workspace JSON includes panels, buttons and notes, but not your named-layout library or checkpoints. Keep a backup of both.', manualUrl: './manual/#workspace-json', keywords: ['json', 'backup', 'download'] },
    { level: 'pro', text: 'Notes export as TXT, Markdown or printable HTML. The HTML one is the nicest thing to hand a stage manager.', setting: 'Notes → Export', manualUrl: './manual/#notes-export', keywords: ['notes', 'markdown', 'html', 'print'] },
  ],
  timecode: [
    { text: 'Internal timecode and external MIDI Time Code are supported. Audio LTC and network timecode aren\'t in this build.', setting: 'Timing → Timecode source', manualUrl: './manual/#timecode', keywords: ['timecode', 'mtc', 'ltc', 'midi'] },
    { level: 'pro', text: 'Arm only previews the chase against timecode. It won\'t trigger anything until you actually run it, so it\'s safe to leave armed while you tweak.', setting: 'Timing → Arm', manualUrl: './manual/#arm', keywords: ['arm', 'preview', 'chase'] },
  ],
  chat: [
    { text: 'Push To Talk is a plain on/off mic toggle, and listeners have to hit Join Call to hear you.', setting: 'Friends & Chat → Join Call', manualUrl: './manual/#chat', keywords: ['push to talk', 'chat', 'call', 'mic'] },
    { level: 'pro', text: 'Direct browser calls expose participants\' IP addresses to each other, like any peer-to-peer call. Worth knowing before you invite a stranger.', manualUrl: './manual/#chat-privacy', keywords: ['privacy', 'ip', 'peer'] },
  ],
  'info-mode': [
    { text: 'Press Ctrl + ? to enter information mode. Hover any control to see what it does. Clicking pins the help instead of operating the control.', setting: 'Ctrl + ? or the "?" button', manualUrl: './manual/#info-mode', keywords: ['information mode', 'info', 'ctrl', 'help'] },
  ],
  settings: [
    { text: 'Settings → Narration has 13 studio voices plus pace and pitch. Preview before you commit to one.', setting: 'Settings → Narration → Voice', manualUrl: './manual/#narration', keywords: ['voice', 'narration', 'read aloud', 'settings'] },
    { text: 'You can plug in your own AI provider under Settings → Assistant. Your key stays in this browser and takes priority over the site assistant.', setting: 'Settings → Assistant → Provider', manualUrl: './manual/#byo-ai', keywords: ['provider', 'api key', 'openai', 'perplexity', 'assistant'] },
    { level: 'pro', text: 'Narration can run studio-only or automatic. Automatic falls back to your device voice if the cloud is slow; studio-only waits for the good voice.', setting: 'Settings → Narration → Mode', manualUrl: './manual/#narration-mode', keywords: ['narration mode', 'fallback', 'device voice'] },
    { level: 'pro', text: 'You can rename me, mute me, or switch me to quiet mode right here. I won\'t take it personally.', setting: 'Settings → Guide', keywords: ['guide', 'avatar', 'quiet', 'mute'] },
  ],
  shortcuts: [
    { text: 'Space is Play/Pause for the current chase. Arrow keys step Previous and Next even when the controls are minimized.', setting: 'Keyboard → Space, ← →', manualUrl: './manual/#shortcuts', keywords: ['keyboard', 'shortcut', 'space', 'arrow'] },
    { level: 'pro', text: 'Hold Shift while dragging a fader to move every selected fader together. Hold Alt for the inverse.', setting: 'Keyboard → Shift / Alt + drag', manualUrl: './manual/#fader-shortcuts', keywords: ['shift', 'alt', 'drag', 'together'] },
  ],
};

window.WAVE_STUDIO_KNOWLEDGE = [
  { title: 'What Wave Studio is', keywords: ['what is', 'wave studio', 'about', 'overview'], answer: 'Wave Studio is Module 1 of Virtual SFX Lab: a reference and virtual rehearsal space for the Explo X2 Wave Flame. You arrange virtual units on a stage, build cues with faders and flash buttons, and rehearse looks. It visualizes; it never fires real hardware.', manualUrl: './manual/#overview' },
  { title: 'Physical output', keywords: ['physical', 'real', 'fire', 'output', 'dmx out', 'hardware', 'ignite', 'burn'], answer: 'Nothing in Wave Studio transmits to physical fixtures. Virtual DMX fields and console mappings are for rehearsal only, so there is no live-effects safety claim here. Physical Art-Net or sACN output is a roadmap item, not a current feature.', manualUrl: './manual/#safety' },
  { title: 'Desktop vs hosted', keywords: ['desktop', 'windows', 'mac', 'macos', 'offline', 'download', 'hosted', 'install'], answer: 'The hosted studio has the full AI Assist and cloud narration. Desktop 0.33.0 (Windows signed, macOS Python launcher) ships the same UI but uses manual search, your own AI provider and device speech instead of hosted endpoints.', manualUrl: './manual/#editions' },
  { title: 'Receiver and Vista Check', keywords: ['receiver', 'vista check', 'datagram', 'udp', 'port'], answer: 'The local receiver listens for sACN. If Vista Check reports zero datagrams, make sure the receiver is closed first so the UDP port is free, then confirm Vista is sending unicast to this machine.', manualUrl: './manual/#receiver' },
  { title: 'Tester access and pricing', keywords: ['tester', 'beta', 'code', 'price', 'cost', 'pricing', 'buy', 'licence', 'license', 'refund', 'discord'], answer: 'Testers with an owner-issued code get the full studio and downloads free until 1.0. Paid browser, Windows and macOS editions are planned at CAD $29.99 one-time, with a 14-day refund window. Beta applications go through a Discord DM.', manualUrl: './manual/#access' },
  { title: 'X2 channels', keywords: ['channel', 'channels', 'dmx map', 'footprint', 'six', 'program', 'ignition', 'arm'], answer: 'The virtual X2 uses a six-channel footprint: angle, program, ignition, arm and two housekeeping channels. The build sheet proposes Angle as tilt over 210° and Program as an 88-slot wheel. Ignition and arm default to zero in every export.', manualUrl: './manual/#channels' },
  { title: 'Saving and backups', keywords: ['lost', 'lose', 'recover', 'restore', 'backup', 'where saved'], answer: 'Your workspace autosaves in this browser, named saves go wherever you pick in Save As, and Customize Workspace keeps a revert checkpoint. Download Workspace JSON for a portable backup. Named-layout libraries and checkpoints are stored separately, so back those up too.', manualUrl: './manual/#backups' },
  { title: 'Companion windows', keywords: ['second monitor', 'second screen', 'multi monitor', 'companion', 'pop out'], answer: 'Pop a panel out from its header menu to open a companion window. You can run up to three, and they stay synchronized with the main studio. Great for a stage view on one screen and faders on another.', manualUrl: './manual/#companion' },
];

window.WAVE_STUDIO_TOURS = {
  'first-look': {
    title: 'First look',
    steps: [
      { selector: '[data-tour="stage"]', context: 'stage', text: 'This is the stage. Six virtual X2 units, alternating inversion so the flames cross. Click a unit to select it, Shift-click for more.', setting: 'Stage → click / Shift-click', manualUrl: './manual/#selection' },
      { selector: '[data-tour="rotate"]', context: 'stage', text: 'With units selected, this rotates them around their bases in 5° steps. Rotation is saved into layouts and exports.', setting: 'Stage toolbar → Rotate 5°', manualUrl: './manual/#stage-rotation' },
      { selector: '[data-tour="faders"]', context: 'faders', text: 'Faders. Each runs in Cue mode or DMX mode, with its own label, universe and address. Addresses must be unique within a universe.', setting: 'Fader → ⋯ → Mode / Label / Address', manualUrl: './manual/#faders' },
      { selector: '[data-tour="flash"]', context: 'flash', text: 'Flash fires the fader at its master level. Give it a longer timing if you want a sustained burst.', setting: 'Flash → Timing', manualUrl: './manual/#flash' },
      { selector: '[data-tour="home"]', context: 'home', text: 'Home releases cues on the selected heads and turns virtual emission off. It greys out when the receiver owns Live Input. That\'s on purpose.', setting: 'Fixture → Home angle', manualUrl: './manual/#home' },
      { selector: '[data-tour="save"]', context: 'save', text: 'Save As names your layout and picks a destination. Autosave runs separately and never overwrites a named save.', setting: 'File → Save As', manualUrl: './manual/#save' },
      { text: 'That\'s the core loop: arrange, build cues, rehearse, save. Hover anything for a tip, or ask me if something looks weird.', mood: 'happy', gesture: 'thumbs' },
    ],
  },
  'console-hookup': {
    title: 'Console hookup',
    steps: [
      { selector: '[data-tour="live-input"]', context: 'live-input', text: 'Live Input listens to sACN from the local receiver. Start here when you want a real console to drive the virtual rig.', setting: 'Live Input → Enable', manualUrl: './manual/#live-input' },
      { selector: '[data-tour="live-input"]', context: 'live-input', text: 'Pick a receiver preset that matches your desk. grandMA2 and grandMA3 presets set Final or Draft sACN and unicast for you.', setting: 'Live Input → Preset → grandMA2 / grandMA3 / Vista', manualUrl: './manual/#ma-presets' },
      { selector: '[data-tour="faders"]', context: 'faders', text: 'Map each fader\'s universe and address to what the console sends. Incoming values are interpreted through these mappings.', setting: 'Fader → Universe / Address', manualUrl: './manual/#addressing' },
      { selector: '[data-tour="home"]', context: 'home', text: 'While Live Input is on, the receiver owns the faders and Home is disabled. Switch Live Input off to get manual control back.', setting: 'Live Input → Disable', manualUrl: './manual/#home' },
      { selector: '[data-tour="export"]', context: 'export', text: 'When the look is right, Export gives the console programmer cue sheets, patch CSVs and a profile build sheet. Cues still get programmed on the desk.', setting: 'File → Export → Vista 3 / grandMA', manualUrl: './manual/#vista-export' },
      { text: 'Reminder: all of this is receive-only. The studio never sends DMX to a fixture. Rehearse with confidence.', mood: 'chill', gesture: 'nod' },
    ],
  },
};
