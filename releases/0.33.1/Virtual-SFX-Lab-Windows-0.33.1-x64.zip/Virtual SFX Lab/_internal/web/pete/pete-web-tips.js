/* Pyro Pete — web tip pack and offline knowledge.
   Shared by the Pete introduction page (pete/index.html) and the Pyro Pete browser extension.
   No network calls: everything here is answered locally. */
(function (root) {
  'use strict';

  var HOME = 'https://virtualsfxlab.com/';

  var TIPS = {
    'pete-intro': [
      'I am Pete. I hang around the corner of the screen and explain things when you hover on them. Click me any time to ask a question.',
      { text: 'Hold me down for a moment and drag: I go wherever you drop me, and I remember the spot.', level: 'pro' }
    ],
    'pete-skills': [
      'Hover any button in Spark Studio and I explain it before you press it. I never repeat the same tip twice in a row.',
      'During a mission I walk over and point at the control you need next, then walk back when you are done.'
    ],
    'pete-spark': [
      'Spark Studio is where I do my best work: six virtual flames, four faders, cues, GO and seven missions. Nothing in it is real fire.',
      { text: 'Finish missions to earn XP. The Classroom button has a teacher tab with reset and progress export.', level: 'pro' }
    ],
    'pete-extension': [
      'The browser extension puts me on any web page. Click the Pete icon in the toolbar to call me, click it again to send me away.',
      'The extension is a developer preview. Install it unpacked from the Extensions page with Developer mode on.',
      { text: 'In the extension my settings and any API key you add live in the extension storage, not in the page, so websites cannot read them.', level: 'pro' }
    ],
    'pete-wave': [
      'Wave Studio is the full Virtual SFX Lab studio for the Explo X2 Wave Flame: cue stacks, virtual faders, sACN and Art-Net receive, grandMA tools.',
      { text: 'Start with the free demo on the landing page; the studio itself is in open beta and runs in your browser.', level: 'pro' }
    ],
    'pete-demo': [
      'The developer demo shows the director console: every command you can send me as JSON, from say and point to tours and moods.'
    ]
  };

  var KNOWLEDGE = [
    { keywords: ['settings', 'size', 'bigger', 'smaller', 'resize', 'api key', 'api', 'connect', 'provider', 'openai', 'perplexity', 'gemini', 'claude', 'voice speed', 'move to the left', 'other corner'], title: 'Pete settings',
      answer: 'Hover over me and press the gear in my little toolbar. My settings have six tabs. Look: size from tiny to huge, corner, speech bubble beside me or above my head, Always on top (off lets me tuck in behind a panel you drop me on), eye tracking, pick up and move, and whether I walk to things and how fast. Voice: read aloud, speed, pitch, device voice, voice source (the studio voice on this site, your device voice, or your own ElevenLabs voice with a key and voice ID) and sound effects. Behavior: mood, humor, greeting, idle remarks and how often, how long my bubble stays open, and whether I remember you. Tips: hover tips with their delay, spacing and level, plus the tips I recite. Gestures: every move I can make with a Play button, and a tick to allow each one as an idle fidget; silly humor off is classroom-safe. AI: connect your own provider such as Perplexity, OpenAI, Anthropic, Gemini or an OpenAI-compatible server, paste your API key, press Test connection, and I can answer anything, not just my notes. The key stays in your browser and is sent only to that provider.' },
    { keywords: ['who are you', 'what are you', 'pete', 'pyro pete', 'your name'], title: 'About Pete',
      answer: 'I am Pyro Pete, the Virtual SFX Lab tutorial guide. I explain controls when you hover them, answer questions, give tours and point at what to press next. I am a cartoon, I live in your browser, and nothing I do involves real fire.' },
    { keywords: ['what can you do', 'help', 'how do you work', 'features'], title: 'What Pete does',
      answer: 'Hover a control and I chime in with a tip. Click me to ask something. In Spark Studio I run missions and walk over to point at controls. Drag me anywhere, mute me with the speaker button, hide me with the dash.' },
    { keywords: ['spark studio', 'spark', 'learning edition', 'missions', 'xp'], title: 'Spark Studio',
      answer: 'Spark Studio is the Virtual SFX Lab learning edition for early teens and classrooms: six virtual flames, Height, Angle, Program and Master faders, eight cues with GO and fade time, DMX addresses and universes, timing to music, seven missions with XP, and a workspace you can rearrange. It runs free in the browser.',
      manualUrl: HOME + 'spark/index.html' },
    { keywords: ['fader', 'faders', 'what is a fader'], title: 'Faders',
      answer: 'A fader is a slider that sets one value from 0 to 100 percent. On a lighting or effects console each fader usually controls one parameter, such as height or master intensity. In Spark Studio you can grab the Height fader and watch the flame answer.' },
    { keywords: ['cue', 'cues', 'go button', 'cue list'], title: 'Cues and GO',
      answer: 'A cue is a saved look: every fader value stored under a number. Pressing GO plays the next cue, fading from the current values over the fade time. Shows are usually a list of cues played in order.' },
    { keywords: ['dmx', 'address', 'addresses', 'universe', 'universes', 'channel'], title: 'DMX addresses and universes',
      answer: 'DMX sends 512 channels of 0 to 255 values down one line, called a universe. Each fixture listens from its start address. Two fixtures with overlapping channels will fight, which is what the Patch mission in Spark Studio teaches you to spot.' },
    { keywords: ['wave studio', 'virtual sfx lab', 'explo', 'x2', 'wave flame'], title: 'Wave Studio',
      answer: 'Wave Studio is Module 1 of Virtual SFX Lab: a virtual rehearsal studio for the Explo X2 Wave Flame with cue stacks, virtual faders, receive-only sACN and Art-Net input from Vista 3 or grandMA, and a free interactive demo on the landing page.',
      manualUrl: HOME + 'welcome.html' },
    { keywords: ['extension', 'install', 'download', 'browser', 'chrome', 'edge', 'brave', 'comet'], title: 'Pyro Pete extension',
      answer: 'Download the Pyro Pete extension ZIP from my page, extract it, open your browser Extensions page, turn on Developer mode, choose Load unpacked and select the folder with manifest.json. Then click the Pete icon on any page to call me.',
      manualUrl: HOME + 'pete/index.html#extension' },
    { keywords: ['safe', 'real fire', 'dangerous', 'fireworks', 'pyrotechnics'], title: 'Safety',
      answer: 'Everything in Virtual SFX Lab and Spark Studio is a simulation. Real pyrotechnics and flame effects are only operated by trained, licensed professionals under local regulations. Learning the controls here is the safe part.' },
    { keywords: ['teacher', 'classroom', 'class', 'students', 'reset', 'export'], title: 'Classroom mode',
      answer: 'In Spark Studio, Classroom holds student profiles, a PIN-protected Teacher tab, per-student or whole-class reset, a progress CSV export and a class backup you can import again.',
      manualUrl: HOME + 'spark/index.html' },
    { keywords: ['privacy', 'data', 'track', 'tracking', 'store'], title: 'Privacy',
      answer: 'I remember a few things in this browser only: how many times we have met, which tips you have seen, and whether you muted me. Nothing is sent anywhere. The extension has no server and asks for no account.' }
  ];

  var TOURS = {
    'meet-pete': {
      title: 'Meet Pete',
      steps: [
        { selector: '#what-pete-does', context: 'pete-skills', text: 'This is what I do: tips on hover, answers on click, tours and pointing.' },
        { selector: '#spark', context: 'pete-spark', text: 'Spark Studio is my home. Open it in the browser and I will meet you there.' },
        { selector: '#extension', context: 'pete-extension', text: 'Want me on other pages too? The extension puts me in your browser toolbar.' },
        { selector: '#developers', context: 'pete-demo', text: 'Builders: the demo page and the JSON command API live here.' }
      ]
    }
  };

  root.PETE_WEB_TIPS = TIPS;
  root.PETE_WEB_KNOWLEDGE = KNOWLEDGE;
  root.PETE_WEB_TOURS = TOURS;
})(typeof window !== 'undefined' ? window : this);
