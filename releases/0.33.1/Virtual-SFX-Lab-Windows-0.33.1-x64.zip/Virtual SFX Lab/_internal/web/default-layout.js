import {DEFAULT_SEED} from './default-seed.js?v=v0340-20261007f';
// Shared fresh-session layout. Saved layouts are never overwritten by defaults.
export function createDefaultFixtures(presetId){
 return structuredClone(DEFAULT_SEED.fixtures).map(f=>({...f,...(presetId===undefined?{}:{presetId})}));
}
export function createDefaultStage(){
 return {fixtures:createDefaultFixtures(),sceneScale:DEFAULT_SEED.sceneScale,zoom:DEFAULT_SEED.view.zoom,panX:DEFAULT_SEED.view.panX,panY:DEFAULT_SEED.view.panY,selectedId:DEFAULT_SEED.selectedId,selectedIds:[...DEFAULT_SEED.selectedIds],layoutLocked:DEFAULT_SEED.layoutLocked,nextId:Math.max(...DEFAULT_SEED.fixtures.map(f=>f.id))+1};
}
