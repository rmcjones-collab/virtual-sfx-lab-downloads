import {aiConfig,aiLabel,askAI,PROVIDERS} from './ai-connect.js?v=v0340-20261007f';
// AI Build: the user's own connected AI writes a small app that runs inside this panel.
// Isolation: the markup renders in a sandboxed opaque-origin frame that can only run the static
// bridge script (the studio CSP is inherited, so inline scripts and handlers never run); the app's
// script runs in a dedicated worker whose network, storage and nested-worker APIs are removed before
// the app code starts. Source and app data stay in this browser (localStorage), never on the server.
const BRIDGE=new URL('./ai-build-bridge.js?v=v0340-20261007f',import.meta.url).href;
const SOURCE_LIMIT=200000,DATA_LIMIT=64000;
const COMMANDS={play:'play',next:'next',previous:'prev',start:'cue-start',end:'cue-end',restart:'restart',release:'bank-release'};
const SYSTEM=`You build small single-panel web apps for the AI Build panel inside Virtual SFX Lab's Wave Studio (a flame-effect visualizer; nothing you write can operate real equipment).
Reply with exactly three fenced code blocks in this order and nothing else: \`\`\`html, \`\`\`css, \`\`\`js.
HTML: body markup only. No <script>, no inline on* handlers, no <form> submission, no external URLs, images or fonts. Give interactive elements ids or classes.
CSS: plain CSS for that markup. Dark theme: background #111315, text #e8e6e1, accent #f07a22, system-ui font. The app must fit and scroll within its panel (width 100%).
JS: runs in a Web Worker. There is NO document, window, DOM, fetch, XMLHttpRequest, WebSocket, localStorage, indexedDB or importScripts. setTimeout, setInterval, Math, Date, JSON and OffscreenCanvas work. Change the screen and read input only through these globals:
ui.on(selector, eventType, handler) — eventType: click, dblclick, input, change, keydown, keyup, pointerdown, pointerup, pointermove, focus, blur, wheel. handler(e) gets {type, id, dataset, value, checked, text, index, key, shift, alt, ctrl, x, y, width, height, buttons, deltaX, deltaY}. Listeners are delegated, so they also match elements created later.
ui.text(selector, text); ui.html(selector, markup); ui.append(selector, markup); ui.attr(selector, name, valueOrNull); ui.style(selector, cssProperty, value); ui.toggle(selector, className, force); ui.value(selector, valueOrChecked); ui.remove(selector); ui.focus(selector). Each applies to every match.
const c = await ui.canvas(selector) — for a <canvas>; returns {ctx, width, height, dpr, present}. Draw with c.ctx (2D context, device pixels), then call c.present() to show the frame. For animation use setTimeout(loop, 16) and present each frame.
ui.size is {width, height} of the panel; ui.onResize(fn).
store.get(key), store.set(key, value) — small JSON saved in this browser for this panel (64 KB total).
await studio.state() → {playing, cue, preset, time, end, state, dmx}. studio.run(command) — command is one of: play (toggles play/pause), next, previous, start, end, restart, release.
Keep the app focused and under 400 lines in total. Use Title Case for UI labels. No emojis.`;
const parse=text=>{
 const block=lang=>{const m=text.match(new RegExp('```'+lang+'[^\\n]*\\n([\\s\\S]*?)```','i'));return m?m[1].trim():''};
 const out={html:block('html'),css:block('css'),js:block('(?:js|javascript)')};
 if(!out.html&&!out.js)throw Error('The AI reply did not contain the html, css and js code blocks. Try again or rephrase the request.');
 return out;
};
const PRELUDE=`'use strict';
const __send=self.postMessage.bind(self),__listeners=new Map(),__canvas=new Map(),__resize=[];let __ops=[],__seq=0,__queued=false,__store={},__pending=new Map();
const __flush=()=>{__queued=false;if(__ops.length){__send({type:'ops',ops:__ops});__ops=[]}};
const __op=o=>{__ops.push(o);if(!__queued){__queued=true;queueMicrotask(__flush)}};
for(const k of ['fetch','XMLHttpRequest','WebSocket','EventSource','WebTransport','importScripts','indexedDB','caches','BroadcastChannel','Worker','SharedWorker','RTCPeerConnection','WebSocketStream','Notification','navigator']){
 for(let o=self;o;o=Object.getPrototypeOf(o)){try{if(Object.prototype.hasOwnProperty.call(o,k))delete o[k]}catch{}try{if(Object.prototype.hasOwnProperty.call(o,k))Object.defineProperty(o,k,{value:undefined,writable:false,configurable:false})}catch{}}
 try{Object.defineProperty(self,k,{value:undefined,writable:false,configurable:false})}catch{}
}
self.ui=Object.freeze({
 on(sel,event,fn){if(typeof fn!=='function')return;const id=++__seq;__listeners.set(id,fn);__flush();__send({type:'listen',id,sel:String(sel),event:String(event)})},
 text:(sel,value)=>__op({op:'text',sel:String(sel),value:String(value??'')}),
 html:(sel,value)=>__op({op:'html',sel:String(sel),value:String(value??'')}),
 append:(sel,value)=>__op({op:'append',sel:String(sel),value:String(value??'')}),
 attr:(sel,name,value)=>__op({op:'attr',sel:String(sel),name:String(name),value:value===null||value===false?null:String(value)}),
 style:(sel,name,value)=>__op({op:'style',sel:String(sel),name:String(name),value:String(value??'')}),
 toggle:(sel,name,force)=>__op({op:'toggle',sel:String(sel),name:String(name),force}),
 value:(sel,value)=>__op({op:'value',sel:String(sel),value:typeof value==='boolean'?value:String(value??'')}),
 remove:sel=>__op({op:'remove',sel:String(sel)}),
 focus:sel=>__op({op:'focus',sel:String(sel)}),
 canvas(sel){sel=String(sel);if(__canvas.has(sel))return __canvas.get(sel).promise;const req=++__seq;let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b});__canvas.set(sel,{promise});__pending.set(req,{resolve:info=>{const canvas=new OffscreenCanvas(info.width,info.height),ctx=canvas.getContext('2d');resolve({canvas,ctx,width:info.width,height:info.height,dpr:info.dpr,present(){__flush();const bitmap=canvas.transferToImageBitmap();__send({type:'frame',sel,bitmap},[bitmap])}})},reject});__flush();__send({type:'canvas',req,sel});return promise},
 size:{width:0,height:0},
 onResize(fn){if(typeof fn==='function')__resize.push(fn)}
});
self.store=Object.freeze({get:k=>__store[String(k)],set(k,v){__store[String(k)]=v===undefined?null:JSON.parse(JSON.stringify(v));__send({type:'store',data:__store})},all:()=>JSON.parse(JSON.stringify(__store))});
self.studio=Object.freeze({run:command=>__send({type:'run',command:String(command)}),state(){const req=++__seq;return new Promise((resolve,reject)=>{__pending.set(req,{resolve,reject});__send({type:'state',req})})}});
self.addEventListener('message',e=>{const m=e.data||{};
 if(m.type==='event'){const fn=__listeners.get(m.id);if(fn)try{fn(m.data)}catch(err){__send({type:'error',message:String(err&&err.stack||err)})}__flush()}
 else if(m.type==='reply'){const p=__pending.get(m.req);if(p){__pending.delete(m.req);m.error?p.reject(new Error(m.error)):p.resolve(m.value)}}
 else if(m.type==='resize'){ui.size.width=m.width;ui.size.height=m.height;for(const fn of __resize)try{fn(ui.size)}catch{}}
});
self.addEventListener('error',e=>__send({type:'error',message:String(e.message||'Script error')+(e.lineno?' (line '+(e.lineno-__PRELUDE_LINES__)+')':'')}));
self.addEventListener('unhandledrejection',e=>__send({type:'error',message:String(e.reason&&e.reason.message||e.reason)}));
`;
const PRELUDE_LINES=PRELUDE.split('\n').length+1;
// Markup is parsed inert in a template and stripped of active or navigating elements before it is framed.
function cleanMarkup(html){
 const t=document.createElement('template');t.innerHTML=String(html||'');
 for(const n of t.content.querySelectorAll('script,iframe,frame,object,embed,base,meta,link,form,portal'))n.remove();
 for(const n of t.content.querySelectorAll('*'))for(const a of [...n.attributes])if(/^on/i.test(a.name)||/^(srcdoc|formaction|action|xlink:href|ping)$/i.test(a.name)||(/^(href|src|poster|background)$/i.test(a.name)&&!/^(#|data:image\/)/i.test(a.value.trim())))n.removeAttribute(a.name);
 return t.innerHTML;
}
function frameDoc({html,css}){
 const safeCSS=String(css||'').replace(/<\/style/gi,'<\\/style').replace(/@import[^;]*;?/gi,'').replace(/url\(\s*['"]?\s*(https?:|\/\/)[^)]*\)/gi,'none');
 return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src ${new URL(BRIDGE).origin}; worker-src blob:; style-src 'unsafe-inline'; img-src data: blob:; font-src data:"><style>html,body{margin:0;background:#111315;color:#e8e6e1;font:14px/1.4 system-ui,sans-serif}body{padding:10px;box-sizing:border-box}*{box-sizing:inherit}button{font:inherit}</style><style>${safeCSS}</style></head><body>${cleanMarkup(html)}<script src="${BRIDGE}"></script></body></html>`;
}
export function createAiBuild({key}){
 const SKEY=`vsl-aibuild:${key}`,DKEY=`vsl-aibuild-data:${key}`;
 const el=document.createElement('section');el.className='ai-build';
 el.innerHTML=`<div class="aib-head"><span class="aib-status" data-aib-ai></span><button type="button" data-aib-connect>Connect Your AI</button></div>
<label class="aib-prompt-label">Describe What To Build<textarea data-aib-prompt rows="3" maxlength="4000" placeholder="For Example: A Countdown To Showtime With Big Digits And A Start Button"></textarea></label>
<div class="aib-actions"><button type="button" class="primary" data-aib-build>Build</button><button type="button" data-aib-revise>Revise</button><button type="button" data-aib-run>Restart App</button><button type="button" data-aib-stop>Stop App</button><details class="aib-more"><summary>More</summary><button type="button" data-aib-source>View Source</button><button type="button" data-aib-copy>Copy Source</button><button type="button" data-aib-reset-data>Clear App Data</button><button type="button" data-aib-clear>Remove App</button></details></div>
<p class="aib-message widget-hint" role="status" aria-live="polite"></p>
<div class="aib-stage"><p class="aib-empty widget-hint">Connect Your Own AI Provider (Your Key Stays In This Browser), Describe An App, And Choose Build. Apps Run Isolated: No Network, No Studio Data Beyond Play State.</p></div>
<pre class="aib-source" hidden></pre>`;
 const $=s=>el.querySelector(s),msg=$('.aib-message'),stage=$('.aib-stage'),prompt=$('[data-aib-prompt]');
 let app=null,worker=false,frame=null,busy=false,pending=null,errors=0;
 try{app=JSON.parse(localStorage.getItem(SKEY)||'null')}catch{app=null}
 if(app&&!(typeof app.html==='string'&&typeof app.css==='string'&&typeof app.js==='string'))app=null;
 if(app?.prompt)prompt.value=app.prompt;
 const say=(text,error=false)=>{msg.textContent=text;msg.classList.toggle('aib-error',error)};
 function status(){
  const cfg=aiConfig();$('[data-aib-ai]').textContent=cfg?.key?`Building With ${aiLabel()}`:'No AI Connected';
  $('[data-aib-connect]').textContent=cfg?.key?'Change AI':'Connect Your AI';
  for(const s of ['[data-aib-build]','[data-aib-revise]'])$(s).disabled=busy||!cfg?.key;
  $('[data-aib-revise]').disabled||=!app;
  for(const s of ['[data-aib-run]','[data-aib-source]','[data-aib-copy]','[data-aib-clear]','[data-aib-reset-data]'])$(s).disabled=!app;
  $('[data-aib-stop]').disabled=!worker;
 }
 function stop(){frame?.remove();frame=null;worker=false;pending=null;status()}
 function data(){try{return JSON.parse(localStorage.getItem(DKEY)||'{}')}catch{return {}}}
 function studioState(){const t=s=>document.querySelector(s)?.textContent?.trim()??'';return {playing:t('#play')==='Pause',cue:t('#cue-name'),preset:t('#preset-name'),time:t('#current-time'),end:t('#end-time'),state:t('#state-label'),dmx:t('#dmx-status')}}
 // The app worker is created inside the sandboxed frame (opaque origin, the frame's own
 // default-src 'none' policy), so the app has no network or same-origin access at all.
 function run(){
  stop();if(!app)return;errors=0;
  stage.querySelector('.aib-empty').hidden=true;
  frame=document.createElement('iframe');frame.className='aib-frame';frame.title='AI Build App';
  frame.setAttribute('sandbox','allow-scripts');frame.setAttribute('referrerpolicy','no-referrer');frame.setAttribute('allow',"camera 'none'; microphone 'none'; geolocation 'none'; midi 'none'; usb 'none'; serial 'none'; hid 'none'; clipboard-read 'none'");
  pending=[PRELUDE.replace('__PRELUDE_LINES__',String(PRELUDE_LINES)),`__store=JSON.parse(${JSON.stringify(JSON.stringify(data()))});`,'\n;(()=>{\n',app.js,'\n})();\n'].join('');
  frame.srcdoc=frameDoc(app);stage.append(frame);worker=true;
  status();
 }
 addEventListener('message',e=>{
  if(!frame||e.source!==frame.contentWindow)return;const m=e.data||{};
  if(m.type==='aib-ready'){if(pending!==null){frame.contentWindow.postMessage({type:'aib-start',code:pending},'*');pending=null}}
  else if(m.type==='aib-store'){let text='';try{text=JSON.stringify(m.data??{})}catch{return}if(text.length>DATA_LIMIT){say('App Data Is Over 64 KB And Was Not Saved.',true);return}try{localStorage.setItem(DKEY,text)}catch{say('App Data Could Not Be Saved In This Browser.',true)}}
  else if(m.type==='aib-run'){const id=Object.hasOwn(COMMANDS,m.command)?COMMANDS[m.command]:null;const b=id&&document.getElementById(id);if(b&&!b.disabled&&!b.closest('[inert]'))b.click()}
  else if(m.type==='aib-state')frame.contentWindow.postMessage({type:'aib-reply',req:m.req,value:studioState()},'*');
  else if(m.type==='aib-error'){if(++errors<=20)say(`App Error: ${String(m.message).slice(0,300)}`,true)}
 });
 async function build(revise){
  const request=prompt.value.trim();if(!request){say('Describe What To Build First.',true);prompt.focus();return}
  if(!aiConfig()?.key){openConnect();return}
  busy=true;status();say(revise?'Revising The App With Your AI…':'Building The App With Your AI…');
  const context=revise&&app?`Here is the current app. Apply the requested change and return the complete updated app.\n\n\`\`\`html\n${app.html}\n\`\`\`\n\n\`\`\`css\n${app.css}\n\`\`\`\n\n\`\`\`js\n${app.js}\n\`\`\``:'';
  try{
   const r=await askAI(`${revise?'Requested change':'Build this app'}: ${request}`,context,{system:SYSTEM,maxTokens:8000,timeout:180000,search:false,siteFallback:false});
   const next=parse(r.text||'');
   const size=next.html.length+next.css.length+next.js.length;if(size>SOURCE_LIMIT)throw Error('The App Is Larger Than 200 KB. Ask For A Smaller Version.');
   app={...next,prompt:request,provider:aiConfig()?.provider,saved:new Date().toISOString()};
   try{localStorage.setItem(SKEY,JSON.stringify(app))}catch{say('Built, But This Browser Could Not Save The App.',true)}
   run();say(revise?'App Updated.':'App Built. It Is Saved In This Browser For This Panel.');
  }catch(e){say(String(e.message||e).slice(0,400),true)}
  finally{busy=false;status()}
 }
 function openConnect(){
  document.getElementById('wave-guide-open')?.click();
  setTimeout(()=>{const s=document.getElementById('ai-connect-summary');const d=s?.closest('details');if(d)d.open=true;(document.getElementById('ai-provider')??s)?.scrollIntoView({block:'center'});document.getElementById('ai-provider')?.focus()},150);
  say(`Choose A Provider (${Object.values(PROVIDERS).map(p=>p.name.replace(/ \(.*\)/,'')).join(', ')}) And Paste Your Own Key In AI Assist. It Stays In This Browser.`);
 }
 $('[data-aib-connect]').onclick=openConnect;
 $('[data-aib-build]').onclick=()=>build(false);
 $('[data-aib-revise]').onclick=()=>build(true);
 $('[data-aib-run]').onclick=()=>{run();say('App Restarted.')};
 $('[data-aib-stop]').onclick=()=>{stop();stage.querySelector('.aib-empty').hidden=false;say('App Stopped. Restart App Runs It Again.')};
 $('[data-aib-source]').onclick=()=>{const pre=$('.aib-source');pre.hidden=!pre.hidden;pre.textContent=pre.hidden?'':`<!-- HTML -->\n${app.html}\n\n/* CSS */\n${app.css}\n\n// JS (runs in an isolated worker)\n${app.js}`;$('[data-aib-source]').textContent=pre.hidden?'View Source':'Hide Source'};
 $('[data-aib-copy]').onclick=async()=>{try{await navigator.clipboard.writeText(`<!-- HTML -->\n${app.html}\n\n/* CSS */\n${app.css}\n\n// JS\n${app.js}`);say('Source Copied.')}catch{say('This Browser Blocked Copying. Use View Source.',true)}};
 $('[data-aib-reset-data]').onclick=()=>{if(!confirm('Clear The Data This App Saved?'))return;localStorage.removeItem(DKEY);run();say('App Data Cleared.')};
 $('[data-aib-clear]').onclick=()=>{if(!confirm('Remove This App From The Panel? The Prompt Stays.'))return;stop();localStorage.removeItem(SKEY);localStorage.removeItem(DKEY);app=null;stage.querySelector('.aib-empty').hidden=false;$('.aib-source').hidden=true;say('App Removed.');status()};
 for(const n of [el])n.addEventListener('keydown',e=>{if(e.target.matches('textarea,input'))e.stopPropagation()});
 el.addEventListener('pointerdown',e=>{if(e.target.matches('textarea,input'))e.stopPropagation()});
 document.addEventListener('wave-ai-changed',status);
 addEventListener('pagehide',()=>{if(worker)stop()});
 let started=false;
 return {el,render(){status();if(app&&!started&&el.isConnected){started=true;run()}},tick(){if(!started&&app&&el.isConnected&&el.getClientRects().length){started=true;run()}}};
}
