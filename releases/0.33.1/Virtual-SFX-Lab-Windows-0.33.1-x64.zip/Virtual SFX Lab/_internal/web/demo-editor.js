import {presets,sample} from './presets.js?v=v0340-20261007f';
import {drawFlameJet,drawFlamerBody} from './flame-visuals.js?v=v0340-20261007f';
import {createDefaultFixtures} from './default-layout.js?v=v0340-20261007f';
import {groupTranslation} from './layout-tools.js?v=v0340-20261007f';
import {FuelLedger} from './fuel-model.js?v=v0340-20261007f';
import {mountFuelUI} from './fuel-ui.js?v=v0340-20261007f';
import {mountMobileSequencePicker} from './mobile-sequence-picker.js?v=v0340-20261007f';
import {mountDemoRecorder} from './demo-recorder.js?v=v0340-20261007f';
import {describeSequences} from './sequence-caption.js?v=v0340-20261007f';

export function mountDemoEditor(){
 const $=s=>document.querySelector(s),root=$('#demo-editor'),stage=$('#demo-stage');
 const canvas=$('#hero-stage'),ctx=canvas.getContext('2d'),motion=$('#motion');
 const reduced=matchMedia('(prefers-reduced-motion: reduce)');
 const fuel=new FuelLedger();let fuelUI=null,sequencePicker=null;
 const freshDemo=()=>createDefaultFixtures().map((f,i,a)=>({...f,x:.08+i*.84/Math.max(1,a.length-1),y:.63,presetId:1,elapsed:0}));
 let fixtures=freshDemo(),selected=fixtures.map(f=>f.id),active=fixtures.at(-1).id,nextId=Math.max(...selected)+1,quickLook='';
 let playing=!reduced.matches,last=0,visible=true,multi=false,gesture=null,W=600,H=340,dpr=1,zoom=1;
 const history=[],pad=n=>String(n).padStart(3,'0'),selectedUnits=()=>fixtures.filter(f=>selected.includes(f.id));
 const announce=text=>$('#demo-status').textContent=text;
 const positions=()=>selectedUnits().map(({id,x,y})=>({id,x,y}));
 const snapshot=()=>({fixtures:structuredClone(fixtures),selected:[...selected],active,nextId,quickLook});
 const remember=()=>{const saved=snapshot();history.push(saved);if(history.length>40)history.shift();return saved};
 const place=rows=>rows.forEach(p=>Object.assign(fixtures.find(f=>f.id===p.id),{x:p.x,y:p.y}));
 const geometry=f=>({x:W/2+(28+f.x*(W-56)-W/2)*zoom,y:H/2+(H*.1+f.y*H*.88-H/2)*zoom});
 const zoomTools=document.createElement('label');zoomTools.className='demo-zoom';zoomTools.innerHTML='<span>Zoom</span><input id="demo-zoom" type="range" min="10" max="250" step="1" value="100" aria-label="Demo Layout Zoom"><output id="demo-zoom-value">100%</output><button type="button" id="demo-zoom-reset">Reset Zoom</button>';root.querySelector('.demo-under-layout').append(zoomTools);
 $('#demo-zoom').oninput=e=>{finishGesture(true);zoom=Math.max(.0001,Number(e.target.value)/100);$('#demo-zoom-value').textContent=e.target.value+'%';draw()};
 $('#demo-zoom-reset').onclick=()=>{$('#demo-zoom').value='100';$('#demo-zoom').dispatchEvent(new Event('input'))};
 const point=e=>{const r=stage.getBoundingClientRect();return{x:e.clientX-r.left,y:e.clientY-r.top}};
 function syncMotion(){motion.textContent=playing?'Pause':'Play';motion.setAttribute('aria-label',playing?'Pause Demo Animation':'Play Demo Animation');motion.setAttribute('aria-pressed',String(!playing))}
 function update(){
  selected=selected.filter(id=>fixtures.some(f=>f.id===id));
  if(!fixtures.some(f=>f.id===active))active=fixtures[0].id;
  const group=selectedUnits();
  $('#demo-unit-count').textContent=`${fixtures.length} UNITS / INTERACTIVE DEMO`;
  $('#demo-selected-count').textContent=`${selected.length} selected`;
  $('#demo-add').disabled=fixtures.length>=40;
  $('#demo-remove').disabled=!group.length||fixtures.length===1;
  $('#demo-invert').disabled=!group.length;
  $('#demo-invert').setAttribute('aria-pressed',group.length&&group.every(f=>f.inverted)?'true':group.some(f=>f.inverted)?'mixed':'false');
  $('#demo-undo').disabled=!history.length;
  root.querySelectorAll('[data-demo-look]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.demoLook===quickLook)));
  const select=$('#demo-sequence');select.disabled=!group.length;
  select.value=group.length&&group.every(f=>f.presetId===group[0].presetId)?String(group[0].presetId):'';
  sequencePicker?.sync();
  const layer=$('#demo-handles');
  layer.querySelectorAll('button').forEach(b=>{if(!fixtures.some(f=>f.id===+b.dataset.demoFixture))b.remove()});
  for(const f of fixtures){
   let button=layer.querySelector(`[data-demo-fixture="${f.id}"]`);
   if(!button){
    button=document.createElement('button');button.type='button';button.dataset.demoFixture=f.id;button.className='demo-fixture';layer.append(button);
    button.onclick=e=>{if(e.detail===0)selectFixture(f.id,multi||e.ctrlKey||e.metaKey||e.shiftKey)};
    button.onkeydown=e=>{
     if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key))return;
     e.preventDefault();e.stopPropagation();
     if(!selected.includes(f.id))selectFixture(f.id,false);
     remember();const step=e.shiftKey?.05:.01;
     place(groupTranslation(positions(),e.key==='ArrowLeft'?-step:e.key==='ArrowRight'?step:0,e.key==='ArrowUp'?-step:e.key==='ArrowDown'?step:0,{unbounded:true}));
     update();announce('Selected fixtures moved. Undo restores the group.');
    };
   }
   button.setAttribute('aria-label',`Fixture ${f.id}, sequence ${pad(f.presetId)}, invert ${f.inverted?'on':'off'}. Drag to move; arrow keys nudge.`);
   button.setAttribute('aria-pressed',String(selected.includes(f.id)));
   button.style.zIndex=selected.includes(f.id)?f.id===active?'3':'2':'1';
  }
  draw();
 }
 function selectFixture(id,toggle){
  selected=toggle?(selected.includes(id)?selected.filter(n=>n!==id):[...selected,id]):[id];
  active=id;update();announce(`${selected.length} selected. Invert and sequence changes apply to this selection.`);
 }
 const seq=$('#demo-sequence'),mixed=document.createElement('option');mixed.value='';mixed.textContent='Select fixtures / mixed sequences';mixed.disabled=true;seq.append(mixed);
 presets.filter(p=>p.id<=70).forEach(p=>{const o=document.createElement('option');o.value=p.id;o.textContent=`${pad(p.id)} · ${p.name}`;seq.append(o)});
 sequencePicker=mountMobileSequencePicker(seq);
 seq.onchange=()=>{
  const id=Number(seq.value);if(!selected.length||!Number.isInteger(id)||id<1||id>70)return;
  remember();quickLook='';selectedUnits().forEach(f=>{f.presetId=id;f.elapsed=0});
  $('#demo-tour').checked=false;update();announce(`Sequence ${pad(id)} applied to ${selected.length} selected unit(s). Auto-next is off so this sequence repeats.`);
 };
 $('#demo-invert').onclick=()=>{
  if(!selected.length)return;remember();const inverted=!selectedUnits().every(f=>f.inverted);
  selectedUnits().forEach(f=>f.inverted=inverted);update();announce(`Invert ${inverted?'on':'off'} for ${selected.length} selected unit(s).`);
 };
 $('#demo-add').onclick=()=>{
  if(fixtures.length>=40)return;remember();
  const source=fixtures.find(f=>f.id===active)||fixtures[0];
  const candidates=[.75,.48,.23].flatMap(y=>[.5,.18,.82,.04,.96,.34,.66].map(x=>({x,y})));
  const p=candidates.find(p=>fixtures.every(f=>Math.hypot(f.x-p.x,f.y-p.y)>.12))||{x:.5,y:.35};
  const id=nextId++;fixtures.push({...source,...p,id,inverted:id%2===1,elapsed:0});
  fuel.reset(id);
  selected=[id];active=id;update();announce(`Fixture ${id} added. Existing positions are unchanged.`);
 };
 function remove(){
  if(!selected.length||fixtures.length===1)return;
  finishGesture(true);remember();
  const keep=selected.length===fixtures.length?(selected.includes(active)?active:selected[0]):null;
  const removeIds=selected.filter(id=>id!==keep);
  fixtures=fixtures.filter(f=>!removeIds.includes(f.id));
  active=keep||fixtures[0].id;selected=[active];update();
  announce(`${removeIds.length} fixture(s) removed.${keep?' Kept one fixture on stage.':''} Undo restores them.`);
 }
 $('#demo-remove').onclick=remove;
 $('#demo-select-all').onclick=()=>{selected=fixtures.map(f=>f.id);update();announce(`All ${fixtures.length} fixtures selected.`)};
 $('#demo-multiselect').onclick=()=>{multi=!multi;$('#demo-multiselect').setAttribute('aria-pressed',String(multi));announce(multi?'Multi-select on. Tap fixtures to add or remove them from the selection.':'Multi-select off. Tap one fixture to select it.')};
 $('#demo-undo').onclick=()=>{
  finishGesture(true);const saved=history.pop();if(!saved)return;
  ({fixtures,selected,active,nextId,quickLook}=saved);update();announce('Last demo edit undone.');
 };
 motion.onclick=()=>{playing=!playing;syncMotion()};
 for(const button of root.querySelectorAll('[data-demo-look]'))button.onclick=()=>{
  finishGesture(true);remember();quickLook=button.dataset.demoLook;
  fixtures.forEach((f,i)=>{f.presetId=quickLook==='wave'?51:quickLook==='burst'?23:23+Math.round((i/Math.max(1,fixtures.length-1)-.5)*6)*(f.inverted?-1:1);f.elapsed=.12});
  selected=fixtures.map(f=>f.id);$('#demo-tour').checked=false;playing=true;syncMotion();update();announce(`${button.textContent} Applied To The Entire Stage. Drag A Unit To Rearrange.`);
 };
 $('#demo-reset').onclick=()=>{
  finishGesture(true);remember();fixtures=freshDemo();selected=fixtures.map(f=>f.id);active=fixtures.at(-1).id;nextId=Math.max(...selected)+1;quickLook='';
  zoom=1;$('#demo-zoom').value='100';$('#demo-zoom-value').textContent='100%';$('#demo-tour').checked=true;update();announce('Six-Unit Demo Restored With Auto-Next. Undo Returns To Your Previous Layout.');
 };
 let expanded=false,previousOverflow='',pageY=0,inerted=[];
 function expand(value){
  finishGesture(true);expanded=value;
  if(value){
   pageY=scrollY;previousOverflow=document.body.style.overflow;document.body.style.overflow='hidden';
   inerted=[...document.querySelectorAll('body > :not(main):not(script):not(dialog),main > :not(.hero),.hero-copy')].filter(el=>!el.inert);
   inerted.forEach(el=>el.inert=true);root.setAttribute('role','dialog');root.setAttribute('aria-modal','true');
  }else{document.body.style.overflow=previousOverflow;inerted.forEach(el=>el.inert=false);inerted=[];root.removeAttribute('role');root.removeAttribute('aria-modal')}
  root.classList.toggle('demo-expanded',value);root.scrollTop=0;
  $('#demo-expand').textContent=value?'Done · Close':'Expand Demo ⛶';$('#demo-expand').setAttribute('aria-pressed',String(value));$('#demo-expand').focus({preventScroll:true});
  if(!value)window.scrollTo({top:pageY,behavior:'instant'});
 }
 $('#demo-expand').onclick=()=>expand(!expanded);
 // The hero “Explore The Demo” button opens the same full-screen demo as Expand Demo.
 for(const link of document.querySelectorAll('[data-demo-expand]'))link.addEventListener('click',e=>{e.preventDefault();if(!expanded)expand(true)});
 root.addEventListener('keydown',e=>{
  if(!expanded)return;
  if(e.key==='Escape'){e.preventDefault();expand(false)}
  if(e.key==='Tab'){
   const controls=[...root.querySelectorAll('button,input,select,summary,[tabindex="0"]')].filter(el=>!el.disabled&&el.getClientRects().length);
   const first=controls[0],last=controls.at(-1);
   if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus()}
   else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus()}
  }
 });
 $('#hero-nozzle').onchange=()=>draw();
 $('#demo-tour').onchange=()=>announce($('#demo-tour').checked?'Auto-next on: each unit advances through internal sequences 001–070.':'Auto-next off: each unit repeats its assigned sequence.');
 reduced.addEventListener('change',e=>{playing=!e.matches;syncMotion()});
 stage.addEventListener('pointerdown',e=>{
  if(e.button!==0||gesture)return;
  e.preventDefault();
  const button=e.target.closest('[data-demo-fixture]'),id=button?+button.dataset.demoFixture:null;
  if(button){
   button.focus({preventScroll:true});
   if(multi||e.ctrlKey||e.metaKey||e.shiftKey){selectFixture(id,true);return}
   if(!selected.includes(id))selectFixture(id,false);else active=id;
  }else stage.focus({preventScroll:true});
  gesture={pointer:e.pointerId,start:point(e),id,starts:positions(),before:[...selected],active,moved:false,snapshot:null,add:multi||e.ctrlKey||e.metaKey||e.shiftKey};
  stage.setPointerCapture(e.pointerId);
 });
 stage.addEventListener('pointermove',e=>{
  const g=gesture;if(!g||e.pointerId!==g.pointer)return;
  const p=point(e),dx=p.x-g.start.x,dy=p.y-g.start.y;
  if(!g.moved&&Math.hypot(dx,dy)<4)return;
  g.moved=true;
  if(g.id){
   if(!g.snapshot)g.snapshot=remember();
   place(groupTranslation(g.starts,dx/(W-56)/zoom,dy/(H*.88)/zoom,{unbounded:true}));draw();
  }else{
   const rect={left:Math.min(g.start.x,p.x),top:Math.min(g.start.y,p.y),right:Math.max(g.start.x,p.x),bottom:Math.max(g.start.y,p.y)};
   const hit=fixtures.filter(f=>{const q=geometry(f);return q.x+22>=rect.left&&q.x-22<=rect.right&&q.y+44>=rect.top&&q.y-8<=rect.bottom}).map(f=>f.id);
   selected=g.add?[...new Set([...g.before,...hit])]:hit;
   if(selected.length)active=selected.at(-1);
   const b=$('#demo-selection-box');b.hidden=false;
   Object.assign(b.style,{left:`${rect.left}px`,top:`${rect.top}px`,width:`${rect.right-rect.left}px`,height:`${rect.bottom-rect.top}px`});
   update();
  }
 });
 function finishGesture(cancel=false){
  const g=gesture;if(!g)return;gesture=null;
  if(cancel){
   place(g.starts);selected=g.before;active=g.active;
   if(g.snapshot&&history.at(-1)===g.snapshot)history.pop();
  }else if(!g.moved){
   if(g.id)selected=[g.id];else if(!g.add)selected=[];
  }
  $('#demo-selection-box').hidden=true;
  if(stage.hasPointerCapture(g.pointer))stage.releasePointerCapture(g.pointer);
  update();announce(cancel?'Gesture cancelled. Original positions and selection restored.':g.id&&g.moved?'Selection moved. Undo restores the original positions.':`${selected.length} selected.`);
 }
 stage.addEventListener('pointerup',()=>finishGesture());
 stage.addEventListener('pointercancel',()=>finishGesture(true));
 stage.addEventListener('lostpointercapture',()=>finishGesture(true));
 window.addEventListener('blur',()=>finishGesture(true));
 root.addEventListener('keydown',e=>{
  if(e.key==='Escape'&&gesture){e.preventDefault();finishGesture(true)}
  if(e.key==='Delete'&&!e.target.closest('input,select,textarea')){e.preventDefault();remove()}
 });
 stage.tabIndex=0;
 new IntersectionObserver(entries=>{visible=entries[0].isIntersecting},{threshold:0}).observe(stage);
 new ResizeObserver(()=>{
  finishGesture(true);
  W=stage.clientWidth;H=stage.clientHeight;dpr=Math.min(2,window.devicePixelRatio||1);
  canvas.width=Math.round(W*dpr);canvas.height=Math.round(H*dpr);draw();
 }).observe(stage);
 function draw(){
  if(!W||!H)return;
  ctx.setTransform(dpr,0,0,dpr,0,0);ctx.fillStyle='#090d10';ctx.fillRect(0,0,W,H);
  ctx.strokeStyle='#ffffff09';ctx.lineWidth=1;
  for(let x=20;x<W;x+=32){ctx.beginPath();ctx.moveTo(x,20);ctx.lineTo(x,H-20);ctx.stroke()}
  for(let y=20;y<H;y+=32){ctx.beginPath();ctx.moveTo(20,y);ctx.lineTo(W-20,y);ctx.stroke()}
  // Keep existing artwork the same size when fixtures are added or removed.
  const nozzle=$('#hero-nozzle').value,scale=Math.min(.72,(W-56)/(6*125))*zoom;
  const looks=[];
  for(const f of [...fixtures].sort((a,b)=>a.y-b.y)){
   const {x,y}=geometry(f),preset=presets[f.presetId-1];
   const sampleAt=t=>{const s=sample(preset,t);return {...s,angle:s.angle*(f.inverted?-1:1)}};
   const degrees=sampleAt(f.elapsed).angle,ang=degrees*Math.PI/180;
   const profile={travel:preset.type==='wave'?.22:preset.long?.19:.14,life:preset.type==='wave'?.66:preset.long?.64:.59};
   drawFlameJet(ctx,{x:x+Math.sin(ang)*14*scale,y:y-Math.cos(ang)*14*scale,length:H*.18*zoom,time:f.elapsed,sampleAt,profile,endTime:preset.duration,id:f.id,nozzle,detail:fixtures.length>8?.6:1});
   drawFlamerBody(ctx,{x,y,angle:degrees,scale,nozzle,fuelLevel:fuel.ratio(f.id)});
   ctx.fillStyle=selected.includes(f.id)?'#ffb17c':'#a8b5bd';ctx.font='11px Arial';ctx.textAlign='center';ctx.fillText(`F${String(f.id).padStart(2,'0')}${f.inverted?' INV':''}`,x,y+66*scale+15);
   const button=$(`[data-demo-fixture="${f.id}"]`);
   if(button)Object.assign(button.style,{left:`${x}px`,top:`${y-10*scale}px`,width:`${Math.max(44,112*scale)}px`,height:`${Math.max(44,85*scale)}px`});
   looks.push(`${String(f.id).padStart(2,'0')}:${pad(f.presetId)}`);
  }
  const status=$('#demo-looks'),text=`Fixture : sequence   ${looks.join(' · ')}`;
  if(status.textContent!==text)status.textContent=text;
  fuelUI?.sync();
 }
 function frame(now){
  const dt=last?Math.min(.05,(now-last)/1000):0;last=now;
  if(playing&&visible&&!document.hidden&&!sequencePicker.isOpen()){
   let changed=false;
   for(const f of fixtures){
    fuel.window(f.id,$('#hero-nozzle').value,dt,offset=>sample(presets[f.presetId-1],f.elapsed+offset).on);
    f.elapsed+=dt;
    const duration=presets[f.presetId-1].duration+1.1;
    if(f.elapsed>=duration){f.elapsed%=duration;if($('#demo-tour').checked){f.presetId=f.presetId%70+1;changed=true}}
   }
   if(changed){quickLook='';update()}else draw();
  }
  requestAnimationFrame(frame);
 }
 fuelUI=mountFuelUI({ledger:fuel,container:$('#demo-handles'),selector:'[data-demo-fixture]',idOf:el=>+el.dataset.demoFixture,getFixtures:()=>fixtures,getSelected:()=>selected,findFixture:id=>{const f=fixtures.find(f=>f.id===id);return f?{...f,nozzle:$('#hero-nozzle').value}:null},onOpen:()=>finishGesture(true),onRefill:()=>draw()});
 mountDemoRecorder({canvas,bar:root.querySelector('.art-bar'),optionHost:$('.demo-under-layout'),getSequence:()=>{
  const groups=new Map();
  for(const f of [...fixtures].sort((a,b)=>a.id-b.id)){const p=presets[f.presetId-1];if(!groups.has(p.id))groups.set(p.id,{id:p.id,name:p.name,units:[]});groups.get(p.id).units.push(f.id)}
  return describeSequences([...groups.values()],{look:quickLook?quickLook[0].toUpperCase()+quickLook.slice(1):'',total:fixtures.length});
 }});
 syncMotion();update();requestAnimationFrame(frame);
}
