// Companion windows share this tab's virtual state. No hardware output or remote access.
import {bindNoteEditor} from './note-editor.js?v=v0340-20261007g';
import {bindNoteTabs} from './note-tabs.js?v=v0340-20261007g';
import {showDefaultFeedback} from './default-feedback.js?v=v0340-20261007g';
export function createBrowserLauncher(){
 const el=document.createElement('section');el.className='workspace-browser';
 el.innerHTML='<h3>Perplexity Comet</h3><p class="widget-hint">Open reference pages alongside Wave Studio. Pages open in your current browser; use Wave Studio in Comet to keep them in Comet. This panel is a launcher, not an embedded Comet engine.</p><label>Website Address<input type="url" aria-label="Browser Website Address" value="https://www.perplexity.ai/" placeholder="https://"></label><button type="button">Open Website</button><a href="https://www.perplexity.ai/comet" target="_blank" rel="noopener noreferrer">Get Comet</a><p role="status"></p>';
 el.querySelector('button').onclick=()=>{
  const input=el.querySelector('input');let url;
  try{url=new URL(input.value);if(!['https:','http:'].includes(url.protocol)||url.username||url.password)throw Error()}
  catch{el.querySelector('[role=status]').textContent='Enter A Valid HTTP Or HTTPS Address Without Login Credentials.';return}
  window.open(url.href,'_blank','noopener,noreferrer');
  el.querySelector('[role=status]').textContent='Opened In A New Browser Tab. If Nothing Opens, Allow Pop-Ups For Wave Studio.';
 };
 el.querySelector('input').onkeydown=e=>{e.stopPropagation();if(e.key==='Enter'){e.preventDefault();el.querySelector('button').click()}};
 return {el,render(){},tick(){}};
}
export function mountMonitorWindows({host,panels,isLive}){
 const el=document.createElement('section');el.className='monitor-settings';
 el.innerHTML='<h3>Multi-Monitor Workspace</h3><p class="widget-hint">Main Window + Up To Three Companion Windows. Move Each Window To A Monitor, Choose Panels, Drag Their Headers And Resize Their Corners. All Controls Share The Main Window’s Virtual State. Dialogs And File Pickers Open In The Main Window. Keep This Tab Open.</p><div class="widget-row"><button type="button" data-displays>Detect Displays</button><button type="button" data-close-monitors>Close Companions</button></div><div class="widget-row monitor-open-buttons"></div><p role="status"></p>';
 host.append(el);
 const slots=new Map();let screens=[];
 const disposeViews=slot=>{for(const v of slot.views.values()){v.editor?.destroy();v.tabs?.destroy()}slot.views.clear()};
 document.addEventListener('wave-default-updated',e=>{for(const slot of slots.values())if(slot.defaultPending&&!slot.win.closed){const anchor=slot.doc?.querySelector(`[data-monitor-id="${slot.defaultPending}"]`);if(anchor)showDefaultFeedback(e.detail.text,anchor);slot.defaultPending=null}});
 const release=slot=>{for(const original of slot.held??[])original.dispatchEvent(new KeyboardEvent('keyup',{key:'Enter',bubbles:true}));slot.held?.clear()};
 const status=t=>el.querySelector('[role=status]').textContent=t;
 const standaloneRequired=()=>globalThis.origin==='null';
 if(standaloneRequired())status('Linked Monitor Windows Require A Standalone Wave Studio Page, Not This Sandboxed Embedded Preview.');
 async function detect(){
  if(!window.getScreenDetails){status('Automatic Display Detection Is Unavailable Here. Open Companion Windows And Move Them To Your Monitors Manually.');return []}
  try{const details=await window.getScreenDetails();screens=[...details.screens].slice(0,4);status(`${screens.length} Display(s) Detected. Open A Companion For Each Additional Display.`);return screens}
  catch{status('Display Permission Was Not Granted. Manual Window Placement Still Works.');return []}
 }
 el.querySelector('[data-displays]').onclick=detect;
 function setup(slot){
  const win=slot.win,doc=win.document,grid=doc.querySelector('#monitor-panels'),catalog=doc.querySelector('#monitor-catalog');
  if(!grid||!catalog)return;
  disposeViews(slot);slot.doc=doc;slot.views=new Map();grid.replaceChildren();catalog.replaceChildren();
  win.addEventListener('blur',()=>release(slot));win.addEventListener('pagehide',()=>release(slot));
  doc.title=`Wave Studio · Monitor ${slot.index+1}`;
  doc.querySelector('#monitor-title').textContent=`Wave Studio · Monitor ${slot.index+1}`;
  const rows=panels().filter(d=>d.el);
  for(const def of rows){
   const label=doc.createElement('label'),input=doc.createElement('input');input.type='checkbox';input.checked=slot.selected.has(def.key);
   label.append(input,doc.createTextNode(def.title));catalog.append(label);
   input.onchange=()=>{input.checked?slot.selected.add(def.key):slot.selected.delete(def.key);build()};
  }
  const focusButton=doc.querySelector('#monitor-fullscreen');
  focusButton.onclick=()=>{const focus=doc.body.classList.toggle('monitor-focus');focusButton.textContent=focus?'Exit Focus View':'Focus View'};
  doc.addEventListener('keydown',e=>{if(e.key==='Escape'){doc.body.classList.remove('monitor-focus');focusButton.textContent='Focus View'}});
  function build(){
   for(const view of slot.views.values()){view.editor?.destroy();view.tabs?.destroy()}
   grid.replaceChildren();slot.views.clear();
   for(const def of rows.filter(d=>slot.selected.has(d.key))){
    const card=doc.createElement('section');card.className='monitor-card';card.dataset.type=def.key;
    const head=doc.createElement('header'),grip=doc.createElement('button'),remove=doc.createElement('button');grip.textContent=def.title;grip.type=remove.type='button';grip.draggable=true;
    grip.ondragstart=e=>{slot.drag=card;e.dataTransfer.setData('text/plain',def.key)};
    card.ondragover=e=>{if(slot.drag){e.preventDefault();card.classList.add('monitor-drop')}};
    card.ondragleave=()=>card.classList.remove('monitor-drop');
    card.ondrop=e=>{e.preventDefault();card.classList.remove('monitor-drop');if(slot.drag&&slot.drag!==card)card.before(slot.drag);slot.drag=null};
    grip.ondragend=()=>{slot.drag=null;grid.querySelectorAll('.monitor-drop').forEach(n=>n.classList.remove('monitor-drop'))};
    remove.textContent='×';remove.setAttribute('aria-label',`Remove ${def.title}`);remove.onclick=()=>{slot.selected.delete(def.key);[...catalog.querySelectorAll('input')][rows.indexOf(def)].checked=false;build()};
    const content=doc.createElement('div');content.className='monitor-card-content';head.append(grip);
    if(def.key==='faders'){const details=doc.createElement('button');details.type='button';details.textContent='Details';details.setAttribute('aria-pressed','false');details.onclick=()=>{const enabled=card.classList.toggle('monitor-fader-details');details.setAttribute('aria-pressed',String(enabled))};head.append(details)}
    head.append(remove);card.append(head,content);grid.append(card);
    slot.views.set(def.key,{source:def.el,content,signature:null,last:0,...(def.key==='notes'?{editor:bindNoteEditor(content),tabs:bindNoteTabs(content,{reorder:(id,target,after)=>def.el.dispatchEvent(new CustomEvent('wave-note-reorder',{detail:{id,target,after}}))})}:{})});
   }
  }
  build();
 }
 function update(slot){
  const win=slot.win;if(win.closed){release(slot);disposeViews(slot);return}
  const doc=win.document;if(!doc.querySelector('#monitor-panels'))return;
  if(doc!==slot.doc)setup(slot);
  doc.documentElement.style.setProperty('--button-scale',getComputedStyle(document.documentElement).getPropertyValue('--button-scale')||1);
  const stopped=!document.body.isConnected;
  doc.querySelector('#monitor-status').textContent=isLive()?'Live Input Owns Playback. Virtual Fader Controls Are Locked.':'Linked To Main Window · Virtual Visualization Only';
  for(const [key,v]of slot.views){
   const focused=v.content.contains(doc.activeElement)&&doc.activeElement.matches('input,select,textarea')||slot.held.size>0;
   const now=performance.now(),html=v.source.innerHTML;
   if(!focused&&now-v.last>500&&html!==v.signature){
    v.last=now;v.signature=html;
    const copy=v.source.cloneNode(true);
    const from=[v.source,...v.source.querySelectorAll('*')],to=[copy,...copy.querySelectorAll('*')];
    to.forEach((n,i)=>{
     if(n.id)n.dataset.monitorId=n.id;
     n.removeAttribute('id');n.removeAttribute('autofocus');n.removeAttribute('name');
     for(const a of [...n.attributes])if(a.name.startsWith('on'))n.removeAttribute(a.name);
     if(n.tagName==='SCRIPT'){n.remove();return}
     if(n.matches('button,input,select,textarea')){
      if(n.matches('button')){
       n.type='button';const original=from[i],momentary=original.matches('[data-hold],.macro-key,#prev,#next,#cue-start,#cue-end');
       const down=()=>{if(original.disabled||original.closest('[inert]'))return;slot.held.add(original);original.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',bubbles:true}))};
       const up=()=>{slot.held.delete(original);original.dispatchEvent(new KeyboardEvent('keyup',{key:'Enter',bubbles:true}))};
       n.onclick=e=>{e.preventDefault();if(!momentary&&!original.disabled&&!original.closest('[inert]')){if(original.matches('#stage-default-layout,#default-layout')){slot.defaultPending=original.id;setTimeout(()=>slot.defaultPending=null,9000)}original.click()}};
       if(momentary){n.onpointerdown=e=>{if(e.button!==0)return;e.preventDefault();n.setPointerCapture(e.pointerId);down()};n.onpointerup=n.onpointercancel=n.onlostpointercapture=up;n.onkeydown=e=>{if(['Enter',' '].includes(e.key)){e.preventDefault();if(!e.repeat)down()}};n.onkeyup=e=>{if(['Enter',' '].includes(e.key)){e.preventDefault();up()}}}
      }
      else for(const type of ['input','change'])n.addEventListener(type,()=>{
       const original=from[i];if(original.disabled||original.closest('[inert]'))return;
       original.value=n.value;if('checked'in n)original.checked=n.checked;
       original.dispatchEvent(new Event(type,{bubbles:true}));
      });
      n.addEventListener('blur',()=>{if(!n.matches('button'))from[i].dispatchEvent(new Event('blur'))});
      n.addEventListener('keydown',e=>{e.stopPropagation();if(e.key==='Enter'&&!n.matches('textarea'))e.preventDefault()});
     }
     n.removeAttribute('for');
    });
    v.content.replaceChildren(copy);
   }
   const original=v.source.querySelectorAll('input,select,textarea'),clones=v.content.querySelectorAll('input,select,textarea');
   original.forEach((n,i)=>{if(!clones[i])return;if(clones[i]!==doc.activeElement)clones[i].value=n.value;if('checked'in n)clones[i].checked=n.checked;clones[i].disabled=n.disabled});
   v.content.inert=stopped||isLive()&&['faders','master','macros','bank','record'].includes(key);
   const from=v.source.querySelectorAll('canvas'),to=v.content.querySelectorAll('canvas');
   from.forEach((c,i)=>{const target=to[i];if(!target||!c.width||!c.height)return;if(target.width!==c.width)target.width=c.width;if(target.height!==c.height)target.height=c.height;target.getContext('2d').drawImage(c,0,0)});
  }
 }
 function open(i,{selected,displayIndex,placement='full'}={}){
   if(![1,2,3].includes(i))return false;
   if(standaloneRequired()){status('Open Wave Studio As A Standalone Page To Use Linked Monitor Windows. The Embedded Preview Cannot Share Its Controls With Another Window.');return false}
   const previous=slots.get(i);
   if(previous&&!previous.win.closed){if(selected){previous.selected=new Set(selected);setup(previous)}previous.win.focus();return true}
   const screen=screens[displayIndex??i],width=screen?.availWidth??1100,height=screen?.availHeight??760;
   const split=placement==='left'||placement==='right',w=split?Math.floor(width/2):width,left=(screen?.availLeft??80*i)+(placement==='right'?w:0),top=screen?.availTop??60;
   const win=window.open('monitor.html',`wave-monitor-${i}`,`popup,width=${w},height=${height},left=${left},top=${top}`);
   if(!win){status('Allow Pop-Ups For Wave Studio, Then Try Again.');return false}
   slots.set(i,{win,index:i,selected:new Set(selected??previous?.selected??[i===1?'stage':i===2?'faders':'library']),views:new Map(),doc:null,held:new Set()});
   status(`Monitor ${i+1} Opened. Move It To Your Preferred Display.`);return true;
 }
 for(let i=1;i<=3;i++){
  const button=document.createElement('button');button.type='button';button.textContent=`Open Monitor ${i+1}`;el.querySelector('.monitor-open-buttons').append(button);
  button.onclick=()=>open(i);
 }
 el.querySelector('[data-close-monitors]').onclick=()=>{for(const slot of slots.values()){release(slot);disposeViews(slot);if(!slot.win.closed)slot.win.close()}slots.clear();status('Companion Windows Closed. Main Workspace Unchanged.')};
 const timer=setInterval(()=>{for(const slot of slots.values())try{update(slot)}catch{status('A Companion Navigated Away Or Disconnected. Close It And Reopen From Here.')}},80);
 window.addEventListener('pagehide',()=>{clearInterval(timer);for(const slot of slots.values()){release(slot);disposeViews(slot);if(!slot.win.closed)slot.win.close()}},{once:true});
 return {open,detect,close:()=>el.querySelector('[data-close-monitors]').click(),status:()=>el.querySelector('[role=status]').textContent,displays:()=>screens.map((s,i)=>({index:i,label:s.label||`Display ${i+1}`,width:s.availWidth,height:s.availHeight,left:s.availLeft,top:s.availTop}))};
}
