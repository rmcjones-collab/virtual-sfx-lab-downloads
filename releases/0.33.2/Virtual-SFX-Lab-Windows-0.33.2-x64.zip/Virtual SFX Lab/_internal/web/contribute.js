import {mountDonorThanks} from './donor-thanks.js?v=v0340-20261007g';
import {creditHistory,drawCreditTrend} from './credit-trend.js?v=v0340-20261007g';
// Public release metadata only. Never put account credentials or billing exports here.
const header = document.querySelector('.topbar, .header-inner');
const brand = header?.querySelector('.brand');
if (header && brand) {
  header.classList.add('has-contribution');
  const contribution = document.createElement('section');
  contribution.className = 'contribution-bar';
  contribution.setAttribute('aria-label', 'Support Wave Studio Development');
  contribution.innerHTML = `
    <p class="contribution-message">Like the program? Please support further development. Thank you!</p>
    <button class="contribute-open" type="button" aria-haspopup="dialog">Contribute</button>
    <div class="development-counter"><span>Perplexity Credits Used</span><div class="credit-total-row"><strong id="development-credits">Not Set</strong><canvas id="credit-trend" width="42" height="16" role="img" title="Manually Reported Credit Growth · Checks For Updates Every Minute · Not Live Billing"></canvas></div><small id="development-asof">Manual Total Pending</small></div>`;
  brand.after(contribution);
  mountDonorThanks({brand, header});
  const version = document.createElement('span');
  version.className = 'beta-version';
  version.textContent = 'Beta';
  (brand.querySelector('div') || brand.querySelector('span')).append(version);

  const modal = document.createElement('dialog');
  modal.id = 'contribute-dialog';
  modal.className = 'contribute-dialog';
  modal.setAttribute('aria-labelledby', 'contribute-title');
  modal.innerHTML = `
    <div class="contribute-dialog-heading"><div><p class="contribute-kicker">INDEPENDENT DEVELOPMENT</p><h2 id="contribute-title">Support Wave Studio</h2></div><button type="button" class="contribute-close" aria-label="Close Contributions" autofocus>Close</button></div>
    <p>Like the program? Please support further development. Thank you!</p>
    <section class="contribute-option"><h3>Leave A Tip With PayPal</h3><p>Choose your amount on PayPal. Tips are optional and do not purchase a license or unlock app features.</p><a id="contribute-paypal" target="_blank" rel="noopener noreferrer" hidden>Continue To PayPal ↗</a><p id="contribute-destination">Loading payment destination…</p></section>
    <section class="contribute-option"><h3>Donor Thank-Yous</h3><p>The rotating thank-you display is prepared but not connected to payments. Donations through this link will not automatically appear. When enabled, only approved donations with consent to display a public username and amount will appear, one at a time for one minute.</p></section>
    <section class="contribute-option"><h3>Support Development Credits</h3><p>Direct Perplexity credit transfers are not available. A PayPal tip can help fund ongoing development instead; it does not transfer credits to this account.</p><a class="contribution-policy" href="https://www.perplexity.ai/help-center/en/articles/13838041-how-credits-work-on-perplexity" target="_blank" rel="noopener noreferrer">Perplexity Credit Policy ↗</a></section>
    <section class="contribute-accounting"><h3>Development Credit Total</h3><p id="contribute-credit-detail">Awaiting the developer’s manually reported total. This is not a live account balance or an automatic usage meter.</p><p id="contribute-metadata-status" role="status"></p></section>`;
  document.body.append(modal);
  const opener = contribution.querySelector('button');
  opener.addEventListener('click', () => modal.showModal());
  modal.querySelector('.contribute-close').addEventListener('click', () => modal.close());
  modal.addEventListener('close', () => opener.focus({preventScroll: true}));
  modal.addEventListener('click', event => {
    if (event.target !== modal) return;
    const rect = modal.getBoundingClientRect();
    if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) modal.close();
  });

  const count = contribution.querySelector('#development-credits');
  const asOf = contribution.querySelector('#development-asof');
  const detail = modal.querySelector('#contribute-credit-detail');
  const status = modal.querySelector('#contribute-metadata-status');
  let refreshing = false;
  let history=[];
  async function refresh() {
    if (refreshing || document.hidden) return;
    refreshing = true;
    try {
      const response = await fetch(new URL('./development.json', import.meta.url), {cache: 'no-store', signal: AbortSignal.timeout(8000)});
      if (!response.ok) throw new Error('Metadata unavailable');
      const data = await response.json();
      if (typeof data.version !== 'string' || !/^0\.\d{1,}(?:\.\d+)?[a-z]?$/.test(data.version)) throw new Error('Invalid release metadata');
      version.textContent = `Beta ${data.version}`;
      document.querySelectorAll('footer .version').forEach(node => node.textContent = `/ Beta ${data.version}`);
      // Permit only the developer's intended payment destination, not arbitrary redirects.
      const payment = new URL(data.paypalUrl);
      if (payment.href !== 'https://paypal.me/rmcjones') throw new Error('Unrecognized payment destination');
      const paypal = modal.querySelector('#contribute-paypal');
      paypal.href = payment.href;
      paypal.hidden = false;
      modal.querySelector('#contribute-destination').textContent = 'Destination: paypal.me/rmcjones · Opens A New Tab';
      const dateValid = typeof data.creditsAsOf === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(data.creditsAsOf) &&
        Number.isFinite(Date.parse(`${data.creditsAsOf}T00:00:00Z`)) &&
        new Date(`${data.creditsAsOf}T00:00:00Z`).toISOString().slice(0,10) === data.creditsAsOf;
      if (typeof data.creditsUsed === 'number' && Number.isFinite(data.creditsUsed) && data.creditsUsed >= 0 && data.creditsUsed <= Number.MAX_SAFE_INTEGER && dateValid) {
        count.textContent = new Intl.NumberFormat('en-CA', {maximumFractionDigits: 2}).format(data.creditsUsed);
        asOf.textContent = `Manual · ${data.creditsAsOf}`;
        history=creditHistory(data,history);drawCreditTrend(contribution.querySelector('#credit-trend'),history,getComputedStyle(header).getPropertyValue('--accent').trim()||'#ee9b62');
        detail.textContent = `${count.textContent} Perplexity credits used for Wave Studio development, as reported by the developer on ${data.creditsAsOf}. Manually updated, not independently verified or connected to a live billing feed. This is usage, not remaining credits or contributions received.`;
      } else {
        history=[];drawCreditTrend(contribution.querySelector('#credit-trend'),[]);
        count.textContent = 'Not Set';
        asOf.textContent = 'Manual Total Pending';
        detail.textContent = 'Awaiting the developer’s manually reported total. This is not a live account balance or an automatic usage meter.';
      }
      status.textContent = '';
    } catch {
      // Do not silently portray stale figures as current.
      status.textContent = 'Release data could not be refreshed. Please reload to try again.';
      asOf.textContent = 'Update Unavailable';
      if (!modal.querySelector('#contribute-paypal').hasAttribute('href')) {
        modal.querySelector('#contribute-destination').textContent = 'Payment destination unavailable. Please reload before contributing.';
      }
    } finally {
      refreshing = false;
    }
  }
  refresh();
  // Refresh the public, manually maintained record, not private account billing.
  setInterval(refresh, 60000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) refresh(); });
  new MutationObserver(()=>drawCreditTrend(contribution.querySelector('#credit-trend'),history,getComputedStyle(header).getPropertyValue('--accent').trim()||'#ee9b62')).observe(document.documentElement,{attributes:true,attributeFilter:['data-theme']});
}
