import {normalize,denormalize,difference,rebuild,readSession,sessionMarkdown} from './session-model.js?v=v0340-20261007g';
import {requestFileSave} from './file-save.js?v=v0340-20261007g';
const PORT='__PORT_8093__';
const API=PORT.startsWith('__')?'http://127.0.0.1:8093':PORT;
const local=['127.0.0.1','localhost'].includes(location.hostname);
const headers={'Content-Type':'application/json',...(local?{'X-Wave-Dev-Visitor':'local-development'}:{})};
const uid=()=>crypto.randomUUID();
const fileId=id=>String(id).replace(/[^0-9a-f-]/gi,'').slice(0,36)||'session';
// Autosave settings from the server get the same range check as the form (0.1 to 1440 minutes).
const goodSettings=p=>p&&typeof p.enabled==='boolean'&&Number.isFinite(p.minutes)&&p.minutes>=.1&&p.minutes<=1440;
const download=(text,name,type)=>requestFileSave(new Blob([text],{type}),name);
export function mountSessions({capture,apply,host}){
 const section=document.createElement('details');section.className='session-setup';section.id='session-setup';
 section.innerHTML=`<summary>Autosave &amp; Session Options</summary><p>Each visit starts a separate log. Logs are saved to your browser’s private server workspace, not a shared public list. Download important sessions for long-term storage.</p>
 <div class="session-options"><label><input id="autosave-enabled" type="checkbox" checked> Autosave Layout</label><label>Interval (Minutes)<input id="autosave-minutes" type="number" min="0.1" max="1440" step="0.1" value="5"></label></div>
 <div class="session-buttons"><button id="session-save">Save Now</button><button id="session-new">New Session</button></div><p id="session-status" role="status">Starting Session…</p>`;
 const sessionsButton=document.createElement('button');sessionsButton.id='session-open';sessionsButton.type='button';sessionsButton.textContent='Session Files';host.append(sessionsButton);
 const autosaveButton=document.createElement('button');autosaveButton.id='autosave-open';autosaveButton.type='button';autosaveButton.textContent='Autosave';host.append(autosaveButton);
 const dialog=document.createElement('dialog');dialog.className='sessions-dialog';
 dialog.innerHTML=`<div class="session-heading"><h2>Session Files</h2><button data-session-close>Close</button></div><p>Open a recorded session or import its JSON / Markdown document. Remove, replace, or edit actions, then apply the resulting layout and settings. Playback is always paused on Apply; live input is disconnected.</p><div class="session-buttons"><button data-session-current>Current Session</button><button data-session-import>Open Document</button><button data-session-json>Download Session File</button><button data-session-md>Download Document</button><input data-session-file type="file" accept=".json,.md,.txt,application/json,text/markdown" hidden><button data-session-archives hidden>Download Archived Logs</button></div><label>Session Name<input data-session-title maxlength="100"></label><div class="session-browser"><aside><h3>Saved Sessions</h3><div data-session-list></div></aside><section><p data-session-summary></p><div data-session-actions></div><button data-session-older hidden>Show Earlier Actions</button></section></div><p data-session-message role="status"></p><div class="session-buttons"><button data-session-apply class="primary">Apply Edited Session</button><button data-session-copy>Save Edited Copy</button></div>`;
 document.body.append(dialog);
 const autosaveDialog=document.createElement('dialog');autosaveDialog.className='sessions-dialog autosave-dialog';autosaveDialog.id='autosave-dialog';
 autosaveDialog.innerHTML='<div class="session-heading"><h2>Autosave</h2><button type="button" data-autosave-close>Close</button></div>';
 section.open=true;autosaveDialog.append(section);document.body.append(autosaveDialog);
 autosaveButton.onclick=()=>autosaveDialog.showModal();autosaveDialog.querySelector('[data-autosave-close]').onclick=()=>autosaveDialog.close();
 const $=s=>dialog.querySelector(s),status=message=>section.querySelector('#session-status').textContent=message;
 let current,baseline,opened=null,previousSave=0,autoAt=Date.now(),dirty=true,saveTask=null,limit=100,suppress=false;
 let records=[],settings={enabled:true,minutes:5},startPerf=performance.now();
 function fresh(label='Session'){
  const now=new Date();return {format:'wave-studio-session',version:1,id:uid(),title:`${label} ${now.toLocaleString()}`,startedAt:now.toISOString(),updatedAt:now.toISOString(),initial:capture(),actions:[]};
 }
 function begin(){current=fresh();baseline=normalize(current.initial);startPerf=performance.now();dirty=true;autoAt=Date.now()}
 begin();
 async function api(path,options={}){
  let r;
  try{r=await fetch(`${API}/api/${path}`,{...options,headers,signal:AbortSignal.timeout(10000)})}
  catch{throw Error('Session Storage Unreachable. Open Current Session And Download A Copy Before Closing.')}
  if(!r.ok)throw Error(r.status===401?'Private storage identity unavailable. Download your session before closing.':`Session storage unavailable (${r.status}). Download a copy.`);
  return r.json();
 }
 // Bounded: at most MAX_ARCHIVES full logs are held; retries back off and stop for archives the server refuses outright.
 const MAX_ARCHIVES=6,unsaved=[];let flushing=null,retryAt=0;
 function syncArchives(){const b=$('[data-session-archives]');b.hidden=!unsaved.length;b.textContent=`Download Archived Logs (${unsaved.length})`}
 function flushArchives(){
  if(flushing)return flushing;
  flushing=(async()=>{
   // An earlier save of the same log id must land first, or it could overwrite the full archive.
   if(saveTask)await saveTask;
   for(const archive of unsaved.filter(a=>!a.refused)){
    let r=null;try{r=await fetch(`${API}/api/sessions/${encodeURIComponent(archive.doc.id)}`,{method:'PUT',headers,body:JSON.stringify(archive.doc),signal:AbortSignal.timeout(15000)})}catch{}
    if(r?.ok){unsaved.splice(unsaved.indexOf(archive),1);continue}
    if(r&&r.status>=400&&r.status<500&&![408,429].includes(r.status))archive.refused=true;
    else{retryAt=Date.now()+60000;break}
   }
   if(unsaved.length)status(unsaved.some(a=>a.refused)?'An Archived Log Was Refused By Session Storage. Session Files > Download Archived Logs Keeps A Copy.':'Archived Log Not Saved Online Yet. Session Files > Download Archived Logs Keeps A Copy.');
   syncArchives();
  })().finally(()=>{flushing=null});
  return flushing;
 }
 function save(){
  if(unsaved.some(a=>!a.refused)&&Date.now()>=retryAt)flushArchives();
  if(saveTask)return saveTask.then(()=>dirty?save():null);if(!dirty)return Promise.resolve();
  dirty=false;
  const doc=structuredClone(current);doc.updatedAt=new Date().toISOString();
  saveTask=api(`sessions/${encodeURIComponent(doc.id)}`,{method:'PUT',body:JSON.stringify(doc)})
   .then(()=>{previousSave=Date.now();status(`Log Saved ${new Date(previousSave).toLocaleTimeString()} · ${current.actions.length} Actions`)})
   .catch(e=>{dirty=true;status(e.message)}).finally(()=>{saveTask=null});
  return saveTask;
 }
 function record(label='Playback / Fuel Checkpoint',force=false){
  if(suppress)return;
  const next=normalize(capture()),patch=difference(baseline,next);
  if(!patch.length&&!force)return;
  if(current.actions.length>=1900){
   // A full log is archived and a new one continues from here. The archive stays in memory until the server
   // has it; if saving fails it is retried with every save and offered under Session Files > Download Archived Logs.
   const archive=structuredClone(current),start=denormalize(baseline);archive.updatedAt=new Date().toISOString();
   unsaved.push({doc:archive,refused:false});
   if(unsaved.length>MAX_ARCHIVES){unsaved.shift();status(`Only The Last ${MAX_ARCHIVES} Archived Logs Are Kept In This Tab. Download Archived Logs Now.`)}
   retryAt=0;flushArchives();
   begin();current.initial=start;
  }
  current.actions.push({id:uid(),at:Math.round(performance.now()-startPerf),label:String(label).slice(0,200),enabled:true,patch});baseline=next;dirty=true;
 }
 async function autosave(){
  record('Autosave Layout Checkpoint');
  try{
   const doc=fresh('Autosave');doc.initial=capture();
   await api(`sessions/${encodeURIComponent(doc.id)}`,{method:'PUT',body:JSON.stringify(doc)});
   status(`Autosaved Layout ${new Date().toLocaleTimeString()}`);
  }catch(e){status(e.message)}
 }
 async function browse(){
  try{records=await api('sessions');const list=$('[data-session-list]');list.replaceChildren();
   for(const item of records){const b=document.createElement('button');b.textContent=`${item.title} · ${item.actions} Actions`;b.onclick=async()=>{
    try{opened=await api(`sessions/${encodeURIComponent(item.id)}`);limit=100;render()}catch(e){$('[data-session-message]').textContent=e.message}
   };list.append(b)}
   if(!records.length)list.textContent='No Saved Sessions Yet.';
  }catch(e){$('[data-session-message]').textContent=e.message}
 }
 function setOpen(doc){opened=structuredClone(doc);limit=100;render();if(!dialog.open)dialog.showModal();browse()}
 function render(){
  $('[data-session-title]').value=opened.title;
  $('[data-session-summary]').textContent=`${opened.actions.filter(a=>a.enabled!==false).length} Included / ${opened.actions.length} Actions · ${opened.startedAt}`;
  const list=$('[data-session-actions]');list.replaceChildren();
  const start=Math.max(0,opened.actions.length-limit);
  opened.actions.slice(start).forEach((action,i)=>{
   const row=document.createElement('article');row.className='session-action';row.classList.toggle('excluded',action.enabled===false);
   const header=document.createElement('div');header.className='session-action-heading';
   const title=document.createElement('strong');title.textContent=`${i+start+1}. ${(action.at/1000).toFixed(1)}s · ${action.label}`;header.append(title);
   const remove=document.createElement('button');remove.textContent=action.enabled===false?'Restore':'Remove';remove.onclick=()=>{action.enabled=action.enabled===false;render()};header.append(remove);row.append(header);
   const details=document.createElement('details');details.innerHTML='<summary>Edit / Replace Action</summary><label>Action Label<input data-action-label maxlength="200"></label><label>Time (Seconds)<input data-action-time type="number" min="0" step="0.001"></label><div class="session-replace"><label>Unit ID<input data-replace-unit type="number" min="1" max="999999"></label><label>Sequence<input data-replace-preset type="number" min="1" max="88" value="1"></label><button data-replace>Replace With Sequence</button></div><label>Changes (JSON)<textarea data-action-patch rows="5" spellcheck="false"></textarea></label><button data-action-save>Save Action Edit</button><p data-action-error role="status"></p>';
   details.querySelector('[data-action-label]').value=action.label;
   details.querySelector('[data-action-time]').value=action.at/1000;
   details.querySelector('[data-action-patch]').value=JSON.stringify(action.patch,null,2);
   details.querySelector('[data-replace-unit]').value=opened.initial.selectedId;
   details.querySelector('[data-action-save]').onclick=()=>{try{
    const patch=JSON.parse(details.querySelector('[data-action-patch]').value),copy=structuredClone(opened);
    const at=Number(details.querySelector('[data-action-time]').value)*1000;
    copy.actions[i+start].patch=patch;copy.actions[i+start].at=at;rebuild(copy);action.patch=patch;action.at=at;action.label=details.querySelector('[data-action-label]').value||'Edited Action';render();
   }catch(e){details.querySelector('[data-action-error]').textContent=e.message}};
   details.querySelector('[data-replace]').onclick=()=>{
    const unit=Number(details.querySelector('[data-replace-unit]').value),preset=Number(details.querySelector('[data-replace-preset]').value);
    if(!Number.isInteger(unit)||unit<1||!Number.isInteger(preset)||preset<1||preset>88){details.querySelector('[data-action-error]').textContent='Choose a valid unit and sequence 1–88.';return}
    action.patch=[{path:['fixtures',String(unit),'presetId'],value:preset}];action.label=`Set Unit ${unit} To Sequence ${preset}`;action.enabled=true;render();
   };
   row.append(details);list.append(row);
  });
  $('[data-session-older]').hidden=start===0;
 }
 const withTitle=()=>{opened.title=$('[data-session-title]').value.trim()||'Edited Session';return opened};
 $('[data-session-older]').onclick=()=>{limit+=100;render()};
 $('[data-session-close]').onclick=()=>dialog.close();
 $('[data-session-current]').onclick=()=>{record();setOpen(current)};
 $('[data-session-archives]').onclick=async()=>{
  for(const archive of [...unsaved]){const result=await download(JSON.stringify(archive.doc,null,2),`wave-session-${fileId(archive.doc.id)}.json`,'application/json');if(!result)return}
  $('[data-session-message]').textContent='Archived Logs Downloaded. They Are Still Retried Online With Each Save.';
 };
 $('[data-session-import]').onclick=()=>$('[data-session-file]').click();
 $('[data-session-file]').onchange=async e=>{try{const f=e.target.files[0];if(!f)return;if(f.size>8000000)throw Error('8 MB maximum');const doc=readSession(await f.text());apply(rebuild(doc),true);setOpen(doc);$('[data-session-message]').textContent='Document Opened. Review Actions Before Applying.'}catch(error){$('[data-session-message]').textContent=error.message}e.target.value=''};
 $('[data-session-json]').onclick=()=>download(JSON.stringify(withTitle(),null,2),`wave-session-${fileId(opened.id)}.json`,'application/json');
 $('[data-session-md]').onclick=()=>download(sessionMarkdown(withTitle()),`wave-session-${fileId(opened.id)}.md`,'text/markdown');
 $('[data-session-apply]').onclick=()=>{
  try{const layout=rebuild(withTitle());apply(layout,true);suppress=true;apply(layout);suppress=false;record(`Applied Edited Session: ${opened.title}`,true);save();$('[data-session-message]').textContent='Applied Layout And Settings. Playback Paused; Live Input Disconnected. Current Session Logs Retain This Change.'}
  catch(e){suppress=false;$('[data-session-message]').textContent=`Not Applied: ${e.message}. Remove dependent actions or correct their changes.`}
 };
 $('[data-session-copy]').onclick=async()=>{
  try{const doc=structuredClone(withTitle());apply(rebuild(doc),true);doc.id=uid();doc.updatedAt=new Date().toISOString();const result=await download(JSON.stringify(doc,null,2),'wave-session-copy.json','application/json');if(!result)return;await api(`sessions/${doc.id}`,{method:'PUT',body:JSON.stringify(doc)});opened=doc;browse();$('[data-session-message]').textContent=result.message+' Edited Copy Also Saved Online. Original Session Preserved.'}
  catch(e){$('[data-session-message]').textContent=e.message}
 };
 sessionsButton.onclick=()=>{record();setOpen(current)};
 section.querySelector('#session-save').onclick=async()=>{record('Manual Save',true);const result=await download(JSON.stringify(current,null,2),'wave-session.json','application/json');if(result){await save();status(result.message+(dirty?' Online Save Is Unavailable.':' Session Also Saved Online.'))}};
 section.querySelector('#session-new').onclick=async()=>{record('Session End',true);await save();if(dirty){status('Download This Session Before Starting Another: Storage Is Unavailable.');return}begin();save();status('New Session Started. Previous Session Is In Session Files.')};
 function readSettings(){
  const minutes=Number(section.querySelector('#autosave-minutes').value);
  if(!Number.isFinite(minutes)||minutes<.1||minutes>1440){status('Enter An Autosave Interval From 0.1 To 1440 Minutes.');return}
  settings={enabled:section.querySelector('#autosave-enabled').checked,minutes};autoAt=Date.now();
  api('preferences',{method:'PUT',body:JSON.stringify(settings)}).catch(e=>status(e.message));
 }
 section.querySelector('#autosave-enabled').onchange=readSettings;section.querySelector('#autosave-minutes').onchange=readSettings;
 for(const type of ['click','change','pointerup','keyup'])document.addEventListener(type,e=>{
  if(e.target.closest('.sessions-dialog,.session-setup,.fuel-dialog,.file-save-dialog')||type==='keyup'&&!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Enter','Delete',' '].includes(e.key))return;
  const fixture=e.target.closest('.fixture-handle'),layout=e.target.closest('#viewport');
  if(type==='pointerup'&&!layout)return;
  if(type==='click'&&(e.target.closest('input,select')||fixture&&e.detail>0))return;
  if(type==='keyup'&&(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Delete'].includes(e.key)||e.target.closest('input,select,textarea')))return;
  const target=e.target.closest('button,input,select')||e.target,label=target.getAttribute('aria-label')||target.textContent?.trim().slice(0,70)||target.id||'Layout Edit';
  setTimeout(()=>record(label,type==='click'||type==='change'),0);
 },true);
 setInterval(()=>{record();if(dirty)save();if(settings.enabled&&Date.now()-autoAt>=settings.minutes*60000){autoAt=Date.now();autosave()}},2000);
 document.addEventListener('visibilitychange',()=>{if(document.hidden){record('Session Hidden');save()}});
 // Ask before leaving while an archived log exists only in this tab.
 window.addEventListener('beforeunload',e=>{if(unsaved.length){e.preventDefault();e.returnValue=''}});
 window.addEventListener('pagehide',()=>{record('Session Closed');fetch(`${API}/api/sessions/${encodeURIComponent(current.id)}`,{method:'PUT',headers,body:JSON.stringify(current),keepalive:true}).catch(()=>{})});
 api('preferences').then(p=>{if(!goodSettings(p))return;settings={enabled:p.enabled,minutes:p.minutes};section.querySelector('#autosave-enabled').checked=p.enabled;section.querySelector('#autosave-minutes').value=p.minutes}).catch(e=>status(e.message));
 save();
 return {record,async saveNow(){record('Save Before Refresh',true);await save();return !dirty},getPreferences:()=>({...settings}),restorePreferences(p){
  if(!goodSettings(p))return;
  settings={enabled:p.enabled,minutes:p.minutes};autoAt=Date.now();
  section.querySelector('#autosave-enabled').checked=p.enabled;section.querySelector('#autosave-minutes').value=p.minutes;
  api('preferences',{method:'PUT',body:JSON.stringify(settings)}).catch(e=>status(e.message));
 }};
}
