// Wave Studio development log. Beta 0.01–0.07 were numbered retroactively from the build history;
// the in-app version label began at Beta 0.08. Newest first.
export const DEV_LOG=[
 {version:'0.34',date:'2026-10-06',title:'V0.34 — VSL Info Mode downloads and the Strange Science example site',items:[
  'Desktop 0.33.1 for Windows (signed) replaces 0.33.0 behind the download gate: the launcher minimizes to the system tray with a status pop-up, the Virtual SFX Lab logo is the exe and window icon, the receiver survives Windows socket errors and joins sACN on every active adapter, selected universes are filtered for Art-Net too, Vista Check gives separate messages for a wrong address, a busy port and a failed multicast join, and the Pete page and Spark Studio ship offline. The macOS launcher package stays at 0.33.0.',
  'Pyro Pete lives in the Discord: on the Virtual SFX Lab server he now posts five to ten times a day (09:00 to 22:00 Toronto) in channels that fit the message, rotating facts, tips, ideas, questions and the odd dry joke, and he reads what members write in the open channels and replies with insights or answers, always when mentioned or asked, sometimes on his own, with per-channel and daily limits so he never floods a conversation. Everything is grounded in his notes, the First Guide and a fact sheet; he still never gives instructions for real flame or pyro equipment.',
  'MA panel under Layout Controls: new workspaces and the default layouts place the MA panel directly below Layout Controls instead of at the end of the main column; saved workspaces whose MA panel still sat where 0.33 appended it move once, panels you placed yourself stay put. On phones the standard view shows it as a detachable MA Console card on the Stage tab, under Layout Controls by default, with Float MA, a minimize button (remembered on the device), a compact bar with a command-line shortcut and long-press drag to dock it above or below Layout Controls or the Layout view. The MA panel no longer repeats on the Sequences, Faders and Settings tabs.',
  'Landing page: a Pyro Pete section after the Spark Studio banner lists what he does in the studio (tips on hover, questions, tours, Pete\'s Fifty, settings) with links to the studio, his page and the browser extension; a slim VSL Info Mode strip under the demo links to the download page.',
  'Information mode cards and Settings → Receiver & Help gain a Download VSL Info Mode button. It opens the standalone VSL Info Mode page inside the app (/vsl/) where you choose the download: the Chromium browser extension for Comet, Chrome, Edge and Brave (with install steps), the Android tester APK, or the Windows desktop companion, which stays marked Coming soon. The page keeps its original layout, including the mock-browser example that engages Info Mode on a Strange Science article.',
  'The full Strange Science website — forty source-linked stories across six topics, search, light/dark mode, the 40-day reading trail with progress and CSV export, Reality checks, About and Sources — is hosted inside the app at /vsl/strange-science/ so every Explore / Open Strange Science link on the example page works without leaving Wave Studio. The VSL mobile reader web app and its privacy page are served at /vsl/app/.',
  'The landing page has an Information Mode section again (nav: Info Mode): the VSL Info Mode logo and Download link open the downloads page, a second link fetches the browser-extension ZIP directly, and the manual-installation steps are kept. In the studio, an orange flask button sits beside “?” and opens the same downloads page in a new tab.',
  'Spark Studio, the learning edition for early teens and classrooms, now runs in the browser at /spark/ (0.6.0: six virtual flames, four faders, cues and GO, DMX addresses and universes, music timing, seven Pete-guided missions with XP, Customize Workspace, Classroom mode). The landing page advertises it with a Pyro Pete banner that says Click Here and a Spark Studio nav link.',
  'New Meet Pyro Pete page at /pete/ introduces the tutorial guide with the live widget on the page, links to Spark Studio and the developer demo, and offers the Pyro Pete browser extension (0.2.0 developer preview, unpacked install): click the toolbar icon on any page to call Pete, click again to dismiss him. activeTab plus extension storage, no server, no account.',
  'Pete settings in six tabs (widget 0.7.0, extension 0.2.1): Look, Voice, Behavior, Tips, Gestures and AI, with Open Pete above and Reset below on every tab. New settings cover everything he can be tuned with that was previously fixed: speech bubble beside or above, eye tracking, pick up and move, walking and walking speed, voice pitch, sound effects, humor level with a mood default, greeting, idle-remark pace, bubble time, memory, hover tips with delay, spacing and tip level. The Gestures tab lists all 26 gestures with a Play preview and Play all; ticked gestures are allowed as idle fidgets, the rest only appear as reactions, and the two rude ones stay locked behind Silly humor. Mood now acts as a preset that fine-tuning overrides.',
  'Pete action bar: one centred row under his feet with voice, tip, settings and an X to close him, faintly visible until you hover. His settings open with an Open Pete button that starts the chat, and in Spark Studio the Ask Pete button now opens his settings first.',
  'Pete\'s Fifty: fifty tips, tricks, shortcuts and bits of advice covering the stage, faders, cues, workspace, recording, consoles, clocks and notes. Pick them in his settings under Tips he recites, grouped by subject with Select all, Deselect all and per-tip tick boxes; the ticked ones join his tip button and idle rotation, mixed with the panel tips.',
  'Pete placement: a Close button sits under his feet, and settings gain Always on top. Leave it on and he floats above everything; turn it off and page menus can cover him, dropping him on a panel tucks him in behind it with his head and shoulders poking out (he follows the panel as the page scrolls and remembers it), and dropping him on empty space lets him float.',
  'Pete fidgets: six new idle gestures. He checks his phone (thumb tapping, eyes down), scratches his wrist, scratches his backside with a hip shimmy and a guilty glance, zones out with glazed eyes and snaps back, and jiggles his left or right leg. Each has its own one-liners and all appear in the demo page gesture list.',
  'Pete in the studio: he peeks over the bottom edge next to How to explore, eyes following your pointer. Click him and he jumps out with the Wave Studio tip pack, the site assistant and the studio voice; hover a panel for a tip, press his dash to send him back. Picking him up no longer freezes his eyes: they follow the drag and settle on the pointer when he lands.',
  'Studio narration now speaks with the Virtual SFX Lab voice: the site owner\'s own voice, generated on the server through ElevenLabs (two takes to choose from under AI Assist → Narration). Read Aloud in AI Assist, Information mode and the tutorials, and Pete in Spark Studio and on his page, all use it; the device voice remains the fallback and a per-visitor allowance protects the monthly voice budget. Pete\'s settings gain a Voice source choice (Studio, Device, My ElevenLabs) so the browser extension can use your own ElevenLabs key and voice ID.',
  'Pete settings: hover him and press the gear for size (tiny to huge), corner, voice and speed, mood, body language and humor toggles, reset position and memory, and an AI connection where you add your own Perplexity, OpenAI, Anthropic, Gemini or OpenAI-compatible key so Pete can answer beyond his built-in notes. Keys stay in the browser (extension storage in the extension) and go only to the provider you choose. Available in Spark Studio, on the Pete page and in the extension.',
  'These VSL, Spark Studio and Pete downloads are developer previews, not store listings; they are not part of the desktop Wave Studio packages.']},
 {version:'0.33c',date:'2026-10-05',title:'V0.33c — open beta: the full studio opens directly',items:[
  'Every studio button on the landing page (hero, demo follow-up, Full studio card, closing section) now opens the full studio immediately. The seven-day trial dialog, the Start Trial redirect and the lock screen no longer run; the studio stays free in the browser for the whole beta. Landing-page copy, FAQ and structured data say so, and the Full studio price block reads Free during the beta with a note that a one-time price may follow.',
  'The Windows and Mac app downloads keep their purchase / tester-code gate (receiver packages are never free public downloads); a redeemed tester code now shows as tester access in the studio header and unlocks both downloads.',
  'The trial code stays in place behind ?gate=on for testing and is off by default; 127.0.0.1 is unchanged.',
  'Header: a ← Back to Demo button (arrow only on phones) returns to the landing page; studio layouts, cues and workspaces stay saved. Minimized panel headers now centre their checkbox and restore button on the title line instead of sitting a few pixels high.']},
 {version:'0.33b',date:'2026-10-05',title:'V0.33b — receiver console presets for grandMA3 and grandMA2',items:[
  'The desktop receiver now asks which console it listens for: the Windows app has a Console drop-down (Vista 3, grandMA3 console / onPC, grandMA2 console / onPC, Other sACN / Art-Net source) above Input mode, the macOS launcher shows a numbered menu (preview, sACN or Art-Net from Vista 3, sACN from grandMA3, sACN from grandMA2, Art-Net from a grandMA, sACN from another console), the Python package adds Start-Wave-Studio-grandMA.cmd, and receiver.py takes --console vista | grandma3 | grandma2 | other. The preset sets the console-specific output hints and the status line (Listening — waiting for grandMA3), and the Vista & MA Receiver dialog opens on that console’s tab with a summary of the running receiver.',
  'Receiver 0.33.0 reads sACN in both the ratified E1.31 Final layout and the older Draft layout grandMA2 still offers (Draft packets are counted separately), accepts unicast as well as multicast sACN (grandMA3 Unicast mode), and ignores Art-Net ArtSync. Nothing is transmitted to the console.',
  'First Guide Part 5 gains the Receiver console presets table and updated grandMA2 Draft / grandMA3 unicast notes plus troubleshooting rows; the receiver dialog, written tutorial, Control Info and desktop START-HERE notes describe the new options. Desktop packages 0.33.0 (signed Windows build and macOS launcher package, downloads swapped on the site) carry this receiver and the MA panel.']},
 {version:'0.33',date:'2026-10-05',title:'V0.33 — MA panel: a grandMA command section inside Wave Studio',items:[
  'New MA panel under the Cue Stack (and in Add Panels): the key section of a grandMA2 / grandMA3 — X1–X10, Go+, Go−, Pause, Off, On, Top, Goto, Temp, Toggle, Time, Select, Learn, Fixture / Channel, Group, Preset, Cue, Sequ, Exec, Page, Macro, View, Effect, Store, Update, Delete, Edit, Label, Copy, Move, Assign, Align, At, Full, If, MA, Set, Thru, the number pad, Please, Esc, Oops, Clear, Blind, Freeze, Prvw, Highlt, Solo, Backup, Setup, Help, Menu / Tools, List, Prev, Next, Up, Down, Page− / Page+. A Key set menu shows the grandMA3 keys, the grandMA2 keys or all of them.',
  'Each key does the closest Wave Studio action with MA grammar (function, objects, value, Please): Fixture 1 Thru 4 At 30 Please parks four heads at 30° (Align fans them), Store Cue records the selection, Group 3 recalls a stored group, Preset 12 applies program 012, Exec 5 At 60 sets fader 5, Go+ runs the Cue Stack, X keys start faders 1–10 (Page 2: 11–20), Oops undoes, Blind switches to Presets, Freeze pauses the stage. The command line accepts the same words typed (f 1-4 at 30). Learn, If, Set, View and Effect report that they are not modelled.',
  'Physical grandMA consoles can press the keys: every key is a button target in the control universe (Console mapping → grandMA keys; Patch Keys In Order fills channels 101–184). Patch one dimmer per key on the desk, assign Temp executor buttons, send the universe over sACN and connect. Export For grandMA adds 06-ma-keys.csv with the key list and channels.',
  'The receiver button is now Vista & MA Receiver. First Guide Part 5 gains section 5.7 (the MA panel, command table and physical-console mapping) and troubleshooting rows; a written tutorial and Control Info entry cover the panel. Desktop packages carry this change in their next build.']},
 {version:'0.32',date:'2026-10-05',title:'V0.32 — grandMA2 / grandMA3 live input and Export For grandMA',items:[
  'Export For grandMA (Layout Controls, next to Export For Vista 3): a ZIP with a GDTF fixture type for the Explo X2 Wave Flame (validated against the official GDTF schema; Tilt, Speed, Ignition, Open Time, Program with a named channel set per sequence, Arm), an MVR scene for grandMA3 with every unit\'s absolute address, stage position and mount rotation (validated against the MVR schema), a grandMA2 fixture-type XML and fixture-layer XML for EditSetup Import, and CSV sheets for patch, cues, cuelists, cue contents (DMX and %) and fader assignments. The dialog asks for the metres the units cover and remembers them on the device. GDTF Only saves just the fixture type.',
  'Vista / Receiver Settings now has Vista 3, grandMA3 and grandMA2 tabs with the console-side sACN and Art-Net output steps, universe numbering (sACN universe 1 = Art-Net port address 0 = Wave Studio slot 0) and the onPC hardware rule. The receiver itself is unchanged: standard sACN E1.31 Final and Art-Net from any console.',
  'First Guide Part 5 gains section 5.6 (grandMA2 / grandMA3 live input and export), new troubleshooting rows and MA documentation sources; the written tutorials and Control Info cover the new button.']},
 {version:'0.31c',date:'2026-10-04',title:'V0.31c preview — Vista 3 show file download and a tidier phone layout panel',items:[
  'AI Assist reads the manual: Find Tutorial now searches the First Guide (all five parts) as well as the written tutorials and lists matching sections under From The First Guide with Open In Manual and Read Aloud. Every tutorial gains an Open In Manual button that jumps to the closest section. Search With Perplexity opens the question on perplexity.ai in a new tab (no account needed).',
  'Search-engine visibility: the landing page, studio and First Guide now carry descriptive titles, meta descriptions, canonical links, Open Graph tags and structured data (Organization, WebSite, SoftwareApplication with pricing, and the FAQ as FAQPage), plus robots.txt and a sitemap, so searches for Wave Studio, Virtual SFX Lab, Explo X2 Wave Flame visualizer and related terms can find the site. The owner statistics and companion monitor pages are excluded from indexing.',
  'Desktop packages 0.31.2: the code-signed Windows build and the macOS launcher package now carry this V0.31c AI Assist update (manual-linked AI Assist, Information mode, checklists, natural Read Aloud; studio narration and the site assistant remain hosted-site features). Buyers and tester-code holders download them from the landing page; the same files and SHA-256 sums are on the public GitHub downloads repository. Existing installs: unzip over the old folder, layouts and settings are kept.',
  'Studio narration: Read Aloud can now use a cloud voice that sounds the same on every device (OpenAI gpt-4o-mini-tts via the site, or your own connected OpenAI key). Choose Studio voice, Device voice or automatic in AI Assist → Read Aloud Voice & Narration, pick from thirteen studio voices, and preview. Site narration is part of the full studio with a fair-use allowance; clips are cached so repeat reads of tutorials and manual excerpts are instant. The text being read is sent to the narration service only when studio narration is in use; the device voice stays fully offline.',
  'More human Read Aloud: AI Assist and Information mode now pick the most natural voice your device offers (Natural, Enhanced, neural or premium voices first), speak sentence by sentence with short breaths, and read Markdown, shortcuts and units cleanly (no asterisks, URLs or citation numbers). A new Read Aloud Voice section in AI Assist lets you choose the voice, pace and pitch, with a preview; the choice is saved in this browser.',
  'Site assistant (Perplexity Agent API): when the site owner has configured a Perplexity API key on the server, AI Assist answers questions through the Agent API with web search and lists its sources, without any set-up by the visitor. It is part of the full studio (trial or licence) with a fair-use allowance per visitor and per day; a visitor’s own connected assistant always takes precedence. The Perplexity option under Your AI Assistant now also uses the Agent API (preset names fast/low/medium/high/xhigh or a provider/model id).',
  'Your AI Assistant: connect the assistant you already use from the AI Assist menu. Perplexity is the recommended default (sign-up and API-key links included); OpenAI, Anthropic Claude, Google Gemini and any OpenAI-compatible endpoint (including a local model server) are also supported. The key is stored only in this browser and sent only to the chosen provider. Whatever you connect runs on that provider’s own usage plan and billing, outside Virtual SFX Lab. When connected, questions are answered from the manual excerpts and tutorials, with sources where the provider returns them.',
  'Information mode (Ctrl + ?): a ? toggle beside Manual turns the pointer into a help cursor. Hover any button, field, fader, fixture or panel title to see what it does, how to use it, the matching First Guide section and a tutorial, with Read Aloud and Ask AI when an assistant is connected. Clicks are held while the mode is on so nothing fires; click to pin a card, Tab to describe the focused control, Esc to exit. The toggle is also in the Buttons list and under Settings → Receiver & Help.',
  'Checklists: the Checklist panel now holds more than one list. New Checklist opens an editor (title + Markdown steps with an Insert Example button); custom lists can be edited, deleted and downloaded like the built-in Colleague Test Checklist. They are stored in this browser only.',
  'Discord community: Join the Community links (Discord logo + caption) in the landing-page header and footer open the Virtual SFX Lab Discord in a new tab. Beta-tester sign-up now runs through the Discord: DM strangebrewgames with the application form pinned in #faq; tester keys are handed out in the Beta Lab channel.',
  'Panel button list: the Buttons editor (Customize Workspace) now lists every button in the app, not only the fixture and file controls. Clock, timecode, cue stack, macro, notes, screen and chess actions, plus the toolbar (Presets / Virtual Faders / Live Input, Vista settings, AI Assist, Chat, Checklist, Camera, Settings, Multi-Screen, Refresh, Layouts, Add Panels, Collapse All, Full Screen, Screenshot, Manual, Shortcuts, theme) can be added as shortcuts to any panel. Buttons with the same name show their panel so the list stays unambiguous.',
  'Rotate fixtures: rotate buttons (⟲ 5° / ⟳ 5°) sit beside Delete selected and again in the Layout Controls row beside Undo; both sets and their degree readouts stay in step. Selected units turn together about their base in 5° steps through a full 360°; hold a button to keep turning, press [ or ] on the keyboard, and click the degree readout to reset to 0°. Rotation is saved with layouts and defaults, shown in the fixture label and exported in the Vista fixture sheet.',
  'Site statistics: a first-party page counter on the landing page and studio records the page, referring site, screen class and a salted digest of the visitor id — no cookies, IP addresses or third-party scripts — and an owner-only statistics page (key required) shows daily views, unique visitors, pages, referrers, devices, and studio usage such as trials, licenses and orders. Counting starts with this release.',
  'Beta testers wanted: the landing page has a new Help shape the lab section (and a Beta testers nav link and FAQ entry) explaining what testers contribute — real-world use, specific notes, ideas from the field — and inviting enquiries by email for a tester code.',
  'New logo: the Virtual SFX Lab mark is now a pixel-art Erlenmeyer flask with a small flame at its mouth, in the same accent colour, drawn on a 16×16 grid so it stays crisp at header size. It appears in the studio top bar, the landing page header and the watermark on recorded videos.',
  'Vista 3 Explo Layout: a ready-made Vista 3 show file (.v3s, 0.6 MB) with the Explo X2 Wave Flame fixtures patched to match the Wave Studio layout is now part of the program. A Vista 3 Layout File button sits beside Vista / Receiver Settings in the toolbar (and in the Receiver & Help settings group); the Vista 3 receiver setup dialog links the same file with a short how-to. Free download, no licence needed.',
  'Fix: the First Guide opened as a blank panel on the hosted site because the host now forbids framing its pages; the manual is fetched and shown inside the dialog instead, with Part links, images and Open in new tab working as before.',
  'Desktop packages 0.31.1: the Windows build (code-signed, about 15 MB) and the macOS launcher package (about 3 MB) now carry the V0.31c studio including the Vista 3 Explo Layout file. Buyers and tester-code holders download them from the landing page; the same files are on the public GitHub downloads repository. Existing installs: unzip over the old folder, layouts and settings are kept.',
  'Phone Layout Controls: the layout buttons are now two even rows — Save, Load, Default and Reset Layout on the first row; Export For Vista 3, Session Files, Autosave and Recordings on a second row underneath — instead of nine buttons squeezed into one line. Desktop and custom-workspace cards are unchanged.',
 ]},
 {version:'0.31b',date:'2026-10-04',title:'V0.31b preview — purchases open, tester codes and the signed Windows download',items:[
  'Tester access: a Tester Access box on the landing page accepts a code shared personally by the developer. A valid code licenses the full studio in that browser (no seven-day limit) and unlocks the Windows download, free of charge until version 1.0 is released. Codes are never published and do not appear in the site files; the studio service compares a salted digest and throttles repeated guesses.',
  'Windows download on the website: Virtual SFX Lab 0.31 for Windows (x64, code-signed with Azure Artifact Signing, about 14 MB) is served by the studio service to licensed visitors through fifteen-minute download links, with the SHA-256 shown beside the button. SmartScreen may still warn because the publisher identity is new: choose More info, then Run anyway; never disable antivirus.',
  'Purchases open: Buy buttons for the full studio (browser), the Windows app and the macOS app — $29.99 CAD each, one-time, plus tax — hand off to Lemon Squeezy as merchant of record; the studio service creates each checkout with the visitor identity attached and grants the matching entitlement when the paid-order webhook is verified against the Orders API (refunds revoke it). Every price now carries “subject to change as updates continue”; purchases made do not expire. The macOS launcher package joins the Windows build as a download for buyers and testers.',
  'Studio: a licensed browser shows a “Tester access · free until 1.0” pill instead of the trial countdown; the trial-ended screen links to the code box. Landing page: Windows card, pre-release note, setup steps (now for the signed exe launcher) and FAQ updated. Purchases remain closed.',
 ]},
 {version:'0.31',date:'2026-10-04',title:'V0.31 preview — Virtual SFX Lab, Module 1: Wave Studio, seven-day trial',items:[
  'Rebrand: the product is now Virtual SFX Lab; Wave Studio is its first module (the Explo X2 Wave Flame). Header, landing page, footer, page titles and the recording watermark (“Made with Virtual SFX Lab · WaveStudio Beta 0.31”) carry the new names. The wave mark stays as the Module 1 logo for now.',
  'Seven-day full-studio trial: the landing page demo stays free forever. Press Start Trial on the landing page to open the full studio for seven days; the header shows a trial pill with the days (then hours) left. When the trial ends the studio locks behind the purchase screen — saved layouts, cues and workspaces are kept — and the demo keeps working.',
  'Trial bookkeeping: the start time is stored in the browser and, when the studio backend is reachable, against the private visitor identity the backend already uses for layouts (GET /api/trial, POST /api/trial/start; the earlier start always wins). Clearing the browser does not restart the clock on the published site. 127.0.0.1 — the paid local receiver and the development tests — is never gated; add ?gate=on to any URL to force the gate for QA.',
  'Pricing preview: Virtual SFX Lab full studio $29.99 CAD one-time after the trial; Vista receiver add-on $29.99 CAD one-time per computer; demo free. Sales are still not open — checkout, activation and refunds are unchanged placeholders.',
  'The First Guide now opens by itself when the full studio starts, so a new user can read the instructions before navigating the studio; an “Open when the studio starts” box in the manual header turns this off (remembered per browser). The desktop packages open on the demo landing page first, for the same reason.',
  'Desktop builds: Virtual SFX Lab for Windows 0.31 is a one-folder executable (Virtual SFX Lab.exe + _internal, PyInstaller, unsigned) bundling Python, the receiver (0.31.0: in-app manual framing allowed, demo page first) and the complete web app including the manual; the earlier single-file build that antivirus heuristics flagged is retired. The Windows launcher window now opens at the size of its own content, centred on the screen, scaled with Windows display scaling, and compacts its text on short high-scale screens (for example 1366×768 at 150 %) so every field and button is visible without dragging or scrolling. It has two clear actions — “Start receiver + open studio” (Enter) and “Skip for now — open studio without a receiver”, which opens the demo, studio and manual with no sACN/Art-Net input; the studio’s Live Input button explains how to start the receiver when it was skipped. Virtual SFX Lab for macOS 0.31 is a readable .command launcher package (Python 3.10+, no pip packages) with a Preview-Only launcher. Both verified with synthetic sACN outside Windows/macOS; native Vista acceptance still pending.',
  'Landing page: new Modules section (Module 1 Wave Studio available; further fixture modules planned to run in tandem on one stage), rewritten pricing cards and FAQ entries for the trial, modules and the receiver add-on; a Start Trial dialog states the terms before the clock starts.',
 ]},
 {version:'0.3',date:'2026-10-04',title:'V0.3 — First Guide, console follow and release clean-up',items:[
  'V0.3 rolls the Beta 0.29 a–d hotfix series into one release: the First Guide, console follow, clock controls, the live visitor count and the footer credits ship together, and recorded videos now carry the “Made with WaveStudio Beta 0.3” watermark.',
  'Console follow: the virtual faders now move with the matching physical faders on the Vista console. In Live Input the Virtual Faders panel mirrors the incoming channels (fader position, 0–255 value, percentage, a VISTA tag and an orange pulse on the strip that just moved) while Vista keeps ownership of the output. In mapped mode, DMX-priority faders now respond to the console as well instead of being skipped.',
  'Play (▶) and intensity (☼) flash keys, Macro keys and the Bank Master light up with an orange hit flash when the console presses or raises their mapped channel, in both Live Input and mapped mode. Channels are set in Vista / console mapping (Play flash 1–20, Sun flash 1–20, Macro F1–F12, Bank master); buttons read pressed at 128 and above.',
  'Manual button (header, next to Reference & Notes) opens the Wave Studio First Guide inside the studio: an index page plus five tutorial parts (landing demo, studio layout, presets → favourites → cues → cue stacks, virtual faders, sACN and Vista) with numbered image callouts. Open In New Tab keeps it beside the workspace.',
  'Clock panel: a small round play/stop button sits beside the running time whenever Stopwatch or Countdown Timers is selected (main and secondary clocks). The same button appears in the minimized Clock bar, and the minimized time is now centred between the title and the +/- button.',
  'Footer: a live visitor count next to How To Explore shows how many browsers are in the studio right now (anonymous heartbeat every 30 seconds; the server keeps only a hashed id in memory for 75 seconds and writes nothing to disk). Hidden when the local backend is not running. A small Claude mark with an “And I helped!” bubble joins the Built By Perplexity credit.',
 ]},
 {version:'0.29',date:'2026-10-01',title:'Panel preferences, button customization and chess',items:[
  'Export For Vista 3 (Fixture & File Controls): downloads a ZIP hand-off package for Vista 3. Vista\'s .v3s show file is a closed format no outside program can write, so the package uses Vista\'s documented imports instead: 01-patch.csv for Patch > Import Patch File (ID, Univ:Adrs, Fixture Type, Fixture Name; Wave Studio port 0 = Vista universe 1), 02-cues.csv for File > Import Cues CSV (Vista 3 R5+: cue numbers, names, fade/delay/hold, notes listing each cue\'s fixtures and sequences), 03-fader-assignments.csv (20 faders, flash levels, loop, DMX-in addresses, chase and macros), 04-cue-contents.csv (per cue, per fixture CH1–CH6 values to store in Vista\'s programmer), a fixture-profile channel map for Vista\'s Fixture Editor and a README with the steps. Vista imports structure and timing, not fixture values, so each cue needs one programming pass from sheet 04 before operating.',
  'Cue Stack panel (under the Cue Recorder; Add Panels for older workspaces): a cuelist that steps through recorded cues with a big GO button, Back, Release and Top. Each entry has a Go, Follow (auto-start Wait seconds after the previous cue finishes) or Timecode (fires when the Timecode panel passes HH:MM:SS:FF) trigger, inline notes, a fade/duration readout that opens the cue timing editor, up/down reordering and remove. Click a cue name to make it Next, double-click to play it now, Space = GO while the panel has focus. Multiple named stacks with Loop; stacks save with the layout and sync through shared layouts. Minimized bar shows the running and next entry plus a GO button.',
  'Export CSV For Vista on the Cue Stack panel downloads the stack as a Vista 3 cuelist CSV (Cue, Name, Fade In, Fade Out, Delay, Hold, Follow, Wait, Timecode, Notes) for File > Import Cues CSV. The Export For Vista 3 package now also includes 02-cuelist-<stack>.csv for every stack with entries.',
  'Fuel Estimates: header shows a Fuel Type menu (Isopar, Propane, Butane, Naphtha, Gasoline) that applies to all units and saves with the layout, plus a Session Total of litres and approximate kilograms burned by all units since load (Reset clears it). The fuel dialog lists the session total and the minimized bar shows it.',
  'Panel headers: the minimize / maximize +/- button is locked to the top-right corner of every panel and never wraps to a second line. Minimized Nozzle Direction, Home Position and DMX Patch readouts sit directly after the panel label with tighter spacing.',
  'Export For Vista 3 dialog gains a Fixture Build Sheet button that downloads the Explo X2 Wave Flame Fixture Editor build sheet on its own as a Markdown file (also included in the package as .md and .txt).',
  'Vista 3 fixture profile: the export\'s 05-fixture-profile sheet is now a field-by-field build sheet for Vista\'s Fixture Editor (Main tab values, the six Add DMX Channel entries with Feature Class/Type and defaults, DMX ranges, all 88 CH5 program slots and optional DMX macros). Vista\'s .v3f and .fix2 fixture files are encrypted, so the profile is built once in Vista and exported from there with Patch > Export Fixture Profiles.',
  'Nozzle Direction and Home Position are now separate panels (right column by default; existing saved workspaces gain the Home Position panel next to Nozzle Direction). Minimized Nozzle Direction shows the live angle in its bar; minimized Home Position shows the home angle (Home +30°) or Home: No Selection.',
  'Minimized Timecode bar is tighter so the maximize + button sits beside Arm on one line at the default card width; Home Position controls wrap cleanly at narrow panel widths.',
  'Every recorded video (demo, Studio layout and camera clips) now carries a small bottom-left watermark: the Wave Studio logo and "Made with WaveStudio Beta 0.xx", using the build version that recorded it. It sits just above the sequence caption when Record Sequence is on.',
  'Landing page demo: new Record button above the demo layout records up to 1 minute of the demo as MP4 (WebM only where the browser cannot encode MP4). Videos open in a Demo Videos window to preview, download or remove; nothing leaves the tab.',
  'Record Sequence option for demo and Studio layout recordings: burns the running sequence (number, name, units and active look) into the video as a caption and adds a downloadable timestamped sequence log for each clip.',
  'Clock panel: World Clock now picks from a dropdown of every time zone (grouped by region, with its current UTC offset) instead of typing a zone name.',
  'Clock panel: manual Time Adjustment (±HH:MM:SS, up to 24 h, with ±1 h / m / s nudges and Reset) shifts Current Time, World Clock, Alarm, Time To Show and Time Until Load Out to match a show or venue clock. Saved per clock, including the secondary clock.',
  'Customize Workspace: a bin pops up while you drag a button; drop on it to remove that button from the layout (restore it from the panel’s Buttons list). Release / Stop controls cannot be binned.',
  'Pressing Customize Workspace saves the current arrangement; Revert Customize, next to it, returns to that saved point. Layouts saves and loads named Customized Layouts per screen type, keeping your notes. Layouts and the revert point are saved privately for this visitor on the server, so they work even where browser storage is blocked.',
  'Customize Workspace: drag any panel button anywhere inside its panel. Drop it on another button to share that button’s row, or between controls to start a new row. Buttons in a row share its width equally.',
  'Customize Workspace: click a button (or drag its corner) to set its own width and height in pixels; Auto Size and Original Spot undo either change. Layouts save per device and are validated on the server.',
  'Hotfix: clicking or typing in text boxes (fader names, values, DMX channels and every other panel field) no longer jumps the screen. The page only reserves room for the layout screen when it is actually pinned over the page.',
  'Hotfix: drag-selecting text stays inside the panel where it started; it no longer spills into other panels or scrolls the page. Panel title bars no longer start text selections.',
  'Hotfix: the mobile Studio Layout Controls sequence dropdown uses a searchable in-app chooser instead of a native browser popup. It stays usable while customizing or floating panels; manual Auto-Next pauses while choosing.',
  'Follow When Selected is available on Layout, Virtual Faders, Fixture & File Controls and Fuel Estimates, using the existing Notes follow behavior.',
  'Settings offers independent Left, Right or Centre panel-label alignment for desktop and mobile, including collapsed headers.',
  'Customize Workspace unlocks button dragging within control groups, reversible removal/restoration and additional shortcuts to existing app actions. Stop and release controls cannot be removed. Workspace saves include these preferences.',
  'Add Panels includes Chess, identified by a single white pawn image. Play a beginner computer or two players sharing one device, with legal moves, promotion choices, undo and PGN export. Online chess matchmaking is not included.',
  'Chess computation runs in a worker rather than the show-rendering thread. Existing layouts and the manually reported credit total are preserved.'
 ]},
 {version:'0.28',date:'2026-09-30',title:'Notification-to-reply shortcuts',items:[
  'Click the flashing Chat button or the Friends & Chat New badge to open the newest unread conversation and focus its message input.',
  'Click New Message on a detached conversation to restore its collapsed panel and jump to its reply box without changing the docking mode.',
  'Browser notification clicks open the specific notified room and focus the same input. Browser notification support and permission are still required.',
  'Unsent text and attachments are retained per room in this tab while navigating conversations. Nothing is sent automatically; drafts are not durable across refresh or closing.'
 ]},
 {version:'0.27',date:'2026-09-30',title:'Panel polish, mobile sequence picker and live talk toggle',items:[
  'Desktop panel labels align left in both expanded and collapsed views. Mobile collapsed titles remain centered.',
  'Nozzle Direction & Home is the new default panel name. Its collapsed header shows nozzle direction plus the selected units’ Home value, or Mixed when their values differ. Custom panel names are retained.',
  'Desktop Layout Controls defaults to 340 px total height. Its regular height slider is removed; Customize Workspace exposes a numeric height field. Phone sizing is unchanged.',
  'Undo now sits beside Select Multiple in desktop Layout Controls, sharing the existing layout history.',
  'The landing demo uses a searchable in-app sequence picker on phones. Touch selection works in normal and expanded demo views; choosing a sequence disables Auto-Next as before.',
  'Chat Push To Talk is a tap-on / tap-off live microphone toggle. On joins the selected room call; other users must Join Call to listen. Off, Leave Call, room changes, Stop All Media and hiding the app stop the microphone. Browser permission and network connectivity are required; no audio is saved by this toggle.',
  'Notes: Scroll Settings is now Note Settings. Export Notes lives inside that area instead of the main toolbar.',
  'Fixed an existing server validation mismatch that rejected custom panel names during online workspace saves.'
 ]},
 {version:'0.26',date:'2026-09-30',title:'Save As: choose file names and supported destinations',items:[
  'Manual file saves and exports now open Save As, with an editable file name and automatic file extension. Save Layout retains its section-selection step.',
  'Supported standalone browsers offer a device Save As window for choosing the destination folder. Devices with file sharing offer a share sheet, including Save to Files where available.',
  'Browser Downloads remains available when folder selection is unsupported or blocked. The dialog explains that download location is controlled by browser settings.',
  'Layout and workspace backups, session files, notes, chat transcripts, screenshots, recordings, checklist results and Dev Log exports use the shared flow.',
  'Cancel does not start a fallback download. Invalid file names and save failures are explained; automatic online saves remain uninterrupted.'
 ]},
 {version:'0.25',date:'2026-09-30',title:'Mobile long-press panel docking and floating',items:[
  'Phone: hold a panel header for about half a second, then drag. The highlighted edge shows where it will dock above or below another panel; drop elsewhere or on the Float zone to leave it floating.',
  'Hold and release without moving to open explicit Float Panel, Dock Above, Dock Below and Cancel choices.',
  'Works with expanded, collapsed, duplicate and already-floating workspace panels, Layout / Layout Controls, support windows and detached conversations. Customize Workspace and Ctrl + Shift are not required.',
  'Short taps still rename workspace panels; swiping before the hold activates still scrolls. Cancelled gestures do not change panel placement, fixtures or playback.',
  'Workspace panel moves use the existing saved mobile arrangement. Separate control/support window placement remains in-session. Desktop dragging and right-aligned collapsed labels are unchanged.'
 ]},
 {version:'0.24',date:'2026-09-30',title:'Desktop collapsed labels aligned right',items:[
  'Desktop collapsed panel titles and the compact Layout Controls label align to the right. Expanded headers are unchanged.',
  'Mobile retains the centered collapsed titles, compact playback bars and Undo placement from Beta 0.23.'
 ]},
 {version:'0.23',date:'2026-09-30',title:'Compact Layout Controls on every screen and centered mobile panel bars',items:[
  'Desktop: Layout and Layout Controls are separate panels. Controls can be resized vertically, floated, moved and docked back below Layout without overwriting saved workspace documents.',
  'Phone and desktop: minimize Layout Controls to a small Previous / Play-Pause / Next bar. Expand restores the full controls; playback always uses the existing transport, including live-input restrictions.',
  'Collapse All also minimizes Layout Controls while keeping the compact playback bar accessible. Expand All restores it.',
  'Phone collapsed panel titles now share a uniform, centered title row; quick settings and status readouts remain centered underneath.',
  'Phone: Undo sits directly beside Multi-Select, sharing the original layout undo history and disabled state.'
 ]},
 {version:'0.22',date:'2026-09-30',title:'Independent phone layout controls, document exports and optional contact profiles',items:[
  'Phones: a larger Layout View with its own height slider. Layout Controls are a separate adjustable, scrollable panel, docked below the view by default; float, drag and redock them without resetting fixtures or saved desktop workspaces.',
  'Notes: export the current note or all notes in a panel as TXT, Markdown or a printable HTML document.',
  'Chats: Markdown and printable HTML join the existing full TXT and JSON transcript downloads. Media filenames are included, not the media files.',
  'Your Friend Code now has a quick Copy button with a manual-copy fallback when clipboard permission is unavailable.',
  'Only a display name is required for a visitor chat profile. Optional email, phone, company, role, location, website and other contact details can be added or edited. They remain private unless explicitly shared with accepted friends.'
 ]},
 {version:'0.21',date:'2026-09-30',title:'Landing demo fit, movable support, chat alerts and detachable conversations',items:[
  'Landing demo: its own six-unit starting arrangement, unrestricted fixture dragging, visible internal sequence and zoom controls below the stage, and Auto-Next on by default.',
  'App Guide: drag its floating header without Customize. Friends & Chat: Ctrl + Shift + drag moves its floating header.',
  'Screenshot button shows the Ctrl + Shift + S shortcut on hover.',
  'Panel renaming uses non-scrolling focus; workspace redraws preserve page and panel scroll positions.',
  'Chat: opt-in notifications and an adjustable-volume ding; unread room indicators on the Chat button and collapsed support or conversation headers. Browser alerts need permission and the app must remain open.',
  'Undock the selected conversation independently; float it or dock in workspace columns. Return To Chat restores it without changing the selected room.',
  'Save / Share Chat: review the complete text transcript, download TXT or JSON, or share through the device share sheet with a clipboard fallback. Media filenames are listed; media files are not embedded.'
 ]},
 {version:'0.20',date:'2026-09-30',title:'Unit List drag-select, per-fader DMX patch, keyboard shortcuts, phone layout and Dev Log',items:[
  'Unit List: drag the mouse across the fixture buttons to select several units at once; Ctrl/Cmd or Multi-Select adds to the current selection; Esc cancels the drag.',
  'Fader Settings: new DMX Patch section. Set each fader to any DMX address (0–512) and its own universe (1–32768), or let it follow the bank universe. Addresses may repeat across universes but not within one. A small U tag on each strip shows the fader’s universe.',
  'Fader “Settings” labels and Virtual Rear Panel keys are now centered in their buttons.',
  'Shortcuts: Ctrl + Shift + P opens or closes Add Panels; Ctrl + Shift + F enters or exits Full Screen; Ctrl + Shift + S saves a PNG screenshot of the layout view; Ctrl + Shift + R starts or stops layout recording. Hover hints on Add Panels and Full Screen show the shortcut.',
  'Ctrl + Shift temporary customizing now waits for a short hold, so the new letter shortcuts never flicker the workspace into edit mode.',
  'Phones: the layout fits all six units across the screen by default; the sequence picker and a zoom slider sit directly under the layout, followed by the transport; the layout no longer sticks over the sequence library while scrolling; the More options are laid out on an even grid.',
  'Settings: new Dev Log tab with the full history from Beta 0.01 to the current version.'
 ]},
 {version:'0.19',date:'2026-09-30',title:'Home, panel rename, quick actions and new default layout',items:[
  'Home button with an adjustable home angle per unit: parks the selected nozzles and releases any cue, flash or chase driving them (also H key, macro and right-click menu).',
  'Click a panel title to rename it; Collapse All / Expand All; Show buttons in Add Panels.',
  'Fixture quick-action menu on right-click or long-press (Home, Invert, Fuel, Apply, Rename, Select All, Fit View, Remove); keyboard shortcut list on the ? key.',
  'Landing page “Explore The Demo” opens the expanded full-screen demo.',
  'Button labels centered throughout; reworked phone Stage tab with even two-column grids.',
  'Shipped desktop default layout rebuilt from the supplied Default Desktop Layout file (sequence 064, alternating inversion, 200% flame scale, dark theme).'
 ]},
 {version:'0.18',date:'2026-09-30',title:'Demo-first landing page',items:[
  'Landing page opens straight into an interactive, one-tap demo layout.',
  'New social preview artwork for link sharing.'
 ]},
 {version:'0.17',date:'2026-09-30',title:'Live collapsed panel controls',items:[
  'Collapsed panels keep their key control on the minimized bar: flame scale slider, nozzle direction reading, nozzle type menu, selected unit count, DMX patch, angle limit menus.',
  'Timecode panel shows the running time with play / pause on its collapsed bar; timecode preview arming.'
 ]},
 {version:'0.16',date:'2026-09-30',title:'Layout video recording and future fixtures',items:[
  'Red-dot recorder in the layout saves silent visual rehearsal clips (MP4 or WebM, browser dependent) to a Recordings list in File Controls, with quality, format, frame rate and auto-stop settings.',
  '“+ Add SQP” and “Add Hydra” fixture buttons marked Coming Soon.',
  'Smaller credit trend line; fader 6 wheel step defaults to 50%.'
 ]},
 {version:'0.15',date:'2026-09-30',title:'Secondary clocks, fixture names and layout chase',items:[
  'Clock panel shows a secondary time under the primary clock; the primary time stays visible when minimized.',
  'Minimized panels with a single checkbox expose it on the bar.',
  'Fixture Position & Name panel with editable fixture names.',
  'Session Files and Autosave split into separate buttons; zoom slider on the landing demo.',
  'Hover hint for the Ctrl + Shift customize shortcut; moved fixtures keep their positions when new units are added.',
  'Layout Chase button with 0–480 BPM rate and Forward / Backward / Random direction; Odd / Even selector.',
  'Live credit trend line beside the development-credit counter.'
 ]},
 {version:'0.14',date:'2026-09-30',title:'Stable selection, Settings and safe refresh',items:[
  'Selecting fixtures no longer re-centres or shifts the layout; note typing no longer moves the page.',
  'Settings button with tidy categories, also available in Full Screen.',
  'Refresh button with a save-first warning (Save or Refresh Without Saving).',
  'Multi-screen button with monitor layout choices.',
  'Notes: working Delete button and drag-to-reorder note buttons.'
 ]},
 {version:'0.13',date:'2026-09-30',title:'Stable tabbed notes and scroll controls',items:[
  'Eliminated screen jumps and width changes when using the notes panel.',
  'Adjustable scroll sensitivity for mouse-wheel and text-selection scrolling in notes.',
  'Notes shown as named buttons beside Add Note instead of a long list.',
  'Phone toolbar: Multi-Select and Arrange on a single row; confirmation bubble when a New Default Layout is saved.'
 ]},
 {version:'0.12',date:'2026-09-30',title:'Note editor isolation, monitors and layout controls',items:[
  'Centered text on the Virtual Rear Panel; Fixture Position and Invert became separate panels.',
  'Enter in notes no longer jumps, refreshes or re-docks a floating panel; text selection stays inside the note.',
  'Button Size slider in settings; support for up to four monitors with companion windows.',
  'Invert button in Fixture & File Controls; Arrange moved next to Fit View.',
  'New Default Layout and Load Default Layout buttons with a saved indicator; Comet browser launcher panel.',
  'Spacing slider follows the zoom level; “Designed by Strange Brew Studios 2026 - Built By Perplexity” footer.'
 ]},
 {version:'0.11',date:'2026-09-30',title:'Approved startup defaults',items:[
  'The approved saved stage and workspace became the startup default for the website and the app.'
 ]},
 {version:'0.10',date:'2026-09-29',title:'Floating workspaces, notes, clocks and timecode',items:[
  'Snap to grid covers the whole layout; any panel can float freely or dock with a highlighted target.',
  'Full Screen mode keeps every layout option and accepts any panel, floating or docked.',
  'Multiple notes with editable titles; optional follow-scroll for the notes panel.',
  'Default Layout button (save current) and Reset to the user’s saved layout.',
  'Clock panel with stopwatch, alarm, countdown timers, world clock, time-to-show, time-to-next-cue and time-until-load-out.',
  'Timecode panel: receive external timecode or run an internal timecode clock.'
 ]},
 {version:'0.09',date:'2026-09-29',title:'Branding first and donor display',items:[
  'Logo and title moved to the left, with Contribute and credit information beside them.',
  'Prepared a consent-based rotating thank-you display for donors.'
 ]},
 {version:'0.08',date:'2026-09-29',title:'Contribute header and version label',items:[
  'Contribute button (PayPal) with “Like the program? Please support further development. Thank you!”.',
  'Manually updated Perplexity development-credit counter.',
  'Ongoing Beta version number shown in the app and on the landing page.'
 ]},
 {version:'0.07',date:'2026-09-29',title:'Fuel, sessions, customizable workspace and collaboration',retro:true,items:[
  'Per-unit estimated fuel gauges with refill and consumption settings, and a selected-unit fuel panel.',
  'Editable session log files, autosave with an adjustable interval, and free placement of units with a Locked / Unlocked toggle.',
  'Transport refinements: single arrows step cues, double arrows jump to the list ends, hold to scroll.',
  'Multi-select button, pinned layout option, Settings (renamed from Setup) and preset favourites.',
  'Fully customizable workspace: resize, add, remove and drag panels on desktop and phone, plus Full Screen fader view and minimize buttons.',
  'AI app guide, consent-based collaboration (chat and calls), media tools and an interactive colleague test checklist.'
 ]},
 {version:'0.06',date:'2026-09-28',title:'Grid snapping and editable landing demo',retro:true,items:[
  'Snap to grid and an undoable spacing slider for selected fixtures.',
  'Landing page demo became editable: drag, add or remove units, box-select, invert and choose sequences, starting with six evenly spaced alternating units.'
 ]},
 {version:'0.05',date:'2026-09-28',title:'Phone workspace and realistic flames',retro:true,items:[
  'Starts at sequence 001 with Auto-next; the library follows and centres the running sequence.',
  'Phone-only navigation with Stage, Sequences, Faders and Settings tabs, touch controls and dark mode by default.',
  'Flames doubled in length and re-drawn from reference video: sharper attack, bright turbulent jet, travelling burn-off, warmer orange and smoother motion.',
  'Six-across phone faders with bank count controls.'
 ]},
 {version:'0.04',date:'2026-09-28',title:'Virtual fader bank and first public release',retro:true,items:[
  'Layout multi-selection with Ctrl-click, box-select and group dragging.',
  'Vista-style ten-fader playback bank with recorded cues, chase fader and momentary flash buttons; later expanded to twenty assignable faders.',
  'Timed cues and delays, bank master, F1–F12 macros, incoming console mapping and virtual arm indicators.',
  'Playback bar under the layout, fractional cycle rate, wide layout zoom, per-fixture nozzles and editable fader DMX channels.',
  'Signed preset-time adjustment, selected-group controls, hover-wheel faders, editable strip labels and a virtual rear menu.',
  'Starred favourites with reorderable look lists, per-look timing and gaps, middle-button pan, 0–255 fader value entry.',
  'First publication of the website.'
 ]},
 {version:'0.03',date:'2026-09-27',title:'macOS package and website',retro:true,items:[
  'macOS receiver package, configured for Vista on the same Mac.',
  'Wave Studio website with the browser simulator, platform downloads and setup guides.',
  'Prepared a one-time CAD $29.99 single-computer storefront (sales not yet open).'
 ]},
 {version:'0.02',date:'2026-09-27',title:'Vista control and Windows receiver',retro:true,items:[
  'Receive-only Art-Net visualization with a Windows receiver package and discovery replies so Vista finds the node.',
  'Same-PC sACN mode and Vista Streaming ACN setup.',
  'Visual flame scale up to 200%.',
  'Independent minimum and maximum angle limits per unit, with Copy To All Units.'
 ]},
 {version:'0.01',date:'2026-09-27',title:'Virtual X2 Wave effect explorer',retro:true,items:[
  'Browser visualizer for the Explo X2 Wave flamer with the 88 documented sequences.',
  'Draggable multi-flamer stage with per-fixture sequences, layout files and undo.',
  'Per-fixture Invert for upside-down mounting.',
  'Thinner, more realistic flames and clearer separation between bursts.'
 ]}
];
