import {draggableWindow,raiseWindow} from './support-windows.js?v=v0340-20261007g';
import {bindMobilePanelDrag} from './mobile-panel-drag.js?v=v0340-20261007g';

// Phone standard view: the MA panel gets its own detachable card under Layout Controls on the
// Stage tab. Like Layout Controls it only moves DOM nodes — saved workspace and fixture
// documents are never touched, and the custom workspace keeps the MA panel as an ordinary card.
const PREFS_KEY='wave-mobile-ma-panel';
export function mountMobileMaPanel(){
 const media=matchMedia('(max-width:700px)');
 const ma=document.querySelector('.ma-panel');if(!ma)return;
 const panel=document.createElement('section');panel.className='mobile-stage-control-panel mobile-ma-panel';panel.setAttribute('aria-label','MA Console');
 panel.innerHTML='<div class="mobile-control-heading"><strong>MA Console</strong><button type="button" data-dock>Float MA</button><button type="button" data-controls-min aria-label="Minimize MA Console" title="Minimize MA Console" aria-expanded="true">−</button></div><div class="layout-mini-transport ma-mini-bar" role="group" aria-label="Compact MA Console"><span>MA Console</span><button type="button" data-ma-mini-line aria-label="Command line" title="Expand and focus the command line">›</button><button type="button" data-controls-expand aria-label="Expand MA Console" title="Expand MA Console" aria-expanded="false">+</button></div><div class="mobile-control-body"></div>';
 const body=panel.querySelector('.mobile-control-body'),grip=panel.querySelector('.mobile-control-heading'),dock=panel.querySelector('[data-dock]');
 const prefs={floating:false,minimized:false,position:null,anchor:null,before:false};
 try{const saved=JSON.parse(localStorage.getItem(PREFS_KEY));if(saved&&typeof saved==='object')prefs.minimized=saved.minimized===true}catch{}
 const remember=()=>{try{localStorage.setItem(PREFS_KEY,JSON.stringify({minimized:prefs.minimized}))}catch{}};
 let home=null,active=false;
 function restore(){
  if(home){home.replaceWith(ma);home=null}
  panel.remove();active=false;
 }
 function place(){
  panel.classList.toggle('is-floating',prefs.floating);dock.textContent=prefs.floating?'Dock MA':'Float MA';
  for(const key of ['height','width','left','top','right','bottom','position','order'])panel.style.removeProperty(key);
  if(prefs.floating){document.body.append(panel);raiseWindow(panel);if(prefs.position)Object.assign(panel.style,{left:prefs.position.x+'px',right:'auto',top:prefs.position.y+'px',width:prefs.position.width+'px'})}
  else{
   panel.style.removeProperty('z-index');
   const controls=document.querySelector('.simulator>.mobile-stage-control-panel:not(.mobile-ma-panel)'),stage=document.querySelector('.stage-live');
   const custom=prefs.anchor?.isConnected&&!prefs.anchor.closest('#workspace-park')&&!prefs.anchor.classList.contains('is-floating')?prefs.anchor:null;
   const anchor=custom??controls??stage;if(!anchor)return;
   anchor[custom&&prefs.before?'before':'after'](panel);
   // Custom anchors share their neighbour's flex order so before/after wins; the default spot keeps the stylesheet order under Layout Controls.
   if(custom)panel.style.order=getComputedStyle(anchor).order;
  }
  minimize(prefs.minimized,false);
 }
 function minimize(value,save=true){
  prefs.minimized=!!value;panel.classList.toggle('controls-minimized',prefs.minimized);
  panel.querySelector('[data-controls-min]').setAttribute('aria-expanded',String(!prefs.minimized));
  panel.querySelector('[data-controls-expand]').setAttribute('aria-expanded',String(!prefs.minimized));
  if(save)remember();
 }
 function mount(){
  restore();
  if(!media.matches||document.body.classList.contains('custom-workspace-mode')||document.body.classList.contains('workspace-focus-mode'))return;
  if(document.body.dataset.mobilePanel!=='stage')return;
  if(!ma.isConnected||ma.closest('.workspace-card'))return;
  home=document.createComment('mobile-ma-home');ma.before(home);body.append(ma);
  active=true;place();
 }
 dock.onclick=()=>{prefs.floating=!prefs.floating;prefs.anchor=null;prefs.position=null;place()};
 panel.querySelector('[data-controls-min]').onclick=()=>{minimize(true);panel.querySelector('[data-controls-expand]').focus({preventScroll:true})};
 panel.querySelector('[data-controls-expand]').onclick=()=>{minimize(false);panel.querySelector('[data-controls-min]').focus({preventScroll:true})};
 panel.querySelector('[data-ma-mini-line]').onclick=()=>{minimize(false);ma.querySelector('[data-ma-input]')?.focus({preventScroll:false})};
 draggableWindow(panel,grip,{allowed:()=>active&&prefs.floating});
 draggableWindow(panel,panel.querySelector('.ma-mini-bar'),{allowed:()=>active&&prefs.floating});
 for(const handle of [grip,panel.querySelector('.ma-mini-bar')])bindMobilePanelDrag(handle,{panel:()=>panel,title:()=>'MA Console',canDock:target=>target.matches('.mobile-stage-control-panel,.stage-live'),drop:p=>{
  prefs.floating=!p.target;prefs.position=p.float;prefs.anchor=p.target;prefs.before=!p.after;place();
 }});
 document.addEventListener('wave-workspace-before-layout',restore);
 document.addEventListener('wave-workspace-layout',mount);
 document.addEventListener('wave-workspace-collapse-all',e=>{if(active)minimize(e.detail.minimized)});
 media.addEventListener('change',mount);
 new MutationObserver(mount).observe(document.body,{attributes:true,attributeFilter:['data-mobile-panel']});
 mount();
}
