// grandMA2 / grandMA3 hand-off package. MA show files (.show, .show.gz) are not a documented
// interchange format, so this writes the formats MA Lighting documents for import instead:
//  - grandMA3: a GDTF fixture type (DIN SPEC 15800) and an MVR scene (DIN SPEC 15801) that
//    carries the patch, stage positions and the GDTF, imported through Show Creator > PSR > MVR
//    or Patch > Fixture Types > Import.
//  - grandMA2: a fixture type XML in grandMA2's own XML schema plus a fixture layer XML for
//    `Import "file" At Layer n` in EditSetup, and the same GDTF for releases that import GDTF.
//  - Both: CSV sheets (patch, cues, cue contents, fader assignments) in Universe.Address form.
import {presets} from './presets.js?v=v0340-20261007g';
import {DMX_STARTS,angleLimits} from './dmx.js?v=v0340-20261007g';
import {fixtureName} from './layout-chase.js?v=v0340-20261007g';
import {requestFileSave} from './file-save.js?v=v0340-20261007g';
import {csv,csvCell,zipStore,angleToDmx,programRange,stackCsv,faderAssignmentsCsv} from './vista-export.js?v=v0340-20261007g';
import {MA_KEYS} from './ma-keys.js?v=v0340-20261007g';

const CRLF='\r\n';
export const MA_MANUFACTURER='Explo';
export const MA_FIXTURE='X2 Wave Flame';
export const MA_MODE='Standard 6ch';
export const GDTF_FIXTURE_TYPE_ID='5B0E2C7A-4F1D-4B8E-9C3A-7E2D6F1A8B40'; // stable so re-imports replace rather than duplicate
export const GDTF_FILE=`${MA_MANUFACTURER}@${MA_FIXTURE.replace(/\s+/g,'_')}@WaveStudio_6ch.gdtf`;
const MA2_TYPE_NO=2; // first user fixture type in a new grandMA2 show (1 = Dimmer)
export const MA2_TYPE_NAME=`${MA_MANUFACTURER} ${MA_FIXTURE}`;

// XML text: characters XML 1.0 forbids (controls, U+FFFE/U+FFFF, lone surrogates) are dropped, then markup is escaped.
const esc=s=>String(s??'').replace(/[\ud800-\udbff][\udc00-\udfff]|[\ud800-\udfff\u0000-\u0008\u000b\u000c\u000e-\u001f\ufffe\uffff]/g,m=>m.length===2?m:'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&apos;');
// GDTF "Name" values must be safe for dotted node paths: ASCII letters, digits, space, dash, underscore.
const gdtfName=(s,fallback='Item')=>{const t=String(s??'').normalize('NFKD').replace(/[^\x20-\x7E]/g,' ').replace(/[^A-Za-z0-9 _-]/g,' ').replace(/\s+/g,' ').trim().slice(0,60);return t||fallback};
const num=(n,d=3)=>Number.isFinite(n)?String(Math.round(n*10**d)/10**d):'0';
const seconds=n=>Number.isFinite(n)?String(Math.round(n*100)/100):'0';
export const maUniverse=f=>(f.patch?.universe??0)+1; // Wave Studio ports are 0-based; MA universes start at 1
export const maAddress=f=>`${maUniverse(f)}.${f.patch?.address??1}`;
export const absoluteAddress=f=>(maUniverse(f)-1)*512+(f.patch?.address??1);
const sorted=fixtures=>[...fixtures].sort((a,b)=>(a.patch?.universe??0)-(b.patch?.universe??0)||(a.patch?.address??0)-(b.patch?.address??0)||a.id-b.id);
const pct=v=>Math.round(v/255*1000)/10;
// Stable UUIDs: the same layout name and fixture ID always give the same MVR UUID, so repeated exports stay consistent.
const stableUuid=key=>{const h=[0x811c9dc5,0x01000193,0x9e3779b9,0x85ebca6b].map(seed=>{let x=seed>>>0;for(let i=0;i<key.length;i++){x^=key.charCodeAt(i);x=Math.imul(x,0x01000193)>>>0}x^=x>>>15;x=Math.imul(x,0x2c1b3c6d)>>>0;x^=x>>>12;return x>>>0});
 const hex=h.map(v=>v.toString(16).padStart(8,'0')).join('').split('');hex[12]='4';hex[16]=(8|(parseInt(hex[16],16)&3)).toString(16);const t=hex.join('');
 return `${t.slice(0,8)}-${t.slice(8,12)}-${t.slice(12,16)}-${t.slice(16,20)}-${t.slice(20,32)}`.toUpperCase()};
const programSets=()=>presets.map((p,i)=>({seq:i+1,range:programRange(i+1),name:p.name||''})).filter(x=>x.range);

// Stage geometry: fixture x/y are layout fractions (x across the stage, y down the screen). The export
// spreads the units over the stage frame the user enters: Width = distance between the outermost
// left/right units, Depth = distance between the upstage-most and downstage-most units, group centred
// on the origin. MA/MVR use metres on a right-handed, Z-up stage (Y positive = upstage).
export function stageFrame(fixtures,stage){
 const xs=fixtures.map(f=>f.x??0.5),ys=fixtures.map(f=>f.y??0.5);
 const minX=Math.min(...xs),maxX=Math.max(...xs),minY=Math.min(...ys),maxY=Math.max(...ys);
 const w=stage?.width??12,d=stage?.depth??6,h=stage?.height??0;
 const sx=maxX>minX?w/(maxX-minX):0,sy=maxY>minY?d/(maxY-minY):0,cx=(minX+maxX)/2,cy=(minY+maxY)/2;
 return f=>({x:((f.x??0.5)-cx)*sx,y:(cy-(f.y??0.5))*sy,z:h,rot:f.rotation||0}); // mount rotation turns the unit in the front view = rotation about the stage depth (Y) axis
}
export function stagePosition(f,stage,fixtures){return stageFrame(fixtures||[f],stage)(f)}

/* ---------------- GDTF ---------------- */
export function gdtfDescriptionXml({version,date}){
 const sets=programSets();
 const P=(name,...rest)=>`<ChannelSet Name="${esc(gdtfName(name))}"${rest.join('')}/>`;
 const seqSets=sets.map(s=>P(`${String(s.seq).padStart(3,'0')} ${s.name}`,` DMXFrom="${s.range.start}/1"`)).join('');
 return `<?xml version="1.0" encoding="UTF-8"?>
<GDTF DataVersion="1.2">
<FixtureType Name="${esc(MA_FIXTURE)}" ShortName="X2 Wave" LongName="${esc(MA_MANUFACTURER)} ${esc(MA_FIXTURE)} (Standard 6 channel, CH5 new)" Manufacturer="${esc(MA_MANUFACTURER)}" Description="Moving-head flame projector, standard six-channel DMX512 map as modelled by Wave Studio (Virtual SFX Lab). Visual rehearsal reference: verify every range against the manufacturer manual before controlling real equipment." FixtureTypeID="${GDTF_FIXTURE_TYPE_ID}" RefFT="" CanHaveChildren="No">
<AttributeDefinitions>
<ActivationGroups><ActivationGroup Name="PanTilt"/></ActivationGroups>
<FeatureGroups>
<FeatureGroup Name="Position" Pretty="Position"><Feature Name="PanTilt"/></FeatureGroup>
<FeatureGroup Name="Control" Pretty="Control"><Feature Name="Control"/></FeatureGroup>
</FeatureGroups>
<Attributes>
<Attribute Name="Tilt" Pretty="Tilt" ActivationGroup="PanTilt" Feature="Position.PanTilt" PhysicalUnit="Angle"/>
<Attribute Name="PositionMSpeed" Pretty="Speed" Feature="Position.PanTilt" PhysicalUnit="None"/>
<Attribute Name="Ignition" Pretty="Ignition" Feature="Control.Control" PhysicalUnit="None"/>
<Attribute Name="OpenTime" Pretty="Open Time" Feature="Control.Control" PhysicalUnit="None"/>
<Attribute Name="Effects1" Pretty="Program" Feature="Control.Control" PhysicalUnit="None"/>
<Attribute Name="Arm" Pretty="Arm" Feature="Control.Control" PhysicalUnit="None"/>
</Attributes>
</AttributeDefinitions>
<Wheels/>
<PhysicalDescriptions/>
<Models>
<Model Name="Base" Length="0.40" Width="0.40" Height="0.30" PrimitiveType="Base"/>
<Model Name="Head" Length="0.25" Width="0.25" Height="0.35" PrimitiveType="Head"/>
</Models>
<Geometries>
<Geometry Name="Base" Model="Base" Position="{1,0,0,0}{0,1,0,0}{0,0,1,0}{0,0,0,1}">
<Axis Name="Head" Model="Head" Position="{1,0,0,0}{0,1,0,0}{0,0,1,0.3}{0,0,0,1}"/>
</Geometry>
</Geometries>
<DMXModes>
<DMXMode Name="${esc(MA_MODE)}" Geometry="Base" Description="Standard Explo six-channel map with CH5 new program numbering. Visual rehearsal data; not for firing decisions.">
<DMXChannels>
<DMXChannel DMXBreak="1" Offset="1" Highlight="128/1" Geometry="Head">
<LogicalChannel Attribute="Tilt" Snap="No" Master="None">
<ChannelFunction Name="Tilt" Attribute="Tilt" OriginalAttribute="Angle" DMXFrom="0/1" Default="128/1" PhysicalFrom="-105" PhysicalTo="105" RealFade="1.2">
${P('Left -105',' DMXFrom="0/1"')}${P('Straight up 0',' DMXFrom="128/1"')}${P('Right 105',' DMXFrom="255/1"')}
</ChannelFunction>
</LogicalChannel>
</DMXChannel>
<DMXChannel DMXBreak="1" Offset="2" Highlight="255/1" Geometry="Base">
<LogicalChannel Attribute="PositionMSpeed" Snap="No" Master="None">
<ChannelFunction Name="Speed" Attribute="PositionMSpeed" OriginalAttribute="Speed" DMXFrom="0/1" Default="255/1" PhysicalFrom="0" PhysicalTo="1">
${P('Follow angle',' DMXFrom="0/1"')}${P('Slow to fast',' DMXFrom="1/1"')}${P('Immediate',' DMXFrom="255/1"')}
</ChannelFunction>
</LogicalChannel>
</DMXChannel>
<DMXChannel DMXBreak="1" Offset="3" Highlight="0/1" Geometry="Base">
<LogicalChannel Attribute="Ignition" Snap="Yes" Master="None">
<ChannelFunction Name="Idle" Attribute="Ignition" OriginalAttribute="Trigger" DMXFrom="0/1" Default="0/1" PhysicalFrom="0" PhysicalTo="0">${P('Idle',' DMXFrom="0/1"')}</ChannelFunction>
<ChannelFunction Name="Fire" Attribute="Ignition" OriginalAttribute="Trigger" DMXFrom="254/1" Default="254/1" PhysicalFrom="1" PhysicalTo="1">${P('Fire on rising edge',' DMXFrom="254/1"')}</ChannelFunction>
</LogicalChannel>
</DMXChannel>
<DMXChannel DMXBreak="1" Offset="4" Highlight="0/1" Geometry="Base">
<LogicalChannel Attribute="OpenTime" Snap="No" Master="None">
<ChannelFunction Name="Open Time" Attribute="OpenTime" OriginalAttribute="Opening time" DMXFrom="0/1" Default="0/1" PhysicalFrom="0" PhysicalTo="1">${P('Built-in sequence timing',' DMXFrom="0/1"')}${P('Short to long',' DMXFrom="1/1"')}</ChannelFunction>
</LogicalChannel>
</DMXChannel>
<DMXChannel DMXBreak="1" Offset="5" Highlight="0/1" Geometry="Base">
<LogicalChannel Attribute="Effects1" Snap="Yes" Master="None">
<ChannelFunction Name="No program" Attribute="Effects1" OriginalAttribute="Program" DMXFrom="0/1" Default="0/1" PhysicalFrom="0" PhysicalTo="0">${P('No program',' DMXFrom="0/1"')}</ChannelFunction>
<ChannelFunction Name="Sequence" Attribute="Effects1" OriginalAttribute="Program" DMXFrom="3/1" Default="3/1" PhysicalFrom="1" PhysicalTo="${sets.length}">${seqSets}</ChannelFunction>
<ChannelFunction Name="Reserved" Attribute="Effects1" OriginalAttribute="Program" DMXFrom="227/1" Default="227/1" PhysicalFrom="0" PhysicalTo="0">${P('Reserved',' DMXFrom="227/1"')}</ChannelFunction>
</LogicalChannel>
</DMXChannel>
<DMXChannel DMXBreak="1" Offset="6" Highlight="0/1" Geometry="Base">
<LogicalChannel Attribute="Arm" Snap="Yes" Master="None">
<ChannelFunction Name="Safe" Attribute="Arm" OriginalAttribute="Mode" DMXFrom="0/1" Default="0/1" PhysicalFrom="0" PhysicalTo="0">${P('Safe',' DMXFrom="0/1"')}</ChannelFunction>
<ChannelFunction Name="Armed" Attribute="Arm" OriginalAttribute="Mode" DMXFrom="50/1" Default="128/1" PhysicalFrom="1" PhysicalTo="1">${P('Armed',' DMXFrom="50/1"')}</ChannelFunction>
<ChannelFunction Name="Safe high" Attribute="Arm" OriginalAttribute="Mode" DMXFrom="201/1" Default="201/1" PhysicalFrom="0" PhysicalTo="0">${P('Safe',' DMXFrom="201/1"')}</ChannelFunction>
</LogicalChannel>
</DMXChannel>
</DMXChannels>
<Relations/>
<FTMacros/>
</DMXMode>
</DMXModes>
<Revisions><Revision Text="Generated by Wave Studio ${esc(version)} (Virtual SFX Lab) from the standard Explo six-channel map. Visual rehearsal reference." Date="${esc(date)}" UserID="0" ModifiedBy="Wave Studio"/></Revisions>
<FTPresets/>
<Protocols/>
</FixtureType>
</GDTF>
`;
}
export const gdtfBlobFiles=({version,date})=>[{name:'description.xml',text:gdtfDescriptionXml({version,date})}];
export async function gdtfBytes(opts){return new Uint8Array(await zipStore(gdtfBlobFiles(opts),opts.now).arrayBuffer())}

/* ---------------- MVR (grandMA3) ---------------- */
export function mvrSceneXml({fixtures,stage,version,layoutName}){
 const layer=stableUuid(`wave-studio|${layoutName||'stage'}|layer`);const note=`Wave Studio ${layoutName||'stage'} - units over ${num(stage?.width??12,2)} m x ${num(stage?.depth??6,2)} m, addresses absolute (universe-1)*512+address`;
 const at=stageFrame(fixtures,stage);
 const items=sorted(fixtures).map(f=>{
  const p=at(f),r=p.rot*Math.PI/180,c=Math.cos(r),s=Math.sin(r);
  const m=`{${num(c,6)},0,${num(-s,6)}}{0,1,0}{${num(s,6)},0,${num(c,6)}}{${num(p.x*1000,1)},${num(p.y*1000,1)},${num(p.z*1000,1)}}`;
  return `<Fixture name="${esc(fixtureName(f))}" uuid="${stableUuid(`wave-studio|${layoutName||'stage'}|fixture|${f.id}`)}">
<Matrix>${m}</Matrix>
<GDTFSpec>${esc(GDTF_FILE)}</GDTFSpec>
<GDTFMode>${esc(MA_MODE)}</GDTFMode>
<CastShadow>false</CastShadow>
<Addresses><Address break="0">${esc(absoluteAddress(f))}</Address></Addresses>
<FixtureID>${esc(f.id)}</FixtureID>
<FixtureIDNumeric>${esc(f.id)}</FixtureIDNumeric>
<UnitNumber>${esc(f.id)}</UnitNumber>
<CustomId>0</CustomId>
</Fixture>`}).join('\n');
 return `<?xml version="1.0" encoding="UTF-8"?>
<GeneralSceneDescription verMajor="1" verMinor="5" provider="Virtual SFX Lab Wave Studio" providerVersion="${esc(version)}">
<Scene>
<Layers>
<Layer name="${esc(note)}" uuid="${layer}">
<ChildList>
${items}
</ChildList>
</Layer>
</Layers>
</Scene>
</GeneralSceneDescription>
`;
}
export async function mvrBytes({fixtures,stage,version,date,now,layoutName,gdtf}){
 const g=gdtf||await gdtfBytes({version,date,now});
 return new Uint8Array(await zipStore([{name:'GeneralSceneDescription.xml',text:mvrSceneXml({fixtures,stage,version,layoutName})},{name:GDTF_FILE,text:g}],now).arrayBuffer());
}

/* ---------------- grandMA2 fixture type + layer XML ---------------- */
const MA_NS='xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="http://schemas.malighting.de/grandma2/xml/MA" xsi:schemaLocation="http://schemas.malighting.de/grandma2/xml/MA http://schemas.malighting.de/grandma2/xml/3.4.0/MA.xsd" major_vers="3" minor_vers="4" stream_vers="0"';
const d24=v=>({min:v<<16,max:((v+1)<<16)-1}); // grandMA2 stores 8-bit ranges as 24-bit values (255 -> 16777215)
const pc=v=>Math.round(v/255*100000)/1000;
function ma2Function(i,name,a,b,attr,user,feature,featureUser,preset,presetUser,sets,phys){
 const r=d24(b),l=d24(a);
 return `<ChannelFunction index="${i}" name="${esc(name)}" from="${pc(a)}" to="${pc(b)}" min_dmx_24="${l.min}" max_dmx_24="${r.max}" physfrom="${phys?.[0]??0}" physto="${phys?.[1]??1}" subattribute="${attr}" subattribute_user_name="${esc(user)}" attribute="${attr}" attribute_user_name="${esc(user)}" feature="${feature}" feature_user_name="${esc(featureUser)}" preset="${preset}" preset_user_name="${esc(presetUser)}">
${sets.map(([n,f,t],k)=>`<ChannelSet index="${k}" name="${esc(n)}" from_dmx="${f}" to_dmx="${t}"/>`).join('\n')}
</ChannelFunction>`;
}
export function ma2FixtureTypeXml({version,date}){
 const sets=programSets();
 const seq=sets.map(s=>[`${String(s.seq).padStart(3,'0')} ${s.name}`.slice(0,60),s.range.start,s.range.end]);
 return `<?xml version="1.0" encoding="utf-8"?>
<MA ${MA_NS}>
<Info datetime="${esc(date)}" showfile="Wave Studio ${esc(version)}"/>
<FixtureType index="0" name="${esc(MA2_TYPE_NAME)}" mode="6ch">
<InfoItems><Info>Standard Explo six-channel DMX512 map (CH5 new) as modelled by Wave Studio, Virtual SFX Lab. CH1 angle -105..+105 (128 = straight up), CH2 speed, CH3 ignition on a rising edge to 254-255, CH4 single-shot open time, CH5 program 003-226, CH6 arm 50-200. Visual rehearsal reference: verify against the manufacturer manual before controlling real equipment.</Info></InfoItems>
<short_name>X2 Wave</short_name>
<manufacturer>${esc(MA_MANUFACTURER)}</manufacturer>
<short_manufacturer>${esc(MA_MANUFACTURER)}</short_manufacturer>
<Modules index="0">
<Module index="0" name="Module" class="Headmover" beamtype="Wash" beam_angle="20" beam_intensity="1000">
<Body><Size x="0.4" y="0.4" z="0.65"/></Body>
<ChannelType index="0" attribute="TILT" feature="POSITION" preset="POSITION" coarse="1" default="128" highlight_value="50">
${ma2Function(0,'Angle',0,255,'TILT','Tilt','POSITION','Position','POSITION','Position',[['Left -105',0,0],['Straight up',128,128],['Right +105',255,255]],[-105,105])}
</ChannelType>
<ChannelType index="1" attribute="PTSPEED" feature="POSITION" preset="CONTROL" coarse="2" default="255" highlight_value="100">
${ma2Function(0,'Speed',0,255,'PTSPEED','Speed','POSITION','Position','CONTROL','Control',[['Follow angle',0,0],['Slow to fast',1,254],['Immediate',255,255]],[0,1])}
</ChannelType>
<ChannelType index="2" attribute="MACROS" feature="MACRO" preset="CONTROL" coarse="3" default="0" highlight_value="0" snap="true">
${ma2Function(0,'Idle',0,253,'MACROS','Ignition','MACRO','Macro','CONTROL','Control',[['Idle',0,253]],[0,0])}
${ma2Function(1,'Fire',254,255,'MACROS','Ignition','MACRO','Macro','CONTROL','Control',[['Fire (rising edge)',254,255]],[1,1])}
</ChannelType>
<ChannelType index="3" attribute="DUMMY" feature="CONTROL" preset="CONTROL" coarse="4" default="0" highlight_value="0">
${ma2Function(0,'Open Time',0,255,'DUMMY','Open Time','CONTROL','Control','CONTROL','Control',[['Built-in timing',0,0],['Short to long',1,255]],[0,1])}
</ChannelType>
<ChannelType index="4" attribute="EFFECTMACROS" feature="EFFECTMACROS" preset="CONTROL" coarse="5" default="0" highlight_value="0" snap="true">
${ma2Function(0,'No program',0,2,'EFFECTMACROS','Program','EFFECTMACROS','Effect Macros','CONTROL','Control',[['No program',0,2]],[0,0])}
${ma2Function(1,'Sequence',3,226,'EFFECTMACROS','Program','EFFECTMACROS','Effect Macros','CONTROL','Control',seq,[1,sets.length])}
${ma2Function(2,'Reserved',227,255,'EFFECTMACROS','Program','EFFECTMACROS','Effect Macros','CONTROL','Control',[['Reserved',227,255]],[0,0])}
</ChannelType>
<ChannelType index="5" attribute="MODE" feature="FIXTURE" preset="CONTROL" coarse="6" default="0" highlight_value="0" snap="true">
${ma2Function(0,'Safe',0,49,'MODE','Arm','FIXTURE','Fixture','CONTROL','Control',[['Safe',0,49]],[0,0])}
${ma2Function(1,'Armed',50,200,'MODE','Arm','FIXTURE','Fixture','CONTROL','Control',[['Armed',50,200]],[1,1])}
${ma2Function(2,'Safe',201,255,'MODE','Arm','FIXTURE','Fixture','CONTROL','Control',[['Safe',201,255]],[0,0])}
</ChannelType>
</Module>
</Modules>
</FixtureType>
</MA>
`;
}
export function ma2LayerXml({fixtures,stage,version,date,typeNo=MA2_TYPE_NO}){
 const at=stageFrame(fixtures,stage);
 const items=sorted(fixtures).map((f,i)=>{const p=at(f);
  return `<Fixture index="${i}" name="${esc(fixtureName(f))}" fixture_id="${esc(f.id)}" channel_id="${esc(f.id)}">
<FixtureType name="${typeNo} ${esc(MA2_TYPE_NAME)} 6ch"><No>${typeNo}</No></FixtureType>
<SubFixture index="0" react_to_grandmaster="true" color="ffffff">
<Patch><Address>${esc(absoluteAddress(f))}</Address></Patch>
<AbsolutePosition><Location x="${num(p.x)}" y="${num(p.y)}" z="${num(p.z)}"/><Rotation x="0" y="${num(p.rot,1)}" z="0"/><Scaling x="1" y="1" z="1"/></AbsolutePosition>
${Array.from({length:6},(_,k)=>`<Channel index="${k}"/>`).join('')}
</SubFixture>
</Fixture>`}).join('\n');
 return `<?xml version="1.0" encoding="utf-8"?>
<MA ${MA_NS}>
<Info datetime="${esc(date)}" showfile="Wave Studio ${esc(version)}"/>
<Layer index="1" name="Wave Studio flame units">
${items}
</Layer>
</MA>
`;
}

/* ---------------- CSV sheets ---------------- */
export function patchCsv(fixtures,stage){
 return csv([['FixtureID','Name','FixtureType','Mode','Universe','Address','Universe.Address','AbsoluteAddress','Channels','PosX_m','PosY_m','PosZ_m','MountRotation_deg','Inverted','MinAngle','MaxAngle','HomeAngle','HomeAngleDMX'],
  ...sorted(fixtures).map(f=>{const p=stageFrame(fixtures,stage)(f),l=angleLimits(f);return [f.id,fixtureName(f),MA2_TYPE_NAME,MA_MODE,maUniverse(f),f.patch?.address??1,maAddress(f),absoluteAddress(f),6,num(p.x),num(p.y),num(p.z),num(p.rot,1),f.inverted?'Yes':'No',l.min,l.max,Math.round(f.homeAngle??0),angleToDmx(Math.round(f.homeAngle??0))]})]);
}
const lookLabel=(l,fixtures)=>{const f=fixtures.find(x=>x.id===l.fixtureId),p=presets[l.presetId-1];return `${f?fixtureName(f):`Fixture ${l.fixtureId}`}: Seq ${String(l.presetId).padStart(3,'0')}${p?.name?` ${p.name}`:''}`};
export function cuesCsv(playback,fixtures){
 const rows=playback.cues.map((c,i)=>{const t=c.timing||{};
  const contents=c.sequenceOrder?`Sequence order ${c.sequenceOrder.map(id=>String(id).padStart(3,'0')).join(' > ')} for ${c.looks.map(l=>{const f=fixtures.find(x=>x.id===l.fixtureId);return f?fixtureName(f):`Fixture ${l.fixtureId}`}).join(', ')}`:c.looks.map(l=>lookLabel(l,fixtures)).join(' | ');
  return [i+1,c.name||`Cue ${c.id}`,seconds(t.fadeIn),seconds(t.fadeOut),seconds(t.delay),seconds(t.hold),'Go',`Wave Studio cue ${c.id}. ${contents}`]});
 return csv([['Cue','Name','Fade','OutFade','Delay','Hold','Trig','Info'],...rows]);
}
export function cueContentsCsv(playback,fixtures){
 const rows=[];
 playback.cues.forEach((c,i)=>{
  const steps=c.sequenceOrder?c.sequenceOrder.map((id,k)=>({id,step:k+1,timing:c.sequenceTiming?.[k]})):null;
  for(const l of c.looks){
   const f=fixtures.find(x=>x.id===l.fixtureId);if(!f)continue;
   for(const s of steps||[{id:l.presetId,step:1}]){
    const p=presets[s.id-1],range=programRange(s.id);if(!p||!range)continue;
    const tilt=angleToDmx(Math.round(f.homeAngle??0));
    rows.push([i+1,c.name||`Cue ${c.id}`,s.step,f.id,fixtureName(f),maAddress(f),String(s.id).padStart(3,'0'),p.name||'',tilt,pct(tilt),255,100,254,100,0,0,range.start,`${range.start}-${range.end}`,pct(range.start),128,pct(128),seconds(s.timing?.duration??p.duration),seconds(s.timing?.gap??1.1)]);
   }
  }
 });
 return csv([['Cue','Cue Name','Step','FixtureID','Name','Universe.Address','Sequence','Sequence Name','CH1 Tilt DMX','CH1 Tilt %','CH2 Speed DMX','CH2 Speed %','CH3 Ignition DMX (pulse)','CH3 %','CH4 Open Time DMX','CH4 %','CH5 Program DMX','CH5 Valid Range','CH5 %','CH6 Arm DMX','CH6 %','Duration s','Gap s'],...rows]);
}
// Numbered so stacks with the same (or same-looking) name never collide inside the ZIP.
export const stackFileName=(stack,i=0)=>`03-cuelist-${String(i+1).padStart(2,'0')}-${String(stack.name??'').replace(/[^\w.-]+/g,'-').replace(/^-+|-+$/g,'').slice(0,40)||'stack'}.csv`;

/* ---------------- README ---------------- */
// 06-ma-keys.csv: the MA panel keys and the control-universe channel each one listens on (blank = not patched).
export function maKeysCsv(playback){
 const mapping=playback.controlMapping||{universe:1,bindings:[]};
 const rows=[['Key','Label','Group','Console','Universe','Channel','Action']];
 for(const k of MA_KEYS){
  const b=mapping.bindings?.find(b=>b.target===`ma:${k.id}`),patched=b&&b.address>0;
  rows.push([k.id,k.label,k.group,k.set==='both'?'grandMA2 + grandMA3':k.set==='ma3'?'grandMA3':'grandMA2',patched?String(b.universe??mapping.universe):'',patched?String(b.address):'',k.hint||'']);
 }
 return csv(rows);
}
export function readmeText({fixtures,playback,version,date,stage}){
 return [`Wave Studio ${version} - grandMA2 / grandMA3 hand-off package (${date})`,'',
  `${fixtures.length} fixture(s), ${playback.cues.length} cue(s), ${(playback.stacks||[]).filter(st=>st.entries.length).length} cue stack(s), 20 fader assignments. Units spread over ${num(stage?.width??12,2)} m (left to right) x ${num(stage?.depth??6,2)} m (upstage to downstage) at ${num(stage?.height??0,2)} m height, centred on the stage origin.`,'',
  'WHAT THIS IS',
  'grandMA show files (.show / .show.gz) are not a documented interchange format, so this package uses the import paths MA Lighting documents:',
  'GDTF and MVR for grandMA3 (DIN SPEC 15800 / 15801), fixture-type and fixture-layer XML for grandMA2, and CSV sheets for both.',
  'Universes are 1-based (Wave Studio port 0 = MA universe 1); addresses are Universe.Address. Fixture IDs match the Wave Studio IDs.','',
  'grandMA3 (console or onPC, 1.9 or newer)',
  `1. Copy grandMA3/${GDTF_FILE} to a USB stick in grandMA3/gma3_library/fixturetypes and grandMA3/WaveStudio-<layout>.mvr to grandMA3/gma3_library/mvr`,
  '   (onPC: the same folders under the grandMA3 user folder on the PC).',
  '2. MVR with patch and positions: Menu > Show Creator > Partial Show Read > MVR, select the .mvr, keep Fixtures checked, Select, then review the MVR Patch',
  '   against the Local Running Patch in PSR Prepare (Use MVR Only for a fresh show, Merge MVR to add to an existing one), Finish, OK. PSR clears the programmer.',
  '   Re-importing an updated layout: delete the Wave Studio fixtures imported last time (or start from a fresh show) so they are not doubled.',
  '   The fixture type arrives inside the MVR; positions and mount rotations (about the stage depth axis) land in the 3D stage.',
  '   Fixture type only: Menu > Patch > Fixture Types > Import, pick the USB drive top right, select the Explo X2 Wave Flame GDTF, Import, then patch by hand from 01-patch.csv.',
  '3. Attributes in the GDTF: Tilt (angle, 128 = straight up), Speed, Ignition (Idle 0-253 / Fire 254-255), Open Time, Program (named channel sets for sequences 001-088) and Arm (Safe / Armed 50-200 / Safe).',
  '   Ignition and Arm are snap channels so fades never pass through firing values.',
  '4. Cues: 02-cues.csv lists cue numbers, names and timing; 04-cue-contents.csv lists per cue and fixture the DMX value and percentage of every channel.',
  '   Set them in the programmer (e.g. select fixtures, Program channel set, Arm Armed, then Ignition Fire for one GO) and Store Cue. 03-cuelist-<nn>-<stack>.csv mirrors each Wave Studio cue stack.',
  '   grandMA3 has no native cue CSV import; the ma.tools PatchImporter plugin reads patch CSVs if you prefer CSV over MVR for the patch.',
  '5. Live rehearsal: DMX Protocols > sACN (or Art-Net) output to the Wave Studio receiver as described in the Wave Studio First Guide, Part 5.6.','',
  'grandMA2 (console or onPC, 3.4 or newer)',
  `1. Copy grandMA2/${MA2_TYPE_NAME.replace(/\s+/g,'_')}@6ch.xml to gma2/library on a USB stick (onPC: ...\\MA Lighting Technologies\\grandma\\gma2_V_x.x\\library),`,
  '   then Setup > Patch & Fixture Schedule > Fixture Types > Import, select the drive and the Explo X2 Wave Flame 6ch type.',
  `2. Copy grandMA2/wavestudio_layer.xml to gma2/importexport (onPC: ...\\gma2_V_x.x\\importexport). In the command line: CD EditSetup, then`,
  `   Import "wavestudio_layer" At Layer 1 (use a free layer number), then CD Root. Check Patch & Fixture Schedule and save with Yes.`,
  `   The layer references fixture type number ${MA2_TYPE_NO} ("${MA2_TYPE_NO} ${MA2_TYPE_NAME} 6ch"). If your show gives the imported type another number, edit <No> and the name in the XML first.`,
  '   Addresses in the layer are absolute (universe-1)*512 + address, the form grandMA2 stores; 01-patch.csv shows both forms.',
  '3. grandMA2 3.9 and newer can also import the GDTF from gma2/gdtf; use whichever your release lists in Fixture Types > Import.',
  '4. Cues: as for grandMA3, program from 04-cue-contents.csv and Store. 02-cues.csv carries names and fade/delay timing for the sequence sheet.',
  '5. Live rehearsal: Setup > Network Protocols > sACN or Art-Net, see Part 5.6 of the Wave Studio First Guide.','',
  'MA PANEL KEYS FROM A PHYSICAL CONSOLE (06-ma-keys.csv)',
  '  The Wave Studio MA panel mirrors the grandMA command section (Go+, Store, Fixture, Thru, Please ...). A physical grandMA2 / grandMA3 console presses those keys',
  '  through ordinary DMX: patch one generic dimmer per key in the Wave Studio control universe at the channels listed in 06-ma-keys.csv (MA panel > Physical grandMA console',
  '  > Patch Keys In Order fills them), then put each dimmer on an executor button set to Temp or Flash (or a macro that sets it to 100 and back to 0). A value of 128 or more',
  '  presses the key; the receiver must run in sACN mode with the console mapping connected (First Guide Part 5.7). Nothing is sent back to the console.','',
  'LIMITS',
  '- Fixture types and patch import automatically; cue contents need one programming pass per cue (MA cannot import cue values from CSV).',
  '- Positions spread the units over the width/depth entered in Wave Studio (outermost units define the extent); adjust in Patch or the 3D window if your stage differs.',
  '- Generated from documented formats and verified against the published specifications, but not on every MA release. Import into an empty show first.',
  '- Wave Studio is a visualizer. Verify every arm, ignition and angle against the manufacturer manual on the real system before firing.',''].join(CRLF);
}

/* ---------------- package ---------------- */
export async function buildGrandMAPackage({fixtures,playback,version,stage,layoutName,now=new Date()}){
 const date=now.toISOString().slice(0,10),iso=now.toISOString().slice(0,19);
 const gdtf=await gdtfBytes({version,date:iso,now});
 const mvr=await mvrBytes({fixtures,stage,version,date:iso,now,layoutName,gdtf});
 const safe=String(layoutName||'stage').replace(/[^\w.-]+/g,'-').replace(/^-+|-+$/g,'').slice(0,40)||'stage';
 const files=[
  {name:'README-grandMA.txt',text:readmeText({fixtures,playback,version,date,stage})},
  {name:`grandMA3/${GDTF_FILE}`,text:gdtf},
  {name:`grandMA3/WaveStudio-${safe}.mvr`,text:mvr},
  {name:`grandMA2/${MA2_TYPE_NAME.replace(/\s+/g,'_')}@6ch.xml`,text:ma2FixtureTypeXml({version,date:iso})},
  {name:'grandMA2/wavestudio_layer.xml',text:ma2LayerXml({fixtures,stage,version,date:iso})},
  {name:`grandMA2/${GDTF_FILE}`,text:gdtf},
  {name:'01-patch.csv',text:patchCsv(fixtures,stage)},
  {name:'02-cues.csv',text:cuesCsv(playback,fixtures)},
  ...(playback.stacks||[]).filter(st=>st.entries.length).map((st,i)=>({name:stackFileName(st,i),text:stackCsv(st,playback,fixtures)})),
  {name:'04-cue-contents.csv',text:cueContentsCsv(playback,fixtures)},
  {name:'05-fader-assignments.csv',text:faderAssignmentsCsv(playback)},
  {name:'06-ma-keys.csv',text:maKeysCsv(playback)}];
 return {files,blob:zipStore(files,now),fileName:`wave-studio-grandma-${date}.zip`};
}

const STAGE_KEY='vsl-ma-stage';
// Stored stage values get the same limits as the form fields.
export function loadStage(){try{const s=JSON.parse(localStorage.getItem(STAGE_KEY)||'null');if(s&&typeof s==='object')return {width:clampM(s.width,1,200,12),depth:clampM(s.depth,1,200,6),height:clampM(s.height,-50,100,0)}}catch{}return {width:12,depth:6,height:0}}
const clampM=(v,lo,hi,d)=>{const n=Number(v);return Number.isFinite(n)?Math.min(hi,Math.max(lo,n)):d};

export function mountGrandMAExport({after,capture,version,announce}){
 const button=document.createElement('button');button.id='export-grandma';button.type='button';button.textContent='Export For grandMA';button.title='Download a grandMA2 / grandMA3 package: GDTF fixture type, MVR scene with patch and positions, grandMA2 fixture-type and layer XML, cue and patch CSV sheets';
 after.after(button);
 const dialog=document.createElement('dialog');dialog.className='vista-dialog';dialog.setAttribute('aria-label','Export For grandMA');
 const stage=loadStage();
 dialog.innerHTML=`<form method="dialog"><h2>Export For grandMA2 / grandMA3</h2>
<p>Creates a ZIP for the MA console or onPC. MA show files are not a documented interchange format, so the package uses the import paths MA Lighting documents.</p>
<ul>
<li><strong>grandMA3/</strong> ${esc(GDTF_FILE)} (fixture type, Patch > Fixture Types > Import) and <strong>WaveStudio-&lt;layout&gt;.mvr</strong> (patch + stage positions + the fixture type, Show Creator > Partial Show Read > MVR)</li>
<li><strong>grandMA2/</strong> fixture type XML for gma2/library and <strong>wavestudio_layer.xml</strong> for <code>Import "wavestudio_layer" At Layer 1</code> in EditSetup, plus the GDTF for 3.9+</li>
<li><strong>01-patch.csv</strong> Universe.Address, absolute address, positions and rotation; <strong>02-cues.csv</strong> cue names and timing; <strong>03-cuelist-&lt;nn&gt;-&lt;stack&gt;.csv</strong> per cue stack; <strong>04-cue-contents.csv</strong> per cue and fixture channel values (DMX and %); <strong>05-fader-assignments.csv</strong>; <strong>06-ma-keys.csv</strong> MA panel keys and their control-universe channels for a physical console</li>
</ul>
<fieldset class="vista-stage"><legend>Stage positions (metres)</legend>
<label title="Distance between the leftmost and rightmost unit">Width <input type="number" min="1" max="200" step="0.1" name="width" value="${stage.width}"></label>
<label title="Distance between the upstage-most and downstage-most unit (ignored when all units are on one line)">Depth <input type="number" min="1" max="200" step="0.1" name="depth" value="${stage.depth}"></label>
<label title="Mounting height of the units above the stage floor">Height <input type="number" min="-50" max="100" step="0.1" name="height" value="${stage.height}"></label>
</fieldset>
<p class="vista-note" data-summary></p>
<p class="vista-note">Fixture types, patch and positions import directly. Cue contents need one programming pass per cue from sheet 04; MA consoles do not import cue values from CSV. Read README-grandMA.txt in the ZIP for the step-by-step.</p>
<menu><button type="button" value="cancel" data-cancel>Cancel</button><button type="button" data-gdtf title="Download only the GDTF fixture type">GDTF Only</button><button type="button" class="primary" data-export>Download Package</button></menu></form>`;
 document.body.append(dialog);
 const readStage=()=>{const fd=new FormData(dialog.querySelector('form'));const s={width:clampM(fd.get('width'),1,200,12),depth:clampM(fd.get('depth'),1,200,6),height:clampM(fd.get('height'),-50,100,0)};try{localStorage.setItem(STAGE_KEY,JSON.stringify(s))}catch{}return s};
 dialog.querySelector('[data-cancel]').onclick=()=>dialog.close();
 dialog.querySelector('[data-gdtf]').onclick=async()=>{
  dialog.close();const now=new Date();
  try{
   const bytes=await gdtfBytes({version,date:now.toISOString().slice(0,19),now});
   const result=await requestFileSave(new Blob([bytes],{type:'application/zip'}),GDTF_FILE).catch(e=>({message:e.message}));
   announce?.(result?.message||`GDTF fixture type ready: ${GDTF_FILE}.`);
  }catch(error){announce?.(`Export Failed: ${error.message||'Unknown Error'}. Nothing Was Downloaded.`)}
 };
 dialog.querySelector('[data-export]').onclick=async()=>{
  let pkg;
  try{const {fixtures,playback,layoutName}=capture(),stage=readStage();pkg=await buildGrandMAPackage({fixtures,playback,version,stage,layoutName})}
  catch(error){dialog.close();announce?.(`Export Failed: ${error.message||'Unknown Error'}. Nothing Was Downloaded.`);return}
  dialog.close();
  const result=await requestFileSave(pkg.blob,pkg.fileName).catch(e=>({message:e.message}));
  announce?.(result?.message||`grandMA package ready: ${pkg.fileName}.`);
 };
 button.onclick=()=>{const {fixtures,playback}=capture();dialog.querySelector('[data-summary]').textContent=`${fixtures.length} fixture(s), ${playback.cues.length} cue(s) and ${(playback.stacks||[]).filter(st=>st.entries.length).length} cue stack(s) will be exported.`;dialog.showModal()};
 return {button,dialog};
}
