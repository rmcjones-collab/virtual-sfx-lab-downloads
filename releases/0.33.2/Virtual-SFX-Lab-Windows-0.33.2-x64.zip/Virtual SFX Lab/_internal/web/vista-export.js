// Vista 3 hand-off package. Vista's native .v3s show file is a closed, undocumented
// format, so this writes the documented import formats instead: a Patch > Import Patch
// File CSV, a File > Import Cues CSV (Vista 3 R5+), plus programming sheets that let the
// operator finish fixture values and playbacks inside Vista in one sitting.
import {presets} from './presets.js?v=v0340-20261007g';
import {DMX_STARTS,angleLimits} from './dmx.js?v=v0340-20261007g';
import {fixtureName} from './layout-chase.js?v=v0340-20261007g';
import {mapTargets} from './control-map.js?v=v0340-20261007g';
import {channelNames} from './playback-model.js?v=v0340-20261007g';
import {requestFileSave} from './file-save.js?v=v0340-20261007g';

export const FIXTURE_TYPE='Explo X2 Wave Flame (6ch)';
const CRLF='\r\n';

// CSV cells are quoted and spreadsheet-formula prefixes are neutralised so a fixture or
// cue named "=HYPERLINK(...)" can never execute when the sheet is opened in Excel/Numbers.
export function csvCell(value){
 let s=value==null?'':String(value).replace(/[\r\n\t\v\f\u2028\u2029]+/g,' ').trim();
 // A leading '-' is only neutralised when it could start a formula, so a cue named "-Intro-" stays as typed.
 const risky=/^[=+@|%]/.test(s)||(/^-/.test(s)&&!/^-?\d+(\.\d+)?$/.test(s)&&(/^-[^A-Za-z]/.test(s)||/[(|!+*/^&=<>]/.test(s)));
 if(risky)s=`'${s}`;
 return /[",;]/.test(s)||/^\s|\s$/.test(s)?`"${s.replace(/"/g,'""')}"`:s;
}
export const csv=rows=>rows.map(r=>r.map(csvCell).join(',')).join(CRLF)+CRLF;

export const vistaUniverse=f=>(f.patch?.universe??0)+1; // Wave Studio ports are 0-based; Vista universes start at 1
export const vistaAddress=f=>`${vistaUniverse(f)}:${f.patch?.address??1}`;
export const angleToDmx=a=>Math.max(0,Math.min(255,Math.round((a+105)*255/210)));
export const programRange=id=>{const i=id-1;if(i<0||i>=DMX_STARTS.length)return null;const end=i+1<DMX_STARTS.length?DMX_STARTS[i+1]-1:226;return {start:DMX_STARTS[i],end}};
const seconds=n=>Number.isFinite(n)?String(Math.round(n*100)/100):'0';
const sorted=fixtures=>[...fixtures].sort((a,b)=>(a.patch?.universe??0)-(b.patch?.universe??0)||(a.patch?.address??0)-(b.patch?.address??0)||a.id-b.id);

export function patchCsv(fixtures){
 return csv([['ID','Univ:Adrs','Fixture Type','Fixture Name'],...sorted(fixtures).map(f=>[f.id,vistaAddress(f),FIXTURE_TYPE,fixtureName(f)])]);
}

export function fixtureLayoutCsv(fixtures){
 const rows=sorted(fixtures).map(f=>{const l=angleLimits(f);return [f.id,fixtureName(f),vistaAddress(f),vistaUniverse(f),f.patch?.address??1,6,
  Math.round((f.x??0)*1000)/10,Math.round((f.y??0)*1000)/10,f.inverted?'Yes':'No',f.nozzle??'outdoor',f.rotation||0,l.min,l.max,Math.round(f.homeAngle??0),angleToDmx(Math.round(f.homeAngle??0))]});
 return csv([['ID','Fixture Name','Univ:Adrs','Universe','Start Address','Channels','Stage X %','Stage Y %','Inverted','Nozzle','Mount Rotation','Min Angle','Max Angle','Home Angle','Home Angle DMX (CH1)'],...rows]);
}

const lookLabel=(l,fixtures)=>{const f=fixtures.find(x=>x.id===l.fixtureId),p=presets[l.presetId-1];return `${f?fixtureName(f):`Fixture ${l.fixtureId}`}: Seq ${String(l.presetId).padStart(3,'0')}${p?.name?` ${p.name}`:''}`};

export function cuesCsv(playback,fixtures){
 const rows=playback.cues.map((c,i)=>{const t=c.timing||{};
  const notes=c.sequenceOrder?`Sequence order ${c.sequenceOrder.map(id=>String(id).padStart(3,'0')).join(' > ')} for ${c.looks.map(l=>{const f=fixtures.find(x=>x.id===l.fixtureId);return f?fixtureName(f):`Fixture ${l.fixtureId}`}).join(', ')}`:c.looks.map(l=>lookLabel(l,fixtures)).join(' | ');
  return [i+1,c.name||`Cue ${c.id}`,seconds(t.fadeIn),seconds(t.fadeOut),seconds(t.delay),seconds(t.hold),'Halt','',`Wave Studio cue ${c.id}. ${notes}`]});
 return csv([['Cue','Name','Fade In','Fade Out','Delay','Hold','Follow','Timecode','Notes'],...rows]);
}

// Cue stack as a Vista cuelist CSV: one row per stack entry. Follow = Vista's follow-on, Wait = the follow delay, Timecode = the trigger time.
const safeFile=s=>String(s??'').replace(/[^\w.-]+/g,'-').replace(/^-+|-+$/g,'').slice(0,40)||'stack';
export function stackCsv(stack,playback,fixtures){
 const rows=stack.entries.map((e,i)=>{
  const c=playback.cues.find(x=>x.id===e.cueId);if(!c)return null;const t=c.timing||{};
  const contents=c.sequenceOrder?`Sequence ${c.sequenceOrder.map(id=>String(id).padStart(3,'0')).join(' > ')}`:c.looks.map(l=>lookLabel(l,fixtures)).join(' | ');
  const follow=e.trigger==='follow'?'Follow':e.trigger==='timecode'?'Timecode':'Halt';
  return [i+1,c.name||`Cue ${c.id}`,seconds(t.fadeIn),seconds(t.fadeOut),seconds(t.delay),seconds(t.hold),follow,e.trigger==='follow'?seconds(e.wait):'',e.trigger==='timecode'?e.timecode:'',`${e.notes?e.notes+' · ':''}Wave Studio cue ${c.id}. ${contents}`]}).filter(Boolean);
 return csv([['Cue','Name','Fade In','Fade Out','Delay','Hold','Follow','Wait','Timecode','Notes'],...rows]);
}
// Numbered so stacks with the same (or same-looking) name never collide inside the ZIP.
export const stackFileName=(stack,i=0)=>`02-cuelist-${String(i+1).padStart(2,'0')}-${safeFile(stack.name)}.csv`;

export function cueContentsCsv(playback,fixtures){
 const rows=[];
 playback.cues.forEach((c,i)=>{
  const steps=c.sequenceOrder?c.sequenceOrder.map((id,k)=>({id,step:k+1,timing:c.sequenceTiming?.[k]})):null;
  for(const l of c.looks){
   const f=fixtures.find(x=>x.id===l.fixtureId);if(!f)continue;
   const list=steps||[{id:l.presetId,step:1}];
   for(const s of list){
    const p=presets[s.id-1],range=programRange(s.id);if(!p||!range)continue;
    rows.push([i+1,c.name||`Cue ${c.id}`,s.step,f.id,fixtureName(f),vistaAddress(f),String(s.id).padStart(3,'0'),p.name||'',
     angleToDmx(Math.round(f.homeAngle??0)),255,255,0,range.start,`${range.start}-${range.end}`,128,seconds(s.timing?.duration??p.duration),seconds(s.timing?.gap??1.1)]);
   }
  }
 });
 return csv([['Cue','Cue Name','Step','Fixture ID','Fixture Name','Univ:Adrs','Sequence','Sequence Name','CH1 Angle','CH2 Speed','CH3 Ignition','CH4 Open Time','CH5 Program','CH5 Valid Range','CH6 Arm (50-200)','Duration s','Gap s'],...rows]);
}

export function faderAssignmentsCsv(playback){
 const mapping=playback.controlMapping||{universe:1,bindings:[]},bind=id=>{const b=mapping.bindings?.find(b=>b.target===id);return b&&b.address>0?`${b.universe??mapping.universe}:${b.address}${b.invert?' (inverted)':''}`:''};
 const rows=playback.slots.map((s,i)=>{const cue=playback.cues.find(c=>c.id===s.cueId),idx=cue?playback.cues.indexOf(cue)+1:'';
  const mode=s.dmxPriority?`DMX channel - ${channelNames[i]??'Channel'}`:s.kind==='chase'?'Chase':'Cue playback';
  return [i+1,mode,s.dmxPriority?s.dmxLabel:s.cueLabel,idx,cue?.name||(s.kind==='chase'?'Layout chase':''),s.flashLevel,s.loop?'Yes':'No',s.wheelStep??1,bind(`fader:${i}`),bind(`top:${i}`),bind(`bottom:${i}`)]});
 const chase=playback.chase||{};
 const extra=[[],['Bank master','Level','Grand master','', '',playback.grandMaster??100,'','',bind('master'),'',''],[],
  ['Chase settings','Sequence',String(chase.presetId??'').padStart(3,'0'),'BPM',chase.bpm??'','Direction',chase.direction??'','Width',chase.width??'','Duty %',chase.duty??''],
  ['Chase targets',chase.all?'All fixtures':(chase.targets||[]).join(' ')],[],
  ['Macro','Name','Action','Target fader','Value','','','','Control input','',''],
  ...(playback.macros||[]).map((m,i)=>[`F${i+1}`,m.name,m.action,m.target,m.value,'','','',bind(`macro:${i}`),'',''])];
 return csv([['Fader','Mode','Label','Cue #','Cue Name','Flash Level %','Loop','Wheel Step','Fader Input (Univ:Adrs)','Play Flash Input','Sun Flash Input'],...rows,...extra]);
}

export const PROFILE_CHANNELS=[
 {ch:1,name:'Angle',cls:'Position',type:'Tilt',bits:'8 bit',def:128,ranges:[['-105° left to +105° right (128 = 0°, straight up)',0,255]],note:'Nozzle angle; 0 = -105°, 128 = 0°, 255 = +105°. Set Maximum Tilt Degrees to 210 on the Main tab so Vista can invert mirrored units.'},
 {ch:2,name:'Speed',cls:'Custom Position',type:'Custom Position',bits:'8 bit',def:255,ranges:[['Slow to fast',0,255]],note:'Movement speed; 255 = follow the Angle channel immediately.'},
 {ch:3,name:'Ignition',cls:'Custom Miscellaneous',type:'Custom Miscellaneous',bits:'8 bit',def:0,ranges:[['Idle',0,253],['Fire (rising edge)',254,255]],note:'A rising edge into 254-255 triggers the flame. Keep default 0. Optional: build it as Feature Class Intensity instead so Intensity 100 % = Fire.'},
 {ch:4,name:'Open Time',cls:'Custom Miscellaneous',type:'Custom Miscellaneous',bits:'8 bit',def:0,ranges:[['Valve open time, short to long',0,255]],note:'Single-shot valve open time. Leave 0 for built-in sequences.'},
 {ch:5,name:'Program',cls:'Gobo',type:'Gobo Wheel',bits:'8 bit',def:0,ranges:[['No program',0,2],['Sequences 001-088 (slots below)',3,226],['Reserved',227,255]],note:'Add one slot per sequence you use (name + DMX value = range start) so the operator picks sequences from the Gobo panel. Custom Miscellaneous with DMX ranges is the lighter alternative.'},
 {ch:6,name:'Arm',cls:'Custom Miscellaneous',type:'Custom Miscellaneous',bits:'8 bit',def:0,ranges:[['Safe',0,49],['Armed',50,200],['Safe',201,255]],note:'Fixture only fires while armed. Default 0 so a clear/release disarms.'}];

export function fixtureProfileText(){
 const L=[];const put=(...x)=>L.push(...x);
 put(`${FIXTURE_TYPE} - build sheet for the Vista 3 Fixture Editor`,'',
  'WHY A BUILD SHEET AND NOT A .v3f / .fix2 FILE',
  'Vista fixture files (.v3f for Vista 3, .fix2 for Vista 2) are an encrypted container, not XML or text, so no outside program can write one.',
  'Build the profile once with the steps below, then Patch > Export Fixture Profiles (or right-click the fixture in Patch > Export to fixture',
  'library) gives you a genuine .v3f to copy to other Vista machines or share with colleagues.','',
  'OPEN THE EDITOR',
  '1. Patch > Fixture Editor (Windows: the Fixture Type Library Editor is also a separate desktop shortcut).',
  '2. Collapse the Factory folder, select User Fixture Library, then Fixture > New Fixture.','',
  'MAIN TAB (double-click a field to edit)',
  '  Manufacturer:                Explo',
  `  Full Name:                   ${FIXTURE_TYPE}`,
  '  Short Name:                  X2 Wave',
  '  Fixture Status:              Verified (or your choice)',
  '  Beam Type:                   Other / None',
  '  Frame Type:                  No Frame',
  '  Movement Type:               Moving Head',
  '  Physical Type:               Effect (flame)',
  '  Light Generation:            Other',
  '  Maximum Pan Degrees:         0',
  '  Maximum Tilt Degrees:        210      (needed for Invert to mirror the nozzle angle)',
  '  Element Count H / V:         1 / 1',
  '  Is a Scroller:               No',
  '  Patch Parts Count:           1',
  '  Compatibility ID / UUID:     leave as generated',
  '  Revision:                    1','',
  'DMX CHART TAB - click Add DMX Channel six times with these values',
  '  Ch  Feature Name   Feature Class            Feature Type             Type    Channel  Default');
 for(const c of PROFILE_CHANNELS)put(`  ${String(c.ch).padEnd(3)} ${c.name.padEnd(14)} ${c.cls.padEnd(24)} ${c.type.padEnd(24)} ${c.bits.padEnd(7)} ${String(c.ch).padEnd(8)} ${c.def}`);
 put('','  Then select each channel and use Add DMX Range (or Add Custom Mode for behaviours a generic control cannot express):');
 for(const c of PROFILE_CHANNELS){put(`  CH${c.ch} ${c.name}:`);for(const [label,a,b] of c.ranges)put(`      ${String(a).padStart(3)}-${String(b).padStart(3)}  ${label}`);put(`      note: ${c.note}`)}
 put('','CH5 PROGRAM SLOTS (Add Slot on the Gobo Wheel channel: Name, DMX value = start of range; or Add DMX Range start-end)');
 presets.forEach((p,i)=>{const r=programRange(i+1);if(r)put(`  Seq ${String(i+1).padStart(3,'0')}  ${String(r.start).padStart(3)}-${String(r.end).padStart(3)}  value ${String(r.start).padStart(3)}  ${p.name||''}`)});
 put('','DMX MACROS TAB (optional but handy)',
  '  Arm:      CH6 = 128      Disarm: CH6 = 0      Home: CH1 = 128, CH2 = 255      Fire: CH3 = 255 (then back to 0)','',
  'SAVE AND USE',
  '1. Compare the ranges with the Explo X2 Wave Flame manual, click OK, then OK on Save Fixture and Exit.',
  '2. Quit the editor, click Apply then OK; Vista rebuilds its catalogue (this takes a moment).',
  '3. The profile now appears under User Fixture Library in Patch. Re-run Patch > Import Patch File with 01-patch.csv and pick it when asked.',
  '4. Patch > Export Fixture Profiles saves the finished .v3f for other machines; Patch > Import Fixture Profiles loads it there.',
  '5. Alternatively submit this sheet with Chroma-Q\'s fixture request form (vistabychromaq.com/vista-by-chroma-q-fixture-request) and they will build the profile.','',
  'Wave Studio models the standard Explo six-channel map; confirm every value against the manufacturer manual before firing real units.');
 return L.join(CRLF)+CRLF;
}

export function fixtureProfileMarkdown(){
 const rows=presets.map((p,i)=>{const r=programRange(i+1);return `| ${String(i+1).padStart(3,'0')} | ${r.start}–${r.end} | ${r.start} | ${p.name||''} |`}).join('\n');
 const ch=PROFILE_CHANNELS.map(c=>`| ${c.ch} | ${c.name} | ${c.cls} | ${c.type} | ${c.bits} | ${c.def} | ${c.ranges.map(([l,a,b])=>`${a}–${b} ${l}`).join('<br>')} |`).join('\n');
 const notes=PROFILE_CHANNELS.map(c=>`- **CH${c.ch} ${c.name}:** ${c.note}`).join('\n');
 return `# Explo X2 Wave Flame — Vista 3 Fixture Editor Build Sheet

## Why this is a build sheet and not a .v3f / .fix2 file

Vista's fixture files (.v3f for Vista 3, .fix2 for Vista 2) are an encrypted container, not XML or text, so no outside program can write one. Build the profile once in Vista's own Fixture Editor using the values below, then use **Patch > Export Fixture Profiles** (or right-click the fixture in Patch > **Export to fixture library**) to get a genuine .v3f you can copy to other Vista machines or share with colleagues. Vista does not import GDTF or Open Fixture Library files.

Alternative: Chroma-Q builds profiles free of charge from a DMX chart via their fixture request form (vistabychromaq.com/vista-by-chroma-q-fixture-request). Send them this sheet.

## Open the editor

1. **Patch > Fixture Editor** (on Windows the Fixture Type Library Editor is also a separate desktop shortcut).
2. Collapse the **Factory** folder, select **User Fixture Library**, then **Fixture > New Fixture**.
3. The fixture window has five tabs: Main, DMX Chart, DMX Macros, Notes, History.

## Main tab

Double-click a field to edit it.

| Field | Value |
|---|---|
| Manufacturer | Explo |
| Full Name | ${FIXTURE_TYPE} |
| Short Name | X2 Wave |
| Fixture Status | Verified (or your choice) |
| Beam Type | Other / None |
| Frame Type | No Frame |
| Movement Type | Moving Head |
| Physical Type | Effect (flame) |
| Light Generation | Other |
| Maximum Pan Degrees | 0 |
| Maximum Tilt Degrees | 210 (needed so Invert mirrors the nozzle angle) |
| Element Count Horizontally / Vertically | 1 / 1 |
| Is a Scroller | No |
| Patch Parts Count | 1 |
| UUID / Compatibility ID | leave as generated |
| Revision | 1 |

## DMX Chart tab

Click **Add DMX Channel** six times. In the dialog set Feature Class, Feature Type, Feature Name (only editable for custom features), DMX Channel Type = 8 bit, Channel number and Default Value, then OK.

| Ch | Feature Name | Feature Class | Feature Type | Type | Default | DMX ranges (Add DMX Range) |
|---|---|---|---|---|---|---|
${ch}

${notes}

### CH5 Program slots

For the Gobo Wheel channel use **Add Slot** per sequence (Name, DMX value = start of the range) so the operator picks sequences from the Gobo panel. If you prefer a lighter profile, make CH5 a Custom Miscellaneous channel and add only the ranges for the sequences your show uses (sheet 04 in the Vista export lists them).

| Seq | DMX range | Slot value | Name |
|---|---|---|---|
${rows}

## DMX Macros tab (optional)

| Macro | Values |
|---|---|
| Arm | CH6 = 128 |
| Disarm | CH6 = 0 |
| Home | CH1 = 128, CH2 = 255 |
| Fire | CH3 = 255, then back to 0 |

## Save and use

1. Compare the ranges with the Explo X2 Wave Flame manual, click **OK**, then **OK** on **Save Fixture and Exit**.
2. Quit the editor, click **Apply** then **OK**; Vista rebuilds its catalogue (this takes a moment).
3. The profile appears under **User Fixture Library** in Patch. Re-run **Patch > Import Patch File** with 01-patch.csv from the Wave Studio export and pick this profile when Vista asks.
4. **Patch > Export Fixture Profiles** saves the finished .v3f; **Patch > Import Fixture Profiles** loads it on another machine (user fixtures live in Documents/Vista/Fixtures).

Wave Studio models the standard Explo six-channel map. Confirm every value against the manufacturer manual before firing real units.

Sources: Vista 3 R3 User Guide, Appendix 5 Fixture Editor (https://www.vistabychromaq.com/wordpress/wp-content/uploads/2021/12/Vista-V3-R3.0-User-Guide-Espanol.pdf); Vista 3 R1 release notes on .v3f naming (https://chroma-q.com/assets/uploads/product_downloads/56d00d363880b699c0e71906af37512c.pdf); CQTB004 Importing Fixture Profiles in Vista 3 (https://www.vistabychromaq.com/wordpress/wp-content/uploads/2021/07/CQTB004_Importing_Fixture_Profiles_in_Vista_3.pdf); Chroma-Q forum sample profiles (https://vistaforum.chroma-q.com/t/fixture-definition/2088, https://vistaforum.chroma-q.com/t/1975); export to fixture library (https://vistaforum.chroma-q.com/t/custom-fixture-move-with-show/3345); GDTF requests (https://vistaforum.chroma-q.com/t/database-gdtf/3115).
`;
}
export const FIXTURE_SHEET_FILE='Explo-X2-Wave-Flame-Vista-3-Fixture-Editor-Build-Sheet.md';

export function readmeText({fixtures,playback,version,date}){
 return [`Wave Studio ${version} - Vista 3 hand-off package (${date})`,'',
  `${fixtures.length} fixture(s), ${playback.cues.length} cue(s), ${(playback.stacks||[]).filter(st=>st.entries.length).length} cue stack(s), 20 fader assignments, ${(playback.macros||[]).length} macros.`,'',
  'WHAT THIS IS',
  'Vista 3 saves shows as .v3s, a closed format that Chroma-Q does not document, so no outside program can write a genuine show file.',
  'This package uses the import paths Vista does document, so the structure arrives automatically and only fixture values are finished inside Vista.','',
  'STEPS IN VISTA 3 (R5 or newer recommended)',
  '1. Fixture profile: open Patch > Fixture Editor and build the Explo X2 Wave Flame profile from 05-fixture-profile-Explo-X2-Wave-Flame.txt',
  '   (field-by-field sheet). Vista fixture files (.v3f / .fix2) are encrypted, so they cannot be generated outside Vista; once built,',
  '   Patch > Export Fixture Profiles gives you a .v3f to reuse. Skip this if the profile is already in your library.',
  '2. Patch: Patch > Import Patch File > choose 01-patch.csv. Columns are ID, Univ:Adrs, Fixture Type, Fixture Name. Universes are 1-based',
  '   (Wave Studio port 0 = Vista universe 1). If Vista asks which profile matches the Fixture Type text, pick the Explo profile.',
  '3. Cues: File > Import Cues CSV > choose 02-cues.csv. This brings cue numbers, names, fade/delay/hold timing and the notes column that lists',
  '   which fixtures and sequences each cue runs. If your Vista build expects different column names, export any cuelist with File > Export CSV,',
  '   copy its header row over ours in a spreadsheet, and import again. Each Cue Stack with entries is also exported as 02-cuelist-<nn>-<name>.csv',
  '   with Follow/Wait/Timecode columns, so you can import a stack as its own Vista cuelist.',
  '4. Program values: open 04-cue-contents.csv and, cue by cue, set each fixture to the listed channel values in the Vista programmer, then',
  '   Store to the matching cue. Program sequences arm on CH6 (50-200) and start on a rising edge of CH3 to 254-255 with CH5 inside the valid range.',
  '   Make CH3 Ignition and CH6 Arm snap channels (no crossfade) in the fixture profile or in each cue, so a fade never passes through firing values.',
  '   Follow every firing cue with a step that returns CH3 Ignition to 0, and end the show with a release cue that sets CH6 Arm to 0 (Safe).',
  '5. Playbacks: use 03-fader-assignments.csv to assign cues to playback faders 1-20, flash levels, loop behaviour and the DMX-in addresses that',
  '   Wave Studio listened to for each fader and button, so your physical layout matches the rehearsal.',
  '6. 00-fixture-layout.csv carries stage positions (as % of the stage), inversion, nozzle type, angle limits and home angles for the Vista',
  '   fixture layout view and for setting a home/park cue.','',
  'LIMITS',
  '- Vista imports cue structure, timing and notes from CSV, not fixture values. Step 4 is a one-time programming pass per cue.',
  '- Chase settings and macros are listed for reference; Vista has its own chase and macro editors.',
  '- Wave Studio is a visualizer. Verify every arm, ignition and angle on the real system with the manufacturer manual before firing.',''].join(CRLF);
}

// Minimal store-only ZIP writer (no compression). Enough for a handful of text files.
const CRC_TABLE=(()=>{const t=new Uint32Array(256);for(let n=0;n<256;n++){let c=n;for(let k=0;k<8;k++)c=c&1?0xEDB88320^(c>>>1):c>>>1;t[n]=c>>>0}return t})();
export function crc32(bytes){let c=0xFFFFFFFF;for(let i=0;i<bytes.length;i++)c=CRC_TABLE[(c^bytes[i])&0xFF]^(c>>>8);return (c^0xFFFFFFFF)>>>0}
function dosTime(d){return {time:((d.getHours()&31)<<11)|((d.getMinutes()&63)<<5)|((d.getSeconds()>>1)&31),date:(((d.getFullYear()-1980)&127)<<9)|(((d.getMonth()+1)&15)<<5)|(d.getDate()&31)}}
export function zipStore(files,now=new Date()){
 const enc=new TextEncoder(),{time,date}=dosTime(now),parts=[],central=[];let offset=0;
 const u16=n=>[n&255,(n>>8)&255],u32=n=>[n&255,(n>>8)&255,(n>>16)&255,(n>>>24)&255];
 if(!Array.isArray(files)||files.length>1000)throw Error('Too many files for one export.');
 for(const {name,text} of files){
  const nameBytes=enc.encode(name),data=typeof text==='string'?enc.encode(text):text,crc=crc32(data);
  const local=new Uint8Array([...u32(0x04034b50),...u16(20),...u16(0x0800),...u16(0),...u16(time),...u16(date),...u32(crc),...u32(data.length),...u32(data.length),...u16(nameBytes.length),...u16(0),...nameBytes]);
  parts.push(local,data);
  central.push(new Uint8Array([...u32(0x02014b50),...u16(20),...u16(20),...u16(0x0800),...u16(0),...u16(time),...u16(date),...u32(crc),...u32(data.length),...u32(data.length),...u16(nameBytes.length),...u16(0),...u16(0),...u16(0),...u16(0),...u32(0),...u32(offset),...nameBytes]));
  offset+=local.length+data.length;
 }
 const centralSize=central.reduce((n,c)=>n+c.length,0);
 const end=new Uint8Array([...u32(0x06054b50),...u16(0),...u16(0),...u16(files.length),...u16(files.length),...u32(centralSize),...u32(offset),...u16(0)]);
 return new Blob([...parts,...central,end],{type:'application/zip'});
}

export function buildVistaPackage({fixtures,playback,version,now=new Date()}){
 const date=now.toISOString().slice(0,10);
 const files=[
  {name:'README-Vista-3.txt',text:readmeText({fixtures,playback,version,date})},
  {name:'00-fixture-layout.csv',text:fixtureLayoutCsv(fixtures)},
  {name:'01-patch.csv',text:patchCsv(fixtures)},
  {name:'02-cues.csv',text:cuesCsv(playback,fixtures)},
  ...(playback.stacks||[]).filter(st=>st.entries.length).map((st,i)=>({name:stackFileName(st,i),text:stackCsv(st,playback,fixtures)})),
  {name:'03-fader-assignments.csv',text:faderAssignmentsCsv(playback)},
  {name:'04-cue-contents.csv',text:cueContentsCsv(playback,fixtures)},
  {name:'05-fixture-profile-Explo-X2-Wave-Flame.txt',text:fixtureProfileText()},
  {name:'05-fixture-profile-Explo-X2-Wave-Flame.md',text:fixtureProfileMarkdown()}];
 return {files,blob:zipStore(files,now),fileName:`wave-studio-vista3-${date}.zip`};
}

export function mountVistaExport({after,capture,version,announce}){
 const button=document.createElement('button');button.id='export-vista';button.type='button';button.textContent='Export For Vista 3';button.title='Download a Vista 3 import package: patch CSV, cues CSV, fader assignments and programming sheets';
 after.after(button);
 const dialog=document.createElement('dialog');dialog.className='vista-dialog';dialog.setAttribute('aria-label','Export For Vista 3');
 dialog.innerHTML=`<form method="dialog"><h2>Export For Vista 3</h2>
<p>Creates a ZIP you can open on the Vista 3 machine. Vista's own <code>.v3s</code> show file is a closed format, so the package uses Vista's documented import paths instead.</p>
<ul>
<li><strong>01-patch.csv</strong> - Patch > Import Patch File (ID, Univ:Adrs, Fixture Type, Fixture Name)</li>
<li><strong>02-cues.csv</strong> - File > Import Cues CSV (Vista 3 R5+): cue numbers, names, timing, notes</li>
<li><strong>03-fader-assignments.csv</strong> - the 20 playback faders, flash levels, loop, DMX-in addresses, chase and macros</li>
<li><strong>04-cue-contents.csv</strong> - per cue, per fixture channel values to store in Vista's programmer</li>
<li><strong>05-fixture-profile</strong> - field-by-field build sheet for Vista's Fixture Editor as .txt and .md (Vista's .v3f/.fix2 files are encrypted, so the profile is built once in Vista and exported from there), plus a README with the steps. <em>Fixture Build Sheet</em> below downloads just that sheet.</li>
</ul>
<p class="vista-note" data-summary></p>
<p class="vista-note">Vista imports structure and timing from CSV, not fixture values, so each cue needs one programming pass from sheet 04 before the show runs.</p>
<menu><button type="button" value="cancel" data-cancel>Cancel</button><button type="button" data-sheet title="Download only the Fixture Editor build sheet (Markdown)">Fixture Build Sheet</button><button type="button" class="primary" data-export>Download Package</button></menu></form>`;
 document.body.append(dialog);
 dialog.querySelector('[data-cancel]').onclick=()=>dialog.close();
 dialog.querySelector('[data-sheet]').onclick=async()=>{
  dialog.close();
  const result=await requestFileSave(new Blob([fixtureProfileMarkdown()],{type:'text/markdown'}),FIXTURE_SHEET_FILE).catch(e=>({message:e.message}));
  announce?.(result?.message||`Fixture build sheet ready: ${FIXTURE_SHEET_FILE}.`);
 };
 dialog.querySelector('[data-export]').onclick=async()=>{
  let pkg;
  try{const {fixtures,playback}=capture();pkg=buildVistaPackage({fixtures,playback,version})}
  catch(error){dialog.close();announce?.(`Export Failed: ${error.message||'Unknown Error'}. Nothing Was Downloaded.`);return}
  dialog.close();
  const result=await requestFileSave(pkg.blob,pkg.fileName).catch(e=>({message:e.message}));
  announce?.(result?.message||`Vista 3 package ready: ${pkg.fileName}.`);
 };
 button.onclick=()=>{const {fixtures,playback}=capture();dialog.querySelector('[data-summary]').textContent=`${fixtures.length} fixture(s), ${playback.cues.length} cue(s) and ${playback.slots.filter(s=>!s.dmxPriority&&s.cueId!=null).length} fader cue assignment(s) will be exported.`;dialog.showModal()};
 return {button,dialog};
}
