#!/bin/bash
# Readable launcher. No downloads, sudo, quarantine removal or security changes.
cd -- "$(dirname -- "$0")" || exit 1
PYTHON=""
for candidate in \
  "/Library/Frameworks/Python.framework/Versions/Current/bin/python3" \
  "/opt/homebrew/bin/python3" \
  "/usr/local/bin/python3" \
  "$(command -v python3 2>/dev/null)"; do
  # Avoid invoking Apple's developer-tools stub.
  [ "$candidate" = "/usr/bin/python3" ] && continue
  if [ -n "$candidate" ] && [ -x "$candidate" ] &&
     "$candidate" -c 'import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)' ; then
    PYTHON="$candidate"
    break
  fi
done
if [ -z "$PYTHON" ]; then
  printf '\nVirtual SFX Lab (Wave Studio) needs Python 3.10 or newer.\n'
  printf 'Install a current stable universal2 release from:\n'
  printf 'https://www.python.org/downloads/macos/\n\n'
  printf 'Then double-click this launcher again. No pip packages are needed.\n'
  printf 'Nothing else is needed: the demo, full studio and manual are all served locally.\n'
  read -r -p 'Press Return to close.' ignored
  exit 1
fi
# Replace this shell too: closing/signalling the launcher must not orphan input.
exec "$PYTHON" -u "./mac_launcher.py" "$@"
