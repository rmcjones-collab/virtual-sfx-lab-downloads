// Local checklist UI. Checking a step never triggers the operation it describes.
// Built-in: the colleague test checklist (./colleague-test-checklist.md). Custom checklists are written in the
// same Markdown shape and stay in this browser's localStorage (prototype storage, no sync, no server copy).
import {requestFileSave} from './file-save.js?v=v0311-20261005d';
const STORE='vsl-checklists',BUILTIN='builtin:colleague',MAX_LISTS=40,MAX_SOURCE=40000;
const FORMAT=`# My Checklist

Intro paragraph (optional).

## Section Title

- [ ] First step to test
- [ ] Second step

## Another Section

- [ ] Step

\`\`\`
Notes template (optional): lines here become the editable Test Notes box.
\`\`\``;
const loadCustom=()=>{try{const v=JSON.parse(localStorage.getItem(STORE)||'[]');return Array.isArray(v)?v.filter(c=>c&&typeof c.id==='string'&&typeof c.title==='string'&&typeof c.source==='string').slice(0,MAX_LISTS):[]}catch{return []}};
const saveCustom=lists=>localStorage.setItem(STORE,JSON.stringify(lists.slice(0,MAX_LISTS)));
export function mountTestChecklist(host){
 host.innerHTML='<p class="support-note">Work through these steps with a colleague. Check a step only after you test it. Progress stays while this page is open; download results before reloading. Checklists you create are saved in this browser only.</p><div class="checklist-toolbar"><label class="checklist-pick">Checklist<select id="test-checklist-select" aria-label="Choose a checklist"></select></label><output id="test-checklist-progress" aria-live="polite">Loading Checklist…</output><div class="support-row"><button id="test-checklist-download" disabled>Download Results</button><button id="test-checklist-reset" disabled>Reset Checklist</button><button id="test-checklist-new">New Checklist</button><button id="test-checklist-edit" hidden>Edit</button><button id="test-checklist-delete" hidden>Delete</button></div></div><form id="test-checklist-editor" class="checklist-editor" hidden><label>Checklist Title<input id="checklist-title" maxlength="80" required placeholder="e.g. Pre-Show Virtual Rehearsal"></label><label>Steps (Markdown)<textarea id="checklist-source" rows="14" spellcheck="false" required></textarea></label><p class="support-note">Format: <code>## Section</code> headings, <code>- [ ] step</code> lines, plain lines become notes, and an optional <code>```</code> block becomes the Test Notes template. Nothing here runs or controls the app.</p><div class="support-row"><button type="submit" id="checklist-save">Save Checklist</button><button type="button" id="checklist-cancel">Cancel</button><button type="button" id="checklist-template">Insert Example</button></div></form><div id="test-checklist-content"></div><p id="test-checklist-status" class="support-status" role="status"></p>';
 const $=s=>host.querySelector(s),content=$('#test-checklist-content'),select=$('#test-checklist-select'),editor=$('#test-checklist-editor'),status=t=>$('#test-checklist-status').textContent=t;
 const plain=s=>s.replace(/\*\*/g,'');
 let checkboxes=[],blocks=[],notes=null,notesTemplate='',current=BUILTIN,currentTitle='Colleague Test Checklist',editing=null,builtinSource=null;
 const progress=()=>{$('#test-checklist-progress').textContent=`${checkboxes.filter(c=>c.checked).length} / ${checkboxes.length} Steps Checked`};
 function render(source){
  content.replaceChildren();checkboxes=[];blocks=[];notes=null;notesTemplate='';let parent=content,code=null,first=true;
  for(const line of source.split('\n')){
   if(line.startsWith('# '))continue;
   if(line.startsWith('```')){
    if(code===null){code=[];continue}
    notesTemplate=code.join('\n');notes=document.createElement('textarea');notes.id='test-checklist-notes';notes.maxLength=12000;notes.value=notesTemplate;notes.rows=10;
    const label=document.createElement('label');label.htmlFor=notes.id;label.textContent='Test Notes / Failure Report';parent.append(label,notes);blocks.push({notes:true});code=null;continue;
   }
   if(code!==null){code.push(line);continue}
   if(!line.trim())continue;
   if(line.startsWith('## ')){
    const title=line.slice(3).trim(),details=document.createElement('details'),summary=document.createElement('summary');summary.textContent=title;details.className='test-checklist-section';details.open=first;first=false;details.append(summary);content.append(details);parent=details;blocks.push({heading:title});continue;
   }
   if(/^[-*] \[[ xX]\] /.test(line)){
    const label=document.createElement('label'),input=document.createElement('input'),text=document.createElement('span');
    input.type='checkbox';input.dataset.testStep=checkboxes.length;text.textContent=plain(line.slice(6).trim());label.className='test-checklist-step';label.append(input,text);parent.append(label);checkboxes.push(input);blocks.push({input,text:text.textContent});input.onchange=progress;continue;
   }
   const p=document.createElement('p');p.textContent=plain(line.replace(/^[-*] /,''));parent.append(p);blocks.push({paragraph:p.textContent});
  }
  if(!notes){notes=document.createElement('textarea');notes.id='test-checklist-notes';notes.maxLength=12000;notes.rows=6;notes.placeholder='Test notes (optional)';const label=document.createElement('label');label.htmlFor=notes.id;label.textContent='Test Notes';content.append(label,notes);blocks.push({notes:true})}
  progress();$('#test-checklist-download').disabled=!checkboxes.length&&!blocks.length;$('#test-checklist-reset').disabled=false;
 }
 async function loadBuiltin(){
  if(builtinSource!==null)return builtinSource;
  const response=await fetch(new URL('./colleague-test-checklist.md',import.meta.url),{cache:'no-store'});
  if(!response.ok)throw Error('Checklist could not load. Reload the preview to retry.');
  return builtinSource=await response.text();
 }
 function fillSelect(){
  const lists=loadCustom();select.replaceChildren(new Option('Colleague Test Checklist (built-in)',BUILTIN));
  for(const c of lists)select.append(new Option(c.title,c.id));
  select.value=lists.some(c=>c.id===current)||current===BUILTIN?current:BUILTIN;current=select.value;
  const custom=current!==BUILTIN;$('#test-checklist-edit').hidden=!custom;$('#test-checklist-delete').hidden=!custom;
 }
 async function show(id){
  current=id;fillSelect();editor.hidden=true;
  try{
   if(id===BUILTIN){currentTitle='Colleague Test Checklist';render(await loadBuiltin())}
   else{const c=loadCustom().find(x=>x.id===id);if(!c)throw Error('That checklist is no longer stored in this browser.');currentTitle=c.title;render(c.source)}
   status('');
  }catch(e){$('#test-checklist-progress').textContent='Checklist Unavailable';status(e.message)}
 }
 select.onchange=()=>show(select.value);
 function openEditor(existing){
  editing=existing||null;editor.hidden=false;$('#checklist-title').value=existing?.title||'';$('#checklist-source').value=existing?.source||'';$('#checklist-title').focus();
  status(existing?`Editing “${existing.title}”. Saving replaces the stored copy.`:'Write the new checklist, then Save Checklist.');
 }
 $('#test-checklist-new').onclick=()=>openEditor(null);
 $('#test-checklist-edit').onclick=()=>{const c=loadCustom().find(x=>x.id===current);if(c)openEditor(c)};
 $('#checklist-template').onclick=()=>{if(!$('#checklist-source').value.trim()||confirm('Replace the editor text with the example format?'))$('#checklist-source').value=FORMAT};
 $('#checklist-cancel').onclick=()=>{editor.hidden=true;editing=null;status('')};
 editor.onsubmit=e=>{
  e.preventDefault();const title=$('#checklist-title').value.trim().slice(0,80),source=$('#checklist-source').value;
  if(!title)return status('Enter a title.');
  if(source.length>MAX_SOURCE)return status(`Checklist text is too long (${source.length} characters; limit ${MAX_SOURCE}).`);
  if(!/^[-*] \[[ xX]\] \S/m.test(source))return status('Add at least one step line that starts with "- [ ] ".');
  const lists=loadCustom();
  if(editing){const c=lists.find(x=>x.id===editing.id);if(c){c.title=title;c.source=source;c.updated=new Date().toISOString()}}
  else{if(lists.length>=MAX_LISTS)return status(`This browser already stores ${MAX_LISTS} checklists. Delete one first.`);editing={id:`custom:${Date.now().toString(36)}${Math.random().toString(36).slice(2,6)}`,title,source,created:new Date().toISOString()};lists.push(editing)}
  try{saveCustom(lists)}catch{return status('Could not save: browser storage is full or blocked.')}
  const id=editing.id;editing=null;show(id);status(`Saved “${title}” in this browser.`);
 };
 $('#test-checklist-delete').onclick=()=>{
  const c=loadCustom().find(x=>x.id===current);if(!c||!confirm(`Delete the checklist “${c.title}” from this browser? Download Results first if you want to keep this run.`))return;
  saveCustom(loadCustom().filter(x=>x.id!==c.id));show(BUILTIN);status(`Deleted “${c.title}”.`);
 };
 $('#test-checklist-download').onclick=async()=>{
  const lines=[`# ${currentTitle} — Results`,'',`Downloaded: ${new Date().toISOString()}`,`${checkboxes.filter(c=>c.checked).length} / ${checkboxes.length} steps checked. Checked means tested, not automatically passed.`,''];
  for(const block of blocks){
   if(block.heading)lines.push('',`## ${block.heading}`,'');
   else if(block.input)lines.push(`- [${block.input.checked?'x':' '}] ${block.text}`);
   else if(block.notes)lines.push('',notes?.value||'','');
   else lines.push(block.paragraph,'');
  }
  const slug=currentTitle.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'').slice(0,50)||'checklist';
  const result=await requestFileSave(new Blob([lines.join('\n')],{type:'text/markdown;charset=utf-8'}),`wave-studio-${slug}-results.md`);
  if(result)status(result.message+' Nothing Was Sent To Chat Or Applied To The App.');
 };
 $('#test-checklist-reset').onclick=()=>{
  if(!confirm('Clear the checklist checkmarks and test notes? Download Results first if you want to keep this test run.'))return;
  checkboxes.forEach(input=>input.checked=false);if(notes)notes.value=notesTemplate;progress();status('Checklist Reset. Your Layout And Chat Are Unchanged.');
 };
 show(BUILTIN);
}
