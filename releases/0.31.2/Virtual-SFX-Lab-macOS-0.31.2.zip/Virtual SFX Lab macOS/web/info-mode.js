// Information mode (Ctrl + ?): the pointer becomes a help cursor. Hovering any control explains it,
// links the manual section and a tutorial, and can ask the connected AI. Clicks on the app are held
// while the mode is on, so nothing is triggered by exploring. Presentation only: no app state changes.
import {lookupInfo} from './control-info.js?v=v0311-20261005d';
import {tutorials,answerGuide} from './app-guide.js?v=v0311-20261005d';
import {loadManualIndex,searchManual,manualSections,manualHref,manualReady} from './manual-index.js?v=v0311-20261005d';
import {aiConnected,askAI,aiLabel} from './ai-connect.js?v=v0311-20261005d';
import {speak,stopSpeaking} from './speech.js?v=v0311-20261005d';
const HOVER='button,a[href],input,select,textarea,output,summary,[role=button],[role=tab],[data-fixture],.fixture-handle,.fader-strip,.workspace-card-head,canvas,label,[data-fuel-bar],.preset,#preset-list li,kbd';
const labelOf=el=>(el.getAttribute?.('aria-label')||el.title||el.labels?.[0]?.textContent||el.getAttribute?.('placeholder')||(el.matches?.('input[type=checkbox],input[type=radio]')?el.closest('label')?.textContent:'')||el.innerText||el.textContent||'').replace(/\s+/g,' ').trim().slice(0,90);
export function mountInfoMode({openTutorial,openManual,anchor}){
 const toggle=document.createElement('button');toggle.id='info-mode-toggle';toggle.type='button';toggle.textContent='?';toggle.setAttribute('aria-pressed','false');toggle.setAttribute('aria-label','Information mode: hover any control for help (Ctrl + ?)');toggle.title='Information Mode · Ctrl + ?';toggle.setAttribute('aria-keyshortcuts','Control+Shift+Slash');
 (anchor||document.querySelector('#manual-open'))?.after(toggle);
 const pop=document.createElement('aside');pop.className='info-popover';pop.hidden=true;pop.setAttribute('role','dialog');pop.setAttribute('aria-label','Control information');document.body.append(pop);
 let on=false,pinned=false,current=null,hoverEl=null,aiBusy=false;
 const text=(tag,cls,t)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(t!==undefined)n.textContent=t;return n};
 function describe(el){
  const hit=lookupInfo(el);if(hit)return hit;
  const label=labelOf(el);if(!label||label.length<2)return null;
  return {key:'generic',name:label,info:el.tagName==='INPUT'?`${el.type==='checkbox'?'Checkbox':el.type==='range'?'Slider':'Field'} · ${label}`:el.tagName==='SELECT'?`Dropdown · ${label}`:`Control · ${label}`,generic:true};
 }
 function manualFor(hit){
  if(hit.manual){const href=manualHref(...hit.manual.split('#'));const s=manualSections().find(x=>x.href===href);return s?{title:s.title,href,snippet:s.blocks[0]?.slice(0,220)}:{title:'First Guide',href}}
  if(!manualReady())return null;
  const [m]=searchManual(`${hit.name} ${hit.info||''}`,1);return m&&m.score>=2?{title:m.title,href:m.href,snippet:m.snippet}:null;
 }
 function tutorialFor(hit){
  if(hit.tutorial){const t=tutorials.find(x=>x.title.startsWith(hit.tutorial));if(t)return t}
  return answerGuide(`${hit.name} ${hit.info||''}`)[0]||null;
 }
 function render(hit,el){
  current=hit;pop.replaceChildren();
  const head=text('div','info-head');head.append(text('strong','',hit.name),text('span','info-tag',hit.viaShortcut?'Shortcut copy':hit.panel?'Panel':hit.inherited?'Inside '+hit.name:'Control'));pop.append(head);
  if(hit.inherited){const own=labelOf(el);if(own)pop.append(text('p','info-own',own))}
  pop.append(text('p','info-body',hit.info));
  if(hit.how)pop.append(text('p','info-how','How: '+hit.how));
  const manual=manualFor(hit),tutorial=tutorialFor(hit);
  if(manual?.snippet&&!hit.manual)pop.append(text('p','info-snippet','Manual: '+manual.snippet));
  else if(manual?.snippet)pop.append(text('p','info-snippet',manual.snippet));
  const row=text('div','info-actions');
  if(manual){const b=text('button','', 'Open In Manual');b.type='button';b.title=manual.title;b.onclick=()=>{exit();openManual(manual.href)};row.append(b)}
  if(tutorial){const b=text('button','','Tutorial: '+tutorial.title.replace(/^(Use|Build|Play|Save|Set|Add And|Select) /,''));b.type='button';b.onclick=()=>{exit();openTutorial(tutorial)};row.append(b)}
  if('speechSynthesis' in window){const b=text('button','','Read Aloud');b.type='button';b.onclick=()=>speak(`${hit.info} ${hit.how?'How to use it: '+hit.how:''}`,{lead:hit.name});row.append(b)}
  if(aiConnected()){const b=text('button','','Ask AI · '+aiLabel().split(' · ')[0]);b.type='button';b.onclick=()=>askAbout(hit,manual,tutorial,b);row.append(b)}
  {const b=text('button','info-exit','Exit Info Mode');b.type='button';b.onclick=exit;row.append(b)}
  pop.append(row);
  const foot=text('p','info-foot',pinned?'Pinned · click elsewhere to follow the pointer again · Esc exits Information mode':'Click to pin this card · Esc exits Information mode');pop.append(foot);
  pop.classList.toggle('pinned',pinned);pop.hidden=false;
 }
 async function askAbout(hit,manual,tutorial,button){
  if(aiBusy)return;aiBusy=true;button.disabled=true;const out=text('p','info-ai','Asking your assistant…');pop.append(out);
  try{
   if(!manualReady())await loadManualIndex().catch(()=>{});
   const ctx=[manual?.snippet?`Manual (${manual.title}): ${manual.snippet}`:'',tutorial?`Tutorial "${tutorial.title}": ${tutorial.steps.join(' ')}`:'',`Control description: ${hit.info}${hit.how?' How: '+hit.how:''}`].filter(Boolean).join('\n\n');
   const r=await askAI(`Explain the "${hit.name}" control in Wave Studio in detail, with one concrete example of using it.`,ctx,{maxTokens:400});
   out.textContent=r.text||'The assistant returned no text.';
  }catch(e){out.textContent='AI unavailable: '+e.message}
  finally{aiBusy=false;button.disabled=false}
 }
 function place(x,y){
  const w=pop.offsetWidth,h=pop.offsetHeight,pad=12;
  let left=x+16,top=y+18;if(left+w>innerWidth-pad)left=Math.max(pad,x-w-16);if(top+h>innerHeight-pad)top=Math.max(pad,y-h-18);
  pop.style.left=`${left}px`;pop.style.top=`${top}px`;
 }
 function targetAt(x,y){
  const el=document.elementFromPoint(x,y);if(!el||pop.contains(el)||el===toggle||el.closest('#info-mode-toggle,.info-popover'))return null;
  return el.closest(HOVER)||(el.closest('.workspace-card-content')?el:null);
 }
 function hover(e){
  if(!on||pinned)return;
  const el=targetAt(e.clientX,e.clientY);
  if(!el){if(hoverEl){hoverEl.classList.remove('info-target');hoverEl=null}pop.hidden=true;return}
  if(el!==hoverEl){hoverEl?.classList.remove('info-target');hoverEl=el;el.classList.add('info-target');const hit=describe(el);if(!hit){pop.hidden=true;return}render(hit,el)}
  if(!pop.hidden)place(e.clientX,e.clientY);
 }
 function block(e){
  if(!on)return;
  if(pop.contains(e.target)||e.target===toggle||e.target.closest?.('#info-mode-toggle'))return;
  e.preventDefault();e.stopImmediatePropagation();
  if(e.type==='pointerdown'){
   if(e.pointerType==='touch'||e.pointerType==='pen'){const el=targetAt(e.clientX,e.clientY);const hit=el&&describe(el);if(hit){hoverEl=el;pinned=true;render(hit,el);place(e.clientX,e.clientY)}else{pinned=false;pop.hidden=true}return}
   if(pinned){pinned=false;hoverEl=null;hover(e);return}
   if(hoverEl&&!pop.hidden){pinned=true;if(current)render(current,hoverEl)}
  }
 }
 function setMode(next){
  on=next;document.body.classList.toggle('info-mode',on);toggle.setAttribute('aria-pressed',String(on));toggle.classList.toggle('active',on);
  if(on){if(!manualReady())loadManualIndex().catch(()=>{});announce('Information mode on. Hover any control for help; clicks are held. Press Ctrl + ? or Escape to exit.')}
  else{pinned=false;pop.hidden=true;hoverEl?.classList.remove('info-target');hoverEl=null;stopSpeaking();announce('Information mode off.')}
 }
 const exit=()=>setMode(false);
 function announce(msg){let live=document.getElementById('info-mode-live');if(!live){live=document.createElement('p');live.id='info-mode-live';live.className='sr-only';live.setAttribute('role','status');document.body.append(live)}live.textContent=msg}
 toggle.onclick=()=>setMode(!on);
 document.addEventListener('pointermove',hover,{passive:true});
 for(const type of ['pointerdown','mousedown','pointerup','mouseup','click','dblclick','contextmenu','auxclick','touchstart','touchend'])document.addEventListener(type,block,{capture:true,passive:false});
 document.addEventListener('keydown',e=>{
  const infoKey=(e.ctrlKey||e.metaKey)&&!e.altKey&&(e.key==='?'||(e.code==='Slash'&&e.shiftKey));
  if(infoKey){e.preventDefault();setMode(!on);return}
  if(!on)return;
  if(e.key==='Escape'){e.preventDefault();e.stopImmediatePropagation();exit();return}
  // Keyboard users: Tab moves focus; describe the focused control.
  if(e.key==='Tab')setTimeout(()=>{const el=document.activeElement;if(!el||el===document.body||pop.contains(el))return;const hit=describe(el.closest(HOVER)||el);if(!hit){pop.hidden=true;return}hoverEl=el;render(hit,el);const r=el.getBoundingClientRect();place(r.left,r.bottom)},0);
  else if(!pop.contains(e.target)&&!['Shift','Control','Meta','Alt'].includes(e.key)){e.preventDefault();e.stopImmediatePropagation()}
 },true);
 return {toggle:()=>setMode(!on),isOn:()=>on,exit};
}
