import {tutorials,answerGuide} from './app-guide.js?v=v0311-20261005d';
import {watermarkedStream} from './watermark.js?v=v0311-20261005d';
import {mountChat} from './team-chat.js?v=v0311-20261005d';
import {mountTestChecklist} from './test-checklist.js?v=v0311-20261005d';
import {draggableWindow,raiseWindow} from './support-windows.js?v=v0311-20261005d';
import {bindMobileUtilityDrag} from './mobile-panel-drag.js?v=v0311-20261005d';
import {requestFileSave} from './file-save.js?v=v0311-20261005d';
import {loadManualIndex,searchManual,manualReady,manualContext} from './manual-index.js?v=v0311-20261005d';
import {PROVIDERS,aiConfig,aiConnected,aiLabel,saveAI,clearAI,askAI,testAI,perplexitySearchURL,checkSiteAssistant,usingSiteAssistant} from './ai-connect.js?v=v0311-20261005d';
import {mountInfoMode} from './info-mode.js?v=v0311-20261005d';
import {speak,stopSpeaking,mountVoiceSettings,onSpeechState} from './speech.js?v=v0311-20261005d';
const $=s=>document.querySelector(s);
export function mountSupport({workspace,state}){
 const launch=document.createElement('div');launch.className='support-launchers';
 launch.innerHTML='<button id="wave-guide-open">AI Assist</button><button id="wave-chat-open">Chat</button><button id="wave-checklist-open">Test Checklist</button><button id="wave-camera-open" aria-label="Camera" title="Camera"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 7h4l2-3h6l2 3h4v13H3z"/><circle cx="12" cy="13" r="4"/></svg></button>';
 ($('#vista-layout-download')||$('#dmx-setup')).after(launch);
 const panel=document.createElement('aside');panel.className='support-panel';panel.hidden=true;panel.setAttribute('aria-label','Wave Studio Support');
 panel.innerHTML='<div class="support-header"><strong id="support-title">App Guide</strong><button data-support-min aria-label="Minimize Support Panel">−</button><button data-support-close aria-label="Close Support Panel">×</button></div><section class="support-body" id="guide-panel"></section><section class="support-body" id="chat-panel" hidden></section><section class="support-body" id="checklist-panel" hidden></section><section class="support-body" id="camera-panel" hidden></section>';
 document.body.append(panel);
 bindMobileUtilityDrag(panel,[panel.querySelector('.support-header')],{title:()=>panel.querySelector('#support-title').textContent});
 let section='guide';
 draggableWindow(panel,panel.querySelector('.support-header'),{allowed:e=>section==='guide'||((e.ctrlKey||e.metaKey)&&e.shiftKey)||document.body.classList.contains('workspace-editing')});
 panel.querySelector('.support-header').title='Drag App Guide To Move · Ctrl + Shift + Drag Friends & Chat';
 const tabs=document.createElement('nav');tabs.className='support-tabs';tabs.setAttribute('aria-label','Support Sections');tabs.innerHTML='<button data-support-tab="guide">Guide</button><button data-support-tab="chat">Chat</button><button data-support-tab="checklist">Checklist</button><button data-support-tab="camera">Camera</button>';panel.querySelector('.support-header').after(tabs);
 const open=kind=>{section=kind;panel.hidden=false;raiseWindow(panel);panel.classList.remove('collapsed');panel.querySelector('[data-support-min]').textContent='−';for(const key of ['guide','chat','checklist','camera'])$(`#${key}-panel`).hidden=key!==kind;$('#support-title').textContent={guide:'App Guide',chat:'Friends & Chat',checklist:'Checklists',camera:'Camera & Video'}[kind];if(kind==='chat')chat.refresh();chat.markVisible()};
 for(const tab of tabs.querySelectorAll('button'))tab.onclick=()=>open(tab.dataset.supportTab);
 launch.querySelector('#wave-guide-open').onclick=()=>open('guide');launch.querySelector('#wave-chat-open').onclick=()=>open('chat');launch.querySelector('#wave-camera-open').onclick=()=>open('camera');
 launch.querySelector('#wave-checklist-open').onclick=()=>open('checklist');
 mountTestChecklist($('#checklist-panel'));
 panel.querySelector('[data-support-min]').onclick=e=>{const collapsed=panel.classList.toggle('collapsed');e.currentTarget.textContent=collapsed?'+':'−';e.currentTarget.setAttribute('aria-label',`${collapsed?'Restore':'Minimize'} Support Panel`)};
 panel.querySelector('[data-support-close]').onclick=()=>{panel.hidden=true;recognition?.stop();stopSpeaking()};
 $('#guide-panel').innerHTML='<p class="support-note" id="guide-mode-note">Searches the written tutorials and the First Guide manual, reads them aloud, and can hand questions to an AI assistant you connect below. Attachments stay in this browser unless you explicitly send them in Chat.</p><label for="guide-question">What Would You Like To Do?</label><textarea id="guide-question" placeholder="How do I arrange units, rotate them or build a cue stack?"></textarea><div class="support-row"><button id="guide-ask">Find Tutorial</button><button id="guide-dictate">Speak Question</button><button id="guide-stop-speaking">Stop Speaking</button><button id="guide-perplexity" title="Search the web with Perplexity in a new tab (no account needed)">Search With Perplexity ↗</button></div><p class="support-note">Dictation, when supported, may use your browser’s speech service. Review the text before searching. Press Ctrl + ? for Information mode: hover any control for its explanation, manual section and tutorial.</p><div id="guide-status" class="support-status" role="status"></div><details class="ai-connect" id="ai-connect"><summary id="ai-connect-summary">Your AI Assistant · Not connected</summary><p class="support-note">Connect the assistant you already pay for. Your key is stored only in this browser and is sent only to the provider you choose. Whatever you connect runs on that provider’s own usage system and billing: all fees are between you and the provider, outside Virtual SFX Lab. Answers are advice about using this visualizer, never instructions for operating real flame equipment.</p><label>Provider<select id="ai-provider"></select></label><p class="support-note" id="ai-provider-note"></p><div class="support-row" id="ai-provider-links"></div><label>API Key<input id="ai-key" type="password" autocomplete="off" spellcheck="false" placeholder="Paste the key from your provider"></label><label>Model (optional)<input id="ai-model" autocomplete="off" spellcheck="false"></label><label id="ai-endpoint-label" hidden>Endpoint URL<input id="ai-endpoint" autocomplete="off" spellcheck="false" placeholder="https://host/v1/chat/completions"></label><div class="support-row"><button id="ai-save">Save &amp; Test</button><button id="ai-disconnect">Disconnect</button></div><p id="ai-status" class="support-status" role="status"></p></details><details id="voice-settings"><summary id="voice-summary">Read Aloud Voice &amp; Narration</summary><div id="voice-host"></div></details><label>Screenshot Or Diagnostics<input id="guide-upload" type="file" accept="image/png,image/jpeg,image/webp,.json,.txt,.log"></label><div id="guide-attachment"></div><div id="guide-answer"></div><div id="guide-results"></div><div id="guide-manual"></div>';
 const guideStatus=t=>$('#guide-status').textContent=t;
 function showTutorials(list){
  const host=$('#guide-results');host.replaceChildren();
  for(const t of list){const article=document.createElement('article');article.className='guide-result';const title=document.createElement('h3');title.textContent=t.title;const steps=document.createElement('ol');for(const step of t.steps){const li=document.createElement('li');li.textContent=step;steps.append(li)}const buttons=document.createElement('div');buttons.className='support-row';
   const show=document.createElement('button');show.textContent='Show Control';show.onclick=()=>{const target=$(t.target);if(!target||!target.getClientRects().length){guideStatus('This control is hidden in your current view. Open Add Panels or return to Standard View.');return}panel.hidden=true;target.scrollIntoView({block:'center',behavior:'smooth'});target.classList.add('guide-highlight');setTimeout(()=>target.classList.remove('guide-highlight'),5000)};
   const read=document.createElement('button');read.textContent='Read Aloud';read.disabled=!('speechSynthesis' in window);read.onclick=()=>speak(t.steps.join(' '),{lead:t.title});
   buttons.append(show,read);
   if(manualReady()){const [m]=searchManual(t.title+' '+t.keys,1);if(m){const b=document.createElement('button');b.textContent='Open In Manual';b.title=m.title;b.onclick=()=>openManual(m.href);buttons.append(b)}}
   article.append(title,steps,buttons);host.append(article);
  }
 }
 const openManual=href=>{document.dispatchEvent(new CustomEvent('wave-open-manual',{detail:{href}}))};
 const el=(tag,cls,t)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(t!==undefined)n.textContent=t;return n};
 function showManual(hits,query){
  const host=$('#guide-manual');host.replaceChildren();if(!hits.length)return;
  host.append(el('h3','guide-section-title','From The First Guide'));
  for(const m of hits){
   const article=el('article','guide-result manual-hit');const part=m.part.replace(/ · .*/,'');article.append(el('h3','',m.title.startsWith(part)?m.title:`${part} · ${m.title}`),el('p','',m.snippet));
   const row=el('div','support-row');const open=el('button','','Open In Manual');open.onclick=()=>openManual(m.href);
   const read=el('button','','Read Aloud');read.disabled=!('speechSynthesis' in window);read.onclick=()=>speak(m.snippet,{lead:m.title});
   row.append(open,read);article.append(row);host.append(article);
  }
 }
 async function showAIAnswer(question,found){
  const host=$('#guide-answer');host.replaceChildren();if(!aiConnected())return;
  const article=el('article','guide-result ai-answer');article.append(el('h3','',`Answer From ${aiLabel()}`),el('p','ai-pending','Thinking…'));host.append(article);
  try{
   const ctx=[manualReady()?manualContext(question):'',...found.slice(0,2).map(t=>`## Tutorial: ${t.title}\n${t.steps.join(' ')}`)].filter(Boolean).join('\n\n');
   const r=await askAI(question,ctx);article.querySelector('.ai-pending')?.remove();
   for(const para of (r.text||'No answer returned.').split(/\n{2,}/))article.append(el('p','',para.trim()));
   const sources=r.sources?.length?r.sources:(r.citations||[]).map(url=>({url,title:url}));
   if(sources.length){const list=el('ol','ai-sources');for(const s of sources.slice(0,8)){const li=el('li');if(!/^https?:\/\//i.test(s.url))continue;const a=el('a','',s.title||s.url);a.href=s.url;a.target='_blank';a.rel='noopener noreferrer';a.title=s.url;li.append(a);if(s.date)li.append(el('span','ai-source-date',` · ${s.date}`));list.append(li)}article.append(el('p','guide-section-title','Sources'),list)}
   const row=el('div','support-row');const read=el('button','','Read Aloud');read.disabled=!('speechSynthesis' in window);read.onclick=()=>speak(r.text);row.append(read);article.append(row,el('p','support-note',r.site?'Generated by the site assistant (Perplexity Agent API) from the manual excerpts, tutorials and web sources; verify against the First Guide.':'Generated by your connected assistant from the manual excerpts and tutorials; verify against the First Guide.'));
  }catch(e){article.querySelector('.ai-pending')?.remove();article.append(el('p','support-status','AI unavailable: '+e.message))}
 }
 showTutorials(tutorials);
 $('#guide-ask').onclick=async()=>{
  const q=$('#guide-question').value.trim();if(!q)return;
  const found=answerGuide(q);
  if(!manualReady()){guideStatus('Searching tutorials and loading the manual…');try{await loadManualIndex()}catch(e){guideStatus(e.message)}}
  const hits=manualReady()?searchManual(q,4):[];
  showTutorials(found.length?found:tutorials);showManual(hits,q);
  guideStatus(found.length||hits.length?`${found.length?'Matching tutorials':'No tutorial match'}${hits.length?` · ${hits.length} manual section${hits.length===1?'':'s'}`:''}${aiConnected()?' · asking your AI':''}`:'No match in the tutorials or manual. Try other words, or Search With Perplexity.');
  showAIAnswer(q,found);
 };
 $('#guide-perplexity').onclick=()=>{const q=$('#guide-question').value.trim()||'Wave Studio Virtual SFX Lab Explo X2 visualizer';window.open(perplexitySearchURL(`Wave Studio (Virtual SFX Lab): ${q}`),'_blank','noopener')};
 // ---- Bring-your-own AI assistant ----
 {
  const provider=$('#ai-provider'),key=$('#ai-key'),model=$('#ai-model'),endpoint=$('#ai-endpoint'),endpointLabel=$('#ai-endpoint-label'),status=$('#ai-status'),note=$('#ai-provider-note'),links=$('#ai-provider-links'),summary=$('#ai-connect-summary');
  for(const [id,p] of Object.entries(PROVIDERS))provider.append(new Option(p.name,id));
  const aiStatus=t=>status.textContent=t;
  function syncProvider(){
   const p=PROVIDERS[provider.value];note.textContent=p.note;model.placeholder=p.model?`Default: ${p.model}`:'Model name';endpointLabel.hidden=provider.value!=='custom';links.replaceChildren();
   const link=(label,href)=>{if(!href)return;const a=el('a','button-link',label+' ↗');a.href=href;a.target='_blank';a.rel='noopener noreferrer';links.append(a)};
   if(provider.value==='perplexity')link('Sign Up For Perplexity',p.signup);else link('Create Account',p.signup);
   link('Get An API Key',p.keys);link('Docs & Pricing',p.docs);
  }
  function syncState(){
   const c=aiConfig(),siteOn=usingSiteAssistant();summary.textContent=`Your AI Assistant · ${c?.key?`Connected: ${aiLabel()}`:siteOn?'Using the site assistant (Perplexity) · connect your own to override':'Not connected'}`;$('#ai-disconnect').disabled=!c?.key;
   $('#guide-mode-note').textContent=c?.key?`Questions go to your connected assistant (${aiLabel()}) together with matching manual excerpts and tutorials; the written tutorials and manual search stay available. Attachments stay in this browser unless you explicitly send them in Chat.`:siteOn?'Questions are answered by the site assistant (Perplexity Agent API, web-grounded, with sources) together with matching manual excerpts and tutorials. It is part of the full studio with a fair-use allowance; connect your own assistant below for unlimited use. Attachments stay in this browser unless you explicitly send them in Chat.':'Searches the written tutorials and the First Guide manual, reads them aloud, and can hand questions to an AI assistant you connect below. Attachments stay in this browser unless you explicitly send them in Chat.';
   if(c){provider.value=c.provider;model.value=c.model||'';endpoint.value=c.endpoint||'';key.value='';key.placeholder='Saved in this browser · paste a new key to replace it'}else{provider.value='perplexity';key.placeholder='Paste the key from your provider'}
   syncProvider();
  }
  provider.onchange=syncProvider;
  $('#ai-save').onclick=async()=>{
   const existing=aiConfig();
   try{
    const cfg=saveAI({provider:provider.value,key:key.value||(existing?.provider===provider.value?existing.key:''),model:model.value,endpoint:endpoint.value});
    aiStatus(`Saved. Testing ${PROVIDERS[cfg.provider].name}…`);syncState();
    try{const reply=await testAI();aiStatus(`Connected. The assistant replied: “${reply.slice(0,40)}”. Ask a question above.`)}
    catch(e){if(existing)localStorage.setItem('vsl-ai-assistant',JSON.stringify(existing));else clearAI();document.dispatchEvent(new CustomEvent('wave-ai-changed'));throw Error(`${e.message}${existing?' Your previous connection was kept.':' Nothing was saved.'}`)}
   }catch(e){aiStatus(`Not connected: ${e.message}`)}
  };
  $('#ai-disconnect').onclick=()=>{clearAI();key.value='';model.value='';endpoint.value='';aiStatus('Disconnected. The key was removed from this browser.');syncState()};
  document.addEventListener('wave-ai-changed',syncState);syncState();checkSiteAssistant();
 }
 const infoMode=mountInfoMode({openManual,openTutorial:t=>{open('guide');$('#guide-answer').replaceChildren();$('#guide-manual').replaceChildren();showTutorials([t]);guideStatus(`Tutorial: ${t.title}`);$('#guide-results').scrollIntoView({block:'start',behavior:'smooth'})}});
 loadManualIndex().then(()=>{if(!$('#guide-manual').children.length&&!$('#guide-question').value)showTutorials(tutorials)}).catch(()=>{});
 $('#guide-stop-speaking').onclick=()=>stopSpeaking();onSpeechState(on=>{$('#guide-stop-speaking').classList.toggle('speaking',on)});mountVoiceSettings($('#voice-host'));
 let recognition=null,guideURL=null;
 const Speech=window.SpeechRecognition||window.webkitSpeechRecognition;
 $('#guide-dictate').onclick=()=>{if(!Speech){guideStatus('Speech input is not supported here. Use your phone’s keyboard microphone or type your question.');return}try{recognition?.stop();recognition=new Speech();recognition.lang='en-CA';recognition.interimResults=false;recognition.onresult=e=>{$('#guide-question').value=e.results[0][0].transcript;guideStatus('Dictation ready. Review it, then Find Tutorial.')};recognition.onerror=e=>guideStatus(`Dictation unavailable (${e.error}). You can still type.`);recognition.onend=()=>$('#guide-dictate').textContent='Speak Question';recognition.start();$('#guide-dictate').textContent='Listening…'}catch{guideStatus('Microphone access is blocked in this browser or embedded preview.')}};
 function guideImage(blob,name='Screenshot'){
  const host=$('#guide-attachment');host.replaceChildren();if(guideURL)URL.revokeObjectURL(guideURL);guideURL=URL.createObjectURL(blob);const image=document.createElement('img');image.src=guideURL;image.alt=name;const note=document.createElement('p');note.textContent='Local screenshot reference only. The app guide cannot analyze images. Attach it in Chat to ask a human instructor.';const clear=document.createElement('button');clear.textContent='Remove Attachment';clear.onclick=()=>{host.replaceChildren();URL.revokeObjectURL(guideURL);guideURL=null};host.append(image,note,clear);
 }
 $('#guide-upload').onchange=async e=>{const f=e.target.files[0];e.target.value='';if(!f)return;if(f.size>6000000){guideStatus('Use a file smaller than 6 MB.');return}if(['image/png','image/jpeg','image/webp'].includes(f.type)){guideImage(f,f.name);return}if(f.size>256000){guideStatus('Diagnostics must be under 256 KB.');return}const host=$('#guide-attachment');host.replaceChildren();const text=await f.text();const pre=document.createElement('pre');pre.className='guide-result';try{const d=JSON.parse(text);pre.textContent=`Diagnostic Summary\nFormat: ${String(d.format??'JSON').slice(0,80)}\nVersion: ${String(d.version??'Not Specified').slice(0,20)}\nUnits: ${d.fixtures?.length??'Not Included'}\nFaders: ${d.playback?.slots?.length??'Not Included'}\nSession Actions: ${d.actions?.length??'Not Included'}\n\nNot executed or applied. No AI analysis.`}catch{pre.textContent='Local Diagnostic Preview (Not AI-Analyzed)\n\n'+text.slice(0,6000)}host.append(pre);guideStatus('Diagnostics loaded locally. Nothing was applied to the app.')};

 const camera=$('#camera-panel');
 camera.innerHTML='<p class="support-note">Camera starts locally and is not shared until you choose Share Camera In Call. This is an observation aid, not a safety or firing control.</p><label>Camera<select id="camera-facing"><option value="environment">Rear Camera</option><option value="user">Front Camera</option></select></label><div class="support-row"><button id="camera-start">Start Camera</button><button id="camera-stop">Stop Camera</button><button id="camera-share">Share Camera In Call</button></div><video id="camera-preview" autoplay muted playsinline></video><div class="support-row"><button id="camera-record">Record Example</button><button id="camera-record-stop">Stop Recording</button></div><div id="camera-recording"></div><p id="camera-status" class="support-status" role="status"></p>';
 let cameraStream=null,recorder=null,recordChunks=[],clipURL=null,cameraGeneration=0,marked=null;
 const camStatus=t=>$('#camera-status').textContent=t;
 function stopCamera(){cameraGeneration++;if(recorder?.state==='recording')recorder.stop();else{marked?.stop();marked=null}cameraStream?.getTracks().forEach(t=>t.stop());cameraStream=null;$('#camera-preview').srcObject=null;chat.setCamera(null);document.dispatchEvent(new CustomEvent('wave-media-state',{detail:{localCamera:false}}));camStatus('Camera stopped.')}
 async function startCamera(){stopCamera();const token=cameraGeneration;try{if(!navigator.mediaDevices?.getUserMedia)throw Error('Camera unavailable in this browser. Open the standalone HTTPS site.');const stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:$('#camera-facing').value}},audio:false});if(token!==cameraGeneration){stream.getTracks().forEach(t=>t.stop());return}cameraStream=stream;$('#camera-preview').srcObject=cameraStream;document.dispatchEvent(new CustomEvent('wave-media-state',{detail:{localCamera:true}}));camStatus('Local Preview Only. Microphone is off.')}catch(e){camStatus(e.message||'Camera permission denied. Try the standalone site.')}}
 $('#camera-start').onclick=startCamera;$('#camera-stop').onclick=stopCamera;$('#camera-facing').onchange=()=>{if(cameraStream)startCamera()};
 $('#camera-share').onclick=()=>{if(!cameraStream){camStatus('Start your camera first.');return}if(!chat.setCamera(cameraStream)){camStatus('Join a chat call first.');return}camStatus('Camera shared with the current call. Stop Camera or Leave Call to end sharing.')};
 $('#camera-record').onclick=async()=>{if(!cameraStream){camStatus('Start the camera first.');return}if(!window.MediaRecorder){camStatus('Recording is not supported here.');return}if(recorder?.state==='recording')return;recordChunks=[];try{marked?.stop();marked=null;const source=cameraStream,next=await watermarkedStream(source);if(source!==cameraStream||recorder?.state==='recording'){next.stop();return}marked=next;recorder=new MediaRecorder(marked.stream,{videoBitsPerSecond:650000});recorder.ondataavailable=e=>{if(e.data.size)recordChunks.push(e.data);if(recordChunks.reduce((n,b)=>n+b.size,0)>5500000&&recorder.state==='recording')recorder.stop()};recorder.onstop=()=>{marked?.stop();marked=null;const blob=new Blob(recordChunks,{type:recorder.mimeType.split(';')[0]});if(clipURL)URL.revokeObjectURL(clipURL);clipURL=URL.createObjectURL(blob);const host=$('#camera-recording');host.replaceChildren();const v=document.createElement('video');v.controls=true;v.src=clipURL;const a=document.createElement('a');a.href=clipURL;a.download='wave-camera-example.'+(blob.type.includes('mp4')?'mp4':'webm');a.textContent='Download Clip';const attach=document.createElement('button');attach.textContent='Attach To Chat';attach.onclick=()=>{chat.attach(blob,a.download);open('chat')};host.append(v,a,attach);camStatus('Recording ready locally. Review before sharing.');};recorder.start(1000);camStatus('Recording silent video locally; automatic size limit is approximately 6 MB.')}catch(e){marked?.stop();marked=null;camStatus(e.message)}};
 $('#camera-record-stop').onclick=()=>{if(recorder?.state==='recording')recorder.stop()};
 const badge=document.createElement('button');badge.type='button';badge.className='chat-unread-badge';badge.setAttribute('aria-label','Reply to new chat message');badge.title='Open the newest unread conversation and reply';badge.hidden=true;panel.querySelector('.support-header').insertBefore(badge,panel.querySelector('[data-support-min]'));
 const chat=mountChat({host:$('#chat-panel'),workspace,onOpen:()=>open('chat'),onUnread:rooms=>{
  const has=rooms.length>0,b=$('#wave-chat-open');b.classList.toggle('has-unread',has);b.textContent=has?`Chat · ${rooms.length} New`:'Chat';b.setAttribute('aria-label',has?`Chat: unread messages in ${rooms.length} conversation${rooms.length===1?'':'s'}`:'Chat');
  badge.hidden=!has;badge.textContent=has?`${rooms.length} New`:'';panel.classList.toggle('has-unread',has);
 },onLeave:()=>{if(cameraStream)stopCamera()}});
 badge.onclick=()=>chat.openUnread();
 launch.querySelector('#wave-chat-open').onclick=()=>chat.openUnread();
 const mediaStop=document.createElement('button');mediaStop.id='support-media-stop';mediaStop.hidden=true;mediaStop.textContent='Media Active · Stop All Media';document.body.append(mediaStop);
 $('#camera-recording').addEventListener('click',async e=>{
  const a=e.target.closest('a[download]');if(!a)return;e.preventDefault();
  try{const blob=await fetch(a.href).then(r=>r.blob());await requestFileSave(blob,a.download)}catch(error){camStatus('Could not save clip: '+error.message)}
 });
 const mediaFlags={};
 document.addEventListener('wave-media-state',e=>{Object.assign(mediaFlags,e.detail);mediaStop.hidden=!Object.values(mediaFlags).some(Boolean)});
 mediaStop.onclick=()=>{stopCamera();chat.leave()};

 const shot=document.createElement('button');shot.id='workspace-screenshot';shot.textContent='Screenshot';$('#workspace-fullscreen').after(shot);
 shot.classList.add('customize-shortcut');shot.dataset.shortcut='Ctrl + Shift + S';shot.title='Screenshot · Ctrl + Shift + S';shot.setAttribute('aria-keyshortcuts','Control+Shift+S');
 const capture=document.createElement('dialog');capture.className='capture-dialog';capture.innerHTML='<h2>Layout Screenshot</h2><p>Current virtual stage only, not your desktop, camera or private chat.</p><img alt="Screenshot Preview"><div class="support-row"><button data-shot-download>Download PNG</button><button data-shot-guide>Attach To Guide</button><button data-shot-chat>Attach To Chat</button><button data-shot-close>Close</button></div>';document.body.append(capture);
 let shotBlob=null,shotURL=null;
 shot.onclick=()=>{const canvas=$('#viewport canvas')??$('#stage');if(!canvas||canvas.width<1||canvas.height<1){alert('Restore the Layout panel before capturing.');return}try{canvas.toBlob(blob=>{if(!blob)return;if(shotURL)URL.revokeObjectURL(shotURL);shotBlob=blob;shotURL=URL.createObjectURL(blob);capture.querySelector('img').src=shotURL;capture.showModal()},'image/png')}catch{alert('This browser blocked screenshot capture. Use your device’s screenshot controls.')}};
 capture.querySelector('[data-shot-close]').onclick=()=>capture.close();
 capture.querySelector('[data-shot-download]').onclick=()=>requestFileSave(shotBlob,'wave-layout-screenshot.png');
 capture.querySelector('[data-shot-guide]').onclick=()=>{guideImage(shotBlob);capture.close();open('guide')};
 capture.querySelector('[data-shot-chat]').onclick=()=>{chat.attach(shotBlob,'wave-layout-screenshot.png');capture.close();open('chat')};
 const tools=$('.mobile-bank-tools'),master=document.createElement('label');master.className='master-visibility';master.innerHTML='<input id="show-master-fader" type="checkbox">Show Master';tools.append(master);
 const masterInput=$('#show-master-fader');
 const applyMaster=(value,save=false)=>{state.masterVisible=value;masterInput.checked=value;document.body.classList.toggle('master-hidden',!value);if(save)workspace.showMaster(value)};
 masterInput.onchange=()=>applyMaster(masterInput.checked,true);
 document.addEventListener('wave-master-visible',e=>applyMaster(e.detail,true));
 document.addEventListener('wave-workspace-layout',()=>{const cfg=workspace.currentProfile();if(workspace.isCustom())applyMaster(cfg.panels.find(p=>p.key==='master').visible)});
 applyMaster(!matchMedia('(max-width:700px)').matches);
 window.addEventListener('pagehide',()=>{stopCamera();stopSpeaking();recognition?.stop()});
}
