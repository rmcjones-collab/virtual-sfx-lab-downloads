import {createCall} from './team-call.js?v=v0320-20261005a';
import {createChatAlerts} from './chat-alerts.js?v=v0320-20261005a';
import {conversationWindow} from './support-windows.js?v=v0320-20261005a';
import {downloadDocument} from './document-export.js?v=v0320-20261005a';
import {requestFileSave} from './file-save.js?v=v0320-20261005a';
import {mountContactProfile,showFriendContacts} from './chat-profile.js?v=v0320-20261005a';
const PORT='__PORT_8093__',API=PORT.startsWith('__')?'http://127.0.0.1:8093':PORT;
const headers={'Content-Type':'application/json',...(['localhost','127.0.0.1'].includes(location.hostname)?{'X-Wave-Dev-Visitor':'local-development'}:{})};
export function mountChat({host,workspace,onLeave,onUnread=()=>{},onOpen=()=>{}}){
 let conversation=null;
 const $=s=>host.querySelector(s)??conversation?.querySelector(s);let data=null,room=null,after=0,signalAfter=0,pending=null,pendingURL=null,polling=false,joining=false,roomMembers=[],grants=[],joined=false,epoch=0,voice=null,chunks=[],voiceStream=null;
 const urls=new Set(),seen=new Set(),drafts=new Map();let localGrant=null,voiceGeneration=0,callSession=null,leaveCount=0,jumpRequest=0;
 host.innerHTML='<p class="support-note">Private, invitation-based rooms for up to four people. Built-in visitor profiles are not cross-device accounts or durable backups. Messages and attachments are stored in the prototype database; send only what you intend to share.</p><div id="chat-register"><label>Display Name<input id="chat-name" maxlength="40" placeholder="Your display name"></label><button id="chat-register-button">Create Chat Profile</button></div><div id="chat-identity" hidden><p>Your Friend Code: <span class="friend-code" id="chat-code"></span></p><label>Friend Code<input id="chat-friend-code" maxlength="32"></label><button id="chat-friend-add">Send Friend Request</button><div id="chat-requests"></div><details><summary>Friends & New Room</summary><div id="chat-friends"></div><label>Room Name<input id="chat-room-name" maxlength="80" value="Rehearsal Help"></label><button id="chat-room-create">Create Room With Selected Friends</button></details><label>Conversation<select id="chat-rooms"><option value="">Choose A Room</option></select></label></div><p id="chat-status" class="support-status" role="status"></p><div id="chat-room" hidden><p id="chat-members" class="support-note"></p><div id="chat-log" class="chat-log" role="log" aria-label="Messages"></div><label>Message<textarea id="chat-text" maxlength="4000" placeholder="Write to this room…"></textarea></label><label>Screenshot, Voice Note Or Video (6 MB Max)<input id="chat-file" type="file" accept="image/png,image/jpeg,image/webp,audio/webm,audio/ogg,audio/mp4,video/webm,video/mp4"></label><div id="chat-attachment"></div><div class="support-row"><button id="chat-send">Send</button><button id="chat-record">Record Voice Note</button><button id="chat-record-stop">Stop Recording</button></div><hr><h3>Live Call</h3><p class="support-note">Calls use direct peer connections, which can reveal network addresses to participants. No TURN relay is configured, so some networks will not connect. Device and screen permissions may be unavailable in embedded/mobile browsers.</p><div class="support-row"><button id="chat-join">Join Call</button><button id="chat-leave">Leave Call</button><button id="chat-mic">Enable Mic</button><button id="chat-screen">Share Screen</button><button id="chat-screen-stop">Stop Screen Share</button></div><div id="chat-peers"></div><h3>Instructor Workspace Control</h3><p class="support-note">Consent lasts five minutes. Only panel arrangement is controllable. No playback, firing, arming, DMX, files or other applications can be controlled.</p><label>Participant<select id="chat-control-target"></select></label><div class="support-row"><button id="chat-control-request">Request Workspace Control</button></div><div id="chat-control-incoming"></div><div id="chat-control-tools" hidden><label>Panel<select id="chat-control-panel"><option value="stage">Layout</option><option value="faders">Virtual Faders</option><option value="library">Sequence Library</option><option value="tools">Fixture & File Controls</option><option value="fuel">Fuel Estimates</option><option value="screen">Screen Settings</option><option value="notes">Notes</option></select></label><div class="support-row"><button data-control="show">Show Panel</button><button data-control="minimize">Minimize</button><button data-control="restore">Restore</button></div><label>Column<select id="chat-control-zone"><option value="left">Left</option><option value="main">Middle</option><option value="right">Right</option></select></label><button data-control="move">Move Panel</button><label>Panel Height<input id="chat-control-height" type="number" min="140" max="1200" value="460"></label><button data-control="resize">Resize Panel</button></div></div>';
 // Move only the conversation, not friends, permissions, call or camera controls.
 conversation=document.createElement('section');conversation.className='chat-conversation';
 const home=$('#chat-room'),divider=home.querySelector('hr');
 while(home.firstChild&&home.firstChild!==divider)conversation.append(home.firstChild);
 home.prepend(conversation);
 const fileLabel=$('#chat-file').closest('label'),attachmentMenu=document.createElement('details');
 attachmentMenu.className='chat-attachment-picker';attachmentMenu.innerHTML='<summary>Attach Image, Voice Or Video</summary>';
 fileLabel.before(attachmentMenu);attachmentMenu.append(fileLabel);
 const conversationTools=document.createElement('div');conversationTools.className='chat-conversation-tools';
 conversationTools.innerHTML='<button type="button" id="chat-undock">Undock Conversation</button><button type="button" id="chat-export">Save / Share Chat</button>';
 const talk=document.createElement('button');talk.type='button';talk.id='chat-push-to-talk';talk.setAttribute('aria-pressed','false');talk.textContent='Push To Talk: Off';talk.title='Toggle live microphone for this room. On joins the call; other participants must Join Call to hear you.';conversationTools.append(talk);
 const talkHelp=document.createElement('p');talkHelp.className='support-note';talkHelp.textContent='Push To Talk is a toggle: tap once to join room audio and broadcast your microphone, then tap again to stop. Other users must Join Call to listen. Live audio is not a saved voice note. Calls use direct peer connections and may reveal network addresses.';
 conversation.prepend(conversationTools);
 conversationTools.after(talkHelp);
 const dock=conversationWindow(conversation,{home,onVisibility:()=>alerts.markVisible(),onNewMessage:()=>openMessage(room)});
 const renderedOther=new Map();
 const visible=id=>{
  if(id!==room||document.hidden||!document.hasFocus()||conversation.closest('[hidden],.collapsed'))return false;
  if((renderedOther.get(id)||0)<(data?.rooms.find(r=>r.id===id)?.lastOther||0))return false;
  const log=$('#chat-log'),r=log.getBoundingClientRect();
  if(!log.getClientRects().length||r.bottom<=0||r.top>=innerHeight||r.right<=0||r.left>=innerWidth||log.scrollTop+log.clientHeight<log.scrollHeight-24)return false;
  const hit=document.elementFromPoint(Math.max(0,Math.min(innerWidth-1,r.left+r.width/2)),Math.max(0,Math.min(innerHeight-1,r.bottom-8)));
  return !!hit&&log.contains(hit);
 };
 const alerts=createChatAlerts({host,visible,onOpen:id=>openMessage(id),onUnread:rows=>{
  onUnread(rows);dock.unread(rows.some(r=>r.id===room));
  if(data)for(const option of $('#chat-rooms').options){const r=data.rooms.find(r=>r.id===option.value);if(r)option.textContent=r.title+(rows.some(x=>x.id===r.id)?' · New':'')}
 }});
 $('#chat-undock').onclick=()=>dock.detach();
 document.addEventListener('wave-conversation-dock',e=>{$('#chat-undock').hidden=e.detail.detached});
 document.addEventListener('visibilitychange',()=>alerts.markVisible());
 window.addEventListener('focus',()=>alerts.markVisible());
 document.addEventListener('scroll',()=>alerts.markVisible(),true);
 document.addEventListener('pointerup',()=>alerts.markVisible());
 const inlineStatus=document.createElement('p');inlineStatus.className='support-status';inlineStatus.setAttribute('role','status');conversationTools.after(inlineStatus);
 const status=t=>{$('#chat-status').textContent=t;inlineStatus.textContent=t};
 // Explicit preview first; no message content is sent by opening this dialog.
 const exportDialog=document.createElement('dialog');exportDialog.className='chat-export-dialog';
 exportDialog.innerHTML='<h2>Save Or Share Chat</h2><p>Review the complete text transcript before sharing. It includes participant names, timestamps and messages. Media is listed by filename only, not embedded. Share only with people authorized to see this conversation.</p><pre></pre><div class="support-row"><button data-export-txt>Download TXT</button><button data-export-json>Download JSON</button><button data-export-share>Share Transcript…</button><button data-export-close>Close</button></div><p data-export-status role="status"></p>';
 document.body.append(exportDialog);
 for(const [format,label]of [['md','Download Markdown'],['html','Download HTML Document']]){
  const button=document.createElement('button');button.textContent=label;button.onclick=()=>downloadDocument(exportData.title,exportText,format);
  exportDialog.querySelector('[data-export-json]').after(button);
 }
 let exportData=null,exportText='',exportName='';
 const download=(text,type,extension)=>requestFileSave(new Blob([text],{type}),exportName+'.'+extension);
 exportDialog.querySelector('[data-export-close]').onclick=()=>exportDialog.close();
 exportDialog.querySelector('[data-export-txt]').onclick=()=>download(exportText,'text/plain','txt');
 exportDialog.querySelector('[data-export-json]').onclick=()=>download(JSON.stringify(exportData,null,2),'application/json','json');
 exportDialog.querySelector('[data-export-share]').onclick=async()=>{
  const message=exportDialog.querySelector('[data-export-status]');
  const file=new File([exportText],exportName+'.txt',{type:'text/plain'});
  try{
   if(navigator.canShare?.({files:[file]})){await navigator.share({title:exportData.title,files:[file]});message.textContent='Share sheet completed.'}
   else if(navigator.clipboard?.writeText){await navigator.clipboard.writeText(exportText);message.textContent='Transcript copied. Paste it only where you intend to share it.'}
   else message.textContent='Sharing is unavailable in this browser. Download TXT and share the file yourself.';
  }catch(e){message.textContent=e.name==='AbortError'?'Sharing cancelled.':'Sharing was blocked. Download TXT instead.'}
 };
 $('#chat-export').onclick=async()=>{
  if(!room)return;const button=$('#chat-export');button.disabled=true;
  try{
   exportData=await api(`/room/${room}/export`);
   exportName='wave-chat-'+exportData.title.replace(/[^a-z0-9_-]+/gi,'-').slice(0,50);
   exportText=`Wave Studio Chat: ${exportData.title}\nExported: ${new Date().toISOString()}\nMedia files are not included.\n\n`+exportData.messages.map(m=>`[${new Date(m.created*1000).toISOString()}] ${m.name}\n${m.text}${m.attachmentName?'\n[Attachment: '+m.attachmentName+']':''}`).join('\n\n');
   exportDialog.querySelector('pre').textContent=exportText;exportDialog.querySelector('[data-export-status]').textContent='';
   exportDialog.querySelector('[data-export-share]').textContent=navigator.canShare?.({files:[new File(['test'],'test.txt',{type:'text/plain'})]})?'Share Transcript…':'Copy Transcript To Share';
   exportDialog.showModal();
  }catch(e){status('Could not export chat: '+e.message)}finally{button.disabled=false}
 };
 const stop=document.createElement('button');stop.id='instructor-stop';stop.hidden=true;stop.textContent='Stop Instructor Control';document.body.append(stop);
 async function api(path='',body){
  const r=await fetch(`${API}/api/social${path}`,{method:body?'POST':'GET',headers,...(body?{body:JSON.stringify(body)}:{}),signal:AbortSignal.timeout(12000)});
  if(!r.ok){let d;try{d=await r.json()}catch{}throw Error(typeof d?.detail==='string'?d.detail:'Chat service unavailable.')}
  return r.json();
 }
 const send=body=>api('',{...body,room});
 const safe=fn=>async()=>{try{await fn()}catch(e){status(e.message)}};
 const call=createCall({container:$('#chat-peers'),status,send:body=>send({op:'signal',...body}),me:()=>data?.profile?.code,session:()=>callSession});
 let refreshing=false;
 async function refresh(){if(refreshing)return;refreshing=true;try{
  data=await api();$('#chat-register').hidden=!!data.profile;$('#chat-identity').hidden=!data.profile;if(!data.profile)return;
  $('#chat-code').textContent=data.profile.code;
  const selected=new Set([...host.querySelectorAll('[data-friend]:checked')].map(n=>n.value));$('#chat-friends').replaceChildren();
  for(const f of data.friends){const label=document.createElement('label'),input=document.createElement('input');input.type='checkbox';input.dataset.friend='';input.value=f.code;input.checked=selected.has(f.code);label.append(input,document.createTextNode(' '+f.name));$('#chat-friends').append(label);if(f.contacts&&Object.keys(f.contacts).length){const b=document.createElement('button');b.textContent='Contact Info: '+f.name;b.onclick=()=>showFriendContacts(f);$('#chat-friends').append(b)}}
  $('#chat-requests').replaceChildren();
  for(const r of data.requests){const row=document.createElement('div');row.className='friend-item';row.textContent=`${r.name} · ${r.outgoing?'Request Sent':'Wants To Connect'}`;
   if(!r.outgoing)for(const op of ['accept','decline']){const b=document.createElement('button');b.textContent=op==='accept'?'Accept':'Decline';b.onclick=safe(async()=>{await api('',{op,code:r.code});await refresh()});row.append(b)}
   $('#chat-requests').append(row);
  }
  const select=$('#chat-rooms');
  for(const option of [...select.options])if(option.value&&!data.rooms.some(r=>r.id===option.value))option.remove();
  for(const r of data.rooms)if(![...select.options].some(o=>o.value===r.id))select.append(new Option(r.title,r.id));
  if(select.value!==(room??''))select.value=room??'';
  alerts.identify(data.profile.code);alerts.update(data.rooms);
 }catch(e){status(e.message)}finally{refreshing=false}}
 const profileEditor=mountContactProfile({host,get:()=>data?.profile,save:async values=>{await api('',{op:'profile',...values});await refresh()},status});
 $('#chat-register-button').onclick=safe(async()=>{await api('',{op:'profile',name:$('#chat-name').value,...profileEditor.registration()});await refresh();status('Profile created. Share your code privately with a friend.')});
 $('#chat-friend-add').onclick=safe(async()=>{await api('',{op:'friend',code:$('#chat-friend-code').value.trim()});await refresh();status('Friend request sent. The recipient must accept.')});
 $('#chat-room-create').onclick=safe(async()=>{const codes=[...host.querySelectorAll('[data-friend]:checked')].map(n=>n.value);const r=await api('',{op:'room',codes,title:$('#chat-room-name').value});await refresh();await selectRoom(r.room)});
 function stopVoice(){voiceGeneration++;if(voice?.state==='recording')voice.stop();voiceStream?.getTracks().forEach(t=>t.stop());voiceStream=null;document.dispatchEvent(new CustomEvent('wave-media-state',{detail:{voiceNote:false}}))}
 async function leave(){
  const previousSession=callSession,previousRoom=room;callSession=null;leaveCount++;$('#chat-join').disabled=true;
  joined=false;localGrant=null;stop.hidden=true;call.close();stopVoice();onLeave?.();
  if(previousRoom)try{if(previousSession)await api('',{op:'call',room:previousRoom,active:false,session:previousSession});await api('',{op:'revoke',room:previousRoom})}catch{}
  $('#chat-join').textContent='Join Call';$('#chat-mic').textContent='Enable Mic';$('#chat-control-incoming').replaceChildren();$('#chat-control-tools').hidden=true;
  leaveCount--;$('#chat-join').disabled=leaveCount>0;
 }
 async function selectRoom(id){
  if(room)drafts.set(room,{text:$('#chat-text').value,attachment:pending});
  const selection=++epoch;$('#chat-room').inert=true;conversation.inert=true;$('#chat-room').setAttribute('aria-busy','true');
  await leave();if(selection!==epoch)return;if(room)clearAttachment();room=id||null;after=0;signalAfter=0;seen.clear();grants=[];$('#chat-log').replaceChildren();$('#chat-text').value='';for(const u of urls)URL.revokeObjectURL(u);urls.clear();$('#chat-room').hidden=!room;$('#chat-rooms').value=room??'';$('#chat-room').inert=false;$('#chat-room').removeAttribute('aria-busy');
  const draft=drafts.get(room);$('#chat-text').value=draft?.text??'';if(draft?.attachment)attach(draft.attachment.blob,draft.attachment.name);
  if(!room)dock.close();else{dock.setTitle(data.rooms.find(r=>r.id===room)?.title||'Conversation');await poll();alerts.markVisible()}
  if(selection===epoch)conversation.inert=false;
 }
 async function openMessage(id){
  const request=++jumpRequest;
  onOpen();
  if(!id)return;
  try{
   if(!data?.rooms.some(r=>r.id===id)){await refresh();if(!data?.rooms.some(r=>r.id===id)){status('That conversation is no longer available.');return}}
   if(room!==id)await selectRoom(id);
   if(request!==jumpRequest||room!==id)return;
   dock.reveal();
   const input=$('#chat-text'),log=$('#chat-log');
   log.scrollTop=log.scrollHeight;
   input.focus({preventScroll:true});
   input.scrollIntoView({block:'nearest',inline:'nearest',behavior:'instant'});
   const token=epoch;
   requestAnimationFrame(()=>{if(request!==jumpRequest||token!==epoch||room!==id)return;input.focus({preventScroll:true});input.scrollIntoView({block:'nearest',inline:'nearest',behavior:'instant'});alerts.markVisible()});
  }catch(error){status('Could not open conversation: '+error.message)}
 }
 function openUnread(){
  const unread=(data?.rooms??[]).filter(r=>alerts.unread(r.id)).sort((a,b)=>(b.lastOther||0)-(a.lastOther||0));
  return openMessage(unread[0]?.id??null);
 }
 $('#chat-rooms').onchange=safe(()=>selectRoom($('#chat-rooms').value));
 function clearAttachment(){pending=null;$('#chat-attachment').replaceChildren();if(pendingURL)URL.revokeObjectURL(pendingURL);pendingURL=null}
 function attach(blob,name){
  if(blob.size>6000000){status('File exceeds 6 MB. Use a shorter clip.');return false}
  clearAttachment();pending={blob,name};pendingURL=URL.createObjectURL(blob);const host=$('#chat-attachment');const note=document.createElement('p');note.textContent=`Attached: ${name} · Not Sent`;
  const media=document.createElement(blob.type.startsWith('image/')?'img':blob.type.startsWith('audio/')?'audio':'video');media.src=pendingURL;media.controls=true;const remove=document.createElement('button');remove.textContent='Remove Attachment';remove.onclick=clearAttachment;host.append(note,media,remove);status(room?'Review the attachment, then Send.':'Select a room before sending.');return true;
 }
 $('#chat-file').onchange=e=>{const f=e.target.files[0];e.target.value='';if(f)attach(f,f.name)};
 $('#chat-send').onclick=safe(async()=>{
  if(!room)return;const targetRoom=room,attachment=pending,message=$('#chat-text').value;
  $('#chat-send').disabled=true;
  try{let a=null;if(attachment){const encoded=await new Promise((resolve,reject)=>{const f=new FileReader();f.onload=()=>resolve(f.result.split(',')[1]);f.onerror=reject;f.readAsDataURL(attachment.blob)});a={name:attachment.name,mime:attachment.blob.type.split(';')[0],data:encoded}}
   await api('',{op:'message',room:targetRoom,text:message,attachment:a});if(room===targetRoom){$('#chat-text').value='';if(pending===attachment)clearAttachment();await poll();await refresh();status('Message sent to this room.')}
  }finally{$('#chat-send').disabled=false}
 });
 $('#chat-record').onclick=safe(async()=>{
  if(!window.MediaRecorder||!navigator.mediaDevices?.getUserMedia)throw Error('Voice recording unavailable here. Try a standalone browser.');
  if(voice?.state==='recording')return;
  const token=++voiceGeneration,stream=await navigator.mediaDevices.getUserMedia({audio:true,video:false});
  if(token!==voiceGeneration){stream.getTracks().forEach(t=>t.stop());return}
  voiceStream=stream;chunks=[];const recordingRoom=room;
  try{voice=new MediaRecorder(voiceStream)}catch(e){stopVoice();throw e}
  voice.ondataavailable=e=>{chunks.push(e.data);if(chunks.reduce((n,b)=>n+b.size,0)>5500000&&voice.state==='recording')voice.stop()};
  voice.onstop=()=>{stream.getTracks().forEach(t=>t.stop());document.dispatchEvent(new CustomEvent('wave-media-state',{detail:{voiceNote:false}}));if(recordingRoom===room)attach(new Blob(chunks,{type:voice.mimeType.split(';')[0]}),'voice-note.'+(voice.mimeType.includes('mp4')?'mp4':'webm'))};
  voice.start(1000);document.dispatchEvent(new CustomEvent('wave-media-state',{detail:{voiceNote:true}}));status('Recording locally. Stop, review, then Send.');
 });
 $('#chat-record-stop').onclick=stopVoice;
 async function appendMessage(m,token){
  if(token!==epoch)return;
  if(seen.has(m.id))return;seen.add(m.id);const log=$('#chat-log'),atBottom=log.scrollTop+log.clientHeight>=log.scrollHeight-24;
  const row=document.createElement('article');row.className='chat-message';const title=document.createElement('header');title.textContent=`${m.name} · ${new Date(m.created*1000).toLocaleTimeString()}`;const text=document.createElement('p');text.textContent=m.text;row.append(title,text);log.append(row);
  if(m.attachment){try{const r=await fetch(`${API}/api/social/blob/${m.attachment}`,{headers,signal:AbortSignal.timeout(12000)});if(!r.ok)throw Error();const blob=await r.blob();if(token!==epoch)return;const u=URL.createObjectURL(blob);urls.add(u);const media=document.createElement(blob.type.startsWith('image/')?'img':blob.type.startsWith('audio/')?'audio':'video');media.controls=true;media.src=u;media.alt='Shared Screenshot';row.append(media)}catch{row.append(document.createTextNode('Attachment unavailable.'))}}
  if(log.children.length>100)log.firstElementChild.remove();if(atBottom)log.scrollTop=log.scrollHeight;
  if(m.sender!==data.profile.code)renderedOther.set(room,Math.max(renderedOther.get(room)||0,m.id));
 }
 function syncGrants(){
  const me=data.profile.code;const incoming=grants.find(g=>g.owner===me&&g.expires*1000>Date.now()&&g.instructor===localGrant);
  if(!incoming){localGrant=null;stop.hidden=true}else stop.hidden=false;
  const target=$('#chat-control-target').value;$('#chat-control-tools').hidden=!joined||!grants.some(g=>g.instructor===me&&g.owner===target&&g.expires*1000>Date.now());
 }
 async function handleSignal(s){
  const b=s.body;if(['offer','answer','ice'].includes(b.kind)){if(joined)await call.signal(s.sender,b);return}
  if(b.kind==='requestControl'){
   if(!joined)return;const sender=roomMembers.find(m=>m.code===s.sender);if(!sender)return;const row=document.createElement('div');row.className='friend-item';row.textContent=`${sender.name} requests panel-only control for five minutes.`;
   const approve=document.createElement('button');approve.textContent='Allow Workspace Control';approve.onclick=safe(async()=>{await send({op:'grant',target:s.sender});localGrant=s.sender;stop.hidden=false;row.remove();await poll()});
   const deny=document.createElement('button');deny.textContent='Decline';deny.onclick=()=>row.remove();row.append(approve,deny);$('#chat-control-incoming').replaceChildren(row);return;
  }
  if(b.kind==='control'&&joined&&localGrant===s.sender&&grants.some(g=>g.owner===data.profile.code&&g.instructor===s.sender&&g.expires*1000>Date.now()))workspace.instructor(b.command);
 }
 async function poll(){
  if(!room||polling||!data?.profile)return;polling=true;const token=epoch,current=room;
  try{if(joined)await send({op:'call',active:true,session:callSession});const r=await api(`/room/${current}?after=${after}&signal_after=${signalAfter}`);if(token!==epoch||current!==room)return;
   roomMembers=r.members;grants=r.grants;$('#chat-members').textContent='Room Members: '+r.members.map(m=>m.name).join(', ');
   const target=$('#chat-control-target'),selected=target.value;target.replaceChildren(...r.members.filter(m=>m.code!==data.profile.code).map(m=>new Option(m.name,m.code)));if([...target.options].some(o=>o.value===selected))target.value=selected;
   syncGrants();if(joined)await call.sync(r.callers,r.members,r.callSessions);
   for(const m of r.messages){
    if(token!==epoch||current!==room)return;
    await appendMessage(m,token);
    if(token!==epoch||current!==room)return;
    after=Math.max(after,m.id);
   }
   for(const s of r.signals){
    if(token!==epoch||current!==room)return;
    signalAfter=Math.max(signalAfter,s.id);try{await handleSignal(s)}catch(e){if(token===epoch)status('Call connection: '+e.message)}
   }
  }catch(e){if(token===epoch){status(e.message);if(localGrant){localGrant=null;stop.hidden=true}}}
  finally{polling=false}
 }
 async function joinCall(){if(joined)return true;if(!room||joining||leaveCount)return false;joining=true;const targetRoom=room,token=epoch,session=crypto.randomUUID();callSession=session;try{
  await api('',{op:'call',room:targetRoom,active:true,start:true,session});
  if(targetRoom!==room||token!==epoch||callSession!==session){await api('',{op:'call',room:targetRoom,active:false,session});return}
  joined=true;$('#chat-join').textContent='In Call';status('Joined with mic and camera off. Enable each only when ready.');await poll();return targetRoom===room&&token===epoch&&joined;
 }finally{joining=false}}
 $('#chat-join').onclick=safe(joinCall);
 $('#chat-leave').onclick=safe(async()=>{await leave();status('Call ended. Shared media and instructor control stopped.')});
 let micBusy=false,micActive=false;
 document.addEventListener('wave-media-state',e=>{
  if(typeof e.detail.callMic!=='boolean')return;micActive=e.detail.callMic;
  talk.textContent=micActive?'Push To Talk: On · Broadcasting':'Push To Talk: Off';talk.setAttribute('aria-pressed',String(micActive));
  $('#chat-mic').textContent=micActive?'Mute Mic':'Enable Mic';$('#chat-mic').setAttribute('aria-pressed',String(micActive));
 });
 async function toggleRoomMic(autoJoin=false){
  if(micBusy)return;micBusy=true;talk.disabled=$('#chat-mic').disabled=true;
  const target=room,token=epoch;
  try{
   if(!joined){if(!autoJoin)throw Error('Join Call first.');if(!await joinCall())return}
   if(!joined||target!==room||token!==epoch||document.hidden)return;
   const active=await call.toggleMic();
   if(target===room&&token===epoch)status(active?'Microphone broadcasting to participants connected to this room call. Tap Push To Talk again to stop.':'Microphone off. You can still listen to the room call.');
  }finally{micBusy=false;talk.disabled=$('#chat-mic').disabled=false}
 }
 talk.onclick=safe(()=>toggleRoomMic(true));
 $('#chat-mic').onclick=safe(()=>toggleRoomMic());
 document.addEventListener('visibilitychange',()=>{if(document.hidden){const wasActive=micActive||micBusy;call.stopMic();if(wasActive)status('Microphone stopped while the app is hidden. Tap Push To Talk to resume.')}});
 $('#chat-screen').onclick=safe(async()=>{if(!joined)throw Error('Join Call first.');$('#chat-screen').disabled=true;try{await call.shareScreen()}finally{$('#chat-screen').disabled=false}});
 $('#chat-screen-stop').onclick=()=>call.stopScreen();
 $('#chat-control-target').onchange=syncGrants;
 $('#chat-control-request').onclick=safe(async()=>{if(!joined)throw Error('Join Call first.');await send({op:'signal',target:$('#chat-control-target').value,body:{kind:'requestControl'}});status('Request sent. Wait for the owner to approve.')});
 stop.onclick=safe(async()=>{localGrant=null;stop.hidden=true;await send({op:'revoke'});status('Instructor control revoked.')});
 for(const b of host.querySelectorAll('[data-control]'))b.onclick=safe(async()=>{let action=b.dataset.control;const command={action,panel:$('#chat-control-panel').value};if(action==='restore'||action==='minimize'){command.action='minimize';command.value=action==='minimize'}if(action==='move')command.zone=$('#chat-control-zone').value;if(action==='resize'){command.height=Number($('#chat-control-height').value);command.span=12}await send({op:'signal',target:$('#chat-control-target').value,body:{kind:'control',command}})});
 setInterval(()=>{poll();if(localGrant)syncGrants()},2000);
 setInterval(refresh,3000);refresh();
 window.addEventListener('pagehide',()=>{localGrant=null;call.close();stopVoice();if(room&&joined)fetch(`${API}/api/social`,{method:'POST',headers,body:JSON.stringify({op:'call',room,active:false,session:callSession}),keepalive:true}).catch(()=>{})});
 return {refresh,attach,leave,openUnread,markVisible:()=>alerts.markVisible(),setCamera(stream){if(stream&&!joined)return false;call.setCamera(stream);return true}};
}
