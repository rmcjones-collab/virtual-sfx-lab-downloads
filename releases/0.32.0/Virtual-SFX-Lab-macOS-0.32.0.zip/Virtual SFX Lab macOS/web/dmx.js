import {presets, sample} from './presets.js?v=v0320-20261005a';

// Receive-only visual model. Standard Explo six-channel DMX512, CH5 "new".
// Exact CH5 intervals from the manufacturer's separate sequence sheet.
export const DMX_STARTS=[3,6,8,11,13,16,18,21,23,26,29,31,34,36,39,41,44,46,49,51,54,57,59,62,64,67,69,72,74,77,80,82,85,87,90,92,95,98,100,102,105,108,110,113,115,118,120,123,125,128,131,133,136,138,141,143,146,148,151,153,156,159,161,164,166,169,171,174,176,179,182,184,187,189,192,194,197,200,202,204,207,210,212,215,217,220,222,225];
export function decodeProgram(value){
 if(value<3)return 0;
 if(value>226)return -1;
 return DMX_STARTS.findLastIndex(start=>value>=start)+1;
}
export const validPatch=p=>p&&Number.isInteger(p.universe)&&p.universe>=0&&p.universe<=32767&&Number.isInteger(p.address)&&p.address>=1&&p.address<=507;
export function nextPatch(fixtures){
 for(let u=0;u<32768;u++)for(let a=1;a<=507;a+=6)
  if(fixtures.every(f=>!f.patch||f.patch.universe!==u||a+5<f.patch.address||a>f.patch.address+5))return {universe:u,address:a};
}
const DIRECT={id:0,type:'wave',positions:[8,8],duration:Infinity,long:false};
// Visualization convention, not a verified firmware emulation: fixed stage-side
// limits after Invert; suppress out-of-range emission rather than redirect it.
export const angleLimits=f=>({min:f.minAngle??-105,max:f.maxAngle??105});
export const validAngles=f=>Number.isInteger(f.minAngle)&&Number.isInteger(f.maxAngle)&&f.minAngle>=-105&&f.maxAngle<=105&&f.minAngle<=f.maxAngle&&f.minAngle%15===0&&f.maxAngle%15===0;
export function limitSample(f,s){
 const requestedAngle=f.inverted?-s.angle:s.angle,{min,max}=angleLimits(f);
 const blocked=requestedAngle<min-1e-7||requestedAngle>max+1e-7;
 return {...s,requestedAngle,angle:Math.max(min,Math.min(max,requestedAngle)),on:s.on&&!blocked,blocked};
}
export class DMXEngine{
 constructor(){this.records=new Map();this.timeout=2.5;}
 clear(){this.records.clear();}
 reset(id){this.records.delete(id);}
 record(f){
  const key=`${f.patch.universe}:${f.patch.address}`;
  let r=this.records.get(f.id);
  if(!r||r.key!==key){
   r={key,values:null,last:-Infinity,source:'',ready:false,job:null,angle:0,target:0,history:[],lastTick:null,status:'Waiting for DMX',triggers:0};
   this.records.set(f.id,r);
  }
  return r;
 }
 stop(r,status){r.job=null;r.history=[];r.ready=false;r.status=status;}
 ingest(packet,fixtures,now){
  for(const f of fixtures){
   if(f.patch.universe!==packet.universe)continue;
   const r=this.record(f);
   if(packet.values.length<f.patch.address+5){this.stop(r,'Incomplete DMX frame');r.values=null;continue;}
   const values=packet.values.slice(f.patch.address-1,f.patch.address+5);
   const sourceId=packet.sourceId??packet.source;
   const fresh=now-r.last>this.timeout||r.sourceId!==sourceId;
   if(fresh)this.stop(r,'New source: reset trigger');
   r.values=values;r.last=now;r.source=packet.source;r.sourceId=sourceId;
   r.target=values[0]*210/255-105;
   const armed=values[5]>=50&&values[5]<=200,high=values[2]>=254;
   if(!armed)this.stop(r,'Test mode: no flame');
   else{
    if(!high)r.ready=true;
    if(high&&r.ready){
     r.ready=false;
     const busy=r.job&&now-r.job.start<r.job.duration;
     if(!busy){
      const id=decodeProgram(values[4]);
      if(id<0){r.status='Unsupported CH5 value';continue;}
      const duration=id?presets[id-1].duration:values[3]===0?8:values[3]===255?2.5:values[3]/100;
      r.job={id,start:now,duration,gate:!id&&(values[3]===0||values[3]===255)};
      r.history=[];r.triggers++;
     }
    }
    if(r.job?.gate&&!high)r.job.duration=Math.min(r.job.duration,now-r.job.start);
    r.status=r.job&&now-r.job.start<r.job.duration?(r.job.id?`Sequence ${String(r.job.id).padStart(3,'0')}`:'Direct DMX flame'):high&&!r.ready?'Return CH3 below 254 to trigger':'Ready for trigger';
   }
  }
 }
 tick(fixtures,now){
  for(const f of fixtures){
   const r=this.record(f),dt=r.lastTick===null?0:Math.min(.1,now-r.lastTick);r.lastTick=now;
   if(now-r.last>this.timeout){this.stop(r,r.last===-Infinity?'Waiting for DMX':'Signal lost: visual output cleared');continue;}
   const speed=r.values?.[1]??0;
   // Intermediate motor speeds are NOT calibrated. 0/255 follow the received target.
   if(speed===0||speed===255)r.angle=r.target;
   else{const step=720*(speed-1)/254*dt;r.angle+=Math.max(-step,Math.min(step,r.target-r.angle));}
   const on=!!r.job&&!r.job.id&&now-r.job.start<r.job.duration;
   r.history.push({t:now,angle:r.angle,on});
   while(r.history.length>2&&r.history[1].t<now-1.2)r.history.shift();
   if(r.job&&now-r.job.start>=r.job.duration)r.status=r.values?.[2]>=254?'Complete: reset CH3 to trigger again':'Ready for trigger';
   if(r.job?.id&&now-r.job.start>r.job.duration+1.1)r.job=null;
  }
 }
 view(f,now){
  const r=this.record(f),alive=now-r.last<=this.timeout,job=r.job;
  const mirror=s=>limitSample(f,s);
  if(alive&&job?.id){
   const p=presets[job.id-1];
   return {preset:p,time:now-job.start,sample:t=>mirror(sample(p,t))};
  }
  const timed=job&&!job.id&&!job.gate;
  return {preset:DIRECT,time:now,profile:timed?{type:'single',long:job.duration>.3}:DIRECT,
   envelope:timed?(_born,time)=>{const tail=job.duration>.3?.12:.09;const fade=Math.max(0,Math.min(1,1-(time-job.start-job.duration)/tail));return fade*fade*(3-2*fade)}:()=>1,
   sample:t=>{
   if(!alive||!r.history.length)return mirror({angle:r.angle,on:false});
   let lo=0,hi=r.history.length-1,index=-1;
   while(lo<=hi){const mid=(lo+hi)>>1;if(r.history[mid].t<=t){index=mid;lo=mid+1}else hi=mid-1;}
   return mirror(index<0?{angle:r.angle,on:false}:r.history[index]);
  }};
 }
}
