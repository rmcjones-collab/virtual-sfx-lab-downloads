import {createDefaultFixtures} from './default-layout.js?v=v0320-20261005a';
import {FuelLedger} from './fuel-model.js?v=v0320-20261005a';
import {requestFileSave} from './file-save.js?v=v0320-20261005a';
const clone=structuredClone;
const layoutKeys=['id','name','x','y','presetId','inverted','bodyScale'];
const settingsKeys=['id','nozzle','flameScale','virtualArmed','minAngle','maxAngle','patch'];
const labels=['cueLabel','dmxLabel','defaultCueLabel','defaultDmxLabel'];
const pick=(obj,keys)=>Object.fromEntries(keys.filter(k=>obj[k]!==undefined).map(k=>[k,clone(obj[k])]));
export function makeSaveBundle(full,options){
 if(!options.layout&&!options.settings&&!options.labels&&!options.preferences)throw Error('Choose at least one option.');
 const sections={};
 if(options.layout||options.preferences)sections.layout={fixtures:full.fixtures.map(f=>pick(f,layoutKeys)),sceneScale:full.sceneScale,view:clone(full.view),selectedId:full.selectedId,selectedIds:clone(full.selectedIds),layoutLocked:full.layoutLocked};
 if(options.settings||options.preferences){
  const playback=clone(full.playback);playback.slots.forEach(s=>labels.forEach(k=>delete s[k]));
  sections.settings={fixtures:full.fixtures.map(f=>pick(f,settingsKeys)),fuel:clone(full.fuel),favorites:clone(full.favorites),favoriteTiming:clone(full.favoriteTiming),playback};
 }
 if(options.labels||options.preferences)sections.faderLabels=full.playback.slots.map(s=>pick(s,labels));
 if(options.preferences)sections.preferences=clone(full.preferences);
 return {format:'wave-studio-save',version:1,sections};
}
export function mergeSaveBundle(data,current){
 if(data?.format!=='wave-studio-save'||data.version!==1||!data.sections||typeof data.sections!=='object'||Array.isArray(data.sections))throw Error('Invalid save document.');
 const sections=data.sections,keys=Object.keys(sections);
 if(!keys.length||keys.some(k=>!['layout','settings','faderLabels','preferences'].includes(k)))throw Error('Unknown save section.');
 const next=clone(current);
 if(sections.layout){
  const l=sections.layout;
  if(!Array.isArray(l.fixtures)||!l.fixtures.length||l.fixtures.length>40)throw Error('Invalid layout section.');
  next.fixtures=l.fixtures.map((f,i)=>{
   const previous=current.fixtures.find(g=>g.id===f.id),base=previous??{...createDefaultFixtures()[0],id:f.id,patch:{universe:0,address:1+i*6}};
   return {...base,...pick(f,layoutKeys)};
  });
  Object.assign(next,pick(l,['sceneScale','view','selectedId','selectedIds','layoutLocked']));
  next.fuel=next.fixtures.map(f=>current.fuel.find(row=>row.id===f.id)??new FuelLedger().serialize([f])[0]);
 }
 if(sections.settings){
  const s=sections.settings;
  if(!Array.isArray(s.fixtures)||s.fixtures.length>40||new Set(s.fixtures.map(f=>f.id)).size!==s.fixtures.length||!Array.isArray(s.fuel))throw Error('Invalid settings section.');
  next.fixtures=next.fixtures.map(f=>({...f,...pick(s.fixtures.find(g=>g.id===f.id)??{},settingsKeys)}));
  const validatedFuel=FuelLedger.validate(s.fuel,s.fixtures);
  next.fuel=next.fixtures.map(f=>validatedFuel.find(row=>row.id===f.id)??next.fuel.find(row=>row.id===f.id));
  Object.assign(next,pick(s,['favorites','favoriteTiming','playback']));
  if(!Array.isArray(next.playback?.slots)||![10,20].includes(next.playback.slots.length))throw Error('Invalid playback settings.');
  while(next.playback.slots.length<current.playback.slots.length)next.playback.slots.push(clone(current.playback.slots[next.playback.slots.length]));
  next.playback.slots.forEach((slot,i)=>Object.assign(slot,pick(current.playback.slots[i],labels)));
 }
 if(sections.faderLabels){
  if(!Array.isArray(sections.faderLabels)||![10,20].includes(sections.faderLabels.length))throw Error('Expected labels for 10 or 20 faders.');
  sections.faderLabels.forEach((row,i)=>{
   if(!row||labels.some(k=>typeof row[k]!=='string'||!row[k].trim()||row[k].length>32||/[\r\n]/.test(row[k])))throw Error('Invalid fader labels.');
   Object.assign(next.playback.slots[i],pick(row,labels));
  });
 }
 if(sections.preferences)next.preferences=clone(sections.preferences);
 return next;
}
export function mountSaveOptions({button,capture,onSaved}){
 const d=document.createElement('dialog');d.className='save-options-dialog';d.id='save-options-dialog';
 d.innerHTML='<form><div class="session-heading"><h2>Save Options</h2><button type="button" data-save-cancel>Cancel</button></div><p>Only checked sections are saved. Loading a partial file preserves the sections you left out.</p><label><input type="checkbox" name="layout" checked> Save Layout</label><small>Units, positions, assigned presets, Invert and view.</small><label><input type="checkbox" name="settings" checked> Save Settings</label><small>Fixture settings, fuel, favourites, cue assignments, macros and mappings.</small><label><input type="checkbox" name="labels" checked> Save Fader Labels</label><small>Current and default DMX / cue labels.</small><label><input type="checkbox" name="preferences" checked> Save All Edited Preferences</label><small>Includes all sections above, plus theme, playback options, visible mobile faders and autosave preferences. Output levels are never restored live.</small><p data-save-error role="status"></p><button type="submit" class="primary">Download File</button></form>';
 document.body.append(d);
 const form=d.querySelector('form'),fields=()=>Object.fromEntries([...d.querySelectorAll('input')].map(e=>[e.name,e.checked]));
 button.onclick=()=>{d.querySelector('[data-save-error]').textContent='';d.showModal()};
 d.querySelector('[data-save-cancel]').onclick=()=>d.close();
 form.onchange=e=>{
  if(e.target.name==='preferences'&&e.target.checked)for(const name of ['layout','settings','labels'])form.elements[name].checked=true;
  if(e.target.name!=='preferences'&&!e.target.checked)form.elements.preferences.checked=false;
 };
 form.querySelector('[type=submit]').textContent='Continue To Save As…';
 form.onsubmit=async e=>{
  e.preventDefault();
  try{const data=makeSaveBundle(capture(),fields()),result=await requestFileSave(new Blob([JSON.stringify(data,null,2)],{type:'application/json'}),'wave-studio-save.json');if(result){d.close();onSaved(result)}}
  catch(error){d.querySelector('[data-save-error]').textContent=error.message}
 };
}
