import {parseLitres,FUEL_TYPES,fuelTypeById} from './fuel-model.js?v=v031-preview-20261004';
import {drawFuelGauge} from './flame-visuals.js?v=v031-preview-20261004';
const litres=n=>n==='infinity'||n===Infinity?'∞':String(Math.round(n)/1000);
export function mountFuelUI({ledger,container,selector,idOf,findFixture,getFixtures=()=>[],getSelected=()=>[],panel=null,onOpen=()=>{},onRefill=()=>{},bindContext=true}){
 const dialog=document.createElement('dialog');dialog.className='fuel-dialog';
 dialog.setAttribute('aria-label','Fuel Consumption');
 dialog.innerHTML=`<div class="fuel-heading"><h2>Fuel Consumption</h2><button type="button" data-fuel-close>Close</button></div>
 <p data-fuel-unit></p><canvas width="240" height="150" aria-hidden="true"></canvas><strong class="fuel-remaining" data-fuel-remaining></strong><p data-fuel-used></p><p data-fuel-session></p>
 <form class="fuel-form">
 <label>Apply To<select data-fuel-scope><option value="one">This Unit</option><option value="selected">Selected Units</option><option value="all">All Units</option></select></label>
 <label>Tank Capacity (L)<input data-fuel-capacity inputmode="decimal" required></label>
 <label>Remaining Amount (L)<input data-fuel-amount inputmode="decimal" required></label>
 <p class="fuel-assumptions">Type 999 for ∞ (unlimited). A specific amount must fit within the tank capacity.</p>
 <label>Outdoor Flow (ml/s)<input data-fuel-outdoor type="number" min="0" max="100000" step="any" required></label>
 <label>Indoor Flow (ml/s)<input data-fuel-indoor type="number" min="0" max="100000" step="any" required></label>
 <label>Calibration (%)<input data-fuel-calibration type="number" min="0" max="10000" step="any" required></label>
 <p data-fuel-rate class="fuel-assumptions"></p>
 <button type="submit" class="fuel-refill">Apply Settings</button><button type="button" data-fuel-refill>Refill To Capacity</button>
 <p data-fuel-message role="status"></p></form>
 <p class="fuel-assumptions">Estimates only, not measured tank levels. Rates apply while simulated emission is on; residual flame artwork does not consume fluid. Empty estimates do not stop visualization. No physical equipment is controlled.</p>
 <p class="fuel-assumptions">Nominal defaults: <a href="https://explo.at/product/x2-wave-flame/" target="_blank" rel="noopener">75 / 31 ml/s</a> · <a href="https://explo.at/wp-content/uploads/2025/06/X2-Wave-Flamer-v2.0-ENG-2.pdf" target="_blank" rel="noopener">10 L tank</a>.</p>`;
 document.body.append(dialog);
 const $=s=>dialog.querySelector(s);
 let current=null,trigger=null,timer=null,down=null,last=-Infinity,amountInitial='',amountEdited=false;
 const targets=()=>($('[data-fuel-scope]').value==='all'?getFixtures().map(f=>f.id):$('[data-fuel-scope]').value==='selected'?getSelected():[current]).filter(id=>findFixture(id));
 function fill(){
  const s=ledger.settings(current);
  $('[data-fuel-capacity]').value=litres(s.capacityMl);$('[data-fuel-amount]').value=litres(s.remainingMl);
  amountInitial=$('[data-fuel-amount]').value;
  amountEdited=false;
  $('[data-fuel-outdoor]').value=s.outdoorRate;$('[data-fuel-indoor]').value=s.indoorRate;$('[data-fuel-calibration]').value=s.calibration;
 }
 function refresh(){
  const f=findFixture(current);if(!dialog.open||!f)return;
  const s=ledger.settings(current),ml=ledger.remaining(current),ratio=ledger.ratio(current);
  $('[data-fuel-unit]').textContent=`F${String(current).padStart(2,'0')} · ${f.nozzle==='indoor'?'Indoor':'Outdoor'} Estimate`;
  $('[data-fuel-remaining]').textContent=`${ml===Infinity?'∞':(ml/1000).toFixed(2)} L${s.capacityMl==='infinity'?'':` · ${(ratio*100).toFixed(1)}%`}`;
  $('[data-fuel-used]').textContent=`Used Since Refill: ${(s.usedMl/1000).toFixed(3)} L${ratio<=.2?' · Low Fuel':''}`;
  $('[data-fuel-session]').textContent=`Session Total (All Units): ${sessionText()}`;
  $('[data-fuel-rate]').textContent=`Current effective flow: ${ledger.rate(current,f.nozzle).toFixed(2)} ml/s. Settings take effect from now; past consumption is not recalculated.`;
  const c=$('canvas'),g=c.getContext('2d');g.clearRect(0,0,c.width,c.height);drawFuelGauge(g,{x:120,y:105,radius:68,level:ratio});
 }
 function open(id,element){
  if(!findFixture(id))return;
  stopHold();onOpen();current=id;trigger=element;$('[data-fuel-scope]').value='one';$('[data-fuel-message]').textContent='';
  fill();if(!dialog.open)dialog.showModal();refresh();
 }
 function stopHold(){clearTimeout(timer);timer=null;down=null}
 // Beta 0.19: when bindContext is false the fixture quick-action menu owns right-click / long-press and calls open() itself.
 if(bindContext)container.addEventListener('contextmenu',e=>{const el=e.target.closest(selector);if(el){e.preventDefault();e.stopPropagation();open(idOf(el),el)}});
 if(bindContext)container.addEventListener('keydown',e=>{if(e.key!=='ContextMenu'&&!(e.shiftKey&&e.key==='F10'))return;const el=e.target.closest(selector);if(el){e.preventDefault();e.stopPropagation();open(idOf(el),el)}});
 if(bindContext)container.addEventListener('pointerdown',e=>{
  const el=e.target.closest(selector);if(e.pointerType!=='touch'||e.button!==0||!el)return;
  stopHold();down={x:e.clientX,y:e.clientY};timer=setTimeout(()=>open(idOf(el),el),600);
 },true);
 window.addEventListener('pointermove',e=>{if(down&&Math.hypot(e.clientX-down.x,e.clientY-down.y)>5)stopHold()},true);
 for(const type of ['pointerup','pointercancel','lostpointercapture'])window.addEventListener(type,stopHold,true);
 window.addEventListener('blur',stopHold);
 $('[data-fuel-close]').onclick=()=>dialog.close();
 dialog.addEventListener('close',()=>{trigger?.focus({preventScroll:true});current=null});
 for(const key of ['capacity','amount'])$(`[data-fuel-${key}]`).addEventListener('change',e=>{if(e.target.value.trim()==='999')e.target.value='∞'});
 $('[data-fuel-amount]').addEventListener('input',()=>amountEdited=true);
 $('.fuel-form').onsubmit=e=>{
  e.preventDefault();
  try{
   const ids=targets();if(!ids.length)throw Error('Select at least one unit.');
   const settings={capacityMl:parseLitres($('[data-fuel-capacity]').value),outdoorRate:Number($('[data-fuel-outdoor]').value),indoorRate:Number($('[data-fuel-indoor]').value),calibration:Number($('[data-fuel-calibration]').value)};
   const amount=$('[data-fuel-amount]').value;
   // An untouched remaining field must not undo fuel consumed while editing.
   if(amountEdited||amount!==amountInitial)settings.remainingMl=parseLitres(amount);
   const rows=ids.map(id=>({id,...ledger.settings(id),...settings}));
   ledger.constructor.validate(rows,ids.map(id=>({id})));
   ids.forEach(id=>ledger.configure(id,settings));onRefill(current);fill();refresh();
   $('[data-fuel-message]').textContent=`Settings Applied To ${ids.length} Unit(s).`;
  }catch(error){$('[data-fuel-message]').textContent=error.message}
 };
 $('[data-fuel-refill]').onclick=()=>{
  const ids=targets();if(!ids.length){$('[data-fuel-message]').textContent='Select at least one unit.';return}
  ids.forEach(id=>ledger.refill(id));onRefill(current);fill();refresh();$('[data-fuel-message]').textContent=`Refilled ${ids.length} Unit(s) To Their Saved Capacity.`;
 };
 const sessionText=()=>{const ml=ledger.sessionUsed(),type=fuelTypeById(ledger.fuelType());return `${(ml/1000).toFixed(3)} L · ≈${(ml/1000*type.density).toFixed(2)} kg ${type.name}`};
 let header=null;
 if(panel){
  header=document.createElement('div');header.className='fuel-session';
  header.innerHTML=`<label>Fuel Type<select data-fuel-type aria-label="Fuel Type">${FUEL_TYPES.map(t=>`<option value="${t.id}">${t.name}</option>`).join('')}</select></label><div class="fuel-session-total"><span>Session Total</span><output data-fuel-session-total aria-live="polite"></output><button type="button" data-fuel-session-reset title="Start a new fuel session total. Per-unit tanks are not changed.">Reset</button></div>`;
  panel.append(header);
  const typeSelect=header.querySelector('[data-fuel-type]');
  for(const event of ['pointerdown','keydown','click'])header.addEventListener(event,e=>{if(e.target.closest('select,button'))e.stopPropagation()});
  typeSelect.onchange=()=>{const ids=getFixtures().map(f=>f.id);ledger.setFuelType(typeSelect.value,ids);onRefill(current);syncPanel(true)};
  header.querySelector('[data-fuel-session-reset]').onclick=()=>{ledger.resetSession();syncPanel(true);if(dialog.open)refresh()};
 }
 if(panel)panel.addEventListener('click',e=>{const button=e.target.closest('[data-fuel-bar]');if(button)open(+button.dataset.fuelBar,button)});
 let lastSession='';
 function syncPanel(force=false){
  if(!panel)return;
  const text=sessionText();
  if(force||text!==lastSession){lastSession=text;header.querySelector('[data-fuel-session-total]').textContent=text;header.querySelector('[data-fuel-session-total]').title=`Estimated fuel burned by all units since ${new Date(ledger.sessionStarted).toLocaleTimeString()} (mass uses a typical liquid density of ${fuelTypeById(ledger.fuelType()).density} kg/L)`;const sel=header.querySelector('[data-fuel-type]');if(document.activeElement!==sel)sel.value=ledger.fuelType()}
  const ids=getSelected().filter(id=>findFixture(id)),key=ids.join(',');
  if(panel.dataset.ids!==key){
   panel.dataset.ids=key;[...panel.childNodes].forEach(n=>{if(n!==header)n.remove()});panel.style.setProperty('--fuel-cols',Math.max(1,Math.ceil(Math.sqrt(ids.length))));
   panel.style.setProperty('--fuel-rows',Math.max(1,Math.ceil(ids.length/Math.max(1,Math.ceil(Math.sqrt(ids.length))))));
   panel.classList.toggle('dense',ids.length>4);
   if(!ids.length){const empty=document.createElement('span');empty.className='fuel-empty';empty.textContent='Select Units';panel.append(empty)}
   for(const id of ids){const b=document.createElement('button');b.type='button';b.dataset.fuelBar=id;b.innerHTML='<span></span><i><b></b></i>';panel.append(b)}
  }
  panel.querySelectorAll('[data-fuel-bar]').forEach(b=>{
   const id=+b.dataset.fuelBar,r=ledger.ratio(id),remaining=ledger.remaining(id),s=ledger.settings(id);
   b.querySelector('span').textContent=`${id} · ${remaining===Infinity?'∞':Math.round(r*100)+'%'}`;
   b.querySelector('span').dataset.unit=String(id);
   b.querySelector('b').style.width=`${r*100}%`;b.style.setProperty('--fuel-color',r<=.2?'#f16d65':r<=.5?'#f1ca54':'#57b9f9');
   b.setAttribute('aria-label',`Unit ${id}: ${remaining===Infinity?'Unlimited':(remaining/1000).toFixed(2)+' litres'} remaining. Edit Fuel Consumption.`);
   b.title=`F${id}: ${litres(s.remainingMl)} L Remaining · ${(s.usedMl/1000).toFixed(3)} L Used`;
  });
 }
 return {open,sync(){
  if(performance.now()-last<100)return;last=performance.now();
  for(const el of container.querySelectorAll(selector)){
   const percent=Math.round(ledger.ratio(idOf(el))*100);
   if(el.dataset.fuelPercent!==String(percent)){el.dataset.fuelPercent=percent;el.title=`Estimated Fuel: ${percent}%. Right-Click Or Hold The Unit, Then Choose Fuel Consumption. Keyboard: Shift+F10.`;el.setAttribute('aria-description',el.title)}
  }
  syncPanel();if(dialog.open){if(findFixture(current))refresh();else dialog.close()}
 },close(){if(dialog.open)dialog.close()}};
}
