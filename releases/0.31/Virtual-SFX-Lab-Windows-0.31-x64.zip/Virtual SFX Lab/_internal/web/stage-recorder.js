// Browser-local visual rehearsal recording. No hardware, camera or microphone access.
import {requestFileSave} from './file-save.js?v=v031-preview-20261004';
import {drawSequenceCaption,createSequenceLog} from './sequence-caption.js?v=v031-preview-20261004';
import {drawWatermark} from './watermark.js?v=v031-preview-20261004';
export const recordingDefaults={quality:'standard',format:'auto',fps:30,seconds:60,sequence:false};
export function validateRecording(value){
 const p={...recordingDefaults,...value};
 if(!['compact','standard','high'].includes(p.quality)||!['auto','mp4','webm'].includes(p.format)||![24,30,60].includes(p.fps)||![15,30,60,120,300].includes(p.seconds)||typeof p.sequence!=='boolean')throw Error('Invalid Recording Preferences.');
 return {quality:p.quality,format:p.format,fps:p.fps,seconds:p.seconds,sequence:p.sequence};
}
const types={mp4:['video/mp4;codecs=avc1.42001E','video/mp4'],webm:['video/webm;codecs=vp9','video/webm;codecs=vp8','video/webm']};
export function mountStageRecorder({canvas,host,overlay,onChange=()=>{},getSequence=null}){
 let prefs={...recordingDefaults},recorder=null,stream=null,frame=0,timer=0,started=0,clips=[],busy=false;
 const supported=!!(globalThis.MediaRecorder&&canvas.captureStream);
 const mime=kind=>supported?types[kind].find(t=>MediaRecorder.isTypeSupported(t)):null;
 const available={mp4:mime('mp4'),webm:mime('webm')};
 const record=document.createElement('button');record.id='layout-record';record.type='button';record.className='layout-record';
 record.innerHTML='<span class="record-dot" aria-hidden="true"></span><span class="record-time" aria-hidden="true"></span>';
 record.setAttribute('aria-label','Record Layout Video');record.title='Record Layout Video · No Audio';
 const open=document.createElement('button');open.id='recordings-open';open.type='button';open.textContent='Recordings';
 host.append(open);overlay.append(record);
 const dialog=document.createElement('dialog');dialog.id='layout-recordings';
 dialog.innerHTML='<div class="dialog-head"><h2>Layout Recordings</h2><button type="button" data-close>Close</button></div><p>Only The Animated Layout Is Recorded. No Camera, Microphone Or Chat. Clips Stay In This Tab Only: Download Before Refreshing Or Closing. Layout Backups Do Not Include Videos.</p><div class="record-options"><label>Quality<select id="record-quality"><option value="compact">Compact · Up To 720p / 2 Mbps</option><option value="standard">Standard · Up To 1080p / 5 Mbps</option><option value="high">High · Up To 1440p / 10 Mbps</option></select></label><label>Video Format<select id="record-format"><option value="auto">Automatic · MP4 When Supported</option><option value="mp4">MP4</option><option value="webm">WebM</option></select></label><label>Frame Rate<select id="record-fps"><option value="24">24 FPS</option><option value="30">30 FPS</option><option value="60">60 FPS</option></select></label><label>Auto-Stop After<select id="record-seconds"><option value="15">15 Seconds</option><option value="30">30 Seconds</option><option value="60">1 Minute</option><option value="120">2 Minutes</option><option value="300">5 Minutes</option></select></label><label class="record-sequence"><input type="checkbox" id="record-sequence"> <span>Record The Running Sequence<small>Shows the sequence number, name and units in the video and saves a timestamped sequence log with the clip.</small></span></label></div><p class="widget-hint">Quality And Frame Rate Are Targets; Actual Output Depends On The Browser And Layout Size. Recording Does Not Start Or Restart Cue Playback. Hidden Tabs Stop Recording Automatically.</p><p data-record-status role="status"></p><div class="settings-actions"><button type="button" data-record-toggle>Start Recording</button></div><div class="recording-list"></div>';
 document.body.append(dialog);
 const status=dialog.querySelector('[data-record-status]'),toggle=dialog.querySelector('[data-record-toggle]'),list=dialog.querySelector('.recording-list');
 const controls={quality:dialog.querySelector('#record-quality'),format:dialog.querySelector('#record-format'),fps:dialog.querySelector('#record-fps'),seconds:dialog.querySelector('#record-seconds'),sequence:dialog.querySelector('#record-sequence')};
 for(const kind of ['mp4','webm']){const option=controls.format.querySelector(`[value="${kind}"]`);option.disabled=!available[kind];if(!available[kind])option.textContent+=' · Unavailable In This Browser'}
 function tell(text){status.textContent=text;record.title=text}
 function sync(){
  record.classList.toggle('is-recording',busy);record.setAttribute('aria-pressed',String(busy));record.setAttribute('aria-label',busy?'Stop Layout Recording':'Record Layout Video');
  toggle.textContent=busy?'Stop Recording':'Start Recording';
  for(const control of Object.values(controls))control.disabled=busy;
  record.disabled=toggle.disabled=!supported||!Object.values(available).some(Boolean);
  if(record.disabled)tell('Layout Video Recording Is Not Supported In This Browser. Try A Current Desktop Chrome Or Edge Browser.');
 }
 function restore(value){prefs=validateRecording(value);for(const [key,control]of Object.entries(controls)){if(control.type==='checkbox')control.checked=prefs[key];else control.value=String(prefs[key])}}
 for(const [key,control]of Object.entries(controls))control.onchange=()=>{prefs=validateRecording({...prefs,[key]:control.type==='checkbox'?control.checked:['fps','seconds'].includes(key)?Number(control.value):control.value});onChange()};
 if(!getSequence)controls.sequence.closest('label').hidden=true;
 function renderClips(){
  // Avoid restarting videos when opening the library again.
  list.replaceChildren();
  if(!clips.length){const p=document.createElement('p');p.className='widget-hint';p.textContent='No Recordings Yet. Use The Red Dot In The Layout To Start And Stop.';list.append(p)}
  for(const clip of [...clips].reverse()){
   const article=document.createElement('article'),title=document.createElement('h3'),details=document.createElement('p'),video=document.createElement('video'),actions=document.createElement('div'),download=document.createElement('a'),remove=document.createElement('button');
   title.textContent=clip.name;details.textContent=`${clip.width} × ${clip.height} · ${clip.seconds.toFixed(1)} s · ${(clip.blob.size/1048576).toFixed(1)} MB · ${clip.downloaded?'Download Requested':'Not Downloaded'}`;
   video.controls=true;video.playsInline=true;video.preload='metadata';video.src=clip.url;
   let used=null;if(clip.log?.entries.length){used=document.createElement('p');used.className='recording-sequences';const list=clip.log.summary();used.textContent=`Sequences Recorded: ${list.slice(0,6).join(' | ')}${list.length>6?` | +${list.length-6} More`:''}`}
   actions.className='settings-actions';download.href=clip.url;download.download=clip.name;download.textContent='Save Video';download.onclick=async e=>{e.preventDefault();const result=await requestFileSave(clip.blob,clip.name);if(result){clip.downloaded=true;details.textContent=details.textContent.replace('Not Downloaded',result.message)}};
   remove.type='button';remove.textContent='Remove';remove.onclick=()=>{if(!confirm('Remove This Recording From This Tab? Download It First If You Want To Keep It.'))return;video.pause();video.removeAttribute('src');video.load();URL.revokeObjectURL(clip.url);clips=clips.filter(c=>c!==clip);renderClips()};
   if(clip.log?.entries.length){const log=document.createElement('button');log.type='button';log.textContent='Save Sequence Log';log.onclick=()=>{const name=clip.name.replace(/\.(mp4|webm)$/,'-sequences.txt');requestFileSave(new Blob([clip.log.toText(clip.name)],{type:'text/plain'}),name)};actions.append(download,log,remove)}else actions.append(download,remove);article.append(title,details,...(used?[used]:[]),video,actions);list.append(article);
  }
  open.textContent=clips.length?`Recordings (${clips.length})`:'Recordings';
 }
 function cleanup(){cancelAnimationFrame(frame);clearInterval(timer);stream?.getTracks().forEach(t=>t.stop());stream=null;busy=false;recorder=null;record.querySelector('.record-time').textContent='';sync()}
 function stop(reason='Recording Ready. Download It From Recordings.'){
  if(recorder?.state==='recording'){tell(reason);toggle.disabled=record.disabled=true;recorder.stop()}
 }
 function start(){
  if(busy)return;
  if(clips.reduce((n,c)=>n+c.blob.size,0)>=200*1048576){tell('Recording Library Is Full. Download And Remove Clips Before Recording More.');if(!dialog.open)dialog.showModal();return}
  const chosen=prefs.format==='auto'?(available.mp4||available.webm):available[prefs.format];
  if(!chosen){tell('Selected Video Format Is Unavailable. Choose Automatic Or Another Supported Format.');if(!dialog.open)dialog.showModal();return}
  let chunks=[],bytes=0,info=null,infoAt=-1;const log=prefs.sequence&&getSequence?createSequenceLog():null;
  const target=document.createElement('canvas'),quality={compact:[720,2000000],standard:[1080,5000000],high:[1440,10000000]}[prefs.quality];
  const ratio=Math.min(1,quality[0]/canvas.height,quality[0]*16/9/canvas.width);
  target.width=Math.max(2,Math.floor(canvas.width*ratio/2)*2);target.height=Math.max(2,Math.floor(canvas.height*ratio/2)*2);
  const ctx=target.getContext('2d',{alpha:false});
  function paint(){ctx.fillStyle='#0d1013';ctx.fillRect(0,0,target.width,target.height);const scale=Math.min(target.width/canvas.width,target.height/canvas.height);const w=canvas.width*scale,h=canvas.height*scale;ctx.drawImage(canvas,(target.width-w)/2,(target.height-h)/2,w,h);let band=0;if(log){const now=performance.now(),elapsed=started?(now-started)/1000:0;if(now-infoAt>200){infoAt=now;try{info=getSequence()}catch{info=null}log.mark(elapsed,info)}band=drawSequenceCaption(ctx,target.width,target.height,info,elapsed)}drawWatermark(ctx,target.width,target.height,band);frame=requestAnimationFrame(paint)}
  try{
   paint();stream=target.captureStream(prefs.fps);
   const current=new MediaRecorder(stream,{mimeType:chosen,videoBitsPerSecond:quality[1]});recorder=current;started=performance.now();
   current.ondataavailable=e=>{if(e.data.size){chunks.push(e.data);bytes+=e.data.size;if(bytes>=64*1048576)stop('Recording Stopped At The 64 MB Clip Limit.')}};
   current.onerror=()=>{tell('The Browser Could Not Finish Recording. Any Recoverable Video Will Appear Below.');if(current.state!=='inactive')current.stop();else cleanup()};
   current.onstop=()=>{
    const seconds=(performance.now()-started)/1000,type=current.mimeType.split(';')[0],blob=new Blob(chunks,{type});
    if(blob.size){const name=`wave-layout-${new Date().toISOString().replace(/[:.]/g,'-')}.${type.includes('mp4')?'mp4':'webm'}`;clips.push({name,blob,url:URL.createObjectURL(blob),seconds,width:target.width,height:target.height,downloaded:false,log})}
    else tell('No Video Was Captured. Try Another Format.');
    cleanup();renderClips();
   };
   current.start(500);busy=true;sync();tell(`Recording ${chosen.startsWith('video/mp4')?'MP4':'WebM'} · Press The Red Dot To Stop.`);
   timer=setInterval(()=>{const elapsed=(performance.now()-started)/1000;record.querySelector('.record-time').textContent=`${Math.floor(elapsed/60)}:${String(Math.floor(elapsed%60)).padStart(2,'0')}`;if(elapsed>=prefs.seconds)stop('Recording Auto-Stopped. Download It From Recordings.')},200);
   if(dialog.open)dialog.close();
  }catch(error){cleanup();tell(`Recording Could Not Start: ${error.message}`);if(!dialog.open)dialog.showModal()}
 }
 record.onclick=toggle.onclick=()=>busy?stop():start();
 open.onclick=()=>dialog.showModal();dialog.querySelector('[data-close]').onclick=()=>{dialog.querySelectorAll('video').forEach(v=>v.pause());dialog.close()};
 document.addEventListener('visibilitychange',()=>{if(document.hidden)stop('Recording Stopped Because The Tab Was Hidden. Download It From Recordings.')});
 window.addEventListener('beforeunload',e=>{if(busy||clips.some(c=>!c.downloaded)){e.preventDefault();e.returnValue=''}});
 window.addEventListener('pagehide',()=>{if(recorder?.state==='recording')recorder.stop();cancelAnimationFrame(frame);clearInterval(timer);stream?.getTracks().forEach(t=>t.stop());clips.forEach(c=>URL.revokeObjectURL(c.url))},{once:true});
 restore(prefs);sync();renderClips();
 return {serialize:()=>({...prefs}),restore,isRecording:()=>busy};
}
