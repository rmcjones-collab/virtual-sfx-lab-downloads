// Local checklist UI. Checking a step never triggers the operation it describes.
import {requestFileSave} from './file-save.js?v=v031-preview-20261004';
export function mountTestChecklist(host){
 host.innerHTML='<p class="support-note">Work through these steps with a colleague. Check a step only after you test it. Progress stays while this page is open; download results before reloading.</p><div class="checklist-toolbar"><output id="test-checklist-progress" aria-live="polite">Loading Checklist…</output><div class="support-row"><button id="test-checklist-download" disabled>Download Results</button><button id="test-checklist-reset" disabled>Reset Checklist</button></div></div><div id="test-checklist-content"></div><p id="test-checklist-status" class="support-status" role="status"></p>';
 const $=s=>host.querySelector(s),content=$('#test-checklist-content');
 const plain=s=>s.replace(/\*\*/g,'');
 const checkboxes=[],blocks=[];let notes=null,notesTemplate='';
 const progress=()=>{$('#test-checklist-progress').textContent=`${checkboxes.filter(c=>c.checked).length} / ${checkboxes.length} Steps Checked`};
 async function load(){
  try{
   const response=await fetch(new URL('./colleague-test-checklist.md',import.meta.url),{cache:'no-store'});
   if(!response.ok)throw Error('Checklist could not load. Reload the preview to retry.');
   const source=await response.text();let parent=content,code=null;
   for(const line of source.split('\n')){
    if(line.startsWith('# '))continue;
    if(line.startsWith('```')){
     if(code===null){code=[];continue}
     notesTemplate=code.join('\n');notes=document.createElement('textarea');notes.id='test-checklist-notes';notes.maxLength=12000;notes.value=notesTemplate;notes.rows=10;
     const label=document.createElement('label');label.htmlFor=notes.id;label.textContent='Test Notes / Failure Report';parent.append(label,notes);blocks.push({notes:true});code=null;continue;
    }
    if(code!==null){code.push(line);continue}
    if(!line.trim())continue;
    if(line.startsWith('## ')){
     const title=line.slice(3),details=document.createElement('details'),summary=document.createElement('summary');summary.textContent=title;details.className='test-checklist-section';details.open=title==='Before You Start';details.append(summary);content.append(details);parent=details;blocks.push({heading:title});continue;
    }
    if(line.startsWith('- [ ] ')){
     const label=document.createElement('label'),input=document.createElement('input'),text=document.createElement('span');
     input.type='checkbox';input.dataset.testStep=checkboxes.length;text.textContent=plain(line.slice(6));label.className='test-checklist-step';label.append(input,text);parent.append(label);checkboxes.push(input);blocks.push({input,text:text.textContent});input.onchange=progress;continue;
    }
    const p=document.createElement('p');p.textContent=plain(line);parent.append(p);blocks.push({paragraph:p.textContent});
   }
   progress();$('#test-checklist-download').disabled=false;$('#test-checklist-reset').disabled=false;
  }catch(e){$('#test-checklist-progress').textContent='Checklist Unavailable';$('#test-checklist-status').textContent=e.message}
 }
 $('#test-checklist-download').onclick=async()=>{
  const lines=['# Wave Studio Colleague Test Results','',`Downloaded: ${new Date().toISOString()}`,`${checkboxes.filter(c=>c.checked).length} / ${checkboxes.length} steps checked. Checked means tested, not automatically passed.`,''];
  for(const block of blocks){
   if(block.heading)lines.push('',`## ${block.heading}`,'');
   else if(block.input)lines.push(`- [${block.input.checked?'x':' '}] ${block.text}`);
   else if(block.notes)lines.push('',notes.value,'');
   else lines.push(block.paragraph,'');
  }
  const result=await requestFileSave(new Blob([lines.join('\n')],{type:'text/markdown;charset=utf-8'}),'wave-studio-colleague-test-results.md');
  if(result)$('#test-checklist-status').textContent=result.message+' Nothing Was Sent To Chat Or Applied To The App.';
 };
 $('#test-checklist-reset').onclick=()=>{
  if(!confirm('Clear the checklist checkmarks and test notes? Download Results first if you want to keep this test run.'))return;
  checkboxes.forEach(input=>input.checked=false);if(notes)notes.value=notesTemplate;progress();$('#test-checklist-status').textContent='Checklist Reset. Your Layout And Chat Are Unchanged.';
 };
 load();
}
