import {PlaybackBank,MACRO_ACTIONS} from './playback-model.js?v=v031-preview-20261004';
import {presets} from './presets.js?v=v031-preview-20261004';
import {ControlMapper,defaultMapping,validateMapping,mapTargets,bindingUniverse} from './control-map.js?v=v031-preview-20261004';

export function mountPlayback({state,onModeChange,onLeaveLive,onSelection}){
 const bank=new PlaybackBank(),$=s=>document.querySelector(s),root=$('#playback-bank');
 const status=message=>$('#bank-status').textContent=message;
 const library=$('#cue-library'),dialog=$('#playback-editor');
 let blocked=false,wasLive=false,lastSelection='',lastPaint=-1,paused=false;
 let mapStream=null,mapController=null;
 const mapper=new ControlMapper({apply:applyMapping,release:()=>{bank.releaseAll();bank.grandMaster=0;macroDown.clear();consoleFollow.buttons.clear();}});
 const macroDown=new Set();
 // Console follow: what the Vista console is doing right now, for on-screen feedback.
 // In mapped mode the console drives the bank and these records only add the visual pulse.
 // In Live Input mode Vista owns the output and the faders/keys mirror the incoming channels, visual only.
 const consoleFollow={levels:new Array(20).fill(null),master:null,buttons:new Set(),touched:new Array(20).fill(0),masterTouched:0,lastPaint:0,source:null,announced:false};
 function noteConsoleTouch(i){consoleFollow.touched[i]=performance.now()}
 function consoleButton(kind,i,active){
  const key=`${kind}:${i}`,was=consoleFollow.buttons.has(key);
  if(active)consoleFollow.buttons.add(key);else consoleFollow.buttons.delete(key);
  if(active&&!was){
   const el=kind==='macro'?$('#macro-grid')?.querySelectorAll('.macro-key')[i]:$(`.fader-strip[data-fader="${i}"] .flash-key[data-hold="${kind}"]`);
   if(el){el.classList.remove('console-hit');void el.offsetWidth;el.classList.add('console-hit')}
  }
 }
 function clearConsoleFollow(){consoleFollow.levels.fill(null);consoleFollow.master=null;consoleFollow.buttons.clear();consoleFollow.touched.fill(0);consoleFollow.masterTouched=0;consoleFollow.source=null;consoleFollow.announced=false}
 const byteValue=level=>String(Math.round(level*255/100));
 function syncByteInput(input,level){
  if(document.activeElement!==input)input.value=byteValue(level);
 }
 function bindByteInput(input,getLevel,commit){
  let dirty=false;
  const restore=()=>{dirty=false;input.value=byteValue(getLevel())};
  const save=()=>{
   if(!dirty)return;
   if(blocked||state.live||input.matches(':disabled')){restore();return}
   const text=input.value.trim(),value=Number(text);
   if(!/^\d{1,3}$/.test(text)||!Number.isInteger(value)||value<0||value>255){
    restore();input.setAttribute('aria-invalid','true');status('Enter a whole value from 0 to 255. The previous fader level is unchanged.');return;
   }
   dirty=false;input.removeAttribute('aria-invalid');
   commit(value);input.value=byteValue(getLevel());
  };
  input.oninput=()=>{dirty=true;input.removeAttribute('aria-invalid')};
  input.onfocus=()=>input.select();
  input.onblur=()=>{save();restore()};
  input.onkeydown=e=>{
   if(e.key==='Enter'){e.preventDefault();save();input.blur()}
   if(e.key==='Escape'){e.preventDefault();e.stopPropagation();restore();input.removeAttribute('aria-invalid');input.blur()}
  };
 }
 function paint(){
  bank.selectGroup(state.selectedIds,state.selectedId);
  $('#bank-enable').checked=bank.enabled;
  $('#bank-master-level').value=bank.grandMaster;
  syncByteInput($('#bank-master-value'),bank.grandMaster);
  $('#bank-master-percent').textContent=`${Number(bank.grandMaster.toFixed(1))}%`;
  const selected=state.fixtures.find(f=>f.id===state.selectedId);
  $('#virtual-dmx-monitor').textContent=selected&&bank.virtualOwns(selected)
   ?`F${String(selected.id).padStart(2,'0')} · Virtual U${selected.patch.universe+1} · CH ${selected.patch.address}–${selected.patch.address+5}: ${bank.virtualEngine.record(selected).values.join(' / ')} · ${bank.virtualEngine.record(selected).status}`
   :'Virtual DMX: check a channel to take over a matching fixture patch. Other fixtures keep cue playback.';
  bank.slots.forEach((s,i)=>{
   const r=bank.runtime[i],row=$(`.fader-strip[data-fader="${i}"]`);
   for(const key of ['cueLabel','dmxLabel']){
    const input=row.querySelector(`[data-label="${key}"]`);
    if(document.activeElement!==input)input.value=s[key];
    input.title=`${s[key]} · Click to rename (32 characters)`;
   }
   row.querySelector('input[type=range]').value=r.level;
   syncByteInput(row.querySelector('.fader-byte'),bank.level(i));
   row.querySelector('.fader-percent').textContent=`${Number(bank.level(i).toFixed(1))}%`;
   const channel=row.querySelector('.fader-dmx');
   if(channel&&document.activeElement!==channel)channel.value=String(bank.controlMapping.bindings[i].address);
   const uTag=row.querySelector('.fader-universe'),ownU=bank.controlMapping.bindings[i].universe!==undefined;
   if(uTag){uTag.textContent=`U${faderUniverse(i)}`;uTag.classList.toggle('custom',ownU);uTag.title=ownU?`Fader ${i+1} uses its own universe ${faderUniverse(i)} (Settings)`:`Follows bank universe ${faderUniverse(i)} · change in Settings`}
   row.querySelector('.dmx-priority').checked=s.dmxPriority;
   row.querySelector('.cue-assignment').disabled=s.dmxPriority;
   row.classList.toggle('dmx-priority-mode',s.dmxPriority);
   const mirror=blocked&&state.live&&consoleFollow.levels[i]!==null;
   if(mirror){
    const level=consoleFollow.levels[i];
    row.querySelector('input[type=range]').value=level;
    syncByteInput(row.querySelector('.fader-byte'),level);
    row.querySelector('.fader-percent').textContent=`${Number(level.toFixed(1))}%`;
   }
   row.classList.toggle('console-mirror',mirror);
   row.classList.toggle('raised',mirror?consoleFollow.levels[i]>0:bank.level(i)>0&&bank.enabled);
   row.classList.toggle('console-touched',performance.now()-consoleFollow.touched[i]<900);
   row.querySelectorAll('.flash-key').forEach(b=>{
    const pressed=r.held.has(b.dataset.hold)||r.held.has(`mapped-${b.dataset.hold}`)||consoleFollow.buttons.has(`${b.dataset.hold}:${i}`);
    b.setAttribute('aria-pressed',String(pressed));
    b.classList.toggle('console-pressed',consoleFollow.buttons.has(`${b.dataset.hold}:${i}`));
   });
  });
  if(blocked&&state.live&&consoleFollow.master!==null){
   $('#bank-master-level').value=consoleFollow.master;syncByteInput($('#bank-master-value'),consoleFollow.master);
   $('#bank-master-percent').textContent=`${Number(consoleFollow.master.toFixed(1))}%`;
  }
  root.classList.toggle('console-master-touched',performance.now()-consoleFollow.masterTouched<900);
  $('#macro-grid').querySelectorAll('.macro-key').forEach((b,i)=>{
   b.querySelector('small').textContent=bank.macros[i].name;
   b.title=`F${i+1}: ${bank.macros[i].name}`;
   b.setAttribute('aria-pressed',String(macroDown.has(i)||consoleFollow.buttons.has(`macro:${i}`)));
   b.classList.toggle('console-pressed',consoleFollow.buttons.has(`macro:${i}`));
  });
 }
 function activate(){
  if(blocked||state.live)return false;
  if(!bank.enabled){bank.enabled=true;paused=false;onModeChange(true)}
  paint();return true;
 }
 function enableVirtualFaders(){
  const switching=state.live||!bank.enabled||mapper.enabled||mapStream||mapController;
  if(mapper.enabled||mapStream||mapController)disconnectMapping();
  if(state.live)onLeaveLive();
  blocked=false;wasLive=false;$('#bank-controls').disabled=false;
  if(switching){bank.releaseAll();bank.grandMaster=100}
  bank.enabled=true;paused=false;onModeChange(true);
  let starter=-1;
  if(!bank.cues.length&&state.selectedIds.length){
   const free=bank.slots.findIndex(s=>!s.dmxPriority&&s.kind==='cue'&&s.cueId===null);
   if(free>=0){const cue=bank.record('Selected virtual units',state.fixtures,state.selectedIds);
   bank.assign(free,cue.id);renderCues();library.value=cue.id;starter=free;}
  }
  paint();
  status(starter>=0?`Virtual faders ready. Selected units assigned to cue fader ${starter+1} at zero. Uncheck overlapping DMX-channel faders to let those fixtures follow cues. MASTER is at 100%.`:'Virtual faders ready. DMX-checked faders take priority over cues on matching fixtures. All levels start at zero; no physical DMX is sent.');
  $('#viewport').scrollIntoView({block:'start',behavior:'auto'});
 }
 $('#mode-faders').onclick=enableVirtualFaders;
 $('#enable-virtual-faders').onclick=enableVirtualFaders;
 function transportState(){
  const active=bank.slots.map((s,i)=>({s,i,r:bank.runtime[i]})).filter(x=>!x.s.dmxPriority&&x.s.kind==='cue'&&x.s.cueId!==null);
  const chosen=active.find(x=>x.s.cueId===Number(library.value))||active.filter(x=>x.r.level>0).sort((a,b)=>b.r.stamp-a.r.stamp)[0]||active[0];
  const cue=bank.cues.find(c=>c.id===chosen?.s.cueId);
  if(!cue)return {paused,time:0,total:0,label:'Bank / chase',slot:null};
  const t=cue.timing,total=Math.round((t.delay+t.fadeIn+(t.hold||bank.cueDuration(cue))+t.fadeOut)*100)/100;
  let elapsed=Math.max(0,bank.time-chosen.r.started);
  if(chosen.s.loop&&elapsed>total&&!$('#tour').checked)elapsed=t.delay+(elapsed-t.delay)%(total-t.delay);
  const step=cue.sequenceOrder?bank.sequenceStep(cue,Math.max(0,elapsed-t.delay)):null;
  return {paused,time:Math.min(total,elapsed),total,presetDuration:cue.sequenceOrder?bank.lookTiming(cue,0).duration:Math.max(...cue.looks.map(l=>presets[l.presetId-1].duration)),label:cue.name+(step?` · ${step.index+1}/${cue.sequenceOrder.length} · ${String(step.presetId).padStart(3,'0')}`:''),slot:chosen.i,cueId:cue.id,loop:chosen.s.loop};
 }
 function navigateCue(direction,edge=null){
  if(!bank.cues.length){status('Record a cue to use cue navigation. Play/Pause still controls the bank clock.');return}
  const current=transportState(),index=bank.cues.findIndex(c=>c.id===(Number(library.value)||current.cueId));
  const cue=bank.cues[edge==='first'?0:edge==='last'?bank.cues.length-1:(Math.max(0,index)+direction+bank.cues.length)%bank.cues.length];
  const previous=current.slot===null?100:bank.runtime[current.slot].level||100;
  bank.releaseAll();
  let target=bank.slots.findIndex(s=>!s.dmxPriority&&s.kind==='cue'&&s.cueId===cue.id);
  if(target<0){target=current.slot??bank.slots.findIndex(s=>!s.dmxPriority);if(target<0){status('Uncheck DMX on a fader to navigate cues.');return}bank.assign(target,cue.id)}
  library.value=String(cue.id);bank.setLevel(target,previous);paused=false;renderCues();
  status(`Playing ${cue.name} on fader ${target+1}. Other cue/chase playbacks released.`);
 }
 function transport(action,value){
  const current=transportState();
  if(action==='play'){paused=!paused;if(!paused&&current.slot!==null&&current.time>=current.total-0.001)bank.runtime[current.slot].started=bank.time}
  else if(action==='prev'||action==='next')navigateCue(action==='prev'?-1:1);
  else if(action==='first'||action==='last')navigateCue(0,action);
  else if(action==='loop'&&current.slot!==null)bank.slots[current.slot].loop=value;
  else if(['start','end','restart','seek'].includes(action)){
   if(current.slot===null){if(action==='restart'){bank.runtime.forEach(r=>r.started=bank.time);paused=false}else status('Assign a recorded cue to use beginning/end navigation.');return}
   const offset=action==='end'?Math.max(0,current.total-0.000001):action==='seek'?Math.min(current.total-0.000001,Math.max(0,value)):0;
   bank.runtime[current.slot].started=bank.time-offset;
   bank.runtime[current.slot].release=null;
   paused=action!=='restart';
   if(action==='restart'&&bank.runtime[current.slot].level===0)bank.setLevel(current.slot,100);
  }
  paint();
 }
 function release(message){
  bank.releaseHolds();macroDown.clear();paint();if(message)status(message);
 }
 function fillOptions(select,options,value){
  select.replaceChildren(...options.map(([v,label])=>new Option(label,v)));
  select.value=value;
 }
 function renderCues(){
  const cueTitle=c=>c.name+(c.sequenceOrder?` · ${c.sequenceOrder.length} looks`:'');
  const current=library.value;
  fillOptions(library,[['','Choose a recorded cue'],...bank.cues.map(c=>[String(c.id),cueTitle(c)])],current);
  if(!library.value)library.value='';
  for(let i=0;i<20;i++){
   const select=$(`.fader-strip[data-fader="${i}"] .cue-assignment`);
   fillOptions(select,[['','Unassigned'],['chase','Multi-unit chase'],...bank.cues.map(c=>[String(c.id),cueTitle(c)])],bank.slots[i].kind==='chase'?'chase':bank.slots[i].cueId??'');
   select.title=bank.cues.find(c=>c.id===bank.slots[i].cueId)?.name??'Choose a recorded cue';
  }
  $('#cue-count').textContent=`${bank.cues.length} / 64 cues`;
  paint();for(const fn of cueListeners)fn();
 }
 const cueListeners=new Set();
 // Cue stacks step through recorded cues by id: release everything else, then raise the cue on its fader (or the first free cue fader).
 function playCueById(id,level=100){
  const cue=bank.cues.find(c=>c.id===id);if(!cue||blocked||state.live)return null;
  if(!bank.enabled){const box=$('#bank-enable');box.checked=true;box.dispatchEvent(new Event('change'))}
  if(!bank.enabled)return null;
  const current=transportState();
  bank.releaseAll();
  let target=bank.slots.findIndex(s=>!s.dmxPriority&&s.kind==='cue'&&s.cueId===cue.id);
  if(target<0){target=current.slot??bank.slots.findIndex(s=>!s.dmxPriority);if(target<0){status('Uncheck DMX on a fader to run cue stacks.');return null}bank.assign(target,cue.id)}
  library.value=String(cue.id);bank.setLevel(target,level);paused=false;renderCues();
  return target;
 }
 $('#bank-master-level').oninput=e=>{bank.grandMaster=Number(e.target.value);paint()};
 bindByteInput($('#bank-master-value'),()=>bank.grandMaster,value=>{
  const range=$('#bank-master-level');range.value=String(value*100/255);range.dispatchEvent(new Event('input',{bubbles:true}));
  status(`Master set to ${value} / 255 (${Number(bank.grandMaster.toFixed(1))}%).`);
 });
 $('#bank-master-level').addEventListener('wheel',e=>{
  const input=e.currentTarget;if(blocked||state.live||input.disabled||e.ctrlKey||!e.deltaY)return;
  e.preventDefault();input.value=String(Math.max(0,Math.min(100,Number(input.value)+(e.deltaY<0?1:-1))));
  input.dispatchEvent(new Event('input',{bubbles:true}));
 },{passive:false});
 $('#master-zero').onclick=()=>{bank.grandMaster=0;paint();status('Bank master at zero. All local cue, chase and flash brightness suppressed.')};
 $('#macro-grid').innerHTML=bank.macros.map((m,i)=>`<div class="macro-cell"><button class="macro-key" data-macro="${i}" aria-pressed="false"><strong>F${i+1}</strong><small></small></button><button class="macro-edit" data-macro="${i}" aria-label="Assign macro F${i+1}">Assign</button></div>`).join('');
 function macroAction(i,pressed,key=`macro-${i}`){
  const m=bank.macros[i];if(blocked||state.live)return;
  if(!pressed){macroDown.delete(i);bank.unhold(m.target,key);for(let n=0;n<20;n++)bank.unhold(n,`${key}:all`);paint();return}
  if(macroDown.has(i))return;
  macroDown.add(i);
  if(m.action==='flash'){
   if(bank.playable(m.target)){activate();bank.hold(m.target,key)}
  }else if(m.action==='flashAll'){
   activate();for(let n=0;n<20;n++)if(bank.playable(n))bank.hold(n,`${key}:all`);
  }else if(m.action==='level'){
   if(bank.playable(m.target)){activate();bank.setLevel(m.target,m.value)}
  }else if(m.action==='release')bank.resetSlot(m.target);
  else if(m.action==='releaseAll'){bank.releaseAll();document.dispatchEvent(new Event('wave-release-all'))}
  else if(m.action==='master')bank.grandMaster=m.value;
  else if(m.action==='blackout')bank.grandMaster=0;
  else if(m.action==='restoreMaster')bank.grandMaster=100;
  else if(m.action==='selectAll')onSelection(state.fixtures.map(f=>f.id));
  else if(m.action==='home')document.dispatchEvent(new Event('wave-home-selected'));
  else if(m.action==='clearSelection')onSelection([]);
  else{
   const buttons={playPause:'#play',restart:'#restart',previousCue:'#prev',nextCue:'#next',firstCue:'#cue-start',lastCue:'#cue-end',toggleLoop:'#loop',toggleAutoNext:'#tour',invertSelected:'#fixture-invert',fitView:'#fit-view',toggleLock:'#layout-lock'};
   if(buttons[m.action])$(buttons[m.action]).click();
  }
  status(`F${i+1}: ${m.action==='none'?'unassigned':m.name}`);paint();
 }
 $('#macro-grid').querySelectorAll('.macro-key').forEach((button,i)=>{
  let pointer=null;
  const down=()=>macroAction(i,true),up=()=>{pointer=null;macroAction(i,false)};
  button.onpointerdown=e=>{if(e.button!==0)return;e.preventDefault();button.focus({preventScroll:true});pointer=e.pointerId;down();button.setPointerCapture(pointer)};
  button.onpointerup=up;button.onpointercancel=up;button.onlostpointercapture=up;
  button.onkeydown=e=>{if([' ','Enter'].includes(e.key)){e.preventDefault();if(!e.repeat)down()}};
  button.onkeyup=e=>{if([' ','Enter'].includes(e.key)){e.preventDefault();up()}};
  button.onblur=()=>{if(pointer===null)up()};
 });
 fillOptions($('#macro-target'),Array.from({length:20},(_,i)=>[i,`Fader ${i+1}`]),2);
 fillOptions($('#macro-action'),MACRO_ACTIONS,'none');
 const macroHelp=document.createElement('p');macroHelp.className='bank-hint';macroHelp.textContent='F1 defaults to Release All; F2 holds every assigned fader at its configured flash level. Releasing F2 restores underlying levels. Flash All does not bypass DMX program or arm rules. Channel labels do not set channel values.';$('#macro-grid').after(macroHelp);
 function macroFields(){
  const action=$('#macro-action').value;
  $('#macro-target').disabled=!['level','flash','release'].includes(action);
  $('#macro-value').disabled=!['level','master'].includes(action);
 }
 $('#macro-action').onchange=macroFields;
 $('#macro-grid').querySelectorAll('.macro-edit').forEach((b,i)=>b.onclick=()=>{
  release();const m=bank.macros[i];$('#macro-dialog').dataset.index=i;
  $('#macro-title').textContent=`Assign F${i+1}`;$('#macro-name').value=m.name;$('#macro-action').value=m.action;$('#macro-target').value=m.target;$('#macro-value').value=m.value;macroFields();$('#macro-dialog').showModal();
 });
 $('#macro-form').onsubmit=e=>{
  e.preventDefault();const i=Number($('#macro-dialog').dataset.index);
  bank.releaseHolds();macroDown.clear();
  const macro={name:$('#macro-name').value.trim()||`Macro ${i+1}`,action:$('#macro-action').value,target:Number($('#macro-target').value),value:Number($('#macro-value').value)};
  const test=bank.serialize();test.macros[i]=macro;try{PlaybackBank.validate(test)}catch{status('Invalid macro assignment. Check its name, action and value.');return}
  bank.macros[i]=macro;
  paint();$('#macro-dialog').close();
 };
 document.addEventListener('keydown',e=>{
  if(!$('#macro-keys').checked||e.ctrlKey||e.altKey||e.metaKey||document.querySelector('dialog[open]')||['INPUT','SELECT','TEXTAREA'].includes(e.target.tagName))return;
  const match=/^F([1-9]|1[0-2])$/.exec(e.key);if(match){e.preventDefault();if(!e.repeat)macroAction(Number(match[1])-1,true)}
 });
 document.addEventListener('keyup',e=>{const match=/^F([1-9]|1[0-2])$/.exec(e.key);if(match&&macroDown.has(Number(match[1])-1)){e.preventDefault();macroAction(Number(match[1])-1,false)}});
 document.querySelectorAll('[data-close-dialog]').forEach(b=>b.onclick=()=>b.closest('dialog').close());
 $('#cue-timing').onclick=()=>{
  const cue=bank.cues.find(c=>c.id===Number(library.value));if(!cue){status('Choose a recorded cue before editing its timing.');return}
  const timing=cue.timing??{delay:0,fadeIn:0,hold:0,fadeOut:0};
  $('#cue-timing-dialog').dataset.cue=cue.id;$('#cue-timing-title').textContent=`Timing · ${cue.name}`;
  for(const [key,id] of [['delay','cue-delay'],['fadeIn','cue-fade-in'],['hold','cue-hold'],['fadeOut','cue-fade-out']])$(`#${id}`).value=timing[key];
  $('#cue-timing-error').textContent='';
  $('#cue-look-timing').hidden=!cue.sequenceOrder;
  $('#cue-look-rows').innerHTML=(cue.sequenceOrder??[]).map((id,i)=>{
   const t=bank.lookTiming(cue,i);
   return `<div class="look-timing-row" data-look="${i}"><strong>${i+1} · ${String(id).padStart(3,'0')}</strong><label>Duration (s)<input class="look-duration" aria-label="Duration for look ${i+1}" type="number" min=".01" max="10" step=".01" required value="${t.duration.toFixed(2)}"></label><label>Gap (s)<input class="look-gap" aria-label="Gap after look ${i+1}" type="number" min="0" max="60" step=".01" required value="${t.gap.toFixed(2)}"></label><button type="button" data-reset-look="${i}">Reset</button></div>`;
  }).join('');
  $('#cue-look-rows').querySelectorAll('[data-reset-look]').forEach(b=>b.onclick=()=>{
   const i=+b.dataset.resetLook,row=b.closest('.look-timing-row');row.querySelector('.look-duration').value=presets[cue.sequenceOrder[i]-1].duration.toFixed(2);row.querySelector('.look-gap').value='1.10';
  });
  $('#cue-timing-dialog').showModal();
 };
 $('#cue-timing-form').onsubmit=e=>{
  e.preventDefault();const cue=bank.cues.find(c=>c.id===Number($('#cue-timing-dialog').dataset.cue));if(!cue)return;
  const timing={delay:Number($('#cue-delay').value),fadeIn:Number($('#cue-fade-in').value),hold:Number($('#cue-hold').value),fadeOut:Number($('#cue-fade-out').value)};
  const sequenceTiming=cue.sequenceOrder?[...$('#cue-look-rows').children].map(row=>({duration:Number(row.querySelector('.look-duration').value),gap:Number(row.querySelector('.look-gap').value)})):undefined;
  const data=bank.serialize(),copy=data.cues.find(c=>c.id===cue.id);copy.timing=timing;if(sequenceTiming)copy.sequenceTiming=sequenceTiming;
  try{PlaybackBank.validate(data)}catch{$('#cue-timing-error').textContent='Use duration 0.01–10 s, gap 0–60 s and valid cue timing.';return}
  cue.timing=timing;if(sequenceTiming)cue.sequenceTiming=sequenceTiming;
  bank.slots.forEach((s,i)=>{if(s.cueId===cue.id)bank.resetSlot(i)});
  paint();$('#cue-timing-dialog').close();status('Cue timing saved. Assigned faders released; raise again to restart.');
 };
 function applyMapping(target,value){
  const [kind,index]=target.split(':'),i=Number(index);
  if(kind==='master'){bank.grandMaster=value;consoleFollow.masterTouched=performance.now()}
  else if(kind==='fader'){noteConsoleTouch(i);if(!bank.playable(i))return;activate();bank.setLevel(i,value)}
  else if(kind==='macro'){consoleButton('macro',i,value>0);macroAction(i,value>0,`mapped-macro-${i}`)}
  else if(kind==='top'||kind==='bottom'){
   consoleButton(kind,i,value>0);noteConsoleTouch(i);
   if(value>0&&bank.playable(i)){activate();bank.hold(i,`mapped-${kind}`)}
   else bank.unhold(i,`mapped-${kind}`);
  }
  paint();
 }
 function disconnectMapping(message='Console mapping disconnected.'){
  mapController?.abort();mapController=null;mapStream?.close();mapStream=null;mapper.enabled=false;mapper.reset();clearConsoleFollow();release();
  $('#mapping-status').textContent=message;
 }
 function showMapping(){
  $('#mapping-universe').value=mapper.config.universe;
  $('#mapping-fields').innerHTML=mapTargets.map((t,i)=>`<div class="mapping-row"><label for="map-channel-${i}">${t.name}</label><input id="map-channel-${i}" type="number" min="0" max="512" value="${mapper.config.bindings[i].address}" aria-label="${t.name} channel" required><label><input id="map-invert-${i}" type="checkbox" ${mapper.config.bindings[i].invert?'checked':''}> Invert</label></div>`).join('');
  $('#mapping-error').textContent='';$('#mapping-dialog').showModal();
 }
 function faderUniverse(i){return bindingUniverse(bank.controlMapping,bank.controlMapping.bindings[i])}
 function commitFaderPatch(i,address,universe){
  const config=structuredClone(bank.controlMapping);
  config.bindings[i].address=address;
  if(universe===undefined||universe===config.universe)delete config.bindings[i].universe;else config.bindings[i].universe=universe;
  validateMapping(config);
  const connected=!!(mapper.enabled||mapStream||mapController);
  if(connected){disconnectMapping();mapper.configure(config)}
  else mapper.config=validateMapping(config);
  bank.controlMapping=mapper.config;bank.clearVirtual();
  if(bank.slots[i].dmxPriority)bank.resetSlot(i);
  return connected;
 }
 function setFaderChannel(i,input){
  const text=input.value.trim();
  const match=/^(\d+)$/.exec(text);
  const address=text===''?0:match?Number(match[1]):NaN;
  try{
   const connected=commitFaderPatch(i,address,bank.controlMapping.bindings[i].universe);
   input.setAttribute('aria-invalid','false');input.value=String(address);
   status(`Fader ${i+1}: ${address?`Universe ${faderUniverse(i)} · DMX channel ${address}`:'unassigned'}.${connected?' Mapping disconnected; reconnect and lower controls before use.':' Check DMX to drive this channel locally instead of its cue. No physical output.'}`);
  }catch{
   input.setAttribute('aria-invalid','true');input.value=String(bank.controlMapping.bindings[i].address);
   status(`Fader ${i+1}: use a channel 1–512 not already used in universe ${faderUniverse(i)}, or leave blank for unassigned. Mapping unchanged.`);
  }
 }
 $('#virtual-universe').onchange=e=>{
  const value=Number(e.target.value);
  if(!Number.isInteger(value)||value<1||value>32768){e.target.value=bank.controlMapping.universe;status('Virtual universe must be 1–32768.');return}
  if(mapper.enabled||mapStream||mapController)disconnectMapping();
  const next={...structuredClone(bank.controlMapping),universe:value};
  try{validateMapping(next)}catch{e.target.value=bank.controlMapping.universe;status(`Universe ${value} would duplicate a fader’s own universe/address patch. Change that fader in Settings first.`);return}
  bank.releaseAll();bank.controlMapping.universe=value;mapper.config=validateMapping(bank.controlMapping);bank.controlMapping=mapper.config;
  status(`Virtual universe ${value}. All levels released. Fixture patch universe must match (internal port-address ${value-1}).`);
 };
 $('#open-mapping').onclick=showMapping;
 $('#mapping-sequential').onclick=()=>{mapTargets.forEach((t,i)=>$(`#map-channel-${i}`).value=i+1)};
 $('#mapping-form').onsubmit=e=>{
  e.preventDefault();
  try{
   const config={universe:Number($('#mapping-universe').value),bindings:mapTargets.map((t,i)=>({target:t.id,address:Number($(`#map-channel-${i}`).value),invert:$(`#map-invert-${i}`).checked,...(bank.controlMapping.bindings[i].universe!==undefined?{universe:bank.controlMapping.bindings[i].universe}:{})}))};
   validateMapping(config);disconnectMapping();mapper.configure(config);bank.controlMapping=mapper.config;bank.clearVirtual();$('#virtual-universe').value=config.universe;paint();$('#mapping-error').textContent='Saved. Reconnect and lower mapped controls to zero/low.';
  }catch{$('#mapping-error').textContent='Use universe 1–32768 and unique channels 1–512, or 0 for unmapped.'}
 };
 $('#mapping-disconnect').onclick=()=>disconnectMapping();
 $('#mapping-connect').onclick=async()=>{
  if(location.protocol!=='http:'||!['127.0.0.1','localhost'].includes(location.hostname)){$('#mapping-error').textContent='Open the Windows receiver’s localhost page for incoming console data.';return}
  disconnectMapping();mapController=new AbortController();const controller=mapController;
  $('#mapping-connect').disabled=true;
  try{
   const result=await fetch('/api/info',{signal:controller.signal});const info=await result.json();
   if(controller!==mapController)return;
   if(info.app!=='wave-studio-receiver'||info.protocol!=='sACN')throw Error('Launch the receiver in sACN mode.');
   if(!info.universes.includes(mapper.config.universe))throw Error('This universe is not subscribed by the receiver. Relaunch with that universe enabled.');
   if(!mapper.config.bindings.some(b=>b.address))throw Error('Save at least one mapped channel first.');
   onLeaveLive();blocked=false;wasLive=false;$('#bank-controls').disabled=false;
   bank.releaseAll();bank.grandMaster=0;bank.enabled=true;onModeChange(true);mapper.enabled=true;
   const stream=new EventSource('/api/events');mapStream=stream;
   stream.onmessage=e=>{
    if(stream!==mapStream||document.hidden)return;
    try{const packet=JSON.parse(e.data);
     if(packet.kind==='dmx')mapper.ingest(packet,performance.now()/1000);
     if(packet.kind==='universe_reset'&&packet.universe===mapper.config.universe-1)mapper.reset();
    }catch{disconnectMapping('Invalid control data; playbacks released.')}
   };
   stream.onerror=()=>{if(stream===mapStream){mapper.reset();release();$('#mapping-status').textContent='Control signal disconnected. Outputs released; lower controls before recovery.'}};
   $('#mapping-error').textContent='Connected. Lower all mapped controls, then raise the master and playback faders.';paint();
  }catch(e){if(e.name!=='AbortError')$('#mapping-error').textContent=e.message}
  finally{$('#mapping-connect').disabled=false}
 };
 root.insertAdjacentHTML('beforeend',`<datalist id="dmx-channel-options">${Array.from({length:513},(_,i)=>`<option value="${i}">${i}</option>`).join('')}</datalist>`);
 root.querySelector('#fader-grid').innerHTML=bank.slots.map((s,i)=>`
  <section class="fader-strip" data-fader="${i}" aria-label="Fader ${i+1}">
   <div class="fader-number">${String(i+1).padStart(2,'0')}</div>
   <textarea class="fader-dmx-label strip-name" data-label="dmxLabel" maxlength="32" rows="2" aria-label="DMX label for fader ${i+1}">DMX channel</textarea><div class="fader-dmx-row"><input class="fader-dmx" id="fader-dmx-${i}" type="text" inputmode="numeric" list="dmx-channel-options" autocomplete="off" placeholder="0" aria-label="DMX channel for fader ${i+1}" title="0 = unassigned; channels 1–512. Wheel down: next unused number. Wheel up: previous unused number." value="${bank.controlMapping.bindings[i].address}"><span class="fader-universe" aria-hidden="true">U1</span><input id="dmx-priority-${i}" class="dmx-priority" type="checkbox" aria-label="DMX priority for fader ${i+1}" title="Checked: drive virtual DMX channel. Unchecked: play selected cue. Switching resets this fader."></div>
   <textarea class="fader-label strip-name" data-label="cueLabel" maxlength="32" rows="2" aria-label="Cue label for fader ${i+1}">Cue</textarea><select id="fader-cue-${i}" class="cue-assignment" aria-label="Assign cue to fader ${i+1}"></select>
   <button class="flash-key flash-play" data-hold="top" aria-label="Hold play flash fader ${i+1}" aria-pressed="false" title="Momentary play flash: hold to output at the flash level"><span class="play-mark" aria-hidden="true"></span></button>
   <input class="fader-byte" id="fader-value-${i}" type="text" inputmode="numeric" autocomplete="off" value="0" aria-label="Fader ${i+1} value, 0 to 255" title="Type 0–255, then Enter or leave the box. 0 releases; 255 is full. Escape cancels."><span class="fader-percent" aria-hidden="true">0%</span>
   <div class="fader-track"><input id="fader-level-${i}" type="range" min="0" max="100" step="0.1" value="0" aria-label="Fader ${i+1} level" aria-orientation="vertical"></div>
   <button class="flash-key flash-sun" data-hold="bottom" aria-label="Hold intensity flash fader ${i+1}" aria-pressed="false" title="Momentary intensity flash: hold to output at the flash level"><span aria-hidden="true">☼</span></button>
   <button class="fader-settings" aria-label="Settings for fader ${i+1}">Settings</button>
   <button class="fader-capture" aria-label="Assign selected virtual units to fader ${i+1}" title="Record the selected virtual units as a new cue on this fader">Use selected</button>
  </section>`).join('');
 bank.slots.forEach((slot,i)=>{
  const row=$(`.fader-strip[data-fader="${i}"]`),range=row.querySelector('input[type=range]');
  bindByteInput(row.querySelector('.fader-byte'),()=>bank.level(i),value=>{
   if(!bank.playable(i)){status(`Assign a cue or checked DMX channel to fader ${i+1} first.`);return}
   range.value=String(value*100/255);range.dispatchEvent(new Event('input',{bubbles:true}));
   status(`Fader ${i+1} set to ${value} / 255 (${Number(bank.runtime[i].level.toFixed(1))}%).${bank.runtime[i].held.size?' Held flash remains active until released.':''}`);
  });
  row.querySelectorAll('.strip-name').forEach(input=>{
   input.onchange=()=>{const s=bank.slots[i],key=input.dataset.label;s[key]=input.value.replace(/\s+/g,' ').trim().slice(0,32)||s[key==='cueLabel'?'defaultCueLabel':'defaultDmxLabel'];s[key==='cueLabel'?'defaultCueLabel':'defaultDmxLabel']=s[key];paint();status(`Fader ${i+1} label and default label saved. Assignments unchanged; Save layout keeps your labels.`)};
   input.onkeydown=e=>{
    if(e.key==='Enter'){e.preventDefault();input.blur()}
    if(e.key==='Escape'){e.preventDefault();input.value=bank.slots[i][input.dataset.label];input.blur()}
   };
  });
  const channel=row.querySelector('.fader-dmx');
  channel.onchange=()=>setFaderChannel(i,channel);
  channel.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();channel.blur()}};
  channel.addEventListener('wheel',e=>{
   if(blocked||state.live||channel.disabled||e.ctrlKey||!e.deltaY)return;
   e.preventDefault();
   // Follow list order, skipping channels already assigned to another control.
   const direction=e.deltaY>0?1:-1,used=new Set(bank.controlMapping.bindings.filter((b,j)=>j!==i&&bindingUniverse(bank.controlMapping,b)===faderUniverse(i)).map(b=>b.address));
   let value=bank.controlMapping.bindings[i].address+direction;
   while(value>0&&value<513&&used.has(value))value+=direction;
   if(value<0||value>512)return;
   channel.value=String(value);setFaderChannel(i,channel);
  },{passive:false});
  row.querySelector('.dmx-priority').onchange=e=>{
   if(e.target.checked&&!bank.controlMapping.bindings[i].address){e.target.checked=false;status(`Assign DMX channel 1–512 to fader ${i+1} first.`);return}
   bank.setPriority(i,e.target.checked);paint();
   status(`Fader ${i+1}: ${e.target.checked?'virtual DMX channel takes priority; cue is bypassed':'cue/chase takes priority; virtual channel released'}. Level reset to zero.`);
  };
  range.addEventListener('input',()=>{
   if(blocked)return;
   const requested=Number(range.value);
   if(!bank.playable(i)){range.value=0;status(`Assign a cue/chase, or a checked DMX channel, to fader ${i+1} first.`);return}
   if(requested>0&&!activate())return;
   bank.setLevel(i,requested);paint();
   if(!bank.slots[i].dmxPriority&&bank.slots[i].cueId!==null)library.value=String(bank.slots[i].cueId);
   status(`Fader ${i+1}: ${range.value}%${bank.slots[i].dmxPriority?` → virtual CH ${bank.controlMapping.bindings[i].address} = ${Math.round(requested*255/100)}`:''}. Lower to zero to release.`);
  });
  range.addEventListener('wheel',e=>{
   if(blocked||state.live||range.disabled||e.ctrlKey||!e.deltaY)return;
   const step=Math.max(.1,bank.slots[i].wheelStep*(e.shiftKey?.1:1));
   e.preventDefault();range.value=String(Math.round(Math.max(0,Math.min(100,Number(range.value)+(e.deltaY<0?1:-1)*step))*10)/10);
   range.dispatchEvent(new Event('input',{bubbles:true}));
  },{passive:false});
  const assignment=row.querySelector('select');
  assignment?.addEventListener('change',()=>{bank.assign(i,assignment.value==='chase'?'chase':assignment.value?Number(assignment.value):null);renderCues();status(`Fader ${i+1} assigned; its level has been reset to zero.`)});
  row.querySelector('.fader-capture')?.addEventListener('click',()=>{
   try{
    const cue=bank.record($('#cue-name').value||`Fader ${i+1} virtual units`,state.fixtures,state.selectedIds);
    bank.assign(i,cue.id);renderCues();library.value=cue.id;
    status(`Assigned ${cue.looks.length} selected virtual unit(s) to fader ${i+1} at zero. ${bank.slots[i].dmxPriority?'Uncheck DMX or set its default mode to Cue before playing this cue.':'Raise this fader to play; keep MASTER above zero.'} Previous cues remain in the library.`);
   }catch(e){status(e.message)}
  });
  row.querySelectorAll('.flash-key').forEach(button=>{
   const key=button.dataset.hold;
   let activePointer=null;
   function press(){
    if(blocked)return false;
    if(!bank.playable(i)){status(`Assign a cue/chase or a checked DMX channel to fader ${i+1} first.`);return false}
    if(!activate())return false;
    bank.hold(i,key);paint();status(`Fader ${i+1} held at ${bank.slots[i].flashLevel}% visual intensity. Release to disengage.`);return true;
   }
   function up(){activePointer=null;bank.unhold(i,key);paint()}
   button.addEventListener('pointerdown',e=>{
    if(e.button!==0)return;
    e.preventDefault();button.focus({preventScroll:true});
    if(press()){activePointer=e.pointerId;button.setPointerCapture(e.pointerId)}
   });
   button.addEventListener('pointerup',up);button.addEventListener('pointercancel',up);button.addEventListener('lostpointercapture',up);
   button.addEventListener('keydown',e=>{if([' ','Enter'].includes(e.key)){e.preventDefault();e.stopPropagation();if(!e.repeat)press()}});
   button.addEventListener('keyup',e=>{if([' ','Enter'].includes(e.key)){e.preventDefault();e.stopPropagation();up()}});
   button.addEventListener('blur',()=>{if(activePointer===null)up()});
   button.addEventListener('contextmenu',e=>e.preventDefault());
  });
  row.querySelector('.fader-settings').onclick=()=>openSettings(i);
 });
 function openSettings(i){
  release();
  dialog.dataset.fader=i;
  $('#playback-editor-title').textContent=`Fader ${i+1} · ${bank.slots[i].dmxPriority?'Virtual DMX':bank.slots[i].kind==='chase'?'Chase':'Cue playback'}`;
  $('#flash-level').value=bank.slots[i].flashLevel;
  $('#fader-wheel-step').value=bank.slots[i].wheelStep;
  $('#fader-default-dmx-label').value=bank.slots[i].defaultDmxLabel;
  $('#fader-default-cue-label').value=bank.slots[i].defaultCueLabel;
  $('#fader-default-mode').value=bank.slots[i].defaultMode;
  $('#fader-patch-address').value=bank.controlMapping.bindings[i].address;
  $('#fader-patch-universe').value=faderUniverse(i);
  $('#fader-patch-follow').checked=bank.controlMapping.bindings[i].universe===undefined;
  syncPatchFollow();
  $('#fader-loop').checked=bank.slots[i].loop;
  updateSettingsMode();
  $('#chase-bpm').value=bank.chase.bpm;
  $('#chase-direction').value=bank.chase.direction;
  $('#chase-width').value=bank.chase.width;
  $('#chase-duty').value=bank.chase.duty;
  $('#chase-loop').checked=bank.chase.loop;
  $('#chase-preset').value=bank.chase.presetId;
  $('#chase-all').checked=bank.chase.all;
  $('#chase-order').value=bank.chase.targets.join(', ');
  $('#playback-edit-error').textContent='';
  dialog.showModal();
 }
 function updateSettingsMode(){
  const i=Number(dialog.dataset.fader),isDmx=$('#fader-default-mode').value==='dmx',isChase=bank.slots[i].kind==='chase'&&!isDmx;
  $('#fader-loop-label').hidden=isDmx||isChase;
  $('#fader-loop').disabled=isDmx||isChase;
  $('#chase-settings').hidden=!isChase;
  $('#chase-settings').querySelectorAll('input,select,button').forEach(el=>el.disabled=!isChase);
 }
 function syncPatchFollow(){
  const follow=$('#fader-patch-follow').checked;$('#fader-patch-universe').disabled=follow;
  if(follow)$('#fader-patch-universe').value=bank.controlMapping.universe;
  $('#fader-patch-bank').textContent=bank.controlMapping.universe;
 }
 $('#fader-patch-follow').onchange=syncPatchFollow;
 $('#fader-default-mode').onchange=updateSettingsMode;
 fillOptions($('#chase-preset'),presets.map(p=>[p.id,`${String(p.id).padStart(3,'0')} · ${p.name}`]),8);
 $('#chase-use-selection').onclick=()=>{$('#chase-order').value=state.selectedIds.join(', ');$('#chase-all').checked=false};
 $('#playback-editor-close').onclick=()=>dialog.close();
 $('#playback-settings-form').onsubmit=e=>{
  e.preventDefault();const i=Number(dialog.dataset.fader);
  const n=Number($('#flash-level').value);
  const wheelStep=Number($('#fader-wheel-step').value);
  const defaultDmxLabel=$('#fader-default-dmx-label').value.trim(),defaultCueLabel=$('#fader-default-cue-label').value.trim(),defaultMode=$('#fader-default-mode').value;
  if(!defaultDmxLabel||!defaultCueLabel){$('#playback-edit-error').textContent='Both default labels need a name.';return}
  const patchAddress=Number($('#fader-patch-address').value),patchUniverse=$('#fader-patch-follow').checked?undefined:Number($('#fader-patch-universe').value);
  if(!Number.isInteger(patchAddress)||patchAddress<0||patchAddress>512){$('#playback-edit-error').textContent='DMX address must be a whole number 0–512 (0 = unassigned).';return}
  if(patchUniverse!==undefined&&(!Number.isInteger(patchUniverse)||patchUniverse<1||patchUniverse>32768)){$('#playback-edit-error').textContent='Universe must be a whole number 1–32768.';return}
  {const u=patchUniverse??bank.controlMapping.universe,clash=patchAddress?bank.controlMapping.bindings.findIndex((b,j)=>j!==i&&b.address===patchAddress&&bindingUniverse(bank.controlMapping,b)===u):-1;
   if(clash>=0){$('#playback-edit-error').textContent=`Universe ${u} · address ${patchAddress} is already used by ${mapTargets[clash].name}.`;return}}
  if(defaultMode==='dmx'&&!patchAddress){$('#playback-edit-error').textContent='Assign this fader a DMX address before setting DMX as its default.';return}
  if(!Number.isFinite(wheelStep)||wheelStep<.1||wheelStep>100){$('#playback-edit-error').textContent='Wheel step must be 0.1–100%.';return}
  if(!Number.isFinite(n)||n<0||n>100){$('#playback-edit-error').textContent='Flash level must be 0–100%.';return}
  const chase={...bank.chase};
  if(bank.slots[i].kind==='chase'&&defaultMode==='cue'){
   Object.assign(chase,{bpm:Number($('#chase-bpm').value),presetId:Number($('#chase-preset').value),direction:$('#chase-direction').value,width:Number($('#chase-width').value),duty:Number($('#chase-duty').value),loop:$('#chase-loop').checked,all:$('#chase-all').checked});
   chase.targets=$('#chase-order').value.trim()?$('#chase-order').value.split(',').map(s=>Number(s.trim())):[];
   if(!chase.all&&(!chase.targets.length||chase.targets.some(id=>!state.fixtures.some(f=>f.id===id)))){$('#playback-edit-error').textContent='Enter existing fixture IDs, comma separated, or choose all units.';return}
  }
  try{
   const test=bank.serialize();test.chase=chase;test.slots[i].flashLevel=n;test.slots[i].loop=$('#fader-loop').checked;test.slots[i].wheelStep=wheelStep;
   Object.assign(test.slots[i],{defaultDmxLabel,defaultCueLabel,defaultMode,dmxLabel:defaultDmxLabel,cueLabel:defaultCueLabel,dmxPriority:defaultMode==='dmx'});
   PlaybackBank.validate(test);
   const reconnect=commitFaderPatch(i,patchAddress,patchUniverse);
   bank.chase=chase;Object.assign(bank.slots[i],test.slots[i]);bank.setPriority(i,defaultMode==='dmx');
   paint();dialog.close();status(`Fader ${i+1} settings saved · ${patchAddress?`Universe ${faderUniverse(i)} · DMX ${patchAddress}`:'DMX unassigned'}.${reconnect?' Mapping disconnected; reconnect and lower controls before use.':''} Raise its fader again to start from the beginning.`);
  }catch{ $('#playback-edit-error').textContent='Check BPM (20–300), width (1–40), gate (5–100%) and unique fixture IDs.'}
 };
 $('#record-cue').onclick=()=>{
  try{
   const c=bank.record($('#cue-name').value,state.fixtures,state.selectedIds);
   $('#cue-name').value='';renderCues();library.value=c.id;
   const free=bank.slots.findIndex(s=>!s.dmxPriority&&s.kind==='cue'&&s.cueId===null);
   if(free>=0){bank.assign(free,c.id);renderCues();library.value=c.id}
   status(`Recorded “${c.name}” from ${c.looks.length} unit(s). ${free>=0?`Assigned to fader ${free+1}; raise it or hold a flash button.`:'Assign it to a cue fader.'}`);
  }catch(e){status(e.message)}
 };
 $('#update-cue').onclick=()=>{
  try{bank.updateCue(Number(library.value),$('#cue-name').value,state.fixtures,state.selectedIds);const c=bank.cues.find(c=>c.id===Number(library.value));renderCues();status(c?.sequenceOrder?'Chase cue name/targets updated; saved look order preserved. Assigned faders reset to zero.':'Cue updated from selected units. Assigned faders reset to zero.')}catch(e){status(e.message)}
 };
 $('#delete-cue').onclick=()=>{if(!library.value){status('Choose a recorded cue first.');return}bank.deleteCue(Number(library.value));renderCues();status('Cue deleted and its faders released.')};
 library.onchange=()=>{const c=bank.cues.find(c=>c.id===Number(library.value));$('#cue-name').value=c?.name??''};
 $('#bank-enable').onchange=e=>{
  const enabled=e.target.checked&&!blocked;
  if(!enabled&&(mapper.enabled||mapStream||mapController))disconnectMapping();
  bank.releaseAll();bank.enabled=enabled;onModeChange(bank.enabled);paint();
  status(bank.enabled?'Bank playback: raise a fader or hold a flash button. Unassigned fixtures stay dark.':'Presets restored. Playback levels and flashes released.');
 };
 $('#bank-release').onclick=()=>{bank.releaseAll();paint();status('All twenty faders released to zero, including virtual DMX channels.')};
 window.addEventListener('blur',()=>{if(mapper.enabled)mapper.reset();release('Flash buttons released because the window lost focus.')});
 document.addEventListener('visibilitychange',()=>{if(document.hidden){if(mapper.enabled)mapper.reset();bank.releaseAll();paint();status('All playbacks released because the tab was hidden.')}});
 document.addEventListener('keydown',e=>{if(e.key==='Escape')release()});
 renderCues();
 return {
  bank,
  releaseTargeting(ids){const n=bank.releaseTargeting(ids,state.fixtures);if(n){paint();status(`${n} running fader(s) released by Home.`)}return n},
  releaseSlot(i){bank.resetSlot(i);paint();status(`Fader ${i+1} removed from the mobile view and released. Its assignments are retained.`)},
  recordSequence(name,order,timing){
   if(state.live)throw Error('Leave Live Input before saving a local chase cue.');
   const c=bank.recordSequence(name,state.fixtures,state.selectedIds,order,timing);
   const free=bank.slots.findIndex(s=>!s.dmxPriority&&s.kind==='cue'&&s.cueId===null);
   if(free>=0)bank.assign(free,c.id);
   renderCues();library.value=c.id;
   const message=`Saved “${c.name}”: ${order.length} ordered look(s), ${c.looks.length} unit(s). ${free>=0?`Assigned to fader ${free+1} at zero.`:'Choose it from any fader cue dropdown.'} Save layout to keep this cue.`;
   status(message);return message;
  },
  transport,transportState,playCueById,onCuesChanged(fn){cueListeners.add(fn);return ()=>cueListeners.delete(fn)},isBlocked:()=>blocked||state.live,openTiming(id){library.value=String(id);$('#cue-name').value=bank.cues.find(c=>c.id===id)?.name??'';$('#cue-timing').click()},
  disconnect(){if(mapper.enabled||mapStream||mapController)disconnectMapping()},
  // Live Input: mirror the Vista console on the virtual faders and flash keys. Visual only; Vista owns the output.
  followLive(packet){
   if(!state.live||!Array.isArray(packet?.values))return;
   const now=performance.now();let changed=false;
   const source=packet.sourceId??packet.source??null;
   if(consoleFollow.source!==null&&source!==consoleFollow.source){consoleFollow.levels.fill(null);consoleFollow.master=null;consoleFollow.buttons.clear()}
   consoleFollow.source=source;
   for(const b of bank.controlMapping.bindings){
    if(!b.address||bindingUniverse(bank.controlMapping,b)-1!==packet.universe||b.address>packet.values.length)continue;
    const raw=packet.values[b.address-1];if(!Number.isInteger(raw)||raw<0||raw>255)continue;
    const value=b.invert?255-raw:raw,[kind,index]=b.target.split(':'),i=Number(index);
    if(kind==='fader'){const level=value/255*100;if(consoleFollow.levels[i]!==level){if(consoleFollow.levels[i]!==null)noteConsoleTouch(i);consoleFollow.levels[i]=level;changed=true}}
    else if(kind==='master'){const level=value/255*100;if(consoleFollow.master!==level){if(consoleFollow.master!==null)consoleFollow.masterTouched=now;consoleFollow.master=level;changed=true}}
    else{const active=value>=128;if(active!==consoleFollow.buttons.has(b.target)){consoleButton(kind,i,active);changed=true}}
   }
   if(!consoleFollow.announced&&consoleFollow.levels.some(l=>l!==null)){consoleFollow.announced=true;status('Following the Vista console: faders and flash keys mirror the incoming channels. Visual only; Vista owns the output.')}
   if(changed||now-consoleFollow.lastPaint>400){consoleFollow.lastPaint=now;paint()}
  },
  liveFollowReset(){clearConsoleFollow();paint()},
  tick(dt){
   bank.selectGroup(state.selectedIds,state.selectedId);
   if(state.live!==wasLive){
    if(state.live&&(mapper.enabled||mapStream||mapController))disconnectMapping();
    wasLive=state.live;blocked=state.live;bank.releaseAll();bank.enabled=false;clearConsoleFollow();
    $('#bank-controls').disabled=blocked;
    if(dialog.open)dialog.close();
    onModeChange(false);paint();status(blocked?'Live Vista input owns the visualizer. Local faders and flash buttons are disabled.':'Presets restored. Bank levels remain released.');
   }
   if(!blocked&&!document.hidden&&!paused){
    bank.tick(dt,state.speed);
    if(bank.enabled&&$('#tour').checked){const t=transportState();if(t.slot!==null&&bank.runtime[t.slot].level>0&&t.time>=t.total)navigateCue(1)}
   }
   if(!blocked&&!state.live)bank.updateVirtual(state.fixtures,document.hidden?0:dt);
   else bank.clearVirtual();
   if(bank.virtualIds.size&&performance.now()-(root._lastVirtualPaint??0)>100){root._lastVirtualPaint=performance.now();paint()}
   mapper.tick(performance.now()/1000);
   if(mapper.enabled)$('#mapping-status').textContent=`sACN control universe ${mapper.config.universe} · ${mapper.count} received frame(s) · ${mapper.last===-Infinity?'Waiting: lower controls before use':'Receiving'} · Local visualization only`;
   const selection=state.selectedIds.join(',');
   if(selection!==lastSelection){lastSelection=selection;$('#intensity-targets').textContent=`Record targets: ${selection?state.selectedIds.map(id=>`F${String(id).padStart(2,'0')}`).join(', '):'none selected'}`}
   if(bank.time-lastPaint>.1){lastPaint=bank.time;paint()}
  },
  serialize:()=>bank.serialize(),
  restore(data,applyDefaults=false){disconnectMapping();paused=false;bank.restore(data,applyDefaults);mapper.configure(bank.controlMapping);bank.grandMaster=100;$('#virtual-universe').value=bank.controlMapping.universe;renderCues();onModeChange(false);status('Playback assignments loaded. All outputs released; Presets selected.')}
 };
}
