// Cue Stack (Beta 0.30): an ordered cuelist that steps through recorded cues with Go, Follow and Timecode triggers.
// Inspired by Vista 3 cuelists and Depence timelines: one big GO, a readable table, inline editing, a progress bar on
// the running row. Local visual playback only; nothing here transmits DMX.
import {parseTimecode} from './timecode.js?v=v031-preview-20261004';
import {stackCsv} from './vista-export.js?v=v031-preview-20261004';
import {requestFileSave} from './file-save.js?v=v031-preview-20261004';

const TRIGGERS=[['go','Go'],['follow','Follow'],['timecode','Timecode']];
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt=n=>Number.isFinite(n)?(Math.round(n*100)/100).toString():'0';
const safeFile=s=>s.replace(/[^\w.-]+/g,'-').replace(/^-+|-+$/g,'').slice(0,40)||'stack';

export function mountCueStack({root,bank,playback,state,timecode,getFixtures=()=>state.fixtures,announce=()=>{}}){
 if(!root)return null;
 root.classList.add('cue-stack');
 root.innerHTML=`
<div class="stack-toolbar">
 <label class="stack-pick">Stack<select data-stack-select aria-label="Cue stack"></select></label>
 <button type="button" data-stack-new title="Create another cue stack">+ New</button>
 <button type="button" data-stack-rename title="Rename this stack">Rename</button>
 <button type="button" data-stack-delete title="Delete this stack">Delete</button>
 <label class="stack-loop"><input type="checkbox" data-stack-loop> Loop stack</label>
 <button type="button" class="stack-export" data-stack-export title="Download this stack as a cue CSV for Vista 3 (File > Import Cues CSV)">Export CSV For Vista</button>
</div>
<div class="stack-transport">
 <button type="button" class="stack-go" data-stack-go title="Play the next entry (Space when the stack has focus)">GO</button>
 <div class="stack-transport-side">
  <button type="button" data-stack-back title="Step back one entry and play it">Back</button>
  <button type="button" data-stack-release title="Release the stack and reset to the top">Release</button>
  <button type="button" data-stack-top title="Point Next at the first entry without playing">Top</button>
 </div>
 <div class="stack-readout" aria-live="polite"><strong data-stack-current>Released</strong><span data-stack-next>Next: —</span><span data-stack-follow></span></div>
</div>
<div class="stack-table-wrap">
<table class="stack-table">
 <thead><tr><th scope="col">#</th><th scope="col">Cue</th><th scope="col">Trigger</th><th scope="col">Wait s</th><th scope="col">Fade</th><th scope="col">Dur</th><th scope="col">Notes</th><th scope="col"><span class="sr-only">Actions</span></th></tr></thead>
 <tbody data-stack-rows></tbody>
</table>
<p class="stack-empty" data-stack-empty hidden>No entries yet. Record cues in the Cue Recorder, then add them below. Go plays the next entry; Follow entries start on their own after the previous cue finishes plus the wait; Timecode entries fire when the Timecode panel passes their time.</p>
</div>
<div class="stack-add">
 <label>Add recorded cue<select data-stack-cue aria-label="Recorded cue to add"></select></label>
 <button type="button" data-stack-add>Add To Stack</button>
 <button type="button" data-stack-add-all title="Append every recorded cue in library order">Add All</button>
 <span class="stack-count" data-stack-count></span>
</div>`;
 const $=s=>root.querySelector(s);
 const rows=$('[data-stack-rows]'),select=$('[data-stack-select]'),cuePick=$('[data-stack-cue]');
 let stackId=bank.stacks[0]?.id??1,current=-1,next=0,followAt=null,lastTcFrames=null,lastRender='',goAt=null;
 const stack=()=>bank.stack(stackId)??(stackId=bank.stacks[0]?.id,bank.stacks[0]);
 const cueOf=e=>bank.cues.find(c=>c.id===e.cueId);
 const cueTotal=cue=>{const t=cue.timing;return Math.round((t.delay+t.fadeIn+(t.hold||bank.cueDuration(cue))+t.fadeOut)*100)/100};
 root.tabIndex=0;root.setAttribute('aria-label','Cue Stack');

 function go(index=next){
  const st=stack(),e=st.entries[index];
  if(!e){announce('Cue stack: nothing left to play. Release or enable Loop stack.');return false}
  if(playback.isBlocked()){announce('Leave Live Input to run cue stacks.');return false}
  const slot=playback.playCueById(e.cueId);
  if(slot===null){announce('Cue stack: the cue could not be started.');return false}
  current=index;followAt=null;goAt=bank.time;
  next=index+1;if(next>=st.entries.length)next=st.loop?0:st.entries.length;
  arm();render(true);return true;
 }
 // Prepare the follow timer for the upcoming entry: it starts after the running cue completes plus its wait.
 function arm(){
  const st=stack(),e=st.entries[next];followAt=null;
  if(!e||e.trigger!=='follow'||current<0)return;
  const running=cueOf(st.entries[current]);if(!running)return;
  followAt={after:cueTotal(running)+e.wait};
 }
 function release(){bank.releaseAll();current=-1;next=0;followAt=null;goAt=null;render(true);announce('Cue stack released. Next: entry 1.')}
 function back(){const st=stack();const target=current>0?current-1:0;if(!st.entries.length)return;go(target)}

 function renderStacks(){
  const keep=select.value;select.replaceChildren(...bank.stacks.map(s=>new Option(`${s.name} (${s.entries.length})`,s.id)));
  select.value=String(bank.stacks.some(s=>String(s.id)===keep)?keep:stackId);stackId=Number(select.value);
  $('[data-stack-loop]').checked=!!stack().loop;$('[data-stack-delete]').disabled=bank.stacks.length<=1;
  const pick=cuePick.value;cuePick.replaceChildren(new Option(bank.cues.length?'Choose a recorded cue':'No recorded cues yet',''),...bank.cues.map(c=>new Option(c.name+(c.sequenceOrder?` · ${c.sequenceOrder.length} looks`:''),c.id)));
  cuePick.value=bank.cues.some(c=>String(c.id)===pick)?pick:'';$('[data-stack-add]').disabled=!bank.cues.length;$('[data-stack-add-all]').disabled=!bank.cues.length;
 }
 function render(force=false){
  const st=stack();if(!st)return;
  if(current>=st.entries.length)current=-1;if(next>st.entries.length)next=st.entries.length;
  // Stack time runs from the GO press, so a looping fader does not restart the progress bar or the follow timer.
  const cur0=st.entries[current],curCue=cur0?cueOf(cur0):null;
  const t=curCue&&goAt!==null?{total:cueTotal(curCue),time:Math.min(cueTotal(curCue),Math.max(0,bank.time-goAt))}:null;
  const progress=t&&t.total?Math.min(1,t.time/t.total):0;
  const signature=JSON.stringify([stackId,st.entries,current,next,bank.cues.map(c=>[c.id,c.name,c.timing]),Math.round(progress*200)]);
  if(!force&&signature===lastRender)return;lastRender=signature;
  const focus=document.activeElement,focusKey=focus&&rows.contains(focus)?`${focus.closest('tr')?.dataset.index}:${focus.dataset.field}`:null,sel=focus?.selectionStart;
  rows.innerHTML=st.entries.map((e,i)=>{
   const cue=cueOf(e);if(!cue)return '';
   const isCurrent=i===current,isNext=i===next;
   return `<tr data-index="${i}" class="${isCurrent?'is-current':''} ${isNext?'is-next':''}" ${isCurrent?`style="--progress:${(progress*100).toFixed(1)}%"`:''}>
<td class="stack-num"><span class="stack-marker" aria-hidden="true">${isCurrent?'▶':isNext?'›':''}</span>${i+1}</td>
<td class="stack-name"><button type="button" class="stack-cue-name" data-field="goto" title="Double-click to play this entry now; click to make it Next">${esc(cue.name)}</button>${cue.sequenceOrder?`<small>${cue.sequenceOrder.length} looks</small>`:`<small>${cue.looks.length} unit(s)</small>`}</td>
<td><select data-field="trigger" aria-label="Trigger for entry ${i+1}">${TRIGGERS.map(([v,l])=>`<option value="${v}" ${e.trigger===v?'selected':''}>${l}</option>`).join('')}</select>${e.trigger==='timecode'?`<input data-field="timecode" class="stack-tc" aria-label="Timecode for entry ${i+1}" placeholder="00:00:00:00" maxlength="11" value="${esc(e.timecode)}">`:''}</td>
<td><input data-field="wait" type="number" min="0" max="600" step="0.1" value="${fmt(e.wait)}" aria-label="Wait seconds for entry ${i+1}" ${e.trigger!=='follow'?'disabled title="Wait applies to Follow entries"':''}></td>
<td class="stack-fade"><button type="button" data-field="timing" title="Fade in / fade out · click to edit the cue timing">${fmt(cue.timing.fadeIn)} / ${fmt(cue.timing.fadeOut)}</button></td>
<td class="stack-dur">${fmt(cueTotal(cue))}</td>
<td><input data-field="notes" maxlength="200" value="${esc(e.notes)}" aria-label="Notes for entry ${i+1}" placeholder="Note"></td>
<td class="stack-actions"><button type="button" data-field="up" title="Move up" aria-label="Move entry ${i+1} up" ${i===0?'disabled':''}>▲</button><button type="button" data-field="down" title="Move down" aria-label="Move entry ${i+1} down" ${i===st.entries.length-1?'disabled':''}>▼</button><button type="button" data-field="remove" title="Remove from stack" aria-label="Remove entry ${i+1}">✕</button></td></tr>`}).join('');
  $('[data-stack-empty]').hidden=!!st.entries.length;
  $('[data-stack-count]').textContent=`${st.entries.length} / 200 entries`;
  const cur=st.entries[current],nxt=st.entries[next];
  $('[data-stack-current]').textContent=cur?`${current+1} · ${cueOf(cur)?.name??''}${t?` · ${fmt(t.time)} / ${fmt(t.total)} s`:''}`:'Released';
  $('[data-stack-next]').textContent=nxt?`Next: ${next+1} · ${cueOf(nxt)?.name??''}`:st.entries.length?'Next: end of stack':'Next: —';
  $('[data-stack-follow]').textContent=nxt?.trigger==='follow'&&cur?`Follow ${fmt(nxt.wait)} s after cue ends`:nxt?.trigger==='timecode'?`Timecode ${nxt.timecode||'not set'}`:'';
  $('[data-stack-go]').disabled=!nxt;
  if(focusKey){const [i,f]=focusKey.split(':');const el=rows.querySelector(`tr[data-index="${i}"] [data-field="${f}"]`);if(el&&el!==document.activeElement){el.focus({preventScroll:true});if(sel!=null&&el.setSelectionRange)try{el.setSelectionRange(sel,sel)}catch{}}}
  const label=select.options[select.selectedIndex];if(label)label.textContent=`${st.name} (${st.entries.length})`;
 }
 function update(index,change,message){
  try{bank.updateStackEntry(stackId,index,change);lastRender='';render(true);if(message)announce(message)}catch(e){announce(e.message);render(true)}
 }
 rows.addEventListener('change',e=>{
  const el=e.target,tr=el.closest('tr');if(!tr)return;const i=+tr.dataset.index,f=el.dataset.field;
  if(f==='trigger')update(i,{trigger:el.value},null);
  if(f==='wait')update(i,{wait:Math.max(0,Math.min(600,Number(el.value)||0))},null);
  if(f==='notes')update(i,{notes:el.value.replace(/[\r\n]+/g,' ').slice(0,200)},null);
  if(f==='timecode'){const v=el.value.trim();if(v){try{parseTimecode(v,timecode?.get().rate??1)}catch(err){announce(err.message+' Timecode uses HH:MM:SS:FF at the Timecode panel frame rate.');render(true);return}}update(i,{timecode:v},null)}
  if(next===i)arm();
 });
 rows.addEventListener('click',e=>{
  const el=e.target.closest('[data-field]'),tr=e.target.closest('tr');if(!el||!tr)return;const i=+tr.dataset.index,f=el.dataset.field,st=stack();
  if(f==='goto'){if(e.detail>=2)go(i);else{next=i;arm();render(true);announce(`Next: entry ${i+1}. Press GO to play it.`)}}
  if(f==='timing'){const cue=cueOf(st.entries[i]);if(cue)playback.openTiming(cue.id)}
  if(f==='up'&&i>0){bank.moveStackEntry(stackId,i,i-1);if(current===i)current--;else if(current===i-1)current++;if(next===i)next--;else if(next===i-1)next++;render(true)}
  if(f==='down'&&i<st.entries.length-1){bank.moveStackEntry(stackId,i,i+1);if(current===i)current++;else if(current===i+1)current--;if(next===i)next++;else if(next===i+1)next--;render(true)}
  if(f==='remove'){bank.removeStackEntry(stackId,i);if(current===i)current=-1;else if(current>i)current--;if(next>i)next--;if(next>st.entries.length)next=st.entries.length;arm();render(true)}
 });
 for(const type of ['pointerdown','keydown'])root.addEventListener(type,e=>e.stopPropagation());
 root.addEventListener('keydown',e=>{
  if(e.target.matches('input,select,textarea'))return;
  if(e.key===' '||e.key==='Enter'&&e.target===root){e.preventDefault();go()}
  if(e.key==='Backspace'&&e.target===root){e.preventDefault();back()}
 });
 $('[data-stack-go]').onclick=()=>go();
 $('[data-stack-back]').onclick=back;
 $('[data-stack-release]').onclick=release;
 $('[data-stack-top]').onclick=()=>{next=0;arm();render(true);announce('Next: entry 1.')};
 $('[data-stack-loop]').onchange=e=>{stack().loop=e.target.checked;if(next>=stack().entries.length&&stack().loop)next=0;render(true)};
 select.onchange=()=>{stackId=Number(select.value);current=-1;next=0;followAt=null;renderStacks();render(true)};
 $('[data-stack-new]').onclick=()=>{try{const name=prompt('Name the new cue stack','Stack '+(bank.stacks.length+1));if(name===null)return;const st=bank.addStack(name||undefined);stackId=st.id;current=-1;next=0;renderStacks();render(true);announce(`Created “${st.name}”. Save layout to keep it.`)}catch(e){announce(e.message)}};
 $('[data-stack-rename]').onclick=()=>{try{const name=prompt('Rename this cue stack',stack().name);if(name===null)return;bank.renameStack(stackId,name);renderStacks();render(true)}catch(e){announce(e.message)}};
 $('[data-stack-delete]').onclick=()=>{try{if(!confirm(`Delete “${stack().name}”? Recorded cues are kept.`))return;bank.deleteStack(stackId);stackId=bank.stacks[0].id;current=-1;next=0;renderStacks();render(true)}catch(e){announce(e.message)}};
 $('[data-stack-add]').onclick=()=>{try{const id=Number(cuePick.value);if(!id)throw Error('Choose a recorded cue first.');bank.addStackEntry(stackId,id);arm();renderStacks();render(true);announce(`Added to ${stack().name} as entry ${stack().entries.length}. Save layout to keep the stack.`)}catch(e){announce(e.message)}};
 $('[data-stack-add-all]').onclick=()=>{try{for(const c of bank.cues)bank.addStackEntry(stackId,c.id);arm();renderStacks();render(true);announce(`Added ${bank.cues.length} cue(s) to ${stack().name}.`)}catch(e){announce(e.message)}};
 $('[data-stack-export]').onclick=async()=>{
  const st=stack();
  if(!st.entries.length){announce('Add entries to the stack before exporting.');return}
  const csv=stackCsv(st,bank,getFixtures());
  const result=await requestFileSave(new Blob([csv],{type:'text/csv'}),`vista-cuelist-${safeFile(st.name)}.csv`).catch(e=>({message:e.message}));
  announce(result?.message||`Vista cue CSV ready for ${st.name}.`);
 };
 playback.onCuesChanged(()=>{renderStacks();lastRender='';render(true)});
 renderStacks();render(true);

 return {
  go,release,back,
  get state(){return {stackId,current,next}},
  tick(){
   const st=stack();if(!st)return;
   // Follow trigger: fire once the running cue has completed plus the entry's wait.
   if(followAt&&current>=0&&goAt!==null&&!playback.isBlocked()&&bank.time-goAt>=followAt.after)go(next);
   // Timecode trigger: fire when the Timecode panel passes the entry's frame while running.
   const nxt=st.entries[next];
   if(nxt?.trigger==='timecode'&&nxt.timecode&&timecode){
    const tc=timecode.get();
    if(tc.running&&!playback.isBlocked()){
     let target=null;try{target=parseTimecode(nxt.timecode,tc.rate)}catch{}
     // Fire on the frame crossing only; a jump of more than 10 seconds (locate / rewind) does not trigger.
     if(target!==null&&lastTcFrames!==null&&lastTcFrames<target&&tc.frames>=target&&tc.frames-lastTcFrames<300)go(next);
     lastTcFrames=tc.frames;
    }else lastTcFrames=tc.running?tc.frames:null;
   }else lastTcFrames=null;
   render();
  }
 };
}
