// Presentation-only floating windows. No fixture, playback or remote control access.
import {bindMobileUtilityDrag} from './mobile-panel-drag.js?v=v031-preview-20261004';
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
let windowZ=700;
export function raiseWindow(panel){if(panel.classList.contains('mobile-stage-control-panel')&&!panel.classList.contains('is-floating'))return;if(!panel.classList.contains('conversation-docked'))panel.style.zIndex=String(++windowZ)}
export function draggableWindow(panel,handle,{allowed=()=>true,onDrop=()=>{},onMove=()=>{},onCancel=()=>{}}={}){
 let drag=null;
 panel.addEventListener('pointerdown',()=>raiseWindow(panel),{capture:true});
 handle.addEventListener('pointerdown',e=>{
  if(e.pointerType==='touch'&&matchMedia('(max-width:700px)').matches)return;
  if(e.button!==0||e.target.closest('button,input,select,a')||!allowed(e))return;
  e.preventDefault();e.stopPropagation();
  const r=panel.getBoundingClientRect();
  drag={id:e.pointerId,x:e.clientX,y:e.clientY,left:r.left,top:r.top,width:r.width,height:r.height,style:panel.style.cssText};
  handle.setPointerCapture(e.pointerId);
 });
 handle.addEventListener('pointermove',e=>{
  if(!drag||drag.id!==e.pointerId)return;
  const dx=e.clientX-drag.x,dy=e.clientY-drag.y;
  if(!drag.moved&&Math.hypot(dx,dy)<5)return;
  drag.moved=true;
  const top=clamp(drag.top+dy,0,Math.max(0,innerHeight-100));
  Object.assign(panel.style,{position:'fixed',right:'auto',bottom:'auto',width:`${Math.min(drag.width,innerWidth-16)}px`,height:`${Math.min(drag.height<100?600:drag.height,innerHeight-top-8)}px`,left:`${clamp(drag.left+dx,0,Math.max(0,innerWidth-drag.width))}px`,top:`${top}px`});
  panel.classList.add('support-moving');onMove(e);
 });
 function finish(e,cancel=false){
  if(!drag||e&&e.pointerId!==drag.id)return;
  const old=drag;drag=null;panel.classList.remove('support-moving');
  if(handle.hasPointerCapture(old.id))handle.releasePointerCapture(old.id);
  if(cancel){panel.style.cssText=old.style;onCancel()}
  else if(old.moved)onDrop(e);
 }
 handle.addEventListener('pointerup',e=>finish(e));
 handle.addEventListener('pointercancel',e=>finish(e,true));
 window.addEventListener('blur',()=>finish(null,true));
 window.addEventListener('resize',()=>{
  if(!panel.style.left||panel.classList.contains('conversation-docked'))return;
  const width=Math.min(parseFloat(panel.style.width)||440,innerWidth-16),top=clamp(parseFloat(panel.style.top)||0,0,Math.max(0,innerHeight-100));
  Object.assign(panel.style,{width:`${width}px`,left:`${clamp(parseFloat(panel.style.left)||0,0,innerWidth-width)}px`,top:`${top}px`,height:`${Math.min(parseFloat(panel.style.height)||600,innerHeight-top-8)}px`});
 });
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&drag){e.preventDefault();finish(null,true)}});
}

export function conversationWindow(content,{home,onVisibility=()=>{},onNewMessage=()=>{}}){
 const panel=document.createElement('section');panel.className='conversation-window';panel.hidden=true;
 panel.setAttribute('aria-label','Detached Conversation');
 panel.innerHTML='<header class="conversation-header"><strong>Conversation</strong><button type="button" class="chat-unread-badge" aria-label="Reply to new message" hidden></button><button data-conv-min aria-label="Minimize Conversation">−</button><button data-conv-return>Return To Chat</button></header><div class="conversation-docking"><label>Position <select aria-label="Conversation Position"><option value="floating">Floating</option><option value="left">Dock Left</option><option value="main">Dock Main</option><option value="right">Dock Right</option></select></label></div><div class="conversation-content support-body"></div>';
 document.body.append(panel);
 let mode='home',drop=null,mobilePlacement=null;
 const body=panel.querySelector('.conversation-content'),select=panel.querySelector('select');
 function preserveHistory(){
  const log=content.querySelector('.chat-log'),top=log.scrollTop,bottom=top+log.clientHeight>=log.scrollHeight-24;
  return()=>{log.scrollTop=bottom?log.scrollHeight:top};
 }
 function mount(){
  if(mode==='home'||mode==='panel')return;
  const restore=preserveHistory();
  const lane=document.querySelector(`#custom-workspace:not([hidden]) .workspace-lane[data-zone="${mode}"]`);
  panel.classList.toggle('conversation-docked',!!lane);
  if(lane){if(panel.parentElement!==lane)lane.append(panel);panel.style.cssText=''}
  else if(panel.parentElement!==document.body){document.body.append(panel);panel.style.cssText=''}
  if(!lane&&mode!=='floating'){mode='floating';select.value=mode}
  if(!panel.contains(content))body.append(content);
  restore();requestAnimationFrame(restore);
 }
 function change(value){
  mobilePlacement?.reset();
  const restore=preserveHistory();
  mode=value;panel.hidden=mode==='home';panel.classList.remove('collapsed');panel.querySelector('[data-conv-min]').textContent='−';
  if(mode==='home'){home.append(content);document.body.append(panel)}
  else {select.value=mode;mount();raiseWindow(panel)}
  restore();requestAnimationFrame(()=>{restore();onVisibility()});
  document.dispatchEvent(new CustomEvent('wave-conversation-dock',{detail:{detached:mode!=='home'}}));onVisibility();
 }
 select.onchange=()=>change(select.value);
 panel.querySelector('.chat-unread-badge').onclick=()=>onNewMessage();
 panel.querySelector('[data-conv-return]').onclick=()=>change('home');
 panel.querySelector('[data-conv-min]').onclick=e=>{const c=panel.classList.toggle('collapsed');e.currentTarget.textContent=c?'+':'−';e.currentTarget.setAttribute('aria-label',c?'Restore Conversation':'Minimize Conversation');onVisibility()};
 draggableWindow(panel,panel.querySelector('header'),{
  onMove(e){
   document.querySelectorAll('.conversation-drop').forEach(n=>n.classList.remove('conversation-drop'));
   panel.style.pointerEvents='none';const lane=document.elementFromPoint(e.clientX,e.clientY)?.closest('.workspace-lane');panel.style.pointerEvents='';
   drop=lane?.dataset.zone??null;lane?.classList.add('conversation-drop');
  },
  onDrop(){document.querySelectorAll('.conversation-drop').forEach(n=>n.classList.remove('conversation-drop'));mode=drop||'floating';select.value=mode;drop=null;mount();onVisibility()},
  onCancel(){document.querySelectorAll('.conversation-drop').forEach(n=>n.classList.remove('conversation-drop'));drop=null}
 });
 document.addEventListener('wave-workspace-layout',mount);
 select.add(new Option('Docked To Panel','panel'));select.querySelector('option[value=panel]').disabled=true;
 mobilePlacement=bindMobileUtilityDrag(panel,[panel.querySelector('header')],{title:()=>panel.querySelector('strong').textContent,onPlacement:target=>{mode=target?'panel':'floating';select.value=mode;onVisibility()}});
 return {
  detach(){change('floating')},isDetached:()=>mode!=='home',panel,
  reveal(){if(mode==='home')return;mount();panel.hidden=false;panel.classList.remove('collapsed');const b=panel.querySelector('[data-conv-min]');b.textContent='−';b.setAttribute('aria-label','Minimize Conversation');raiseWindow(panel)},
  setTitle(title){panel.querySelector('strong').textContent=title},
  unread(value){const b=panel.querySelector('.chat-unread-badge');b.hidden=!value;b.textContent=value?'New Message':'';panel.classList.toggle('has-unread',!!value)},
  close(){change('home')}
 };
}
