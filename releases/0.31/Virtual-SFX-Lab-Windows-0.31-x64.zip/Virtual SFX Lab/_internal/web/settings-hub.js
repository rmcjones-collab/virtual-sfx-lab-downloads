import {makeSaveBundle} from './save-options.js?v=v031-preview-20261004';
import {DEV_LOG} from './dev-log.js?v=v031-preview-20261004';
import {requestFileSave} from './file-save.js?v=v031-preview-20261004';
const $=s=>document.querySelector(s);
const categories=[
 {key:'appearance',title:'Appearance & Workspace',fields:[['Button Size','#button-size'],['Layout Scrolling','#layout-screen-mode'],['Angle Guides','#guides'],['Movement Path','#path']],actions:[['Switch Light / Dark','#theme'],['Add / Arrange Panels','catalog'],['Multi-Screen Workspace','screens']]},
 {key:'layout',title:'Layout & Fixtures',fields:[['Active Fixture Name','#fixture-name'],['Layout Zoom %','#zoom-value'],['Spacing % Of View','#layout-spacing'],['X Position %','#fixture-x'],['Y Position %','#fixture-y'],['Invert Selected Units','#fixture-invert'],['Fixture Scale','#stage-scale'],['Layout Chase BPM','#layout-chase-bpm']],actions:[['Fit View','#fit-view'],['Arrange','#arrange'],['Snap To Grid','#snap-grid'],['Lock / Unlock Fixtures','#layout-lock'],['Multi-Select','#select-multiple'],['Odd / Even Selection','#select-odd-even'],['Start / Stop Visual Chase','#layout-chase'],['New Default Layout','#stage-default-layout'],['Load Default Layout','#stage-load-default-layout'],['Reset Layout','#stage-reset-layout']]},
 {key:'flames',title:'Flames, Limits & Patch',fields:[['Nozzle','#fixture-nozzle'],['Visual Flame Scale %','#size'],['Virtual Armed State','#virtual-armed'],['Minimum Angle','#fixture-min-angle'],['Maximum Angle','#fixture-max-angle'],['Universe / Port-Address','#dmx-universe'],['Start Address','#dmx-address']],actions:[['Apply Patch','#dmx-patch'],['Reset Angle Limits','#reset-angle-limits'],['Copy Limits To All','#copy-angle-limits']]},
 {key:'playback',title:'Playback & Faders',fields:[['Loop Preset','#loop'],['Auto-Next','#tour'],['Duration (Seconds)','#speed'],['Virtual Universe','#virtual-universe'],['Keyboard F1–F12','#macro-keys'],['Show Master','#show-master-fader']],actions:[['Virtual Faders','#mode-faders'],['Release All','#bank-release'],['Console Mapping','#open-mapping'],['Show Fader Panel','panel:faders'],['Show Macros','panel:macros'],['Cue Recording & Timing','panel:record']]},
 {key:'fuel',title:'Fuel & Consumption',fields:[],actions:[['Show Fuel Estimates','panel:fuel']],hint:'Click A Unit’s Fuel Indicator To Edit Capacity, Remaining Fuel And Consumption Variables For One Or All Units. These Are Estimates, Not Hardware Measurements.'},
 {key:'notes',title:'Notes, Clocks & Timecode',fields:[['Notes Wheel Sensitivity %','.workspace-notebook [data-note-wheel]'],['Notes Selection Scroll %','.workspace-notebook [data-note-selection]'],['Follow Notes When Selected','.workspace-notebook [data-follow-note]']],actions:[['Show Notes','panel:notes'],['Show Clock','panel:clock'],['Show Timecode','panel:timecode']],hint:'Note Settings Apply To The First Notes Panel In This Arrangement. Each Additional Panel Has Independent Scroll Settings. Clock And Timecode Settings Remain In Their Respective Panels.'},
 {key:'files',title:'File Controls & Autosave',fields:[['Autosave Layout','#autosave-enabled'],['Autosave Interval (Minutes)','#autosave-minutes']],actions:[['Save Layout / Preferences','#save-layout'],['Load Layout','#load-layout'],['Recordings','#recordings-open'],['Session Files','#session-open'],['Autosave','#autosave-open'],['Workspace Backup / Import','catalog'],['Refresh App','refresh']],hint:'Download Important Work. Visitor-Scoped Prototype Storage Is Not A Durable Backup. Video Recordings Stay In This Tab Only And Are Not Included In Layout Or Session Backups.'},
 {key:'recording',title:'Layout Recording',fields:[['Video Quality','#record-quality'],['Video Format','#record-format'],['Frame Rate','#record-fps'],['Auto-Stop After','#record-seconds']],actions:[['Open Recordings','#recordings-open']],hint:'Use The Red Dot In The Layout To Record Silent Visual Rehearsals. MP4 Availability Depends On Your Browser; Automatic Uses WebM When MP4 Is Unavailable. Download Clips Before Refreshing Or Closing.'},
 {key:'devlog',title:'Dev Log',fields:[],actions:[],hint:'Every Beta Release From 0.01 To The Current Version, Newest First. Beta 0.01–0.07 Were Numbered Retroactively From The Build History; The In-App Version Label Began At Beta 0.08.'},
 {key:'support',title:'Receiver & Help',fields:[],actions:[['Vista / Receiver Settings','#dmx-setup'],['AI App Guide','#wave-guide-open'],['Test Checklist','#wave-checklist-open'],['Reference Notes','#sources']],hint:'Live Input Is A Visual Rehearsal Feature. No Physical DMX Or Firing Output Is Implemented.'}
];
export function mountSettingsHub({workspace,capture,saveSession}){
 const d=document.createElement('dialog');d.id='wave-settings-dialog';d.className='app-settings-dialog';
 d.innerHTML='<div class="dialog-head"><h2>Settings</h2><button type="button" data-close>Close</button></div><div class="settings-shell"><nav aria-label="Settings Categories"></nav><section class="settings-content"></section></div>';
 document.body.append(d);let active='appearance';
 const nav=d.querySelector('nav'),content=d.querySelector('.settings-content');let proxies=[];
 const close=()=>d.close();d.querySelector('[data-close]').onclick=close;
 function action(target){
  close();
  if(target==='catalog')workspace.openCatalog();
  else if(target==='screens')openScreens();
  else if(target==='refresh')openRefresh();
  else if(target.startsWith('panel:'))workspace.showPanel(target.slice(6));
  else $(target)?.click();
 }
 function render(){
  const category=categories.find(c=>c.key===active);content.replaceChildren();proxies=[];
  for(const b of nav.children)b.setAttribute('aria-pressed',String(b.dataset.category===active));
  const h=document.createElement('h3');h.textContent=category.title;content.append(h);
  if(category.hint){const p=document.createElement('p');p.className='widget-hint';p.textContent=category.hint;content.append(p)}
  const fields=document.createElement('div');fields.className='settings-fields';content.append(fields);
  if(active==='appearance'){
   for(const device of ['desktop','mobile']){
    const row=document.createElement('label'),title=document.createElement('span'),select=document.createElement('select');
    title.textContent=`Panel Label Alignment · ${device==='desktop'?'Desktop':'Mobile'}`;select.setAttribute('aria-label',title.textContent);
    for(const [value,label] of [['left','Left'],['right','Right'],['center','Centre']])select.append(new Option(label,value));
    select.value=workspace.labelAlignment()[device];select.onchange=()=>workspace.setLabelAlignment(device,select.value);
    row.append(title,select);fields.append(row);
   }
  }
  for(const [name,selector] of category.fields){
   const source=selector.startsWith('.workspace-notebook')?[...document.querySelectorAll(selector)].find(n=>n.getClientRects().length):$(selector);if(!source)continue;
   const row=document.createElement('label'),text=document.createElement('span'),control=source.cloneNode(true),output=document.createElement('output');
   text.textContent=name;control.removeAttribute('id');control.removeAttribute('name');control.removeAttribute('aria-describedby');control.setAttribute('aria-label',name);
   control.value=source.value;if('checked'in control)control.checked=source.checked;control.disabled=source.matches(':disabled')||!!source.closest('[inert]');
   for(const type of ['input','change'])control.addEventListener(type,()=>{source.value=control.value;if('checked'in control)source.checked=control.checked;source.dispatchEvent(new Event(type,{bubbles:true}));output.textContent=control.type==='range'?control.value:''});
   output.textContent=control.type==='range'?control.value:'';row.classList.toggle('has-range',control.type==='range');output.hidden=control.type!=='range';row.append(text,control,output);fields.append(row);proxies.push({source,control,output});
  }
  const actions=document.createElement('div');actions.className='settings-actions';content.append(actions);
  for(const [name,target] of category.actions){
   const source=target.startsWith('#')?$(target):null;if(target.startsWith('#')&&!source)continue;
   const b=document.createElement('button');b.type='button';b.textContent=name;b.disabled=!!source?.matches(':disabled')||!!source?.closest('[inert]');b.onclick=()=>action(target);actions.append(b);
  }
  if(active==='devlog'){
   const log=document.createElement('div');log.className='dev-log';log.setAttribute('role','list');
   for(const entry of DEV_LOG){
    const item=document.createElement('details');item.className='dev-log-entry';item.setAttribute('role','listitem');if(entry===DEV_LOG[0])item.open=true;
    const sum=document.createElement('summary'),ver=document.createElement('strong'),title=document.createElement('span'),date=document.createElement('time');
    ver.textContent=`Beta ${entry.version}`;title.textContent=entry.title;date.dateTime=entry.date;date.textContent=entry.date+(entry.retro?' · retroactive':'');
    sum.append(ver,title,date);const list=document.createElement('ul');
    for(const text of entry.items){const li=document.createElement('li');li.textContent=text;list.append(li)}
    item.append(sum,list);log.append(item);
   }
   const tools=document.createElement('div');tools.className='dev-log-tools';
   const expand=document.createElement('button');expand.type='button';expand.textContent='Expand All';
   expand.onclick=()=>{const all=[...log.children].every(d=>d.open);log.querySelectorAll('details').forEach(d=>d.open=!all);expand.textContent=all?'Expand All':'Collapse All'};
   const copy=document.createElement('button');copy.type='button';copy.textContent='Download Dev Log';
   copy.onclick=()=>{const text=DEV_LOG.map(e=>`Beta ${e.version} — ${e.date}${e.retro?' (retroactive)':''}\n${e.title}\n${e.items.map(i=>`- ${i}`).join('\n')}`).join('\n\n');requestFileSave(new Blob([`Wave Studio Dev Log\n\n${text}\n`],{type:'text/plain'}),'wave-studio-dev-log.txt')};
   tools.append(expand,copy);content.append(tools,log);
  }
  if(active==='playback'){
   for(const [title,count,selector] of [['Fader Settings',20,i=>`.fader-strip[data-fader="${i}"] .fader-settings`],['Assign Macro',12,i=>`.macro-edit[data-macro="${i}"]`]]){
    const row=document.createElement('label'),pick=document.createElement('select'),b=document.createElement('button'),label=document.createElement('span');label.textContent=title;pick.setAttribute('aria-label',title);
    for(let i=0;i<count;i++)pick.append(new Option(`${title==='Fader Settings'?'Fader':'F'} ${i+1}`,i));
    b.type='button';b.textContent='Edit';b.onclick=()=>{const source=$(selector(Number(pick.value)));if(source&&!source.matches(':disabled')&&!source.closest('[inert]')){close();source.click()}};
    row.className='settings-editor-choice';row.append(label,pick,b);content.append(row);
   }
  }
 }
 for(const c of categories){const b=document.createElement('button');b.type='button';b.dataset.category=c.key;b.textContent=c.title;b.onclick=()=>{active=c.key;render()};nav.append(b)}
 function openSettings(){render();d.showModal()}
 const refresh=document.createElement('dialog');refresh.id='wave-refresh-dialog';refresh.className='refresh-dialog';
 refresh.innerHTML='<div class="dialog-head"><h2>Refresh Wave Studio?</h2><button type="button" data-cancel>Cancel</button></div><p>Refreshing Reloads The App, Stops This Preview And Closes Companion Windows. Save Your Progress First. Unsaved Stage, Fader And Workspace Changes May Be Lost.</p><p>Stop Any Layout Recording And Download Your Videos From Recordings First. Refreshing Deletes All Clips In This Tab. Save Downloads A Layout And Preferences Backup, Including Notes But Not Videos. It Also Attempts To Save Your Workspace And Session Online.</p><div class="settings-actions"><button type="button" data-save>Save Progress</button><button type="button" data-reload>Refresh Without Save</button><button type="button" data-after hidden>I Have Saved · Refresh</button></div><p role="status"></p>';
 document.body.append(refresh);refresh.querySelector('[data-cancel]').onclick=()=>refresh.close();
 const reload=()=>location.reload();refresh.querySelector('[data-reload]').onclick=reload;refresh.querySelector('[data-after]').onclick=reload;
 refresh.querySelector('[data-save]').onclick=async()=>{
  const b=refresh.querySelector('[data-save]'),status=refresh.querySelector('[role=status]');b.disabled=true;
  try{
   const data=makeSaveBundle(capture(),{layout:true,settings:true,labels:true,preferences:true}),result=await requestFileSave(new Blob([JSON.stringify(data,null,2)],{type:'application/json'}),'wave-studio-before-refresh.json');
   if(!result){status.textContent='Save Cancelled. The App Has Not Refreshed.';return}
   status.textContent=result.message+' Saving Online…';
   const ws=await workspace.saveNow(),session=await saveSession();
   status.textContent=`${ws&&session?'Workspace And Session Saved Online.':'Online Save Was Not Fully Successful.'} Check Your Chosen File Destination Before Refreshing.`;
   refresh.querySelector('[data-after]').hidden=false;
  }catch(e){status.textContent=`Could Not Save: ${e.message}. Cancel Refresh And Try Save Layout.`}finally{b.disabled=false}
 };
 function openRefresh(){refresh.querySelector('[role=status]').textContent='';refresh.querySelector('[data-after]').hidden=true;refresh.showModal()}
 const screens=document.createElement('dialog');screens.id='wave-screens-dialog';screens.className='app-screens-dialog';
 screens.innerHTML='<div class="dialog-head"><h2>Multi-Screen Workspace</h2><button type="button" data-close>Close</button></div><p>Main Window + Up To Three Linked Companion Windows. Choose A Workflow, Then Open Each Screen Individually. All Views Share This App’s Virtual State.</p><div class="settings-actions"><button type="button" data-detect>Detect Connected Monitors</button><button type="button" data-close-all>Close Companion Windows</button></div><label>Workflow Layout<select data-preset><option value="dual">Two Screens · Layout / Faders</option><option value="triple">Three Screens · Layout / Faders / Library</option><option value="quad">Four Screens · Layout / Faders / Cues / Notes & Timecode</option><option value="instructor">Instructor · Stage / Notes & Reference</option><option value="custom">Custom · Choose Panels Per Screen</option></select></label><div class="screen-choices"></div><p data-screen-status role="status"></p><p class="widget-hint">Display Detection And Automatic Placement Depend On Browser Permission. If Unavailable, Drag Windows Onto Your Monitors Manually. Allow Pop-Ups. Embedded Previews Require Opening The App As A Standalone Page For Linked Screens.</p>';
 document.body.append(screens);screens.querySelector('[data-close]').onclick=()=>screens.close();
 const names=[['stage','Layout'],['faders','Virtual Faders'],['library','Sequence Library'],['notes','Notes'],['clock','Clock'],['timecode','Timecode'],['rear','Virtual Rear Panel'],['fuel','Fuel Estimates'],['monitor','Virtual DMX Monitor'],['tools','Fixture & File Controls']];
 const presets={dual:[['faders']],triple:[['faders'],['library']],quad:[['faders'],['library'],['notes','clock','timecode']],instructor:[['stage','notes','rear']],custom:[['stage'],['faders'],['library','notes']]};
 function renderScreens(){
  const host=screens.querySelector('.screen-choices');host.replaceChildren();
  const preset=screens.querySelector('[data-preset]').value,displays=workspace.monitors.displays();
  presets[preset].forEach((selected,index)=>{
   const card=document.createElement('fieldset'),legend=document.createElement('legend');legend.textContent=`Screen ${index+2}`;card.append(legend);
   const display=document.createElement('select');display.setAttribute('aria-label',`Screen ${index+2} Monitor`);
   display.append(new Option('Manual Placement',''));
   for(const s of displays)display.append(new Option(`${s.label} · ${s.width} × ${s.height}`,s.index));
   if(displays[index+1])display.value=String(index+1);
   const placement=document.createElement('select');placement.setAttribute('aria-label',`Screen ${index+2} Window Layout`);for(const [v,t]of [['full','Full Monitor'],['left','Left Half'],['right','Right Half']])placement.append(new Option(t,v));
   card.append(display,placement);const checks=document.createElement('div');checks.className='screen-panel-options';card.append(checks);
   for(const [key,title]of names){const label=document.createElement('label'),input=document.createElement('input');input.type='checkbox';input.value=key;input.checked=selected.includes(key);label.append(input,document.createTextNode(title));checks.append(label)}
   const b=document.createElement('button');b.type='button';b.textContent=`Open Screen ${index+2}`;card.append(b);
   b.onclick=()=>{const selected=[...checks.querySelectorAll('input:checked')].map(n=>n.value);if(!selected.length){screens.querySelector('[data-screen-status]').textContent='Choose At Least One Panel For This Screen.';return}workspace.monitors.open(index+1,{selected,displayIndex:display.value===''?undefined:Number(display.value),placement:placement.value});screens.querySelector('[data-screen-status]').textContent=workspace.monitors.status()};
   host.append(card);
  });
  screens.querySelector('[data-screen-status]').textContent=displays.length?`${displays.length} Connected Display(s) Detected.`:'Display List Not Available Yet. Manual Placement Works Without Detection.';
 }
 screens.querySelector('[data-preset]').onchange=renderScreens;
 screens.querySelector('[data-detect]').onclick=async()=>{await workspace.monitors.detect();renderScreens();if(!workspace.monitors.displays().length)screens.querySelector('[data-screen-status]').textContent=workspace.monitors.status()};
 screens.querySelector('[data-close-all]').onclick=()=>{workspace.monitors.close();screens.querySelector('[data-screen-status]').textContent='Companion Windows Closed.'};
 function openScreens(){renderScreens();screens.showModal()}
 function buttons(anchor,prefix){
  const group=document.createElement('span');group.className='app-global-controls';
  for(const [name,fn,key]of [['Settings',openSettings,'settings'],['Multi-Screen',openScreens,'screens'],['Refresh',openRefresh,'refresh']]){
   const b=document.createElement('button');b.type='button';b.id=`${prefix}-${key}`;b.textContent=name;b.onclick=fn;group.append(b);
  }
  anchor.after(group);
 }
 buttons($('#dmx-setup'),'app');buttons($('#focus-add'),'focus');
 new ResizeObserver(entries=>{$('#workspace-focus').style.setProperty('--focus-toolbar-height',`${Math.ceil(entries[0].target.getBoundingClientRect().height)+16}px`)}).observe($('.focus-toolbar'));
 const timer=setInterval(()=>{if(!d.open)return;for(const {source,control,output}of proxies){control.disabled=source.matches(':disabled')||!!source.closest('[inert]');if(document.activeElement!==control){control.value=source.value;if('checked'in control)control.checked=source.checked}output.textContent=control.type==='range'?control.value:''}},250);
 window.addEventListener('pagehide',()=>clearInterval(timer),{once:true});
}
