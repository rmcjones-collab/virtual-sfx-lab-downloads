// Virtual SFX Lab — seven-day full-studio trial.
// The demo landing page is always free. The full studio (index.html) opens for seven days
// after the visitor presses Start Trial on the landing page; afterwards it locks behind the
// purchase screen until sales open. The start time is kept in this browser and, when the
// local backend is reachable, against the visitor identity the backend already uses for
// private storage, so clearing the browser does not restart the clock.
//
// Gate scope: enforced on every public host. 127.0.0.1 (the paid local receiver and the
// development test suite) is never gated; add ?gate=on to any URL to force the gate for QA.
export const PRODUCT='Virtual SFX Lab';
export const MODULE='Wave Studio';
export const MODULE_FIXTURE='Explo X2 Wave Flame';
export const TRIAL_DAYS=7;
export const PRICES={studio:{amount:'29.99',currency:'CAD',label:'Virtual SFX Lab · full studio',terms:'One-time purchase · plus applicable tax'},receiver:{amount:'29.99',currency:'CAD',label:'Vista receiver add-on · one computer',terms:'One-time purchase · plus applicable tax · Windows or macOS'}};
const KEY='vsl-trial';
const PORT='__PORT_8093__';
const API=PORT.startsWith('__')?'http://127.0.0.1:8093':PORT;
const localHost=['127.0.0.1','localhost'].includes(location.hostname);
const headers={'Content-Type':'application/json',...(localHost?{'X-Wave-Dev-Visitor':'local-development'}:{})};
const DAY=86400000;

function readLocal(){try{const raw=localStorage.getItem(KEY);const rec=raw?JSON.parse(raw):null;return rec&&typeof rec.started==='string'&&Number.isFinite(Date.parse(rec.started))?rec:null}catch{return null}}
function writeLocal(rec){try{if(rec)localStorage.setItem(KEY,JSON.stringify({started:rec.started}));else localStorage.removeItem(KEY)}catch{}}

export function describe(started){
 if(!started)return {status:'none',started:null,expires:null,daysLeft:TRIAL_DAYS,trialDays:TRIAL_DAYS,licensed:false};
 const begin=Date.parse(started),end=begin+TRIAL_DAYS*DAY,left=end-Date.now();
 return {status:left>0?'active':'expired',started:new Date(begin).toISOString(),expires:new Date(end).toISOString(),daysLeft:left>0?Math.ceil(left/DAY):0,hoursLeft:left>0?Math.ceil(left/3600000):0,trialDays:TRIAL_DAYS,licensed:false};
}

export function gateEnabled(){
 const params=new URLSearchParams(location.search),flag=params.get('gate');
 try{
  if(flag==='on'||flag==='off')sessionStorage.setItem('vsl-gate',flag);
  const forced=sessionStorage.getItem('vsl-gate');
  if(forced)return forced==='on';
 }catch{if(flag)return flag==='on'}
 return !['127.0.0.1','::1','[::1]'].includes(location.hostname);
}

async function remote(path,init){
 try{
  const r=await fetch(`${API}${path}`,{headers,signal:AbortSignal.timeout(5000),...init});
  if(!r.ok)return null;
  return await r.json();
 }catch{return null}
}

// Merge the browser record with the backend record; the earlier start wins everywhere.
export async function trialState(){
 let rec=readLocal();
 const server=await remote('/api/trial');
 if(server&&server.started){
  if(!rec||Date.parse(server.started)<Date.parse(rec.started))rec={started:server.started};
  else if(Date.parse(rec.started)<Date.parse(server.started))await remote('/api/trial/start',{method:'POST',body:JSON.stringify({started:rec.started})});
  writeLocal(rec);
 }else if(server&&rec){
  await remote('/api/trial/start',{method:'POST',body:JSON.stringify({started:rec.started})});
 }
 return describe(rec?.started??null);
}

export async function startTrial(){
 const existing=readLocal();
 const started=existing?.started??new Date().toISOString();
 writeLocal({started});
 const server=await remote('/api/trial/start',{method:'POST',body:JSON.stringify({started})});
 if(server&&server.started&&Date.parse(server.started)<Date.parse(started))writeLocal({started:server.started});
 return describe(readLocal()?.started??started);
}

export function trialLabel(state){
 if(state.status==='none')return `${TRIAL_DAYS}-day trial available`;
 if(state.status==='expired')return 'Trial ended';
 if(state.daysLeft<=1)return `Trial · ${state.hoursLeft} hour${state.hoursLeft===1?'':'s'} left`;
 return `Trial · ${state.daysLeft} day${state.daysLeft===1?'':'s'} left`;
}

export function formatPrice(p){return `$${p.amount} ${p.currency}`}
