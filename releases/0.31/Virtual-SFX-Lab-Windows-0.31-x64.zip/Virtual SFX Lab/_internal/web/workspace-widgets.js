import {TC_RATES} from './timecode.js?v=v031-preview-20261004';
import {bindNoteEditor} from './note-editor.js?v=v031-preview-20261004';
import {bindNoteTabs} from './note-tabs.js?v=v031-preview-20261004';
import {exportNotesDialog} from './document-export.js?v=v031-preview-20261004';
const pad=n=>String(n).padStart(2,'0');
export const duration=s=>{const negative=s<0;s=Math.max(0,Math.floor(Math.abs(s)));return `${negative?'-':''}${pad(Math.floor(s/3600))}:${pad(Math.floor(s/60)%60)}:${pad(s%60)}`};
const uid=()=>crypto.randomUUID();
export function createNotes({get,change}){
 const el=document.createElement('section');el.className='workspace-notebook';
 // Notes are editors, not workspace keyboard/drag targets. Enter remains a newline.
 el.addEventListener('keydown',e=>{if(e.target.matches('input,textarea')){e.stopPropagation();if(e.key==='Enter'&&e.target.matches('input'))e.preventDefault()}});
 el.addEventListener('keyup',e=>{if(e.target.matches('input,textarea'))e.stopPropagation()});
 el.addEventListener('pointerdown',e=>{if(e.target.matches('input,textarea'))e.stopPropagation()});
 el.innerHTML='<div class="note-toolbar"><button type="button" data-add-note>Add Note</button><div class="note-tabs" role="tablist" aria-label="Notes"></div></div><div class="note-options"><label><input type="checkbox" data-follow-note> Follow When Selected</label><details class="note-scroll-settings"><summary>Scroll Settings</summary><label>Mouse Wheel <input type="range" data-note-wheel aria-label="Notes Mouse Wheel Sensitivity" min="10" max="300" step="10" value="100"><output data-wheel-output>100%</output></label><label>Text Selection <input type="range" data-note-selection aria-label="Notes Text Selection Scroll Sensitivity" min="0" max="300" step="10" value="100"><output data-selection-output>100%</output></label><p class="widget-hint">Lower Values Scroll More Slowly. Text Selection At 0% Disables Edge Autoscroll.</p></details></div><div class="note-list"></div>';
 bindNoteEditor(el);
 el.querySelector('.note-scroll-settings summary').textContent='Note Settings';
 const exportButton=document.createElement('button');exportButton.type='button';exportButton.textContent='Export Notes';
 exportButton.onclick=()=>exportNotesDialog(structuredClone(get().notes??[]),selected()?.id);el.querySelector('.note-scroll-settings').append(exportButton);
 const editors=new Map(),notebookId=uid();let active=null;
 function reorder(id,target,after){
  const notes=get().notes??[],from=notes.findIndex(n=>n.id===id);if(from<0||id===target)return;
  const [note]=notes.splice(from,1),to=notes.findIndex(n=>n.id===target);notes.splice(to+(after?1:0),0,note);change();tabs();
 }
 bindNoteTabs(el.querySelector('.note-tabs'),{reorder});
 el.addEventListener('wave-note-reorder',e=>reorder(e.detail.id,e.detail.target,e.detail.after));
 function deleteNote(id){
  const note=get().notes?.find(n=>n.id===id);if(!note)return;
  const dialog=doc.createElement('dialog');dialog.className='note-delete-dialog';
  const title=doc.createElement('h2');title.textContent='Delete Note?';
  const text=doc.createElement('p');text.textContent=`Delete “${note.title||'Untitled Note'}”? This Cannot Be Undone.`;
  const cancel=doc.createElement('button'),remove=doc.createElement('button');cancel.type=remove.type='button';cancel.textContent='Cancel';remove.textContent='Delete Note';
  dialog.append(title,text,cancel,remove);doc.body.append(dialog);
  dialog.addEventListener('close',()=>dialog.remove(),{once:true});cancel.onclick=()=>dialog.close();
  remove.onclick=()=>{const notes=get().notes??[],index=notes.findIndex(n=>n.id===id);get().notes=notes.filter(n=>n.id!==id);get().activeNoteId=get().notes[Math.min(index,get().notes.length-1)]?.id??'';change();dialog.close();render()};
  dialog.showModal();
 }
 function selected(){const notes=get().notes??[];return notes.find(n=>n.id===(get().activeNoteId??active))??notes[0]}
 function tabs(){
  const options=get(),notes=options.notes??[],current=selected(),host=el.querySelector('.note-tabs'),scroll=host.scrollLeft;
  for(const button of [...host.children])if(!notes.some(n=>n.id===button.dataset.note))button.remove();
  for(const note of notes){
   let button=[...host.children].find(n=>n.dataset.note===note.id);
   if(!button){button=doc.createElement('button');button.type='button';button.dataset.note=note.id;button.setAttribute('role','tab');button.onclick=()=>{active=note.id;get().activeNoteId=note.id;change();render()};host.append(button)}
   button.textContent=note.title||'Untitled Note';button.title=`${note.title||'Untitled Note'} · Drag To Reorder Or Use Alt + Arrow Keys`;button.setAttribute('aria-label',`Open Note: ${note.title||'Untitled Note'}`);button.setAttribute('aria-selected',String(current?.id===note.id));button.setAttribute('aria-controls',`note-editor-${notebookId}-${note.id}`);
   const index=notes.indexOf(note);if(host.children[index]!==button)host.insertBefore(button,host.children[index]??null);
  }
  host.scrollLeft=scroll;el.querySelector('[data-add-note]').disabled=notes.length>=16;
 }
 const doc=el.ownerDocument;
 function render(){
  const options=get();el.querySelector('[data-follow-note]').checked=!!options.follow;
  for(const [key,selector,out]of [['wheelSensitivity','[data-note-wheel]','[data-wheel-output]'],['selectionSensitivity','[data-note-selection]','[data-selection-output]']]){const value=options[key]??100;el.querySelector(selector).value=value;el.querySelector(out).textContent=value+'%'}
  const list=el.querySelector('.note-list'),current=selected();active=current?.id??null;
  for(const [id,box]of editors)if(!options.notes?.some(n=>n.id===id)){box.remove();editors.delete(id)}
  for(const note of options.notes??[]){
   let box=editors.get(note.id);
   if(!box){
    box=doc.createElement('article');box.className='workspace-note';box.id=`note-editor-${notebookId}-${note.id}`;box.setAttribute('role','tabpanel');
    box.innerHTML='<div class="widget-row"><input aria-label="Note Title" maxlength="80"><button type="button" aria-label="Delete Note">Delete</button></div><textarea aria-label="Note Text" maxlength="4000" placeholder="Write your note…"></textarea>';
    const find=()=>get().notes?.find(n=>n.id===note.id),title=box.querySelector('input'),body=box.querySelector('textarea');
    title.oninput=()=>{if(find())find().title=title.value;change();tabs()};body.oninput=()=>{if(find())find().body=body.value;change()};
    box.querySelector('button').onclick=()=>deleteNote(selected()?.id??note.id);
    editors.set(note.id,box);list.append(box);
   }
   box.hidden=note.id!==current?.id;
   for(const [selector,value]of [['input',note.title],['textarea',note.body]]){const field=box.querySelector(selector);if(doc.activeElement!==field&&field.value!==value)field.value=value}
  }
  let empty=list.querySelector('.note-empty');if(!current&&!empty){empty=doc.createElement('p');empty.className='widget-hint note-empty';empty.textContent='Add A Note To Start Writing. Up To 16 Notes Per Panel.';list.append(empty)}if(current)empty?.remove();
  tabs();
 }
 el.querySelector('[data-add-note]').onclick=()=>{const o=get();o.notes??=[];if(o.notes.length<16){const note={id:uid(),title:`Note ${o.notes.length+1}`,body:''};o.notes.push(note);o.activeNoteId=note.id;active=note.id}change();render();el.querySelector('.workspace-note:not([hidden]) input')?.focus({preventScroll:true})};
 el.querySelector('[data-follow-note]').onchange=e=>{get().follow=e.target.checked;change();el.dispatchEvent(new CustomEvent('wave-note-follow-change',{bubbles:true}))};
 for(const [key,selector,out]of [['wheelSensitivity','[data-note-wheel]','[data-wheel-output]'],['selectionSensitivity','[data-note-selection]','[data-selection-output]']])el.querySelector(selector).oninput=e=>{get()[key]=Number(e.target.value);el.querySelector(out).textContent=e.target.value+'%';change()};
 return {el,render,tick(){}};
}
// Every IANA time zone the browser knows, grouped by region, labelled with its current UTC offset.
const FALLBACK_ZONES=['UTC','America/St_Johns','America/Halifax','America/Toronto','America/Winnipeg','America/Regina','America/Edmonton','America/Vancouver','America/New_York','America/Chicago','America/Denver','America/Phoenix','America/Los_Angeles','America/Anchorage','Pacific/Honolulu','America/Mexico_City','America/Sao_Paulo','America/Argentina/Buenos_Aires','Europe/London','Europe/Dublin','Europe/Lisbon','Europe/Paris','Europe/Berlin','Europe/Madrid','Europe/Rome','Europe/Amsterdam','Europe/Stockholm','Europe/Athens','Europe/Istanbul','Europe/Moscow','Africa/Cairo','Africa/Johannesburg','Africa/Lagos','Asia/Dubai','Asia/Karachi','Asia/Kolkata','Asia/Dhaka','Asia/Bangkok','Asia/Singapore','Asia/Hong_Kong','Asia/Shanghai','Asia/Seoul','Asia/Tokyo','Australia/Perth','Australia/Adelaide','Australia/Sydney','Pacific/Auckland'];
let zoneCache=null;
export function timeZoneList(){
 if(zoneCache)return zoneCache;
 let zones=[];try{zones=Intl.supportedValuesOf('timeZone')}catch{}
 if(!zones.length)zones=FALLBACK_ZONES;
 zoneCache=[...new Set(['UTC',...zones])].filter(z=>{try{new Intl.DateTimeFormat('en',{timeZone:z});return true}catch{return false}});
 return zoneCache;
}
function zoneOffset(zone,date=new Date()){
 try{const part=new Intl.DateTimeFormat('en-US',{timeZone:zone,timeZoneName:'longOffset'}).formatToParts(date).find(p=>p.type==='timeZoneName')?.value||'';const m=part.match(/GMT([+-]\d{2}):?(\d{2})?/);return m?`UTC${m[1].replace('-','−')}:${m[2]||'00'}`:'UTC+00:00'}catch{return ''}
}
function fillZones(select,current){
 const zones=timeZoneList(),groups=new Map();
 if(current&&!zones.includes(current))zones.push(current);
 for(const z of zones){const region=z.includes('/')?z.split('/')[0]:'Universal';if(!groups.has(region))groups.set(region,[]);groups.get(region).push(z)}
 select.replaceChildren();
 for(const [region,list] of [...groups].sort((a,b)=>a[0]==='Universal'?-1:b[0]==='Universal'?1:a[0].localeCompare(b[0]))){
  const group=document.createElement('optgroup');group.label=region;
  for(const z of list.sort()){const o=document.createElement('option');o.value=z;o.textContent=`${z.replace(/_/g,' ')} (${zoneOffset(z)})`;group.append(o)}
  select.append(group);
 }
}
export const MAX_CLOCK_ADJUST=86400;
export function formatAdjust(seconds){const s=Math.abs(seconds|0),sign=seconds<0?'−':'+';return `${sign}${String(Math.floor(s/3600)).padStart(2,'0')}:${String(Math.floor(s%3600/60)).padStart(2,'0')}:${String(s%60).padStart(2,'0')}`}
export function parseAdjust(text){
 const m=String(text).trim().replace(/\u2212/g,'-').match(/^([+-])?\s*(\d{1,2})(?::(\d{1,2}))?(?::(\d{1,2}))?$/);
 if(!m)return null;const [h,mi,se]=[m[2],m[3]||'0',m[4]||'0'].map(Number);if(mi>59||se>59)return null;
 const v=(m[1]==='-'?-1:1)*(h*3600+mi*60+se);return Math.abs(v)<=MAX_CLOCK_ADJUST?v:null;
}
export function createClock({get,change,timecode,timing,secondary=false}){
 const el=document.createElement('section');el.className='workspace-clock-widget';
 el.innerHTML='<input class="clock-title" aria-label="Clock Title" maxlength="100" placeholder="Clock"><div class="clock-readout"><output class="clock-value">00:00:00</output><button type="button" class="clock-run-toggle" data-run-toggle hidden aria-label="Start" title="Start / stop">▶</button></div><p class="clock-status" role="status"></p><details><summary>Clock Settings</summary><label>Display<select data-clock-mode></select></label><label data-zone-label>Time Zone<select data-zone aria-label="Time Zone"></select></label><div class="clock-adjust" data-adjust-box role="group" aria-label="Manual Time Adjustment"><label>Time Adjustment<input data-adjust inputmode="text" maxlength="9" placeholder="+00:00:00" aria-label="Time Adjustment (Plus Or Minus Hours:Minutes:Seconds)"></label><div class="widget-row clock-adjust-buttons"><button type="button" data-nudge="-3600">−1 h</button><button type="button" data-nudge="-60">−1 m</button><button type="button" data-nudge="-1">−1 s</button><button type="button" data-nudge="1">+1 s</button><button type="button" data-nudge="60">+1 m</button><button type="button" data-nudge="3600">+1 h</button><button type="button" data-adjust-reset>Reset</button></div><p class="widget-hint" data-adjust-hint>Shifts The Displayed Time To Match A Show Or Venue Clock (Up To ±24 h). Applies To Current Time, World Clock, Alarm, Time To Show And Time Until Load Out.</p></div><label data-target-label>Date And Time<input type="datetime-local" data-target></label><label><input type="checkbox" data-sound> Enable Alarm Sound</label><p class="widget-hint">Timers Continue By Elapsed Time, But Browser Suspension May Delay Alerts. Not A Safety Clock.</p></details><div class="widget-row clock-buttons"><button data-start>Start</button><button data-stop>Pause</button><button data-reset>Reset</button></div><div class="clock-timers"></div>';
 const modes={local:'Current Time',world:'World Clock',stopwatch:'Stopwatch',alarm:'Alarm',countdown:'Countdown Timers',show:'Time To Show',nextcue:'Time To Next Cue',loadout:'Time Until Load Out',timecode:'Timecode'};
 const select=el.querySelector('[data-clock-mode]');for(const [v,t]of Object.entries(modes)){const opt=document.createElement('option');opt.value=v;opt.textContent=t;select.append(opt)}
 const zoneSelect=el.querySelector('[data-zone]'),adjustInput=el.querySelector('[data-adjust]');
 fillZones(zoneSelect,get().zone??'America/Toronto');
 const adjust=()=>Number.isInteger(get().adjust)?get().adjust:0;
 const clockNow=()=>Date.now()+adjust()*1000;
 const valueOutput=el.querySelector('.clock-value'),statusOutput=el.querySelector('.clock-status'),runToggle=el.querySelector('[data-run-toggle]');
 let secondaryClock=null,secondaryDisplay=null,secondaryControls=null,secondaryToggle=null;
 let start=0,elapsed=0,running=false,alarmArmed=false,alarmDone=false,audio=null,timers=new Map();
 const mode=()=>get().mode??'local';
 const alert=()=>{if(!el.querySelector('[data-sound]').checked||!audio)return;const oscillator=audio.createOscillator(),gain=audio.createGain();oscillator.frequency.value=880;gain.gain.setValueAtTime(.12,audio.currentTime);gain.gain.exponentialRampToValueAtTime(.001,audio.currentTime+.6);oscillator.connect(gain).connect(audio.destination);oscillator.start();oscillator.stop(audio.currentTime+.6)};
 el.querySelector('[data-sound]').onchange=async e=>{if(e.target.checked){try{audio??=new AudioContext();await audio.resume()}catch{e.target.checked=false}}};
 function renderTimers(){
  const host=el.querySelector(':scope > .clock-timers');host.replaceChildren();host.hidden=mode()!=='countdown';
  if(host.hidden)return;
  for(const t of get().timers??[]){
   const row=document.createElement('div');row.className='clock-timer';row.innerHTML='<input aria-label="Timer Title" maxlength="80"><input aria-label="Timer Seconds" type="number" min="1" max="604800"><output></output><div class="widget-row"><button data-t-start>Start</button><button data-t-pause>Pause</button><button data-t-reset>Reset</button><button data-t-remove>Delete</button></div>';
   row.dataset.timer=t.id;const inputs=row.querySelectorAll('input');inputs[0].value=t.title;inputs[1].value=t.seconds;
   inputs[0].oninput=()=>{t.title=inputs[0].value;change()};
   inputs[1].onchange=()=>{const v=Number(inputs[1].value);if(v>=1&&v<=604800){t.seconds=v;timers.delete(t.id);change()}else inputs[1].value=t.seconds};
   const current=()=>timers.get(t.id)??{left:t.seconds,running:false,done:false};
   row.querySelector('[data-t-start]').onclick=()=>{const s=current();if(s.running)return;s.end=performance.now()+s.left*1000;s.running=true;s.done=false;timers.set(t.id,s)};
   row.querySelector('[data-t-pause]').onclick=()=>{const s=current();if(s.running)s.left=Math.max(0,(s.end-performance.now())/1000);s.running=false;timers.set(t.id,s)};
   row.querySelector('[data-t-reset]').onclick=()=>timers.delete(t.id);
   row.querySelector('[data-t-remove]').onclick=()=>{get().timers=get().timers.filter(x=>x.id!==t.id);timers.delete(t.id);change();renderTimers()};
   host.append(row);
  }
  const add=document.createElement('button');add.textContent='Add Countdown';add.disabled=(get().timers?.length??0)>=12;add.onclick=()=>{get().timers??=[];get().timers.push({id:uid(),title:'Countdown',seconds:60});change();renderTimers()};host.append(add);
 }
 function render(){
  const o=get();select.value=mode();el.querySelector('.clock-title').value=o.title??'Clock';if(o.zone&&![...zoneSelect.options].some(x=>x.value===o.zone))fillZones(zoneSelect,o.zone);zoneSelect.value=o.zone??'America/Toronto';if(document.activeElement!==adjustInput)adjustInput.value=adjust()?formatAdjust(adjust()):'';el.querySelector('[data-target]').value=o.target??'';
  el.querySelector('[data-zone-label]').hidden=mode()!=='world';el.querySelector('[data-adjust-box]').hidden=!['local','world','alarm','show','loadout'].includes(mode());el.querySelector('[data-target-label]').hidden=!['alarm','show','loadout'].includes(mode());el.querySelector(':scope > .clock-buttons').hidden=!['alarm','stopwatch'].includes(mode());renderTimers();
  if(secondaryClock){const enabled=!!o.secondaryEnabled;secondaryToggle.value=enabled?'on':'off';secondaryDisplay.hidden=!enabled;secondaryControls.hidden=!enabled;secondaryClock.render()}
  tick();
 }
 select.onchange=()=>{get().mode=select.value;change();render()};
 el.querySelector('.clock-title').oninput=e=>{get().title=e.target.value;change()};
 zoneSelect.onchange=()=>{get().zone=zoneSelect.value;change();tick()};
 const setAdjust=v=>{v=Math.max(-MAX_CLOCK_ADJUST,Math.min(MAX_CLOCK_ADJUST,Math.round(v)));if(v)get().adjust=v;else delete get().adjust;alarmDone=false;adjustInput.value=v?formatAdjust(v):'';adjustInput.setCustomValidity('');change();tick()};
 adjustInput.onchange=()=>{if(adjustInput.value.trim()===''){setAdjust(0);return}const v=parseAdjust(adjustInput.value);if(v===null){adjustInput.setCustomValidity('Use ±HH:MM:SS, Up To 24 Hours, Such As +00:05:00 Or -01:30:00');adjustInput.reportValidity();return}setAdjust(v)};
 for(const b of el.querySelector('[data-adjust-box]').querySelectorAll('[data-nudge]'))b.onclick=()=>setAdjust(adjust()+Number(b.dataset.nudge));
 el.querySelector('[data-adjust-reset]').onclick=()=>setAdjust(0);
 el.querySelector('[data-target]').onchange=e=>{get().target=e.target.value;alarmDone=false;change()};
 el.querySelector('[data-start]').onclick=()=>{if(mode()==='alarm'){alarmArmed=true;alarmDone=false}else if(!running){start=performance.now();running=true}};
 el.querySelector('[data-stop]').onclick=()=>{if(running)elapsed+=(performance.now()-start)/1000;running=false;alarmArmed=false};
 el.querySelector('[data-reset]').onclick=()=>{elapsed=0;running=false;alarmArmed=false;alarmDone=false};
 // Compact play/stop control for the modes that actually run: the stopwatch, or the first countdown timer (the one the big readout shows).
 const firstTimer=()=>(get().timers??[])[0];
 function runState(){
  const m=mode();
  if(m==='stopwatch')return {running,label:running?'Stop stopwatch':'Start stopwatch'};
  if(m==='countdown'){const t=firstTimer();if(!t)return null;const s=timers.get(t.id);return {running:!!s?.running,label:s?.running?`Pause ${t.title||'countdown'}`:`Start ${t.title||'countdown'}`}}
  return null;
 }
 function toggleRun(){
  const m=mode();
  if(m==='stopwatch'){if(running){elapsed+=(performance.now()-start)/1000;running=false}else{start=performance.now();running=true}}
  else if(m==='countdown'){const t=firstTimer();if(!t)return;const s=timers.get(t.id)??{left:t.seconds,running:false,done:false};if(s.running){s.left=Math.max(0,(s.end-performance.now())/1000);s.running=false}else{if(s.done||s.left<=0)s.left=t.seconds;s.end=performance.now()+s.left*1000;s.running=true;s.done=false}timers.set(t.id,s)}
  tick();
 }
 runToggle.onclick=toggleRun;
 function tick(){
  let text='',status='';const m=mode(),o=get(),now=new Date(clockNow()),shift=adjust()?` · Adjusted ${formatAdjust(adjust())}`:'';
  if(m==='local'||m==='world'){try{text=now.toLocaleTimeString('en-CA',m==='world'?{timeZone:o.zone??'America/Toronto'}:{});const z=o.zone??'America/Toronto';status=(m==='world'?`${z.replace(/_/g,' ')} · ${zoneOffset(z,now)}`:'Local Time')+shift}catch{text='Invalid Time Zone'}}
  if(m==='stopwatch'){text=duration(elapsed+(running?(performance.now()-start)/1000:0));status=running?'Running':'Paused'}
  if(['alarm','show','loadout'].includes(m)){
   const target=Date.parse(o.target),left=(target-clockNow())/1000;
   text=Number.isFinite(target)?duration(left):'Set Date And Time';
   if(m==='alarm'){if(alarmArmed&&!alarmDone&&left<=0){alarmDone=true;alert()}status=alarmDone?'ALARM: Time Reached':alarmArmed?'Alarm Armed':'Alarm Off'}
   else status=left<=0?'Target Time Passed':m==='show'?'Until Show':'Until Load Out';status+=shift;
  }
  if(m==='nextcue'){const t=timing();text=Number.isFinite(t.nextCue)?duration(t.nextCue):'Not Available';status=t.label}
  if(m==='timecode'){const t=timecode.get();text=t.text;status=t.status}
  if(m==='countdown'){text='00:00:00';status='Add A Countdown';for(const [index,t]of (o.timers??[]).entries()){const s=timers.get(t.id);const left=s?.running?Math.max(0,(s.end-performance.now())/1000):s?.left??t.seconds;if(s?.running&&left===0){s.running=false;s.left=0;s.done=true;alert()}const output=[...el.querySelector(':scope > .clock-timers').querySelectorAll('[data-timer]')].find(e=>e.dataset.timer===t.id)?.querySelector('output');if(output)output.textContent=(s?.done?'DONE · ':'')+duration(left);if(index===0){text=duration(left);status=(s?.done?'DONE · ':'')+t.title}}}
  valueOutput.textContent=text;statusOutput.textContent=status;
  const rs=runState();runToggle.hidden=!rs;if(rs){runToggle.textContent=rs.running?'■':'▶';runToggle.setAttribute('aria-label',rs.label);runToggle.title=rs.label;runToggle.classList.toggle('is-running',rs.running)}
  if(secondaryClock&&get().secondaryEnabled)secondaryClock.tick();
 }
 if(!secondary){
  const settings=el.querySelector('details'),label=document.createElement('label');label.textContent='Secondary Time';
  secondaryToggle=document.createElement('select');secondaryToggle.setAttribute('aria-label','Show Secondary Clock');secondaryToggle.append(new Option('Off','off'),new Option('On','on'));label.append(secondaryToggle);settings.append(label);
  secondaryControls=document.createElement('div');secondaryControls.className='secondary-clock-settings';
  const heading=document.createElement('h4');heading.textContent='Secondary Clock Settings';secondaryControls.append(heading);
  secondaryClock=createClock({get:()=>get().secondary??(get().secondary={}),change,timecode,timing,secondary:true});
  secondaryClock.el.querySelector('details').open=true;
  secondaryControls.append(secondaryClock.el);settings.append(secondaryControls);
  secondaryDisplay=document.createElement('aside');secondaryDisplay.className='secondary-clock-display';secondaryDisplay.setAttribute('aria-label','Secondary Clock');const secondaryReadout=document.createElement('div');secondaryReadout.className='clock-readout secondary-clock-readout';secondaryReadout.append(secondaryClock.valueOutput,secondaryClock.runToggle);secondaryDisplay.append(secondaryReadout,secondaryClock.statusOutput);el.append(secondaryDisplay);
  secondaryToggle.onchange=()=>{get().secondaryEnabled=secondaryToggle.value==='on';change();render()};
 }
 return {el,render,tick,valueOutput,statusOutput,runToggle,runState,toggleRun};
}
export function createTimecodePanel(timecode){
 const el=document.createElement('section');el.className='workspace-timecode';
 el.innerHTML='<output class="clock-value"></output><p role="status"></p><label>Source<select data-source><option value="internal">Internal Clock</option><option value="midi">External MIDI Time Code</option></select></label><label>Frame Rate<select data-rate></select></label><label>Start Position<input data-position value="00:00:00:00" maxlength="11"></label><div class="widget-row"><button data-locate>Set Position</button><button data-play>Start</button><button data-pause>Pause</button><button data-reset>Reset</button></div><details><summary>MIDI Input Settings</summary><label><input type="checkbox" data-sysex> Receive Full-Frame SysEx (Extra Permission)</label><div class="widget-row"><button data-connect>Connect MIDI Input</button><button data-disconnect>Disconnect</button></div><label>Input<select data-input></select></label></details><label><input type="checkbox" data-chase> Chase Preset Preview</label><p class="widget-hint">Receive Only: MTC Quarter-Frame / Optional Full-Frame. No MIDI, DMX Or Firing Output. Chase Scrubs The Current Preset Only; Faders And Live Input Stay Independent. Audio LTC And Network Timecode Are Not Implemented.</p>';
 const rate=el.querySelector('[data-rate]');TC_RATES.forEach((r,i)=>{const o=document.createElement('option');o.value=i;o.textContent=r.label;rate.append(o)});
 const arm=document.createElement('button');arm.type='button';arm.dataset.arm='';arm.onclick=()=>timecode.arm(!timecode.get().armed);el.querySelector('.widget-row').append(arm);
 const armHint=document.createElement('p');armHint.className='widget-hint';armHint.textContent='Arm Timecode To Enable Chase Preset Preview. Arming Does Not Start The Clock Or Arm Physical Fixtures. Reloading Starts Disarmed.';el.append(armHint);
 el.querySelector('[data-source]').onchange=e=>{if(e.target.value==='internal')timecode.internal();else timecode.connect(el.querySelector('[data-sysex]').checked)};
 rate.onchange=e=>timecode.rate(e.target.value);
 el.querySelector('[data-locate]').onclick=()=>{try{timecode.locate(el.querySelector('[data-position]').value);el.querySelector('[data-position]').setCustomValidity('')}catch(e){el.querySelector('[data-position]').setCustomValidity(e.message);el.querySelector('[data-position]').reportValidity()}};
 for(const action of ['play','pause','reset','disconnect'])el.querySelector(`[data-${action}]`).onclick=()=>timecode[action]();
 el.querySelector('[data-connect]').onclick=()=>timecode.connect(el.querySelector('[data-sysex]').checked);
 el.querySelector('[data-input]').onchange=e=>timecode.select(e.target.value);
 el.querySelector('[data-chase]').onchange=e=>timecode.chase(e.target.checked);
 function render(){const t=timecode.get();el.querySelector('[data-source]').value=t.source;rate.value=t.rate;rate.disabled=t.source!=='internal';for(const a of ['play','pause','reset','locate'])el.querySelector(`[data-${a}]`).disabled=t.source!=='internal';const input=el.querySelector('[data-input]');input.replaceChildren();for(const row of t.inputs){const opt=document.createElement('option');opt.value=row.id;opt.textContent=row.name;input.append(opt)}input.value=t.inputId;el.querySelector('[data-chase]').checked=t.chaseRequested;arm.textContent=t.armed?'Timecode Armed':'Arm Timecode';arm.setAttribute('aria-pressed',String(t.armed));arm.setAttribute('aria-label',t.armed?'Disarm Timecode Preview':'Arm Timecode Preview')}
 function tick(){const t=timecode.get();el.querySelector('output').textContent=t.text;el.querySelector('[role=status]').textContent=t.status;rate.value=t.rate}
 timecode.subscribe(render);render();return {el,render,tick};
}
