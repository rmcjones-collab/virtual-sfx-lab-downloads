import {mountDemoEditor} from './demo-editor.js?v=v031-preview-20261004';
import {trialState,startTrial,trialLabel,gateEnabled,PRICES,formatPrice} from './trial.js?v=v031-preview-20261004';
// Progressive enhancement: accessible OS tabs and decorative, non-calibrated art.
const tabs=[...document.querySelectorAll('[role="tab"]')];
function selectPlatform(platform,focus=false){
 for(const tab of tabs){
  const selected=tab.dataset.platform===platform;
  tab.setAttribute('aria-selected',String(selected));tab.tabIndex=selected?0:-1;
  document.getElementById(tab.getAttribute('aria-controls')).hidden=!selected;
  if(selected&&focus)tab.focus();
 }
}
tabs.forEach((tab,index)=>{
 tab.addEventListener('click',()=>selectPlatform(tab.dataset.platform));
 tab.addEventListener('keydown',event=>{
  if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Home','End'].includes(event.key))return;
  event.preventDefault();
  const next=event.key==='Home'?0:event.key==='End'?tabs.length-1:(index+(['ArrowLeft','ArrowUp'].includes(event.key)?-1:1)+tabs.length)%tabs.length;
  selectPlatform(tabs[next].dataset.platform,true);
 });
});
document.querySelectorAll('.guide-jump').forEach(link=>link.addEventListener('click',()=>selectPlatform(link.dataset.platform)));
const licenseDialog=document.getElementById('license-dialog');
document.querySelectorAll('.license-open').forEach(button=>button.addEventListener('click',()=>{
openLicense(button.dataset.platform)}));
function openLicense(kind){
 const mac=kind==='macos',studio=kind==='studio',platform=mac?'macOS':'Windows';
 licenseDialog.querySelector('.license-dialog-head .eyebrow').textContent=studio?'ONE-TIME PURCHASE / FULL STUDIO':'ONE-TIME PURCHASE / ONE COMPUTER';
 document.getElementById('license-title').textContent=studio?'Virtual SFX Lab — Wave Studio full studio':`Vista receiver add-on for ${platform}`;
 document.getElementById('license-platform').textContent=studio?'Web browser':platform;
 licenseDialog.querySelector('.license-facts dd').textContent=studio?'This browser account':'One computer';
 document.getElementById('license-platform-note').textContent=studio
  ?'Unlocks the full Wave Studio module after the seven-day trial: 40 units, 88 presets, virtual faders, cue stacks, layouts and workspaces. The free demo never needs this. Live Vista input additionally needs the receiver add-on.'
  :mac?'Native macOS, Safari and Vista interoperability testing is pending. The current prototype requires Python 3.10+ and is not a signed or notarized app.'
  :'The Windows prototype has worked with same-PC Vista in the development setup. It requires Python 3.10+; the earlier quarantined EXE is not offered.';
 licenseDialog.showModal();
}
document.getElementById('license-close').addEventListener('click',()=>licenseDialog.close());
licenseDialog.addEventListener('click',event=>{
 if(event.target!==licenseDialog)return;
 const box=licenseDialog.getBoundingClientRect();
 if(event.clientX<box.left||event.clientX>box.right||event.clientY<box.top||event.clientY>box.bottom)licenseDialog.close();
});
mountDemoEditor();
// Keep the first screen focused on the demo, without removing support information.
const support=document.querySelector('#landing-support'),header=document.querySelector('.header-inner');
function placeSupport(){
 const contribution=header.querySelector('.contribution-bar'),thanks=header.querySelector('.donor-thanks');
 if(contribution)support.append(contribution);
 if(thanks)support.prepend(thanks);
}
placeSupport();new MutationObserver(placeSupport).observe(header,{childList:true});

// Seven-day full-studio trial: every studio link becomes Start Trial, Open Studio (N days left) or Buy.
const trialDialog=document.getElementById('trial-dialog'),ctas=[...document.querySelectorAll('.studio-cta')],standing=document.getElementById('trial-standing');
const gate=gateEnabled();
function paintCtas(state){
 const arrow='<span aria-hidden="true">↗</span>';
 for(const cta of ctas){
  cta.dataset.state=state.status;
  if(!gate){cta.innerHTML=`Open the full studio ${arrow}`;cta.href='./index.html';continue}
  if(state.status==='none'){cta.innerHTML=`Start 7-day trial ${arrow}`;cta.href='./index.html'}
  else if(state.status==='active'){cta.innerHTML=`Open the full studio <span class="cta-days">· ${trialLabel(state).replace('Trial · ','')}</span> ${arrow}`;cta.href='./index.html'}
  else{cta.innerHTML=`Buy the full studio · ${formatPrice(PRICES.studio)} ${arrow}`;cta.href='#license'}
 }
 if(standing)standing.textContent=!gate?'':state.status==='active'?`Your trial is running — ${trialLabel(state).replace('Trial · ','')}.`:state.status==='expired'?'Your seven-day trial has ended. The demo above stays free.':'';
}
let trial={status:'none',daysLeft:7};
trialState().then(state=>{trial=state;paintCtas(state);if(gate&&state.status==='none'&&new URLSearchParams(location.search).get('studio')==='trial')trialDialog.showModal()}).catch(()=>paintCtas(trial));
ctas.forEach(cta=>cta.addEventListener('click',event=>{
 if(!gate||trial.status==='active')return;
 event.preventDefault();
 if(trial.status==='expired')openLicense('studio');else trialDialog.showModal();
}));
document.getElementById('trial-close').addEventListener('click',()=>trialDialog.close());
trialDialog.addEventListener('click',event=>{if(event.target===trialDialog)trialDialog.close()});
trialDialog.querySelector('[data-demo-expand]').addEventListener('click',()=>trialDialog.close());
document.getElementById('trial-begin').addEventListener('click',async()=>{
 const button=document.getElementById('trial-begin');button.disabled=true;button.textContent='Starting…';
 try{trial=await startTrial();paintCtas(trial);document.getElementById('trial-dialog-status').textContent='Trial started. Opening the studio…';location.assign('./index.html')}
 catch{button.disabled=false;button.textContent='Start the 7-day trial';document.getElementById('trial-dialog-status').textContent='Could not record the trial start. Please try again.'}
});
