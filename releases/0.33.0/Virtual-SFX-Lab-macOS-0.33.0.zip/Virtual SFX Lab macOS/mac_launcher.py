"""Virtual SFX Lab for macOS (Module 1: Wave Studio) — source launcher, Python 3.10+, standard library only."""
import argparse
import ipaddress
import os
import socket
import subprocess
import sys
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parent
WEB = ROOT / "web"


def local_ipv4():
    """Non-loopback IPv4 addresses of this Mac, via ifconfig (no third-party packages)."""
    found = []
    try:
        out = subprocess.run(["ifconfig"], capture_output=True, text=True, timeout=5).stdout
    except (OSError, subprocess.SubprocessError):
        return found
    for line in out.splitlines():
        line = line.strip()
        if line.startswith("inet ") and not line.startswith("inet 127."):
            found.append(line.split()[1])
    return found


CONSOLE_NAMES = {"vista": "Vista", "grandma3": "grandMA3", "grandma2": "grandMA2", "other": "the console"}


def choose_interface(console="vista"):
    addresses = local_ipv4()
    name = CONSOLE_NAMES.get(console, "the console")
    print(f"\nWhich interface does {name} use for sACN output?")
    for i, ip in enumerate(addresses, 1):
        print(f"  {i}. {ip}")
    print(f"  (or type the IPv4 address shown in {name}'s network settings)")
    while True:
        raw = input(f"Interface [{addresses[0] if addresses else '0.0.0.0'}]: ").strip()
        if not raw:
            return addresses[0] if addresses else "0.0.0.0"
        if raw.isdigit() and 1 <= int(raw) <= len(addresses):
            return addresses[int(raw) - 1]
        try:
            ip = ipaddress.IPv4Address(raw)
            if ip.is_loopback or ip.is_multicast:
                raise ValueError()
            return str(ip)
        except ValueError:
            print("Enter a listed number or a local non-loopback IPv4 address.")


def main():
    parser = argparse.ArgumentParser(description="Virtual SFX Lab macOS launcher")
    modes = parser.add_mutually_exclusive_group()
    modes.add_argument("--mode", choices=["preview", "sacn", "artnet"],
                       help="Override the default same-computer Vista sACN mode")
    modes.add_argument("--menu", action="store_true", help="Show preview / sACN / Art-Net / grandMA choices")
    parser.add_argument("--console", choices=["vista", "grandma3", "grandma2", "other"],
                        help="Console preset for the receiver hints and the studio's receiver dialog (default: vista)")
    parser.add_argument("--interface", help="This Mac's multicast interface IPv4")
    parser.add_argument("--universes")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--no-browser", action="store_true")
    args = parser.parse_args()
    print("\nVIRTUAL SFX LAB FOR macOS | MODULE 1: WAVE STUDIO | RECEIVE-ONLY VISUALIZER")
    print("Keep physical flame hardware disconnected from the rehearsal network.")
    if not (WEB / "welcome.html").is_file():
        raise SystemExit("Missing web folder. Extract the entire ZIP into a new folder and launch again.")
    mode = args.mode or "sacn"
    console = args.console or "vista"
    if args.menu:
        mode = None
        print("\n1. Manual preview (demo + full studio, no receiver / no network input)")
        print("2. Live sACN from Vista 3 (recommended with Vista on the same Mac)")
        print("3. Live Art-Net from Vista 3 (Vista on a separate computer)")
        print("4. Live sACN from grandMA3 (console or onPC with MA hardware)")
        print("5. Live sACN from grandMA2 (console or onPC with MA hardware; Final or Draft)")
        print("6. Live Art-Net from grandMA3 / grandMA2 (console on a separate computer)")
        print("7. Live sACN from another console or software")
        choices = {"1": ("preview", "vista"), "2": ("sacn", "vista"), "3": ("artnet", "vista"),
                   "4": ("sacn", "grandma3"), "5": ("sacn", "grandma2"), "6": ("artnet", "grandma3"),
                   "7": ("sacn", "other"), "": ("sacn", "vista")}
        while mode is None:
            picked = choices.get(input("Choose [2]: ").strip())
            if picked is None:
                print("Please enter 1 to 7.")
            else:
                mode, console = picked
                if picked == ("artnet", "grandma3"):
                    answer = input("grandMA3 or grandMA2? [3]: ").strip()
                    console = "grandma2" if answer == "2" else "grandma3"
    url = f"http://127.0.0.1:{args.port}/welcome.html"
    if mode == "preview":
        # Plain local static server: the demo landing page first, full studio and manual one click away.
        print(f"\nPreview server: {url}\nKeep this window open. Press Ctrl+C to stop.")
        if not args.no_browser:
            webbrowser.open(url)
        os.execv(sys.executable, [sys.executable, "-m", "http.server", "--bind", "127.0.0.1",
                                  "--directory", str(WEB), str(args.port)])
    interface = args.interface
    if mode == "sacn" and interface is None:
        print(f"\n{CONSOLE_NAMES.get(console, 'CONSOLE').upper()} sACN PRESET: sACN input on UDP 5568 (E1.31 Final and grandMA2 Draft, multicast or unicast).")
        print("Art-Net UDP 6454 is not opened; no node discovery is required.")
        interface = choose_interface(console)
    universes = args.universes or ("1,2,3,4" if mode == "sacn" else "0,1,2,3")
    if mode == "sacn":
        print(f"\nSubscriptions (one-based): {universes}")
        print("Match the virtual fixtures' universe and start addresses to the console; console output steps print below.")
        print("The browser opens on the demo page; Open the full studio, then select Live Input. Keep Terminal open.")
    command = [sys.executable, "-u", str(ROOT / "receiver.py"), "--protocol", mode, "--console", console, "--port", str(args.port)]
    if mode == "sacn":
        command += ["--interface", interface or "0.0.0.0"]
    if universes:
        command += ["--universes", universes]
    if args.no_browser:
        command += ["--no-browser"]
    # Replace the launcher so Ctrl+C / Terminal lifecycle applies directly to the receiver.
    os.execv(sys.executable, command)


if __name__ == "__main__":
    try:
        main()
    except (KeyboardInterrupt, EOFError):
        print("\nVirtual SFX Lab closed.")
        sys.exit(130)
