// Only buttons captured from the application's own panels can be shortcut targets.
// Stored data contains IDs, anchors and pixel sizes — never selectors, code, markup or URLs.
const stopToggleIds=new Set(['layout-chase','layout-record','play']);
export const isProtectedPanelAction=id=>stopToggleIds.has(id.replace(/^shortcut-/,''))||/release|stop|zero|panic/i.test(id);
const protectedAction=isProtectedPanelAction;
const ID=/^[a-zA-Z][\w-]{0,99}$/;
export const BUTTON_SIZE_LIMITS={w:[24,800],h:[20,300]};
// Our own nodes never count when addressing panel structure, so anchors stay stable
// no matter which buttons have been moved away from their original spots.
const SKIP='[data-custom-button],.custom-button-row,.panel-shortcuts,.panel-button-editor,.button-drop-marker,.button-size-popover';
// Containers the app rebuilds; a new row is placed beside them, never inside them.
const DYNAMIC='#preset-list,#mobile-stage-sequences,.fuel-panel,.chat-log,.workspace-notebook,.panel-mirror,.panel-shortcuts,svg,canvas,select,datalist,textarea,input';
const kids=n=>[...n.children].filter(c=>!c.matches(SKIP));
const clamp=(v,[lo,hi])=>Math.round(Math.min(hi,Math.max(lo,v)));
function vertical(p){
 const s=getComputedStyle(p);
 if(/^(block|flow-root|list-item)$/.test(s.display))return true;
 if(s.display.includes('flex'))return s.flexDirection.startsWith('column');
 if(s.display.includes('grid'))return s.gridTemplateColumns.trim().split(/\s+/).length<=1;
 return false;
}
export function mountPanelButtons({root,itemFor,editing,changed}){
 const catalog=new Map(),homes=new Map();let drag=null,dialog=null,popover=null,built=[];
 const originalSelector='.workspace-card-content button[id],.mobile-control-body button[id]';
 // Buttons that never become shortcut targets: hold-to-flash keys, board squares, fixture chips and our own chrome.
 const NEVER='.flash-key,.chess-square,[data-fixture],.fixture,.stage-fixture,[data-workspace-control],[data-dock],[data-controls-min],.panel-mirror button,.stage-canvas button,.fixture-strip button,#preset-list button,.chat-log button,.workspace-notebook button,.panel-shortcuts button,.panel-button-editor button,.custom-button-row>button:not([id])';
 // Toolbar and header buttons live outside the panels, so they can be added as shortcuts but not dragged in place.
 const TOOLBAR=['mode-preview','mode-faders','mode-dmx','dmx-setup','vista-layout-download','wave-guide-open','wave-chat-open','wave-checklist-open','wave-camera-open','app-settings','app-screens','app-refresh','workspace-layouts','workspace-catalog-open','workspace-collapse-all','workspace-fullscreen','workspace-screenshot','manual-open','info-mode-toggle','shortcuts','sources','theme','help','enable-virtual-faders'];
 const slug=t=>t.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'').slice(0,40);
 // Labelled groups (role=group / aria-label wrappers) between a button and its panel, outermost first.
 function groupsOf(b){
  const content=b.closest('.workspace-card-content,.mobile-control-body');if(!content)return [];
  const out=[];for(let n=b.parentElement;n&&n!==content;n=n.parentElement){const l=n.getAttribute('aria-label');if(l)out.unshift(l.replace(/\s+/g,' ').trim())}
  return out.slice(-2);
 }
 function identifyDynamicButtons(){
  let changed=false;
  for(const b of document.querySelectorAll('.fader-strip .fader-settings,.fader-strip .fader-capture,[data-fuel-bar]')){
   if(b.id)continue;
   if(b.matches('[data-fuel-bar]'))b.id=`custom-fuel-${b.dataset.fuelBar}`;
   else b.id=`custom-fader-${b.closest('[data-fader]').dataset.fader}-${b.matches('.fader-settings')?'settings':'capture'}`;
   changed=true;
  }
  // Every other panel button gets a stable id from its panel, class and data attribute
  // (or its text), so clocks, timecode, cue stack, macros, notes, screens and chess actions
  // can all be added, moved and resized like the rest.
  for(const b of document.querySelectorAll('.workspace-card-content button:not([id]),.mobile-control-body button:not([id])')){
   if(b.matches(NEVER)||b.closest('.chess-board,dialog'))continue;
   const key=keyFor(b);if(!key)continue;
   const data=[...b.attributes].find(a=>a.name.startsWith('data-')&&a.name!=='data-custom-button');
   const cls=(b.className||'').split(/\s+/).find(c=>c&&!/^(active|primary|secondary|small|ghost)$/.test(c));
   const text=b.getAttribute('aria-label')||b.textContent||b.title;
   let base=`custom-${slug(key)}-${[...groupsOf(b).map(slug),cls,data&&data.name.slice(5),data?.value&&/^[\w-]{1,24}$/.test(data.value)?data.value.replace(/^-/,'minus-'):'',!data&&!cls?slug(text):''].filter(Boolean).map(slug).join('-')}`;
   if(!ID.test(base)||base.endsWith('-'))base=`custom-${slug(key)}-${slug(text)||'button'}`;
   let id=base,n=2;while(document.getElementById(id))id=`${base}-${n++}`;
   b.id=id;changed=true;
  }
  return changed;
 }
 const label=b=>b.getAttribute('aria-label')||(b.innerText||b.textContent).replace(/\s+/g,' ').trim()||b.title||b.id;
 const keyFor=b=>b.closest('.workspace-card')?.dataset.panel||(b.closest('.mobile-stage-control-panel')?'stage':null);
 const blank=()=>({order:[],hidden:[],added:[]});
 const options=key=>{const item=itemFor(key);return item?(item.options.buttonLayout??=blank()):null};
 const buttons=host=>[...host.querySelectorAll('[data-custom-button]')];
 const inRow=b=>!!b.parentElement?.matches('.custom-button-row');
 // Fuel bars are rebuilt whenever the selection changes, so they stay in their own group.
 const movable=b=>!b.matches('[data-fuel-bar]');
 function remember(b){
  if(!homes.has(b)){const anchor=document.createComment(`button:${b.id}`);b.before(anchor);homes.set(b,anchor)}
 }
 function clearSize(b){b.classList.remove('btn-w','btn-h');b.style.removeProperty('--btn-w');b.style.removeProperty('--btn-h')}
 function restore(){
  closePopover();
  for(const [b,anchor] of homes){if(anchor.parentNode)anchor.after(b);b.classList.remove('user-hidden-button','button-dragging');clearSize(b);delete b.dataset.customButton}
  document.querySelectorAll('.panel-shortcuts,.panel-button-editor,.custom-button-row,.button-drop-marker,.button-drag-chip,.button-trash').forEach(n=>n.remove());
  built=[];
 }
 function hosts(){
  return [...root.querySelectorAll('.workspace-card')].map(host=>({host,key:host.dataset.panel,content:host.querySelector('.workspace-card-content')}))
   .concat([...document.querySelectorAll('.mobile-stage-control-panel')].map(host=>({host,key:'stage',content:host.querySelector('.mobile-control-body')})));
 }
 function contentOf(host){return host.querySelector(host.matches('.workspace-card')?'.workspace-card-content':'.mobile-control-body')}
 function applyOrder(list,order){
  const parents=new Set(list.map(b=>b.parentNode));
  for(const parent of parents){
   const siblings=list.filter(b=>b.parentNode===parent);
   const sorted=[...siblings].sort((a,b)=>{
    const ia=order.indexOf(a.dataset.customButton),ib=order.indexOf(b.dataset.customButton);
    return (ia<0?1000+siblings.indexOf(a):ia)-(ib<0?1000+siblings.indexOf(b):ib);
   });
   const anchors=siblings.map(b=>{const a=document.createComment('button-order');b.before(a);return a});
   anchors.forEach((a,i)=>{a.replaceWith(sorted[i])});
  }
 }
 // ---- Anchors: where a custom row lives inside its panel ----
 function pathOf(el,content){
  const out=[];
  for(let n=el;n!==content;n=n.parentElement){
   const p=n?.parentElement;if(!p||!content.contains(p))return null;
   const i=kids(p).indexOf(n);if(i<0)return null;out.unshift(i);
  }
  return out.length&&out.length<=12?out.join('.'):null;
 }
 function refFor(node,content){
  if(node.id&&ID.test(node.id)&&content.querySelectorAll(`#${CSS.escape(node.id)}`).length===1)return `id:${node.id}`;
  const path=pathOf(node,content);return path?`path:${path}`:'bottom';
 }
 function resolve(at,content,host){
  const ref=at?.ref||'bottom',side=at?.side==='before'?'before':'after';
  if(ref.startsWith('home:')){const b=catalog.get(ref.slice(5)),a=b&&homes.get(b);if(a?.isConnected&&host.contains(a))return {node:a,side:'after'}}
  else if(ref.startsWith('id:')){const n=content.querySelector(`#${CSS.escape(ref.slice(3))}`);if(n&&!n.matches(SKIP))return {node:n,side}}
  else if(ref.startsWith('path:')){let n=content;for(const i of ref.slice(5).split('.').map(Number)){n=n&&kids(n)[i]}if(n&&n!==content)return {node:n,side}}
  else if(ref==='top'){const s=content.querySelector(':scope>.panel-shortcuts');return s?{node:s,side:'after'}:{parent:content,first:true}}
  return {parent:content};
 }
 function place(row,spot){
  if(spot.node)spot.node[spot.side](row);else if(spot.first)spot.parent.prepend(row);else spot.parent.append(row);
 }
 function sizeOf(o,id){return o?.sizes?.[id]}
 function applySize(b,s){
  clearSize(b);if(!s)return;
  if(s.w){b.classList.add('btn-w');b.style.setProperty('--btn-w',`${s.w}px`)}
  if(s.h){b.classList.add('btn-h');b.style.setProperty('--btn-h',`${s.h}px`)}
 }
 function syncRowCounts(){
  for(const {el} of built){if(!el.isConnected)continue;const n=[...el.children].filter(c=>!c.classList.contains('user-hidden-button')).length;el.style.setProperty('--row-count',Math.max(1,n));el.classList.toggle('row-empty',!n)}
 }
 function sync(){
  for(const b of document.querySelectorAll('[data-shortcut-action]')){
   const original=catalog.get(b.dataset.shortcutAction);
   b.disabled=!original?.isConnected||original.matches(':disabled')||!!original.closest('[inert]');
   if(original){b.textContent=label(original);if(original.hasAttribute('aria-pressed'))b.setAttribute('aria-pressed',original.getAttribute('aria-pressed'))}
  }
 }
 function refresh(){
  const reopen=popover?.dataset.button;
  restore();
  identifyDynamicButtons();
  for(const [id,b] of catalog)if(!b.isConnected)catalog.delete(id);
  for(const [b,a] of homes)if(!a.isConnected)homes.delete(b);
  for(const b of document.querySelectorAll(originalSelector)){
   if(!b.closest('.panel-mirror,.stage-canvas,.fixture-strip')&&!b.matches('[data-fixture],.fixture,.stage-fixture,[data-workspace-control="selector"],.flash-key,.chess-square')&&b.id&&ID.test(b.id)){catalog.set(b.id,b);remember(b);b.dataset.customButton=b.id}
  }
  for(const id of TOOLBAR){const b=document.getElementById(id);if(b&&b.tagName==='BUTTON'&&!b.closest('dialog,.workspace-card-content'))catalog.set(id,b)}
  for(const {host,key,content} of hosts()){
   if(!content)continue;
   const settings=itemFor(key)?.options.buttonLayout??blank();
   const toolbar=document.createElement('div');toolbar.className='panel-button-editor';
   const manage=document.createElement('button');manage.type='button';manage.textContent='Buttons';manage.title='Add, Remove, Move Or Resize Panel Buttons';manage.onclick=()=>open(host,key);
   const hint=document.createElement('span');hint.className='widget-hint';hint.textContent='Drag Buttons Anywhere · Drop On The Bin To Remove · Click Or Drag A Corner To Resize';toolbar.append(manage,hint);
   content.before(toolbar);
   const shortcuts=document.createElement('div');shortcuts.className='panel-shortcuts';shortcuts.setAttribute('aria-label','Custom Panel Buttons');
   for(const action of settings.added){
    if(!catalog.has(action))continue;
    const b=document.createElement('button');b.type='button';b.dataset.shortcutAction=action;b.dataset.customButton=`shortcut-${action}`;
    b.onclick=()=>{
     if(editing())return;
     const target=catalog.get(action);if(target?.isConnected&&!target.matches(':disabled')&&!target.closest('[inert]'))target.click();
    };shortcuts.append(b);
   }
   content.prepend(shortcuts);
   // Resolve every anchor first, then insert rows, then move buttons in.
   const pending=[];
   for(const row of settings.rows??[]){
    const members=row.buttons.map(id=>host.querySelector(`[data-custom-button="${CSS.escape(id)}"]`)).filter(b=>b&&movable(b));
    if(!members.length)continue;
    pending.push({row,members,spot:resolve(row.at,content,host)});
   }
   for(const p of pending){
    const el=document.createElement('div');el.className='custom-button-row';el.dataset.rowId=p.row.id;el.setAttribute('role','group');el.setAttribute('aria-label','Custom Button Row');
    place(el,p.spot);p.el=el;
   }
   for(const p of pending){
    p.members.forEach(m=>p.el.append(m));
    p.el.classList.add(p.el.parentElement&&p.el.parentElement!==content&&!vertical(p.el.parentElement)?'row-inline':'row-block');
    built.push({el:p.el,members:p.members});
   }
   const list=buttons(host);
   for(const b of list){
    b.classList.toggle('user-hidden-button',settings.hidden.includes(b.dataset.customButton)&&!protectedAction(b.dataset.customButton));
    applySize(b,sizeOf(settings,b.dataset.customButton));
   }
   applyOrder(list.filter(b=>!inRow(b)),settings.order);
  }
  syncRowCounts();sync();
  if(reopen&&editing()){const b=document.querySelector(`[data-custom-button="${CSS.escape(reopen)}"]`);if(b)openPopover(b)}
 }
 // Rows the app wiped (by rebuilding a container) hand their buttons back before re-applying.
 function repair(){
  let broken=false;
  for(const {el,members} of built){
   if(el.isConnected)continue;broken=true;
   for(const b of members)if(!b.isConnected){const a=homes.get(b);if(a?.isConnected)a.after(b)}
  }
  return broken;
 }
 function saveOrder(host,key){const o=options(key);if(!o)return;const here=buttons(host).filter(b=>!inRow(b)).map(b=>b.dataset.customButton);o.order=[...o.order.filter(id=>!here.includes(id)),...here].slice(-160);changed()}
 function rowOf(o,id){return o.rows?.find(r=>r.buttons.includes(id))}
 function tidy(o){o.rows=(o.rows||[]).filter(r=>r.buttons.length);if(!o.rows.length)delete o.rows}
 function newRowId(o){let i=(o.rows?.length||0)+1;while(o.rows?.some(r=>r.id===`row${i}`))i++;return `row${i}`}
 function move(host,key,b,target){
  if(!editing()||!target||b===target||b.parentNode!==target.parentNode)return;
  if(inRow(b)){
   const o=options(key),r=o&&rowOf(o,b.dataset.customButton);if(!r)return;
   const a=r.buttons.indexOf(b.dataset.customButton),t=r.buttons.indexOf(target.dataset.customButton);if(a<0||t<0)return;
   r.buttons.splice(a,1);r.buttons.splice(t,0,b.dataset.customButton);changed();refresh();return;
  }
  const list=[...b.parentNode.children],after=list.indexOf(b)<list.indexOf(target);
  target[after?'after':'before'](b);saveOrder(host,key);
 }
 function sendHome(key,id){
  const o=options(key);if(!o)return;
  for(const r of o.rows||[])r.buttons=r.buttons.filter(v=>v!==id);
  tidy(o);changed();refresh();
 }
 function setSize(key,id,next){
  const o=options(key);if(!o)return;
  const s={...(o.sizes?.[id]||{})};
  for(const k of ['w','h']){if(next[k]===undefined)continue;if(next[k]===null||next[k]===''||!Number.isFinite(+next[k]))delete s[k];else s[k]=clamp(+next[k],BUTTON_SIZE_LIMITS[k])}
  o.sizes={...(o.sizes||{})};
  if(Object.keys(s).length)o.sizes[id]=s;else delete o.sizes[id];
  if(!Object.keys(o.sizes).length)delete o.sizes;
  const b=document.querySelector(`[data-custom-button="${CSS.escape(id)}"]`);if(b)applySize(b,o.sizes?.[id]);
  changed();
 }
 // ---- Moving: drop targets ----
 function dropAt(x,y){
  const d=drag,content=d.content;
  const el=document.elementFromPoint(x,y);
  if(!el||!content.contains(el))return null;
  const over=el.closest('[data-custom-button]');
  if(over===d.b)return null;
  if(over&&content.contains(over)&&!over.classList.contains('user-hidden-button')&&movable(over)){
   const r=over.getBoundingClientRect();
   return {kind:'beside',target:over,before:x<r.left+r.width/2,rect:r};
  }
  const rowEl=el.closest('.custom-button-row');
  if(rowEl&&content.contains(rowEl)){
   const items=[...rowEl.children].filter(n=>n!==d.b&&!n.classList.contains('user-hidden-button'));
   const next=items.find(n=>{const r=n.getBoundingClientRect();return x<r.left+r.width/2});
   return {kind:'row',row:rowEl,next,rect:rowEl.getBoundingClientRect()};
  }
  let n=el.closest('button')||el;
  const dyn=n.closest(DYNAMIC);if(dyn&&content.contains(dyn))n=dyn;
  if(n.closest('.panel-shortcuts'))n=n.closest('.panel-shortcuts');
  if(n===content){
   const blocks=kids(content).filter(c=>c.getClientRects().length);
   const below=blocks.find(c=>y<c.getBoundingClientRect().top+c.getBoundingClientRect().height/2);
   if(below)return {kind:'new',node:below,side:'before',rect:below.getBoundingClientRect()};
   const last=blocks.at(-1);return last?{kind:'new',node:last,side:'after',rect:last.getBoundingClientRect()}:{kind:'new',node:null,rect:content.getBoundingClientRect()};
  }
  while(n.parentElement&&n.parentElement!==content&&(!vertical(n.parentElement)||/^inline/.test(getComputedStyle(n).display)||getComputedStyle(n).display==='contents'))n=n.parentElement;
  if(!content.contains(n)||n===content)return null;
  const r=n.getBoundingClientRect();
  return {kind:'new',node:n,side:y<r.top+r.height/2?'before':'after',rect:r};
 }
 function marker(drop){
  let m=document.querySelector('.button-drop-marker');
  if(!drop){m?.remove();return}
  if(!m){m=document.createElement('div');m.className='button-drop-marker';m.setAttribute('aria-hidden','true');document.body.append(m)}
  let box;
  if(drop.kind==='beside'){const r=drop.rect;box={left:(drop.before?r.left:r.right)-2,top:r.top,width:4,height:r.height}}
  else if(drop.kind==='row'){const r=drop.next?drop.next.getBoundingClientRect():drop.rect;box={left:(drop.next?r.left:r.right)-2,top:drop.rect.top,width:4,height:drop.rect.height}}
  else {const r=drop.rect;const y=drop.node?(drop.side==='before'?r.top:r.bottom):r.bottom;box={left:r.left,top:y-2,width:r.width,height:4}}
  Object.assign(m.style,{left:`${box.left}px`,top:`${box.top}px`,width:`${box.width}px`,height:`${box.height}px`});
 }
 function commit(drop){
  const d=drag,o=options(d.key);if(!o||!drop)return;
  const id=d.b.dataset.customButton;
  o.rows=(o.rows||[]).map(r=>({...r,buttons:r.buttons.filter(v=>v!==id)}));
  if(drop.kind==='beside'){
   const tid=drop.target.dataset.customButton;let row=o.rows.find(r=>r.buttons.includes(tid));
   if(!row){
    const at=catalog.get(tid)===drop.target?{ref:`home:${tid}`,side:'after'}:{ref:'top',side:'after'};
    row={id:newRowId(o),at,buttons:[tid]};o.rows.push(row);
   }
   const i=row.buttons.indexOf(tid);row.buttons.splice(drop.before?i:i+1,0,id);
  }else if(drop.kind==='row'){
   const row=o.rows.find(r=>r.id===drop.row.dataset.rowId);if(!row)return;
   const i=drop.next?row.buttons.indexOf(drop.next.dataset.customButton):-1;row.buttons.splice(i<0?row.buttons.length:i,0,id);
  }else{
   const at=drop.node?{ref:refFor(drop.node,d.content),side:drop.side}:{ref:'bottom',side:'after'};
   o.rows.push({id:newRowId(o),at,buttons:[id]});
  }
  o.rows=o.rows.slice(0,40).map(r=>({...r,buttons:r.buttons.slice(0,24)}));
  tidy(o);changed();refresh();
 }
// ---- Trash: pops up while a button is dragged; dropping on it removes the button from the layout ----
 const TRASH_SVG='<svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 7h16"/><path d="M9 7V4h6v3"/><path d="M6 7l1 13h10l1-13"/><path d="M10 11v6M14 11v6"/></svg>';
 function showTrash(d){
  const t=document.createElement('div');t.className='button-trash';t.setAttribute('role','status');
  const locked=protectedAction(d.b.dataset.customButton);t.classList.toggle('locked',locked);
  t.innerHTML=TRASH_SVG;const span=document.createElement('span');span.textContent=locked?'Release / Stop Stays':'Drop To Remove';t.append(span);
  document.body.append(t);
  // Near the visible part of the panel, but never under the pointer where the drag began.
  const r=d.host.getBoundingClientRect(),w=t.offsetWidth,h=t.offsetHeight;
  const top=Math.max(12,r.top+12),bottom=Math.min(innerHeight-12,r.bottom-12)-h,left=Math.max(12,r.left+12),right=Math.min(innerWidth-12,r.right-12)-w;
  const spots=[[right,Math.max(top,bottom)],[right,top],[left,Math.max(top,bottom)],[left,top]];
  const clear=([x,y])=>d.x<x-40||d.x>x+w+40||d.y<y-40||d.y>y+h+40;
  const [x,y]=spots.find(clear)||spots[0];
  t.style.left=`${Math.max(12,x)}px`;t.style.top=`${Math.max(12,y)}px`;
  requestAnimationFrame(()=>t.classList.add('shown'));d.trash=t;
 }
 function overTrash(d,x,y){const t=d.trash;if(!t)return false;const r=t.getBoundingClientRect();const over=x>=r.left-8&&x<=r.right+8&&y>=r.top-8&&y<=r.bottom+8;t.classList.toggle('over',over);return over}
 function removeFromLayout(d){
  const o=options(d.key),id=d.b.dataset.customButton;if(!o||protectedAction(id))return;
  const name=label(d.b);
  for(const r of o.rows||[])r.buttons=r.buttons.filter(v=>v!==id);tidy(o);
  if(d.b.dataset.shortcutAction)o.added=o.added.filter(v=>v!==d.b.dataset.shortcutAction);
  else if(!o.hidden.includes(id))o.hidden=[...o.hidden,id].slice(-160);
  changed();refresh();
  const s=document.getElementById('workspace-save-status');if(s)s.textContent=d.b.dataset.shortcutAction?`Removed Shortcut “${name}”.`:`Removed “${name}”. Restore It From The Panel’s Buttons List.`;
 }
 // ---- Sizing: popover and corner handle ----
 function closePopover(){popover?.remove();popover=null}
 function openPopover(b){
  closePopover();
  const key=keyFor(b),id=b.dataset.customButton;if(!key||!id)return;
  const o=itemFor(key)?.options.buttonLayout,s=sizeOf(o,id)||{},rect=b.getBoundingClientRect();
  popover=document.createElement('div');popover.className='button-size-popover';popover.dataset.button=id;popover.setAttribute('role','dialog');popover.setAttribute('aria-label',`Size: ${label(b)}`);
  const title=document.createElement('strong');title.textContent=label(b);
  const field=(k,text)=>{const l=document.createElement('label');const span=document.createElement('span');span.textContent=text;const input=document.createElement('input');input.type='number';input.inputMode='numeric';input.min=BUTTON_SIZE_LIMITS[k][0];input.max=BUTTON_SIZE_LIMITS[k][1];input.step=1;input.placeholder=`Auto (${Math.round(k==='w'?rect.width:rect.height)})`;input.value=s[k]??'';input.dataset.size=k;
   input.onchange=()=>{setSize(key,id,{[k]:input.value===''?null:input.value});input.value=sizeOf(itemFor(key)?.options.buttonLayout,id)?.[k]??''};l.append(span,input);return l};
  const auto=document.createElement('button');auto.type='button';auto.textContent='Auto Size';auto.onclick=()=>{setSize(key,id,{w:null,h:null});popover.querySelectorAll('input').forEach(i=>i.value='')};
  const home=document.createElement('button');home.type='button';home.textContent='Original Spot';home.disabled=!inRow(b);home.onclick=()=>{closePopover();sendHome(key,id)};
  const done=document.createElement('button');done.type='button';done.textContent='Done';done.onclick=closePopover;
  const note=document.createElement('p');note.className='widget-hint';note.textContent='Pixels. Leave Blank For Auto: Buttons In A Row Share Its Width Equally.';
  const actions=document.createElement('div');actions.className='button-size-actions';actions.append(auto,home,done);
  popover.append(title,field('w','Width'),field('h','Height'),note,actions);document.body.append(popover);
  const pw=popover.offsetWidth,ph=popover.offsetHeight;
  popover.style.left=`${Math.max(8,Math.min(innerWidth-pw-8,rect.left))}px`;
  popover.style.top=`${rect.bottom+ph+8<innerHeight?rect.bottom+6:Math.max(8,rect.top-ph-6)}px`;
  popover.querySelector('input').focus({preventScroll:true});
 }
 function corner(b,e){const r=b.getBoundingClientRect(),zone=Math.min(14,r.width/3,r.height/2);const right=r.right-e.clientX<=zone,bottom=r.bottom-e.clientY<=zone;return right&&bottom?'both':right&&r.right-e.clientX<=6?'w':bottom&&r.bottom-e.clientY<=6?'h':null}
 // ---- Dialog (keyboard-accessible equivalent of drag and resize) ----
 function open(host,key){
  if(!editing())return;
  dialog?.remove();dialog=document.createElement('dialog');dialog.className='button-editor-dialog';
  const h=document.createElement('h2');h.textContent='Panel Buttons';
  const p=document.createElement('p');p.className='widget-hint';p.textContent='Drag Buttons Anywhere In The Panel, Or Use The Arrows To Reorder Within A Group Or Row. Width And Height Are In Pixels; Blank Means Auto. Remove Hides A Button; Restore Brings It Back. Release / Stop Controls Cannot Be Removed. Added Buttons Are Shortcuts To Existing Actions.';
  const list=document.createElement('div');list.className='button-editor-list';
  const pick=document.createElement('select');pick.setAttribute('aria-label','Action To Add');
  // Same wording in several places (Reset, Start…) gets its panel name so the list stays unambiguous.
  const where=b=>{
   const card=b.closest('.workspace-card');if(!card)return b.closest('.mobile-stage-control-panel')?'Layout Controls':'Toolbar';
   const title=card.querySelector('.workspace-grip')?.textContent.replace(/\s+/g,' ').trim()||card.dataset.panel;
   return [title,...groupsOf(b)].join(' · ');
  };
  const counts=new Map();for(const [,b] of catalog)counts.set(label(b),(counts.get(label(b))||0)+1);
  const optionLabel=b=>counts.get(label(b))>1?`${label(b)} · ${where(b)}`:label(b);
  const seen=new Map(),numbered=b=>{const t=optionLabel(b),n=(seen.get(t)||0)+1;seen.set(t,n);return n>1?`${t} (${n})`:t};
  for(const [id,b] of [...catalog].sort((a,b)=>optionLabel(a[1]).localeCompare(optionLabel(b[1]))))pick.append(new Option(numbered(b),id));
  const add=document.createElement('button');add.textContent='Add Button';add.type='button';
  const restoreAll=document.createElement('button');restoreAll.textContent='Reset This Panel’s Buttons';restoreAll.type='button';
  const close=document.createElement('button');close.textContent='Done';close.type='button';close.onclick=()=>dialog.close();
  function draw(){
   list.replaceChildren();
   for(const b of buttons(host)){
    const id=b.dataset.customButton;
    const row=document.createElement('div');row.className='button-editor-row';
    const text=document.createElement('span');text.textContent=label(b)+(inRow(b)?' · Custom Row':'');row.append(text);
    for(const [dir,title] of [[-1,'Move Earlier'],[1,'Move Later']]){
     const arrow=document.createElement('button');arrow.type='button';arrow.textContent=dir<0?'↑':'↓';arrow.setAttribute('aria-label',`${title}: ${label(b)}`);
     const siblings=buttons(host).filter(n=>n.parentNode===b.parentNode),target=siblings[siblings.indexOf(b)+dir];arrow.disabled=!target;
     arrow.onclick=()=>{move(host,key,b,target);draw()};row.append(arrow);
    }
    const s=sizeOf(itemFor(key)?.options.buttonLayout,id)||{};
    for(const k of ['w','h']){const input=document.createElement('input');input.type='number';input.min=BUTTON_SIZE_LIMITS[k][0];input.max=BUTTON_SIZE_LIMITS[k][1];input.placeholder=k==='w'?'W':'H';input.value=s[k]??'';input.className='button-editor-size';input.setAttribute('aria-label',`${k==='w'?'Width':'Height'} In Pixels: ${label(b)}`);input.onchange=()=>{setSize(key,id,{[k]:input.value===''?null:input.value});draw()};row.append(input)}
    if(inRow(b)){const home=document.createElement('button');home.type='button';home.textContent='Home';home.title='Return To Its Original Spot';home.setAttribute('aria-label',`Return ${label(b)} To Its Original Spot`);home.onclick=()=>{sendHome(key,id);draw()};row.append(home)}
    const remove=document.createElement('button');remove.type='button';remove.disabled=protectedAction(id);
    remove.textContent=b.classList.contains('user-hidden-button')?'Restore':'Remove';
    remove.onclick=()=>{if(!editing())return;const o=options(key);
     o.hidden=o.hidden.includes(id)?o.hidden.filter(v=>v!==id):[...o.hidden,id].slice(-160);
     changed();refresh();draw();
    };row.append(remove);list.append(row);
   }
  }
  add.onclick=()=>{if(!editing())return;const o=options(key),id=pick.value;if(catalog.has(id)&&!o.added.includes(id)&&o.added.length<80){o.added.push(id);changed();refresh();draw()}};
  restoreAll.onclick=()=>{if(!editing())return;delete itemFor(key).options.buttonLayout;changed();refresh();draw()};
  dialog.append(h,p,list,pick,add,restoreAll,close);document.body.append(dialog);draw();dialog.showModal();
 }
 // ---- Pointer handling (Customize Workspace only) ----
 document.addEventListener('click',e=>{
  if(editing()&&e.target.closest('[data-custom-button]')){e.preventDefault();e.stopImmediatePropagation()}
 },true);
 document.addEventListener('pointerdown',e=>{
  if(popover&&!e.target.closest('.button-size-popover')&&!e.target.closest('[data-custom-button]'))closePopover();
  const b=e.target.closest('[data-custom-button]');
  if(!editing()||!b||e.button!==0)return;
  e.preventDefault();e.stopImmediatePropagation();
  const key=keyFor(b),host=b.closest('.workspace-card,.mobile-stage-control-panel'),content=host&&contentOf(host);
  if(!host||!key||!content)return;
  const r=b.getBoundingClientRect(),mode=corner(b,e);
  drag={b,key,host,content,x:e.clientX,y:e.clientY,mode:mode?'resize':'move',axis:mode,w:r.width,h:r.height,moved:false,drop:null,pointer:e.pointerId};
  try{b.setPointerCapture?.(e.pointerId)}catch{}
 },true);
 document.addEventListener('pointermove',e=>{
  if(!drag||!editing()||e.pointerId!==drag.pointer)return;e.preventDefault();
  const dx=e.clientX-drag.x,dy=e.clientY-drag.y;
  if(!drag.moved&&Math.hypot(dx,dy)<5)return;
  if(!drag.moved){drag.moved=true;closePopover();if(drag.mode==='move'){drag.b.classList.add('button-dragging');const chip=document.createElement('div');chip.className='button-drag-chip';chip.textContent=label(drag.b);document.body.append(chip);showTrash(drag)}}
  if(drag.mode==='resize'){
   const next={};
   if(drag.axis!=='h')next.w=clamp(drag.w+dx,BUTTON_SIZE_LIMITS.w);
   if(drag.axis!=='w')next.h=clamp(drag.h+dy,BUTTON_SIZE_LIMITS.h);
   drag.size=next;applySize(drag.b,{...sizeOf(itemFor(drag.key)?.options.buttonLayout,drag.b.dataset.customButton),...next});return;
  }
  const chip=document.querySelector('.button-drag-chip');if(chip)Object.assign(chip.style,{left:`${e.clientX+12}px`,top:`${e.clientY+12}px`});
  drag.overTrash=overTrash(drag,e.clientX,e.clientY);
  if(drag.overTrash||!movable(drag.b)){drag.drop=null;marker(null);return}
  drag.drop=dropAt(e.clientX,e.clientY);marker(drag.drop);
  // Keep a long panel moving under the pointer while dragging near its edges.
  const sc=drag.content.closest('.workspace-card-content,.mobile-control-body')||drag.content,cr=sc.getBoundingClientRect();
  if(sc.scrollHeight>sc.clientHeight){if(e.clientY<cr.top+24)sc.scrollTop-=12;else if(e.clientY>cr.bottom-24)sc.scrollTop+=12}
 },{passive:false});
 function end(e){
  if(!drag)return;const d=drag;
  try{d.b.releasePointerCapture?.(d.pointer)}catch{}
  d.b.classList.remove('button-dragging');marker(null);document.querySelectorAll('.button-drag-chip,.button-trash').forEach(n=>n.remove());
  if(e.type==='pointerup'&&editing()){
   if(!d.moved)openPopover(d.b);
   else if(d.mode==='resize'&&d.size)setSize(d.key,d.b.dataset.customButton,d.size);
   else if(d.mode==='move'&&d.overTrash)removeFromLayout(d);
   else if(d.mode==='move'&&d.drop)commit(d.drop);
  }else if(d.mode==='resize')applySize(d.b,sizeOf(itemFor(d.key)?.options.buttonLayout,d.b.dataset.customButton));
  drag=null;
 }
 document.addEventListener('pointerup',end,true);document.addEventListener('pointercancel',end,true);
 document.addEventListener('dblclick',e=>{const b=e.target.closest('[data-custom-button]');if(editing()&&b&&corner(b,e)){e.preventDefault();setSize(keyFor(b),b.dataset.customButton,{w:null,h:null})}},true);
 document.addEventListener('keydown',e=>{if(e.key==='Escape'){if(drag){end({type:'pointercancel'})}else if(popover){closePopover()}}},true);
 window.addEventListener('blur',()=>{if(drag)end({type:'pointercancel'})});
 setInterval(()=>{if(drag)return;if(identifyDynamicButtons()||repair())refresh();else{sync();syncRowCounts()}},150);
 return {refresh,restore};
}
