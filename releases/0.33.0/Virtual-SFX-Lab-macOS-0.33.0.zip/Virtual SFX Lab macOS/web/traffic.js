// First-party page-view beacon. One POST per page load to the studio service, carrying only the
// page name, the referring site's address and a coarse device class. The service keeps a salted
// digest of the visitor identity it already uses for private storage — no cookies, no IP address,
// no user agent and no third-party scripts. Statistics are visible to the site owner only.
const PORT='__PORT_8093__';
const API=PORT.startsWith('__')?'http://127.0.0.1:8093':PORT;
const local=['127.0.0.1','localhost'].includes(location.hostname);
export function recordVisit(page){
 if(navigator.webdriver&&!local)return;
 const w=Math.min(screen.width,screen.height,innerWidth),device=w<700?'phone':w<1100?'tablet':'desktop';
 const body=JSON.stringify({page,referrer:document.referrer||'',device});
 const headers={'Content-Type':'application/json',...(local?{'X-Wave-Dev-Visitor':'local-development'}:{})};
 try{fetch(`${API}/api/traffic`,{method:'POST',headers,body,keepalive:true,signal:AbortSignal.timeout(8000)}).catch(()=>{})}catch{}
}
