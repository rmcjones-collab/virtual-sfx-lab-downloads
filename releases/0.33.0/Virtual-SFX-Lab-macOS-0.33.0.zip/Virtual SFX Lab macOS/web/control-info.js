// Information-mode reference: what each control does, how to use it, where the First Guide covers it
// and which in-app tutorial demonstrates it. Keys are element ids (or `panel:<key>` for a panel).
// `manual` is a page#section inside ./manual/. `tutorial` matches the start of an app-guide title.
const M={top:'part2.html#21-the-three-bars-across-the-top',columns:'part2.html#22-the-three-columns',tools:'part2.html#23-fixture-file-controls',stage:'part2.html#24-the-stage-and-layout-controls',panel:'part2.html#25-anatomy-of-a-panel-and-customize-workspace',library:'part3.html#31-the-sequence-library',stars:'part3.html#32-starring-favourites-as-the-list-scrolls',order:'part3.html#33-ordering-and-timing-favourites-then-saving-the-order-as-a-cue',recordCues:'part3.html#34-recording-cues-from-the-stage',stack:'part3.html#35-building-a-cue-stack',channels:'part4.html#the-x2s-six-channels-say-this-once-show-it-on-the-build-sheet',strip:'part4.html#41-the-fader-strip',takeControl:'part4.html#42-taking-control-of-a-unit',faderSettings:'part4.html#43-settings-flash-keys-and-cue-faders',bank:'part4.html#44-bank-controls-master-and-macros',rear:'part4.html#45-rear-panel-armed-state-direction-and-the-dmx-monitor',live:'part5.html#51-live-input-mode-and-the-receiver-dialog',grandma:'part5.html#56-grandma2-and-grandma3-live-input-and-export',receiver:'part5.html#start-the-receiver',vista:'part5.html#52-vista-side-connect-universes',patch:'part5.html#53-wave-studio-side-dmx-patch',mapping:'part5.html#54-console-mapping-vista-faders-on-wave-studios-faders',export:'part5.html#55-export-for-vista-3-fixture-build-sheet-and-cue-lists',trouble:'part5.html#troubleshooting',demo:'part1.html#11-cold-open-the-hero',looks:'part1.html#12-looks-and-sequences',recordDemo:'part1.html#13-recording-from-the-demo'};
export const CONTROL_INFO={
 // ---- Top bars ----
 'mode-preview':{name:'Presets mode',info:'Mode 1 of 3. The stage is driven by the Sequence Library: pick a look, press Play, and every selected unit performs it. Loop and Auto-next live in the playback bar.',how:'Click Presets, choose a sequence in the library, then Space or Play. Switch to Virtual Faders or Live Input to drive channels yourself.',manual:M.top,tutorial:'Play Presets'},
 'mode-faders':{name:'Virtual Faders mode',info:'Mode 2. Up to 20 on-screen faders drive the X2 channels (angle, speed, ignition, and so on) exactly as a console would. Nothing leaves the browser.',how:'Click Virtual Faders, enable Fader playback in Bank & Mapping, then raise a strip. Settings under each strip sets its DMX address and label.',manual:M.strip,tutorial:'Use Virtual Faders'},
 'mode-dmx':{name:'Live Input mode',info:'Mode 3. The stage follows sACN or Art-Net arriving through the separate local receiver prototype, so a Vista 3 (or any console) can rehearse against the visualizer.',how:'Start the receiver on your machine, connect your console universes, then open Vista & MA Receiver to patch units.',manual:M.live,tutorial:'Vista / Receiver'},
 'dmx-setup':{name:'Vista & MA Receiver',info:'Opens the receiver dialog with tabs for Vista 3, grandMA3 and grandMA2: console output settings (sACN or Art-Net), universe numbering, the local receiver launchers and the patch table that maps incoming channels to virtual units. The desktop receiver has a matching Console preset (Windows drop-down, Mac menu, --console) and the dialog opens on that tab while it runs.',how:'Use it after starting the local receiver with your console preset. Live Input reads from here; Presets and Faders ignore it.',manual:M.live,tutorial:'Vista & MA Receiver'},
 'vista-layout-download':{name:'Vista 3 Layout File',info:'Downloads a ready-made Vista 3 show file (.v3s) containing the Explo X2 Wave Flame fixture layout, so the console side starts patched the same way as the virtual stage.',how:'Save it, open it in Vista 3, then Connect Universes to the receiver.',manual:M.vista},
 'wave-guide-open':{name:'AI Assist',info:'Opens the App Guide: keyword search across the written tutorials and the First Guide manual, optional read-aloud, and answers from your own AI assistant when one is connected.',how:'Type a question or a keyword such as "cue stack" and press Find Tutorial. Connect an assistant under Your AI Assistant for conversational answers.',manual:M.top},
 'wave-chat-open':{name:'Chat',info:'Friends & Chat: private rooms with up to three friends, voice notes, screenshots, calls, screen share and instructor control. Calls are peer-to-peer (WebRTC) and show participants each other\'s network addresses.',how:'Create a profile, exchange friend codes, then create a room.',manual:M.top,tutorial:'Friends, Chat'},
 'wave-checklist-open':{name:'Test Checklist',info:'The colleague test checklist plus any checklists you create. Checking a step records that you tested it; it never performs the step.',how:'Open it, work through a section with a colleague, then Download Results. New Checklist lets you write your own in the same format.',manual:M.top},
 'wave-camera-open':{name:'Camera',info:'Local camera preview for observing a rehearsal room. It is shared only when you join a chat call and press Share Camera In Call.',how:'Pick Front or Rear, Start Camera, allow the browser prompt.',tutorial:'Camera And Stage Video'},
 'app-settings':{name:'Settings',info:'Every setting grouped by category: appearance and workspace, layout and fixtures, flames and patch, playback and faders, fuel, notes, clocks, files and help. Each row jumps to or toggles the real control.',how:'Use it when you cannot remember which panel owns a setting.',manual:M.panel,tutorial:'Settings, Multi-Screen'},
 'app-screens':{name:'Multi-Screen',info:'Chooses a two-, three- or four-screen workflow, instructor view or custom companion windows, and can detect connected monitors (with permission) to place them.',how:'Pick a layout, then Open Monitor for each companion display.',tutorial:'Settings, Multi-Screen'},
 'app-refresh':{name:'Refresh',info:'Saves the workspace and autosave state, then reloads the page. Safer than the browser refresh because nothing in progress is lost.',how:'Use after a long session or when a panel misbehaves.',tutorial:'Settings, Multi-Screen'},
 'customize-workspace':{name:'Customize Workspace',info:'Enters editing mode: drag panel titles to dock or float, resize from a corner, copy panels, rename titles, and open Buttons to add, move, hide or resize any button in a panel.',how:'Press it (or hold Ctrl + Shift for temporary editing), make changes, then Finish Customizing. Revert restores the last saved arrangement.',manual:M.panel,tutorial:'Customize, Move And Resize'},
 'workspace-layouts':{name:'Layouts',info:'Saves and loads named workspace arrangements (desktop, mobile and full-screen are stored separately) and downloads a backup.',how:'Arrange panels, then Layouts → Save As. Load swaps the arrangement without touching fixtures or cues.',manual:M.panel},
 'workspace-catalog-open':{name:'Add Panels',info:'Catalog of every panel (Clock, Notes, Cue Stack, Timecode, Fuel, Chess…) with Show, Copy and visibility toggles. Ctrl + Shift + P.',how:'Tick a panel to add it; use Show to scroll to one already on screen.',manual:M.panel,tutorial:'Rename Panels'},
 'workspace-collapse-all':{name:'Collapse All',info:'Minimizes every visible panel to its title bar, or restores them. Minimized clocks keep ticking in their headers.',manual:M.panel,tutorial:'Rename Panels'},
 'workspace-fullscreen':{name:'Full Screen',info:'A separate full-screen arrangement (Layout, Virtual Faders, Fixture & File Controls by default) with its own Settings, Add Panels and Stack / Columns. Ctrl + Shift + F.',manual:M.panel,tutorial:'Full Screen And Mobile'},
 'workspace-screenshot':{name:'Screenshot',info:'Captures the virtual stage as a PNG (never your desktop). Download it or attach it to the App Guide or a chat. Ctrl + Shift + S.',tutorial:'Screenshot And Attach'},
 'sources':{name:'Reference & notes',info:'Design notes and sources: how the visualizer models the X2 positions, flame widths, DMX footprint and what is intentionally not simulated.',manual:'part5.html#notes-and-sources'},
 'manual-open':{name:'First Guide manual',info:'Five tutorial parts with image callouts: the landing demo, around the studio, sequences and cues, virtual faders, and live input from Vista 3. Opens by itself on start until you untick the box.',how:'Open it any time; Information mode (Ctrl + ?) links each control to the matching section.',manual:'index.html'},
 'shortcuts':{name:'Keyboard shortcuts',info:'The full key list: Space, arrows, H, Delete, [ ], Ctrl + Shift combinations and Ctrl + ? for Information mode.',tutorial:'Keyboard Shortcuts'},
 'info-mode-toggle':{name:'Information mode (Ctrl + ?)',info:'When on, the pointer becomes a help cursor: hovering any control shows what it does, how to use it, the manual section and a tutorial, without triggering it. Clicks are held until you turn it off.',how:'Press Ctrl + ? or this button to toggle. Escape also turns it off.'},
 'theme':{name:'Theme',info:'Switches between the dark stage theme and a light theme. Saved for this browser.'},
 'trial-pill':{name:'Trial status',info:'Days left on the seven-day full-studio trial. The free demo on the landing page keeps working afterwards; the full studio is a one-time purchase (price subject to change, 14-day refund).'},
 // ---- Fixture & File Controls ----
 'add-fixture':{name:'+ Add Flamer',info:'Adds a virtual Explo X2 Wave Flame unit (up to 40). New units inherit the current look and take the next free DMX address.',how:'Add, then drag the unit into place with the layout unlocked.',manual:M.tools,tutorial:'Add And Arrange'},
 'delete-fixtures':{name:'Delete Selected',info:'Removes the selected units from the stage (Delete key does the same). Undo restores them, including their patch and rotation.',manual:M.tools,tutorial:'Add And Arrange'},
 'rotate-ccw':{name:'Rotate −5°',info:'Turns every selected unit 5° counter-clockwise about its base: body, head sweep, guides and flame rotate together while the label stays upright. Hold to keep turning; [ key.',how:'Select one or more units, then click or hold. The readout shows the angle; click it to reset to 0°.',manual:M.stage,tutorial:'Add And Arrange'},
 'rotate-cw':{name:'Rotate +5°',info:'Turns every selected unit 5° clockwise about its base. Hold to keep turning; ] key. Rotation saves with layouts and exports in the Vista fixture sheet.',how:'Select units, click or hold. Click the degree readout to reset.',manual:M.stage,tutorial:'Add And Arrange'},
 'rotate-readout':{name:'Rotation readout',info:'Current mount rotation of the selected units (MIXED when they differ). Clicking resets the selection to 0°.',manual:M.stage},
 'controls-home':{name:'Home',info:'Parks the selected heads at their home angle with emission off, releases any fader, flash or chase reaching them, and stops the layout chase. H key.',how:'Set a home angle in Home Position first (−105° to +105°).',manual:M.tools,tutorial:'Home Button'},
 'mobile-stage-invert':{name:'Invert',info:'Flips the horizontal direction mapping of the selected units (position 1 ↔ 15), matching the Explo manual. The default stage inverts odd units so mirrored pairs sweep towards each other.',manual:M.tools,tutorial:'Add And Arrange'},
 'undo-layout':{name:'Undo',info:'Steps back through layout history: moves, adds, deletes, rotations, spacing and arrange operations. Shares history with Undo in Layout Controls.',manual:M.tools},
 'save-layout':{name:'Save Layout',info:'Downloads a JSON file with fixture positions, rotation, patch, angle limits, home angles and optionally settings, fader labels and preferences.',how:'Choose what to include in the dialog, then save. Keep backups; built-in storage is a prototype.',manual:M.tools,tutorial:'Save Layouts'},
 'load-layout':{name:'Load Layout',info:'Applies a saved layout JSON after validating every field (unknown or out-of-range values are rejected).',manual:M.tools,tutorial:'Save Layouts'},
 'default-layout':{name:'Default Layout',info:'Saves the current fixture layout as your personal reset target, stored privately for this visitor on the server.',how:'Arrange the stage you want to come back to, then press it. Reset Layout restores it.',manual:M.tools,tutorial:'Default Layout And Fit View'},
 'reset-layout':{name:'Reset Layout',info:'Restores your saved default (or the shipped six-unit layout) after confirmation and pauses playback.',manual:M.tools,tutorial:'Default Layout And Fit View'},
 'export-grandma':{name:'Export For grandMA',info:'Downloads a grandMA2 / grandMA3 package: GDTF fixture type, MVR scene with patch and stage positions (grandMA3), fixture-type and layer XML (grandMA2), plus patch, cue, cuelist, cue-contents and fader CSV sheets. GDTF Only saves just the fixture type.',how:'Patch and record cues first, enter the metres the units cover, then export. Import the MVR through Show Creator > Partial Show Read (grandMA3) or the XML through Fixture Types > Import and EditSetup Import (grandMA2); program cues from sheet 04.',manual:M.grandma,tutorial:'Export For grandMA'},
 'export-vista':{name:'Export For Vista 3',info:'Downloads a package for the console: fixture build sheet with patch and mount rotation, cue lists as CSV, fader assignments and programming sheets.',how:'Patch and record cues first, then export. Vista 3 cannot import a native show from this, so the sheets guide manual building.',manual:M.export,tutorial:'Build A Cue Stack'},
 'session-open':{name:'Session Files',info:'Browse saved sessions (prototype server storage): edit, remove or replace actions, then apply a session paused.',manual:M.tools,tutorial:'Save Layouts'},
 'autosave-open':{name:'Autosave',info:'Shows what autosave has stored for this visitor and lets you restore or clear it.',tutorial:'Save Layouts'},
 'recordings-open':{name:'Recordings',info:'Layout videos recorded with Record Layout Video or Ctrl + Shift + R, watermarked "Made with WaveStudio", ready to download.',manual:M.recordDemo},
 // ---- Stage & Layout Controls ----
 'zoom-out':{name:'Zoom out',info:'Zooms the stage view out. Pan by dragging empty space; Fit View resets.',manual:M.stage},
 'zoom-in':{name:'Zoom in',info:'Zooms the stage view in around its centre.',manual:M.stage},
 'zoom-value':{name:'Zoom percent',info:'Type an exact zoom level and press Enter.',manual:M.stage},
 'fit-view':{name:'Fit View',info:'Resets pan and zoom so every unit and its programmed flame envelope is visible, and defines that view as 100%.',manual:M.stage,tutorial:'Default Layout And Fit View'},
 'arrange':{name:'Arrange Row',info:'Lines the selected units up in an evenly spaced row at their average height. Undo reverses it.',manual:M.stage,tutorial:'Add And Arrange'},
 'snap-grid':{name:'Snap To Grid',info:'While dragging, snaps the active unit to 5% layout increments and keeps the group offsets.',manual:M.stage,tutorial:'Add And Arrange'},
 'layout-lock':{name:'Lock / Unlock layout',info:'Locked prevents accidental moves, rotation and spacing changes; selection still works.',manual:M.stage},
 'select-multiple':{name:'Select Multiple',info:'Tap-to-add selection without holding Ctrl or Cmd (useful on touch screens). Drag empty stage to box-select.',manual:M.stage,tutorial:'Select Several Units'},
 'layout-quick-undo':{name:'Undo (Layout Controls)',info:'Same history as Undo in Fixture & File Controls.',manual:M.stage},
 'layout-spacing':{name:'Spacing',info:'Spreads the selected units horizontally around their centre, up to 250% of the current spread.',manual:M.stage,tutorial:'Add And Arrange'},
 'snapshot':{name:'Save Frame',info:'Downloads the current stage frame as a PNG image.',manual:M.stage},
 'layout-chase':{name:'Chase',info:'Visual-only chase across the selected units at a BPM: Forward, Backward or Random. Switches to Presets and pauses ordinary playback. No hardware output.',how:'Select units, press Chase, set BPM with + / − (Shift for ten).',manual:M.stage,tutorial:'Layout Chase'},
 'layout-chase-bpm':{name:'Chase BPM',info:'0 to 480 beats per minute; zero pauses emission. Each beat gates the target\'s preset to 60% of the beat.',tutorial:'Layout Chase'},
 'select-odd-even':{name:'Odd / Even',info:'First press selects odd fixture IDs, the next selects even IDs, handy for mirrored pairs.',tutorial:'Layout Chase'},
 'stage-default-layout':{name:'New Default Layout',info:'Saves the current layout as your reset target (same as Default Layout in Fixture & File Controls).',tutorial:'Default Layout And Fit View'},
 'stage-load-default-layout':{name:'Load Default Layout',info:'Restores your saved default layout and pauses playback.',tutorial:'Default Layout And Fit View'},
 'stage-reset-layout':{name:'Reset Layout',info:'Restores the default layout after confirmation.',tutorial:'Default Layout And Fit View'},
 'layout-record':{name:'Record Layout Video',info:'Records the stage view to a WebM video with the beta watermark. Press again to stop, then open Recordings. Ctrl + Shift + R.',manual:M.recordDemo,tutorial:'Keyboard Shortcuts'},
 'stage-scale':{name:'Fixture scale',info:'Draws the unit bodies at 30–100% so dense stages stay readable; flames are unaffected.'},
 'scrub':{name:'Preview timeline',info:'Scrubs through the current sequence. Drag while paused to inspect a frame.',manual:M.looks},
 'play':{name:'Play / Pause',info:'Starts or pauses preview playback for the current mode. Space does the same.',manual:M.looks,tutorial:'Play Presets'},
 'prev':{name:'Previous cue',info:'Selects the previous sequence (favourites list when that tab is active). Hold to scroll.',tutorial:'Play Presets'},
 'next':{name:'Next cue',info:'Selects the next sequence. Hold to scroll; Auto-next does this automatically when a look ends.',tutorial:'Play Presets'},
 'cue-start':{name:'First cue',info:'Jumps to the start of the active list.',tutorial:'Play Presets'},
 'cue-end':{name:'Last cue',info:'Jumps to the end of the active list.',tutorial:'Play Presets'},
 'restart':{name:'Restart cue',info:'Restarts the current sequence from its first position.',tutorial:'Play Presets'},
 'loop':{name:'Loop',info:'Repeats the stage after the longest documented duration. Auto-next takes priority over Loop.',manual:M.looks},
 'tour':{name:'Auto-next',info:'Advances every fixture through the catalog (or the favourites order) when a look finishes.',manual:M.stars,tutorial:'Play Presets'},
 'speed':{name:'Sequence duration',info:'Seconds for the current sequence; + / − step it and Reset returns to the documented native time.',manual:M.looks},
 // ---- Library and cues ----
 'tab-catalog':{name:'All Sequences',info:'The full documented X2 catalog: single bursts, stepped bursts and continuous waves, each with its native timing.',manual:M.library,tutorial:'Play Presets'},
 'tab-favorites':{name:'Favorites',info:'Your starred sequences in a drag-to-reorder list. Auto-next follows this order when the tab is active.',manual:M.stars,tutorial:'Play Presets'},
 'search':{name:'Find a sequence',info:'Filters the library by number, type or position (for example "wave 1 → 15").',manual:M.library},
 'save-favorite-cue':{name:'Save Order As Cue',info:'Stores the favourites order and timing as a recorded cue for the Cue Recorder and Cue Stack.',manual:M.order,tutorial:'Build A Cue Stack'},
 'record-cue':{name:'Record Selected',info:'Captures the selected units\' current look, angles and timing as a named cue.',manual:M.recordCues,tutorial:'Build A Cue Stack'},
 'update-cue':{name:'Update From Selection',info:'Overwrites the chosen cue with what the selected units are doing now.',manual:M.recordCues},
 'cue-timing':{name:'Timing / Delay',info:'Per-unit delays and fade timing for the chosen cue.',manual:M.recordCues},
 'delete-cue':{name:'Delete Cue',info:'Removes the chosen recorded cue (faders assigned to it are cleared).',manual:M.recordCues},
 'apply-all':{name:'Apply To All',info:'Gives every unit the selected units\' preset.',manual:M.tools},
 // ---- Faders, bank, rear panel ----
 'mobile-fader-plus':{name:'Add fader',info:'Shows another fader strip (up to 20).',manual:M.strip,tutorial:'Use Virtual Faders'},
 'mobile-fader-minus':{name:'Remove fader',info:'Hides the last fader strip; its settings are kept.',manual:M.strip},
 'mobile-fader-assignments':{name:'Assignments',info:'Table of every fader\'s label, DMX address, universe, cue and priority.',manual:M.faderSettings},
 'show-master-fader':{name:'Show Master',info:'Shows or hides the bank master without changing its level.',manual:M.bank,tutorial:'Use Virtual Faders'},
 'bank-enable':{name:'Fader playback',info:'Lets the virtual faders drive the stage. Off keeps the strips editable without output.',manual:M.bank},
 'bank-release':{name:'Release All',info:'Releases every fader, flash and cue hold so the stage returns to preset playback.',manual:M.bank},
 'open-mapping':{name:'Console mapping',info:'Maps incoming console faders (from Vista through the receiver) onto Wave Studio faders.',manual:M.mapping},
 'bank-master-level':{name:'Bank Master',info:'Scales every fader in the bank (0–255).',manual:M.bank},
 'master-zero':{name:'Master Zero',info:'Sets the bank master to 0 instantly.',manual:M.bank},
 'macro-keys':{name:'Keyboard F1–F12',info:'Binds the Macros panel to the function keys. F1 is Release All and F2 Flash All by default.',manual:M.bank},
 'rear-ok':{name:'Mode / OK',info:'Virtual rear panel: enters menus and confirms, as on the physical X2 display.',manual:M.rear},
 'rear-minus':{name:'E / Minus',info:'Virtual rear panel: previous value or menu item.',manual:M.rear},
 'rear-plus':{name:'Light / Plus',info:'Virtual rear panel: next value or display light.',manual:M.rear},
 'rear-esc':{name:'Test / ESC',info:'Virtual rear panel: back out of a menu or run the self-test display.',manual:M.rear},
 'virtual-armed':{name:'Virtual armed state',info:'Simulates the X2 armed switch: unarmed units show no flame regardless of channel values. Purely visual.',manual:M.rear},
 'virtual-dmx-monitor':{name:'Virtual DMX Monitor',info:'Live view of the six channels per unit; tick a channel to take it over manually.',manual:M.rear},
 // ---- Unit inspector ----
 'fixture-min-angle':{name:'Minimum angle',info:'Clamps the head\'s lowest position (−105° = position 1). Sequences never sweep past it.',manual:M.channels},
 'fixture-max-angle':{name:'Maximum angle',info:'Clamps the head\'s highest position (+105° = position 15).',manual:M.channels},
 'reset-angle-limits':{name:'Reset full range',info:'Restores −105° to +105° for the selected units.'},
 'copy-angle-limits':{name:'Copy limits to all',info:'Applies the selected unit\'s angle limits to every unit.'},
 'fixture-nozzle':{name:'Nozzle type',info:'Chooses the modelled nozzle, which changes flame height and spread for the selected units.',manual:M.channels},
 'dmx-universe':{name:'Universe',info:'Universe for the selected unit (port-address for Art-Net, 1-based for sACN).',manual:M.patch},
 'dmx-address':{name:'DMX address',info:'Start address 1–512 of the six-channel footprint. Each address is used once per universe.',manual:M.patch},
 'dmx-patch':{name:'Update patch',info:'Applies the universe and address to the selected units after checking for overlaps.',manual:M.patch},
 'fixture-invert':{name:'Invert',info:'Mirrors the position mapping (1 ↔ 15) for the selected units.',tutorial:'Add And Arrange'},
 'home-angle':{name:'Home angle',info:'Where Home parks the head, −105° to +105°. Saved with the layout.',tutorial:'Home Button'},
 'home-selected':{name:'Home',info:'Parks the selected heads at their home angle and releases their cues (H key).',tutorial:'Home Button'},
 'fixture-name':{name:'Fixture name',info:'Label shown on the stage chip and in exports.'},
 'fixture-x':{name:'X position',info:'Horizontal position as a percentage of the stage width.'},
 'fixture-y':{name:'Y position',info:'Vertical position as a percentage of the stage height.'},
 'remove-fixture':{name:'Remove',info:'Removes the selected unit (Undo restores).'},
 'guides':{name:'Angle guides',info:'Draws the −105° to +105° arc and position ticks around the active unit.',manual:M.stage},
 'path':{name:'Movement path',info:'Shows the sweep the head will travel for the current sequence.',manual:M.stage},
 'size':{name:'Flame scale',info:'Visual-only flame size multiplier; does not change the simulated channel values.'},
 'select-all-fixtures':{name:'Select all',info:'Selects every unit on the stage.',tutorial:'Select Several Units'},
 'clear-selection':{name:'Clear selection',info:'Deselects everything.'},
 'layout-screen-mode':{name:'Layout Screen',info:'Chooses which companion screen shows the layout view.',tutorial:'Settings, Multi-Screen'},
 'button-size':{name:'Button size',info:'Scales every button in the workspace for touch or distance viewing.'},
 // ---- Panels ----
 'panel:stage':{name:'Layout panel',info:'The virtual stage: units, flames, guides and the Layout Controls row (zoom, Fit View, Arrange Row, Snap, Lock, Select Multiple, Undo, Rotate).',manual:M.stage},
 'panel:tools':{name:'Fixture & File Controls',info:'Add, delete, rotate, home and invert units; save, load, default and reset layouts; export for Vista; sessions, autosave and recordings.',manual:M.tools},
 'panel:library':{name:'Sequence Library',info:'The X2 catalog and your favourites. The active cue stays centred as Auto-next advances.',manual:M.library},
 'panel:faders':{name:'Virtual Faders',info:'Up to 20 strips with DMX address, priority, cue assignment and flash keys.',manual:M.strip},
 'panel:bank':{name:'Bank & Mapping Controls',info:'Fader playback enable, virtual universe, Release All and console mapping.',manual:M.bank},
 'panel:master':{name:'Bank Master',info:'Scales the whole fader bank.',manual:M.bank},
 'panel:macros':{name:'Macros',info:'Twelve assignable macro keys (F1–F12) for release, flash and cue actions.',manual:M.bank},
 'panel:record':{name:'Cue Recorder',info:'Record, update, time and delete cues from the stage.',manual:M.recordCues},
 'panel:stack':{name:'Cue Stack',info:'Ordered cue list with GO, Back, Release, Follow and Timecode triggers, exportable as CSV for Vista.',manual:M.stack},
 'panel:rear':{name:'Virtual Rear Panel',info:'The X2\'s rear display and buttons for menu navigation and self-test.',manual:M.rear},
 'panel:monitor':{name:'Virtual DMX Monitor',info:'Channel values per unit with manual override.',manual:M.rear},
 'panel:patch':{name:'DMX Patch',info:'Universe and start address for the selected units.',manual:M.patch},
 'panel:angle':{name:'Angle Limits',info:'Minimum and maximum head positions per unit.',manual:M.channels},
 'panel:fuel':{name:'Fuel Estimates',info:'Per-unit fuel bars with capacity, remaining fluid and consumption by fuel type. Estimates only.',tutorial:'Estimate Fuel'},
 'panel:ma':{name:'MA (grandMA command section)',info:'The key section of a grandMA2 / grandMA3 inside Wave Studio: Go+, Go−, Pause, Off, Store, Update, Fixture, Group, Preset, Cue, Exec, Thru, At, the number pad, Please and the X1–X10 executor keys. Each key does the closest Wave Studio action (Fixture 1 Thru 4 At 30 Please parks four heads at 30°; Store Cue records the selection; X keys start faders). Keys can be pressed from a physical grandMA through the control universe.',how:'Press keys or type MA words on the command line and press Enter (Please). Open Physical grandMA console at the bottom to patch the keys to channels for a real desk.',manual:'part5.html#57-the-ma-panel-a-grandma-command-section-inside-wave-studio',tutorial:'MA Panel'},
 'panel:notes':{name:'Notes',info:'Tabbed notes with drag-to-reorder, scroll settings and export.',tutorial:'Notes And Independent Clocks'},
 'panel:clock':{name:'Clock',info:'Current time, world clock, stopwatch, alarm, countdowns, time to show and next cue; optional secondary clock.',tutorial:'Secondary Clock'},
 'panel:timecode':{name:'Timecode',info:'Internal clock or external MTC via Web MIDI; chases the preset preview at the received position.',tutorial:'Timecode Input'},
 'panel:screen':{name:'Screen Settings',info:'Layout screen assignment, button size, companion monitors.',tutorial:'Settings, Multi-Screen'},
 'panel:selection':{name:'Unit Selection',info:'Select all or clear.',tutorial:'Select Several Units'},
 'panel:units':{name:'Unit List',info:'Chips for every unit; drag across them to select several.',tutorial:'Select Several Units'},
 'panel:home':{name:'Home Position',info:'Home angle and the Home action.',tutorial:'Home Button'},
 'panel:direction':{name:'Nozzle Direction',info:'Direction readout and Home for the selected units.',manual:M.rear},
 'panel:arm':{name:'Virtual Armed State',info:'Simulated armed switch.',manual:M.rear},
 'panel:sequence':{name:'Sequence Information',info:'Describes the current sequence: type, positions and documented timing.',manual:M.library},
 'panel:display':{name:'Preview Guides',info:'Angle guides and movement path toggles.',manual:M.stage},
 'panel:fixture':{name:'Fixture Position & Name',info:'Exact X / Y, name and remove for the selected unit.'},
 'panel:nozzle':{name:'Nozzle Type',info:'Nozzle model for the selected units.',manual:M.channels},
 'panel:scale':{name:'Flame Scale',info:'Visual flame size.'},
 'panel:invert':{name:'Invert',info:'Mirror the position mapping of the selected units.'},
 'panel:browser':{name:'Comet Browser Launcher',info:'Opens a website in a companion window.'},
 'panel:chess':{name:'Chess',info:'A break-time chess board with a built-in engine. Save PGN exports the game.'}
};
// Fixture chips on the stage share one entry.
export const FIXTURE_INFO={name:'Virtual X2 unit',info:'A modelled Explo X2 Wave Flame unit. Click to select, Ctrl-click to add to the selection, drag to move the selected group, arrow keys to nudge (Shift for larger steps). Right-click or long-press for Home, Invert, Fuel, Apply To All and Remove.',manual:M.stage,tutorial:'Add And Arrange'};
export function lookupInfo(el){
 if(!el)return null;
 const card=el.closest('.workspace-card');
 if(el.matches('[data-fixture],.fixture-handle')||/^fixture-\d+$/.test(el.id))return {key:'fixture',...FIXTURE_INFO};
 if(el.id&&CONTROL_INFO[el.id])return {key:el.id,...CONTROL_INFO[el.id]};
 const shortcut=el.dataset?.shortcutAction;if(shortcut&&CONTROL_INFO[shortcut])return {key:shortcut,...CONTROL_INFO[shortcut],viaShortcut:true};
 const strip=el.closest('.fader-strip');
 if(strip){
  if(el.matches('.fader-settings'))return {key:'fader-settings',name:'Fader Settings',info:'DMX priority, label, cue or flash behaviour and the strip\'s own universe and address.',manual:M.faderSettings,tutorial:'Set A Fader'};
  if(el.matches('.fader-capture'))return {key:'fader-capture',name:'Assign selected units',info:'Points this fader at the units currently selected on the stage.',manual:M.takeControl,tutorial:'Use Virtual Faders'};
  if(el.matches('.flash-key'))return {key:'flash-key',name:'Flash key',info:'Hold to flash this fader to full (play flash) or full intensity (sun flash); release to return.',manual:M.faderSettings};
  if(el.matches('input[type=range]'))return {key:'fader-level',name:'Fader level',info:'Drag for 0–255. The number box beside it accepts exact values.',manual:M.strip,tutorial:'Use Virtual Faders'};
  return {key:'fader-strip',name:'Fader strip',info:'One virtual fader: DMX channel, priority, cue assignment, level and flash keys.',manual:M.strip,tutorial:'Use Virtual Faders'};
 }
 if(el.matches('[data-fuel-bar]'))return {key:'fuel-bar',name:'Fuel bar',info:'Estimated fluid remaining for this unit. Click to edit capacity, remaining and consumption.',tutorial:'Estimate Fuel'};
 if(el.closest('#preset-list'))return {key:'preset',name:'Sequence',info:'One documented X2 sequence. Click to apply it to the selected units; the star adds it to favourites.',manual:M.library,tutorial:'Play Presets'};
 if(card&&(el.matches('.workspace-card-head,.workspace-grip')||el.closest('.workspace-card-head'))){const k=`panel:${card.dataset.panel}`;if(CONTROL_INFO[k])return {key:k,...CONTROL_INFO[k],panel:true}}
 if(card&&CONTROL_INFO[`panel:${card.dataset.panel}`])return {key:`panel:${card.dataset.panel}`,...CONTROL_INFO[`panel:${card.dataset.panel}`],inherited:true};
 return null;
}
