// Bring-your-own AI assistant for AI Assist and Information mode.
// The key is kept in this browser only (localStorage) and is sent solely to the provider the user picked.
// Virtual SFX Lab never sees it and never bills for it: usage runs on the user's own account.
const KEY='vsl-ai-assistant';
// Site assistant: the server answers through the Perplexity Agent API with the owner's key (see agent_assist.py).
// Active only when the backend reports it; a visitor's own connected assistant always takes precedence.
const AGENT_PORT='__PORT_8093__',AGENT_API=AGENT_PORT.startsWith('__')?'http://127.0.0.1:8093':AGENT_PORT;
const agentHeaders={'Content-Type':'application/json',...(['127.0.0.1','localhost'].includes(location.hostname)?{'X-Wave-Dev-Visitor':'local-development'}:{})};
const site={available:false,preset:null,checked:false,lastResponseId:null,lastAt:0};
export const siteAssistant=()=>({...site});
export async function checkSiteAssistant(){
 try{const r=await fetch(`${AGENT_API}/api/agent/status`,{signal:AbortSignal.timeout(4000)});const d=r.ok?await r.json():null;site.available=!!d?.available;site.preset=d?.preset||null}
 catch{site.available=false}
 site.checked=true;document.dispatchEvent(new CustomEvent('wave-ai-changed'));return site.available;
}
async function askSite(question,context){
 const body={question,context};
 if(site.lastResponseId&&Date.now()-site.lastAt<15*60*1000)body.previous_response_id=site.lastResponseId;
 let r;try{r=await fetch(`${AGENT_API}/api/agent/ask`,{method:'POST',headers:agentHeaders,body:JSON.stringify(body),signal:AbortSignal.timeout(75000)})}
 catch(e){throw Error(e.name==='TimeoutError'?'The site assistant did not answer in time.':'The site assistant could not be reached.')}
 const d=await r.json().catch(()=>({}));
 if(!r.ok){if(r.status===503&&/not configured/i.test(d.detail||''))site.available=false;throw Error(d.detail||`Site assistant error (${r.status}).`)}
 site.lastResponseId=d.response_id||null;site.lastAt=Date.now();
 const sources=(d.sources||[]).filter(s=>typeof s?.url==='string'&&/^https?:\/\//i.test(s.url));
 return {text:d.text||'',citations:sources.map(s=>s.url),sources,model:d.model,site:true};
}
export function resetSiteConversation(){site.lastResponseId=null}
export const PROVIDERS={
 perplexity:{name:'Perplexity (recommended)',model:'fast',signup:'https://www.perplexity.ai/',keys:'https://console.perplexity.ai/project/keys',docs:'https://docs.perplexity.ai/docs/getting-started/quickstart',note:'Web-grounded answers with sources through the Perplexity Agent API. Create a free Perplexity account, then generate an API key in the API console (usage is billed by Perplexity). Model field: a preset name (fast, low, medium, high, xhigh) or a provider/model id.'},
 openai:{name:'OpenAI',model:'gpt-4o-mini',signup:'https://platform.openai.com/',keys:'https://platform.openai.com/api-keys',docs:'https://platform.openai.com/docs/quickstart',note:'Uses your OpenAI platform account and credit balance.'},
 anthropic:{name:'Anthropic Claude',model:'claude-3-5-haiku-latest',signup:'https://platform.claude.com/',keys:'https://platform.claude.com/settings/keys',docs:'https://docs.anthropic.com/',note:'Uses your Anthropic console account. Browser access must be allowed for the key (the request sets the required header).'},
 gemini:{name:'Google Gemini',model:'gemini-2.0-flash',signup:'https://aistudio.google.com/',keys:'https://aistudio.google.com/app/apikey',docs:'https://ai.google.dev/gemini-api/docs',note:'Uses a Google AI Studio key on your Google account.'},
 custom:{name:'Custom (OpenAI-compatible)',model:'',signup:'',keys:'',docs:'',note:'Any OpenAI-compatible chat endpoint, including a local model server such as Ollama or LM Studio on this machine.'}
};
const SYSTEM=`You are the built-in assistant for Virtual SFX Lab's Wave Studio, a browser visualizer for Explo X2 Wave Flame units (visual only, no physical output). Answer the user's question about using the app in plain, specific steps. Prefer the excerpts from the First Guide manual and the app tutorials supplied as context; when they do not cover something, say so rather than guessing. Never describe how to operate, arm or fire real flame or pyrotechnic equipment. Keep answers under 180 words unless the user asks for more.`;
export function aiConfig(){try{const c=JSON.parse(localStorage.getItem(KEY)||'null');return c&&PROVIDERS[c.provider]&&typeof c.key==='string'?c:null}catch{return null}}
export const aiConnected=()=>!!aiConfig()?.key||site.available;
export const usingSiteAssistant=()=>!aiConfig()?.key&&site.available;
export const aiLabel=()=>{const c=aiConfig();if(c?.key)return `${PROVIDERS[c.provider].name.replace(/ \(.*\)/,'')} · ${c.model||PROVIDERS[c.provider].model}`;return site.available?`Perplexity · site assistant${site.preset?` (${site.preset})`:''}`:''};
export function saveAI({provider,key,model,endpoint}){
 if(!PROVIDERS[provider])throw Error('Unknown provider');
 key=String(key||'').trim();if(!key||key.length>400||/\s/.test(key))throw Error('Enter the API key exactly as issued (no spaces).');
 model=String(model||'').trim().slice(0,120)||PROVIDERS[provider].model;
 if(provider==='custom'){
  let u;try{u=new URL(String(endpoint||'').trim())}catch{throw Error('Enter the full endpoint URL, e.g. https://host/v1/chat/completions')}
  const local=/^(localhost|127\.0\.0\.1|\[::1\])$/.test(u.hostname);
  if(u.protocol!=='https:'&&!(u.protocol==='http:'&&local))throw Error('Custom endpoints must use https:// (http:// is allowed only for localhost).');
  if(!model)throw Error('Enter the model name your endpoint expects.');
  endpoint=u.href;
 }else endpoint='';
 const cfg={provider,key,model,endpoint,saved:new Date().toISOString()};
 localStorage.setItem(KEY,JSON.stringify(cfg));document.dispatchEvent(new CustomEvent('wave-ai-changed'));return cfg;
}
export function clearAI(){localStorage.removeItem(KEY);document.dispatchEvent(new CustomEvent('wave-ai-changed'))}
async function request(url,init,timeout=45000){
 const r=await fetch(url,{...init,signal:AbortSignal.timeout(timeout)}).catch(e=>{throw Error(e.name==='TimeoutError'?'The AI service did not answer in time.':'Could not reach the AI service. If this is a browser (CORS) block, the provider does not allow direct browser calls; try another provider or a local endpoint.')});
 const text=await r.text();let data=null;try{data=JSON.parse(text)}catch{}
 if(!r.ok){const msg=data?.error?.message||data?.error?.type||data?.message||data?.detail||text.slice(0,200)||r.statusText;throw Error(`${r.status}: ${msg}`.slice(0,300))}
 return data;
}
// Ask the connected assistant. `context` is plain text (manual excerpts + tutorial steps) assembled by the caller.
export async function askAI(question,context='',{maxTokens=600}={}){
 const cfg=aiConfig();
 if(!cfg?.key){if(site.available)return askSite(question,context);throw Error('No AI assistant is connected.')}
 const user=(context?`Context from the Wave Studio manual and tutorials:\n\n${context}\n\n`:'')+`Question: ${question}`;
 const model=cfg.model||PROVIDERS[cfg.provider].model;
 if(cfg.provider==='anthropic'){
  const d=await request('https://api.anthropic.com/v1/messages',{method:'POST',headers:{'content-type':'application/json','x-api-key':cfg.key,'anthropic-version':'2023-06-01','anthropic-dangerous-direct-browser-access':'true'},body:JSON.stringify({model,max_tokens:maxTokens,system:SYSTEM,messages:[{role:'user',content:user}]})});
  return {text:(d.content||[]).map(c=>c.text||'').join('\n').trim(),citations:[]};
 }
 if(cfg.provider==='gemini'){
  const d=await request(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`,{method:'POST',headers:{'content-type':'application/json','x-goog-api-key':cfg.key},body:JSON.stringify({systemInstruction:{parts:[{text:SYSTEM}]},contents:[{role:'user',parts:[{text:user}]}],generationConfig:{maxOutputTokens:maxTokens}})});
  return {text:(d.candidates?.[0]?.content?.parts||[]).map(p=>p.text||'').join('\n').trim(),citations:[]};
 }
 if(cfg.provider==='perplexity'){
  // Agent API: a preset name bundles model, tools and limits; anything else is treated as a provider/model id.
  const preset=/^(fast|low|medium|high|xhigh)$/.test(model),body={instructions:SYSTEM,input:user,max_output_tokens:maxTokens,tools:[{type:'web_search',search_context_size:'low',max_results:6}]};
  if(preset)body.preset=model;else body.model=model;
  const d=await request('https://api.perplexity.ai/v1/agent',{method:'POST',headers:{'content-type':'application/json',authorization:`Bearer ${cfg.key}`},body:JSON.stringify(body)});
  const text=(d.output||[]).filter(o=>o.type==='message').flatMap(o=>o.content||[]).filter(c=>c.type==='output_text').map(c=>c.text).join('').trim();
  const seen=new Set(),sources=[];
  const ok=u=>typeof u==='string'&&/^https?:\/\//i.test(u)&&!seen.has(u);
  for(const o of d.output||[]){if(o.type==='search_results')for(const r of o.results||[])if(ok(r.url)){seen.add(r.url);sources.push({url:r.url,title:r.title||r.url,date:r.date})}else if(o.type==='message')for(const c of o.content||[])for(const a of c.annotations||[])if(ok(a.url)){seen.add(a.url);sources.push({url:a.url,title:a.title||a.url})}}
  return {text,citations:sources.map(x=>x.url).slice(0,8),sources};
 }
 const url=cfg.provider==='openai'?'https://api.openai.com/v1/chat/completions':cfg.endpoint;
 const d=await request(url,{method:'POST',headers:{'content-type':'application/json',authorization:`Bearer ${cfg.key}`},body:JSON.stringify({model,max_tokens:maxTokens,messages:[{role:'system',content:SYSTEM},{role:'user',content:user}]})});
 const text=(d.choices?.[0]?.message?.content??'').toString().trim();
 const citations=Array.isArray(d.citations)?d.citations.filter(c=>typeof c==='string'&&/^https?:\/\//.test(c)).slice(0,8):(d.search_results||[]).map(s=>s.url).filter(Boolean).slice(0,8);
 return {text,citations};
}
export async function testAI(){const r=await askAI('Reply with the single word OK.','',{maxTokens:40});if(!r.text)throw Error('The service answered without text.');return r.text}
// Perplexity as the search engine: no key needed, opens a new tab with the question.
export const perplexitySearchURL=q=>`https://www.perplexity.ai/search?q=${encodeURIComponent(q.slice(0,500))}`;
