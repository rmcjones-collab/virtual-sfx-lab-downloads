// Searchable index of the First Guide (./manual/part1-5.html). Pages are fetched from this origin only,
// parsed with DOMParser (never executed) and reduced to plain text per section.
const PARTS=['part1.html','part2.html','part3.html','part4.html','part5.html'];
const PART_TITLES={'part1.html':'Part 1 · The landing-page demo','part2.html':'Part 2 · Around the studio','part3.html':'Part 3 · Sequences and cues','part4.html':'Part 4 · Virtual faders','part5.html':'Part 5 · Live input from Vista 3 and grandMA'};
const STOP=new Set(['the','and','for','with','that','this','from','your','you','are','into','then','than','them','they','its','was','were','will','can','how','what','use','used','using','does','not','but','all','any','one','two','also','when','where','which','have','has','had','our','out','off','set','see','per','via']);
const MANUAL_BASE=new URL('./manual/',import.meta.url);
let loading=null,sections=[];
export const manualHref=(page,id)=>new URL(`${page}${id?`#${id}`:''}`,MANUAL_BASE).href;
export const words=text=>(text.toLowerCase().match(/[a-z0-9][a-z0-9+\-']*/g)??[]).filter(w=>w.length>2&&!STOP.has(w));
const clean=t=>t.replace(/\s+/g,' ').trim();
function parse(page,html){
 const doc=new DOMParser().parseFromString(html,'text/html');
 doc.querySelectorAll('script,style,nav,header,footer').forEach(n=>n.remove());
 const out=[];let current=null;
 const open=(id,title,level)=>{current={page,id,title:clean(title),level,blocks:[]};out.push(current)};
 open('',PART_TITLES[page]||page,1);
 const body=doc.body;
 for(const node of body.querySelectorAll('h1,h2,h3,p,li,td,th,figcaption,dt,dd,pre')){
  if(/^H[123]$/.test(node.tagName)){if(node.id)open(node.id,node.textContent,Number(node.tagName[1]));else if(current)current.title||=clean(node.textContent);continue}
  if(node.closest('h1,h2,h3'))continue;
  const text=clean(node.textContent);if(text.length<12||!current)continue;
  // Table rows read better as "label — description".
  if(node.tagName==='TD'){const row=node.parentElement;if(row&&row.firstElementChild!==node)continue;const cells=[...row.children].map(c=>clean(c.textContent)).filter(Boolean);current.blocks.push(cells.join(' — '));continue}
  if(node.tagName==='TH')continue;
  if(node.tagName==='LI'&&node.querySelector('li'))continue;
  current.blocks.push(text);
 }
 for(const s of out){s.text=(s.title+' '+s.blocks.join(' ')).toLowerCase();s.href=manualHref(s.page,s.id)}
 return out.filter(s=>s.blocks.length);
}
export function loadManualIndex(){
 return loading??=(async()=>{
  const results=await Promise.allSettled(PARTS.map(async page=>{
   const url=new URL(page,MANUAL_BASE);if(url.origin!==location.origin)throw Error('cross-origin');
   const r=await fetch(url.pathname,{cache:'force-cache',signal:AbortSignal.timeout(10000)});if(!r.ok)throw Error(String(r.status));
   return parse(page,await r.text());
  }));
  sections=results.flatMap(r=>r.status==='fulfilled'?r.value:[]);
  if(!sections.length){loading=null;throw Error('The manual could not be loaded. Check your connection and try again.')}
  return sections;
 })();
}
export const manualSections=()=>sections;
export const manualReady=()=>sections.length>0;
function bestBlock(section,terms){
 let best='',bestScore=-1;
 for(const block of section.blocks){
  const lower=block.toLowerCase();const score=terms.reduce((n,t)=>n+(lower.includes(t)?1:0),0);
  if(score>bestScore||(score===bestScore&&block.length<best.length&&score>0)){best=block;bestScore=score}
 }
 return bestScore>0?best:section.blocks[0];
}
// Rank sections by how many distinct query terms they contain (title hits count double).
export function searchManual(query,limit=4){
 const terms=[...new Set(words(query))];if(!terms.length||!sections.length)return [];
 const scored=sections.map(s=>{
  let score=0;for(const t of terms){if(s.text.includes(t))score+=1;if(s.title.toLowerCase().includes(t))score+=1}
  return {s,score};
 }).filter(x=>x.score>0).sort((a,b)=>b.score-a.score||a.s.blocks.length-b.s.blocks.length);
 return scored.slice(0,limit).map(({s,score})=>({page:s.page,part:PART_TITLES[s.page]||s.page,id:s.id,title:s.title,href:s.href,score,snippet:trim(bestBlock(s,terms),260)}));
}
export function trim(text,max){return text.length>max?text.slice(0,max-1).replace(/\s+\S*$/,'')+'…':text}
// Plain-text context for an AI assistant: the most relevant sections, bounded in size.
export function manualContext(query,maxChars=3200){
 const hits=searchManual(query,5);let out='';
 for(const h of hits){const s=sections.find(x=>x.href===h.href);if(!s)continue;const body=trim(s.blocks.join(' '),1200);const chunk=`## ${h.part} — ${h.title}\n${body}\n\n`;if(out.length+chunk.length>maxChars)break;out+=chunk}
 return out;
}
