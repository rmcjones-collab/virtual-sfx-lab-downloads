// Read Aloud with a more natural voice. Picks the most human-sounding voice the browser offers (neural /
// "Natural" / premium voices first), cleans Markdown and citation noise out of the text, speaks sentence by
// sentence with short breaths between them, and lets the listener choose voice, pace and pitch (saved in
// this browser as `vsl-voice`). Everything runs on the device's own speech engine; nothing is sent anywhere.
const KEY='vsl-voice';
const supported=()=>'speechSynthesis' in window&&'SpeechSynthesisUtterance' in window;
// Studio narration: the server (narration.py) or the visitor's own OpenAI key can generate a cloud voice that
// sounds the same on every device. Text is sent to that service only when studio narration is in use.
import {aiConfig} from './ai-connect.js?v=v0330-20261005b';
const NARRATE_PORT='__PORT_8093__',NARRATE_API=NARRATE_PORT.startsWith('__')?'http://127.0.0.1:8093':NARRATE_PORT;
const narrateHeaders={'Content-Type':'application/json',...(['127.0.0.1','localhost'].includes(location.hostname)?{'X-Wave-Dev-Visitor':'local-development'}:{})};
const CLOUD_VOICES=['marin','cedar','coral','sage','nova','shimmer','alloy','ash','ballad','echo','fable','onyx','verse'];
const CLOUD_LABELS={marin:'Marin · warm, clear',cedar:'Cedar · calm, deep',coral:'Coral · bright',sage:'Sage · soft',nova:'Nova · friendly',shimmer:'Shimmer · light',alloy:'Alloy · neutral',ash:'Ash · steady',ballad:'Ballad · gentle',echo:'Echo · even',fable:'Fable · storyteller',onyx:'Onyx · deep',verse:'Verse · expressive'};
const cloud={available:false,voice:'marin',checked:false,lastError:''};
export const studioNarration=()=>({...cloud,byo:byoCloud()});
const byoCloud=()=>{const c=aiConfig();return !!(c?.key&&c.provider==='openai')};
export async function checkStudioNarration(){
 try{const r=await fetch(`${NARRATE_API}/api/narrate/status`,{signal:AbortSignal.timeout(4000)});const d=r.ok?await r.json():null;cloud.available=!!d?.available;cloud.voice=CLOUD_VOICES.includes(d?.voice)?d.voice:'marin'}
 catch{cloud.available=false}
 cloud.checked=true;document.dispatchEvent(new CustomEvent('wave-voice-changed'));return cloud.available;
}
const cloudEligible=()=>prefs.mode!=='device'&&(cloud.available||byoCloud());
const DEFAULTS={voice:'',rate:0.96,pitch:1,gap:260,mode:'auto',cloudVoice:''};
let prefs={...DEFAULTS};try{Object.assign(prefs,JSON.parse(localStorage.getItem(KEY)||'{}'))}catch{}
const savePrefs=()=>{localStorage.setItem(KEY,JSON.stringify(prefs));document.dispatchEvent(new CustomEvent('wave-voice-changed'))};
export const voicePrefs=()=>({...prefs});
export function setVoicePrefs(next){
 if(typeof next.voice==='string')prefs.voice=next.voice.slice(0,120);
 if(['auto','cloud','device'].includes(next.mode))prefs.mode=next.mode;
 if(typeof next.cloudVoice==='string'&&(next.cloudVoice===''||CLOUD_VOICES.includes(next.cloudVoice)))prefs.cloudVoice=next.cloudVoice;
 if(Number.isFinite(next.rate))prefs.rate=Math.min(1.4,Math.max(0.6,next.rate));
 if(Number.isFinite(next.pitch))prefs.pitch=Math.min(1.5,Math.max(0.6,next.pitch));
 savePrefs();
}
// Voices load asynchronously in Chrome; resolve once they exist.
let voicesPromise=null;
export function loadVoices(){
 if(!supported())return Promise.resolve([]);
 return voicesPromise??=new Promise(resolve=>{
  const got=()=>{const v=speechSynthesis.getVoices();if(v.length){resolve(v);return true}return false};
  if(got())return;speechSynthesis.addEventListener('voiceschanged',()=>got(),{once:true});setTimeout(()=>resolve(speechSynthesis.getVoices()),1500);
 });
}
// Human-likeness heuristics: neural / natural / premium engines first, then well-known good system voices,
// then any voice matching the page language. Scores are additive so a local natural voice beats a remote robotic one.
const QUALITY=[/natural/i,/neural/i,/premium/i,/enhanced/i,/online/i,/google/i,/siri/i,/\b(samantha|ava|allison|zoe|aria|jenny|guy|libby|sonia|ryan|karen|daniel|moira|tessa|fiona|serena|oliver)\b/i];
const ROBOTIC=[/espeak/i,/compact/i,/\bfred\b/i,/\balbert\b/i,/zarvox/i,/whisper/i,/novelty/i,/bells/i,/cellos/i,/organ/i,/trinoids/i,/boing/i,/bubbles/i,/bad news/i,/good news/i,/junior/i,/ralph/i,/kathy/i,/eddy/i,/flo/i,/grandma/i,/grandpa/i,/reed/i,/rocko/i,/sandy/i,/shelley/i,/wobble/i,/jester/i,/superstar/i];
export function scoreVoice(v,lang=document.documentElement.lang||navigator.language||'en'){
 let s=0;const name=v.name||'';const base=lang.slice(0,2).toLowerCase();
 if(v.lang?.toLowerCase().startsWith(base))s+=40;if(v.lang?.toLowerCase()===lang.toLowerCase())s+=5;if(/^en-(us|ca)/i.test(v.lang||''))s+=4;
 QUALITY.forEach((re,i)=>{if(re.test(name))s+=30-i*2});
 if(ROBOTIC.some(re=>re.test(name)))s-=60;
 if(v.localService)s+=3;if(v.default)s+=2;
 return s;
}
export async function bestVoice(){const voices=await loadVoices();if(!voices.length)return null;if(prefs.voice){const chosen=voices.find(v=>v.voiceURI===prefs.voice||v.name===prefs.voice);if(chosen)return chosen}return voices.slice().sort((a,b)=>scoreVoice(b)-scoreVoice(a))[0]}
export async function rankedVoices(){const voices=await loadVoices();return voices.slice().sort((a,b)=>scoreVoice(b)-scoreVoice(a))}
// Turn Markdown-ish assistant text into something that reads naturally.
export function speakable(text){
 return String(text||'')
  .replace(/```[\s\S]*?```/g,' code block omitted. ')
  .replace(/https?:\/\/\S+/g,'')                       // URLs are noise when spoken
  .replace(/\[(\d+(?:,\s*\d+)*)\]/g,'')                 // [1], [2, 3] citation markers
  .replace(/[*_`#>]+/g,' ')                              // bold / italics / headings / quotes
  .replace(/^\s*[-•]\s+/gm,'. ')                         // bullets become sentence breaks
  .replace(/^\s*(\d+)[.)]\s+/gm,'Step $1. ')             // numbered steps
  .replace(/\s*[→]\s*/g,' to ').replace(/−/g,'minus ').replace(/\s*\+\s*(?=\d)/g,' plus ').replace(/°/g,' degrees')
  .replace(/\s*\+\s*\?/g,' and question mark').replace(/\s\/\s/g,' or ').replace(/\[\s*and\s*\]/g,'the left and right bracket keys').replace(/\bShift\s*\+\s*/g,'Shift and ').replace(/\bCtrl\s*\+\s*/g,'Control and ').replace(/\bAlt\s*\+\s*/g,'Alt and ')
  .replace(/\bCtrl\b/g,'Control').replace(/\bCmd\b/g,'Command').replace(/\bEsc\b/g,'Escape').replace(/\bsACN\b/g,'S A C N').replace(/\bDMX\b/g,'D M X').replace(/\bX2\b/g,'X two').replace(/\bUI\b/g,'U I').replace(/\bBPM\b/g,'beats per minute').replace(/\bFX\b/g,'effects').replace(/\bVSL\b/g,'Virtual S F X Lab')
  .replace(/ {2,}/g,' ').replace(/\s+([.,;:!?])/g,'$1').replace(/([.!?])\s*\.(\s|$)/g,'$1$2').trim();
}
const sentences=text=>text.match(/[^.!?\n]+[.!?]+["')\]]?|[^.!?\n]+$/gm)?.map(s=>s.trim()).filter(Boolean)||[text];
let current=0,onStateChange=()=>{};
export const onSpeechState=fn=>{onStateChange=fn};
export function stopSpeaking(){current++;stopAudio();if(supported())speechSynthesis.cancel();onStateChange(false)}
let audio=null;
function stopAudio(){if(audio){audio.pause();if(audio.src.startsWith('blob:'))URL.revokeObjectURL(audio.src);audio=null}}
// Split cleaned text into ≤3800-character chunks on sentence boundaries (the API limit is 4096).
function chunks(text,max=3800){const out=[];let cur='';for(const s of sentences(text)){if((cur+' '+s).length>max&&cur){out.push(cur.trim());cur=''}cur+=' '+s}if(cur.trim())out.push(cur.trim());return out}
async function fetchClip(text,token){
 const voice=prefs.cloudVoice||cloud.voice,speed=Math.min(1.3,Math.max(0.7,prefs.rate+0.04));
 let r;
 if(cloud.available){
  r=await fetch(`${NARRATE_API}/api/narrate`,{method:'POST',headers:narrateHeaders,body:JSON.stringify({text,voice,speed}),signal:AbortSignal.timeout(60000)});
  if(!r.ok&&!(r.status===402||r.status===429)&&byoCloud())r=null;   // site unavailable → try the visitor's own key
  else if(!r.ok){const d=await r.json().catch(()=>({}));throw Error(d.detail||`Narration error (${r.status}).`)}
 }
 if(!r){
  const c=aiConfig();
  r=await fetch('https://api.openai.com/v1/audio/speech',{method:'POST',headers:{'content-type':'application/json',authorization:`Bearer ${c.key}`},body:JSON.stringify({model:'gpt-4o-mini-tts',voice,input:text,speed,response_format:'mp3',instructions:'Warm, clear, unhurried narrator for a technician\'s reference app. Natural pauses between sentences and steps; read key names and numbers plainly.'}),signal:AbortSignal.timeout(60000)});
  if(!r.ok){const d=await r.json().catch(()=>({}));throw Error(d.error?.message||`Narration error (${r.status}).`)}
 }
 if(token!==current)return null;
 return URL.createObjectURL(await r.blob());
}
async function speakCloud(parts,token){
 const urls=parts.map(p=>fetchClip(p,token));   // start all requests at once; play in order
 for(const [i,pending] of urls.entries()){
  const url=await pending;if(token!==current||!url){Promise.allSettled(urls).then(rs=>rs.forEach(r=>{if(r.value&&r.value!==url)URL.revokeObjectURL(r.value)}));if(url)URL.revokeObjectURL(url);return}
  await new Promise((resolve,reject)=>{stopAudio();audio=new Audio(url);audio.onended=()=>setTimeout(resolve,i<urls.length-1?120:0);audio.onerror=()=>reject(Error('Playback failed.'));audio.play().catch(reject)});
  stopAudio();
 }
}
export async function speak(text,{lead=''}={}){
 stopSpeaking();const token=current;
 if(cloudEligible()){
  const clean=speakable(text),parts=chunks(lead?`${speakable(lead)}. ${clean}`:clean);
  onStateChange(true);cloud.lastError='';
  try{await speakCloud(parts,token);if(token===current)onStateChange(false);return true}
  catch(e){stopAudio();cloud.lastError=e.message||String(e);document.dispatchEvent(new CustomEvent('wave-voice-changed'));if(token!==current||prefs.mode==='cloud'){onStateChange(false);return false}}
 }
 if(!supported()){onStateChange(false);return false}
 const voice=await bestVoice();if(token!==current)return false;
 const parts=sentences(speakable(text));if(lead)parts.unshift(speakable(lead));
 onStateChange(true);
 for(const [i,part] of parts.entries()){
  if(token!==current)break;
  await new Promise(resolve=>{
   const u=new SpeechSynthesisUtterance(part);if(voice){u.voice=voice;u.lang=voice.lang}u.rate=prefs.rate;u.pitch=prefs.pitch;u.volume=1;
   u.onend=u.onerror=()=>setTimeout(resolve,i<parts.length-1?prefs.gap:0);
   speechSynthesis.speak(u);
  });
 }
 if(token===current)onStateChange(false);
 return true;
}
// Voice chooser for AI Assist: voice list ranked by naturalness, pace and pitch sliders, a Preview button.
export function mountVoiceSettings(host){
 host.innerHTML='<label>Narration<select id="voice-mode"><option value="auto">Studio voice when available, otherwise device voice</option><option value="cloud">Studio voice only</option><option value="device">Device voice only</option></select></label><label id="cloud-voice-label">Studio voice<select id="cloud-voice-select"><option value="">Site default</option></select></label><p class="support-note" id="cloud-note"></p><p class="guide-section-title">Device voice</p><label>Voice<select id="voice-select"><option value="">Most natural available (automatic)</option></select></label><label>Pace <output id="voice-rate-out"></output><input id="voice-rate" type="range" min="0.6" max="1.4" step="0.02"></label><label>Pitch <output id="voice-pitch-out"></output><input id="voice-pitch" type="range" min="0.6" max="1.5" step="0.05"></label><div class="support-row"><button type="button" id="voice-preview">Preview Voice</button><button type="button" id="voice-reset">Reset</button></div><p class="support-note" id="voice-note">Device voices come from your device or browser. For the most human sound, install a “Natural” or “Enhanced” voice in your system settings; Microsoft Edge and recent macOS and Android versions include them.</p>';
 const $=s=>host.querySelector(s),select=$('#voice-select'),rate=$('#voice-rate'),pitch=$('#voice-pitch'),mode=$('#voice-mode'),cloudSelect=$('#cloud-voice-select');
 for(const v of CLOUD_VOICES)cloudSelect.append(new Option(CLOUD_LABELS[v]||v,v));
 const cloudNote=()=>{const byo=byoCloud();if(cloud.available)return `Studio narration is generated on the server (OpenAI ${'gpt-4o-mini-tts'}) and sounds the same on every device. It is part of the full studio with a fair-use allowance; the text being read is sent to the narration service. Clips are cached so repeat reads are instant.${cloud.lastError?` Last error: ${cloud.lastError}`:''}`;if(byo)return `Studio narration uses your connected OpenAI key directly (billed by OpenAI at about US$0.015 per spoken minute).${cloud.lastError?` Last error: ${cloud.lastError}`:''}`;return 'Studio narration is not available right now (the site has no narration key configured). Connect an OpenAI assistant under Your AI Assistant to narrate with your own key, or use the device voice.'};
 const sync=()=>{rate.value=prefs.rate;pitch.value=prefs.pitch;$('#voice-rate-out').textContent=`${Math.round(prefs.rate*100)}%`;$('#voice-pitch-out').textContent=prefs.pitch.toFixed(2);select.value=prefs.voice;mode.value=prefs.mode;cloudSelect.value=prefs.cloudVoice;$('#cloud-note').textContent=cloudNote();$('#cloud-voice-label').hidden=!(cloud.available||byoCloud());if(!supported())$('#voice-note').textContent='This browser has no device voices; only studio narration can read aloud.'};
 mode.onchange=()=>setVoicePrefs({mode:mode.value});cloudSelect.onchange=()=>setVoicePrefs({cloudVoice:cloudSelect.value});document.addEventListener('wave-voice-changed',sync);document.addEventListener('wave-ai-changed',sync);
 if(supported())rankedVoices().then(voices=>{
  for(const v of voices){const tag=QUALITY.slice(0,5).some(re=>re.test(v.name))?' · natural':'';select.append(new Option(`${v.name} (${v.lang})${tag}`,v.voiceURI))}
  if(voices.length)$('#voice-note').textContent=`${voices.length} voice${voices.length===1?'':'s'} available. Automatic picks “${voices[0].name}”. Natural or Enhanced voices sound the most human; install more in your system settings.`;
  sync();
 });
 select.onchange=()=>setVoicePrefs({voice:select.value});rate.oninput=()=>{setVoicePrefs({rate:Number(rate.value)})};pitch.oninput=()=>{setVoicePrefs({pitch:Number(pitch.value)})};
  checkStudioNarration();
 $('#voice-preview').onclick=()=>speak('Hi, I am the Wave Studio assistant. Select a few units, press Play, and watch the flames sweep across the stage. Press Control and question mark any time for Information mode.');
 $('#voice-reset').onclick=()=>{prefs={...DEFAULTS};savePrefs()};
 sync();
}
