import {Chess} from './vendor/chess.js';
import {requestFileSave} from './file-save.js?v=v0330-20261005b';
const pieces={p:'♟',n:'♞',b:'♝',r:'♜',q:'♛',k:'♚'};
const names={p:'Pawn',n:'Knight',b:'Bishop',r:'Rook',q:'Queen',k:'King'};
export function createChessPanel(){
 const el=document.createElement('section');el.className='chess-panel';
 el.innerHTML='<div class="chess-options"><label>Opponent<select data-chess-mode><option value="computer">Computer</option><option value="local">Two Players · Same Device</option></select></label><label>Your Side<select data-chess-side><option value="w">White</option><option value="b">Black</option></select></label><label>Promote To<select data-chess-promote><option value="q">Queen</option><option value="r">Rook</option><option value="b">Bishop</option><option value="n">Knight</option></select></label></div><p class="chess-status" role="status"></p><div class="chess-board" role="group" aria-label="Chessboard"></div><div class="chess-actions"><button type="button" data-chess-new>New Game</button><button type="button" data-chess-undo>Undo Move</button><button type="button" data-chess-flip>Flip Board</button><button type="button" data-chess-export>Save PGN</button></div><p class="widget-hint">Select A Piece, Then A Highlighted Square. Two Players Share This Device. Games Stay In This Tab; Save PGN Before Closing.</p><output class="chess-performance" aria-label="Chess engine performance">Computer: beginner · ready</output><p class="chess-history" aria-label="Recent chess moves"></p>';
 const $=s=>el.querySelector(s),board=$('.chess-board'),status=$('.chess-status');
 $('[data-chess-mode] option[value=local]').textContent='Two Players';
 $('[data-chess-mode]').title='Computer Or Two Players Sharing This Device';
 let game=new Chess(),selected=null,flipped=false,worker=null,workerURL=null,busy=false,token=0,error='',lastPerf='Computer: beginner · ready';
 const mode=()=> $('[data-chess-mode]').value,side=()=> $('[data-chess-side]').value;
 const editable=()=>document.body.classList.contains('workspace-editing');
 const state=()=>({mode:mode(),turn:game.turn(),fen:game.fen(),selected,legal:selected?game.moves({square:selected,verbose:true}).map(m=>m.to):[],busy,status:status.textContent,orientation:flipped?'Black at bottom; files h to a, ranks 1 to 8':'White at bottom; files a to h, ranks 8 to 1',moves:game.history().slice(-12)});
 // Turn-based: elapsed time does not change the board. Do not replace squares
 // between pointer-down and pointer-up when the game test harness advances time.
 function expose(){window.render_game_to_text=()=>JSON.stringify(state());window.advanceTime=async()=>{}}
 function releaseWorker(){worker?.terminate();worker=null;if(workerURL){URL.revokeObjectURL(workerURL);workerURL=null}}
 function stop(){token++;releaseWorker();busy=false}
 async function computer(){
  if(mode()!=='computer'||game.turn()===side()||game.isGameOver()||busy)return;
  busy=true;error='';const id=++token;render();
  try{
   const moduleURL=new URL('./chess-worker.bundle.js',import.meta.url);
   try{worker=new Worker(moduleURL)}
   catch{
    // Shared previews have an opaque origin. Fetch our trusted bundled worker
    // as text, then start it from a same-context blob without cross-origin imports.
    const response=await fetch(moduleURL);if(!response.ok)throw Error('Worker Not Available');
    const code=await response.text();if(id!==token)return;
    workerURL=URL.createObjectURL(new Blob([code],{type:'text/javascript'}));
    worker=new Worker(workerURL);
   }
   worker.onmessage=e=>{
    if(e.data.id!==token)return;
    releaseWorker();busy=false;
    if(e.data.error){error=e.data.error;render();return}
    try{if(e.data.move)game.move(e.data.move)}catch{error='Computer Move Rejected. Undo Or Start A New Game.'}
    lastPerf=`Computer: ${e.data.nodes} positions · ${e.data.ms} ms`;render();
   };
   worker.onerror=()=>{stop();error='Computer Unavailable. Choose Two Players Or Start A New Game To Retry.';render()};
   worker.postMessage({id,fen:game.fen()});
  }catch{if(id!==token)return;stop();error='Computer Unavailable In This Browser. Two-Player Mode Is Available.'}
  render();
 }
 function render(){
  const started=performance.now(),turn=game.turn()==='w'?'White':'Black';
  status.textContent=error||(game.isCheckmate()?`${turn} Is Checkmated. ${turn==='White'?'Black':'White'} Wins.`:game.isStalemate()?'Draw · Stalemate.':game.isThreefoldRepetition()?'Draw · Threefold Repetition.':game.isInsufficientMaterial()?'Draw · Insufficient Material.':game.isDraw()?'Draw.':busy?'Computer Is Thinking…':`${turn} To Move${game.isCheck()?' · Check':''}`);
  const legal=selected?game.moves({square:selected,verbose:true}).map(m=>m.to):[];
  board.replaceChildren();
  const files=flipped?'hgfedcba':'abcdefgh',ranks=flipped?'12345678':'87654321';
  for(const rank of ranks)for(const file of files){
   const sq=file+rank,p=game.get(sq),b=document.createElement('button');b.type='button';b.dataset.square=sq;
   b.className=`chess-square ${(file.charCodeAt(0)+Number(rank))%2?'light':'dark'} ${p?.color==='w'?'white-piece':'black-piece'}`;
   b.classList.toggle('selected',sq===selected);b.classList.toggle('legal',legal.includes(sq));
   b.setAttribute('aria-label',`${sq}${p?` ${p.color==='w'?'White':'Black'} ${names[p.type]}`:' Empty'}${legal.includes(sq)?' Legal Move':''}`);b.setAttribute('aria-pressed',String(sq===selected));
   const glyph=document.createElement('span');glyph.textContent=p?pieces[p.type]:'';glyph.setAttribute('aria-hidden','true');const coordinate=document.createElement('small');coordinate.textContent=sq;b.append(glyph,coordinate);
   b.onclick=()=>select(sq);board.append(b);
  }
  $('[data-chess-undo]').disabled=!game.history().length&&!busy;
  $('[data-chess-side]').disabled=mode()==='local';
  $('.chess-history').textContent=game.history().slice(-12).join(' · ')||'No Moves Yet';
  $('.chess-performance').textContent=`${lastPerf} · render ${(performance.now()-started).toFixed(1)} ms`;
 }
 function select(sq){
  expose();if(editable()||busy||game.isGameOver()||mode()==='computer'&&game.turn()!==side())return;
  if(selected){
   try{
    const move=game.move({from:selected,to:sq,promotion:$('[data-chess-promote]').value});
    if(move){selected=null;error='';render();computer();return}
   }catch{/* Illegal target simply selects a different friendly piece. */}
  }
  selected=game.get(sq)?.color===game.turn()?sq:null;render();
  board.querySelector(`[data-square="${sq}"]`)?.focus({preventScroll:true});
 }
 function reset(){stop();game=new Chess();selected=null;error='';flipped=mode()==='computer'&&side()==='b';render();computer()}
 $('[data-chess-new]').onclick=reset;
 $('[data-chess-mode]').onchange=reset;$('[data-chess-side]').onchange=reset;
 $('[data-chess-undo]').onclick=()=>{stop();error='';game.undo();if(mode()==='computer'&&game.turn()!==side())game.undo();selected=null;render();computer()};
 $('[data-chess-flip]').onclick=()=>{flipped=!flipped;render()};
 $('[data-chess-export]').onclick=()=>requestFileSave(new Blob([game.pgn()],{type:'application/x-chess-pgn'}),'wave-studio-chess.pgn');
 board.addEventListener('keydown',e=>{
  const delta={ArrowLeft:-1,ArrowRight:1,ArrowUp:-8,ArrowDown:8}[e.key];if(!delta)return;
  const buttons=[...board.children],at=buttons.indexOf(e.target.closest('[data-square]')),next=at+delta;
  if(at<0)return;e.preventDefault();
  if(next>=0&&next<64&&(Math.abs(delta)!==1||Math.floor(at/8)===Math.floor(next/8)))buttons[next].focus({preventScroll:true});
 });
 el.addEventListener('keydown',e=>e.stopPropagation());
 el.addEventListener('pointerdown',expose);
 render();expose();
 return {el,render,tick(){},state};
}
