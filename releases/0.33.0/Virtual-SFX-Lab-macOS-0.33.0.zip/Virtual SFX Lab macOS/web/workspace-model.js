import {DEFAULT_SEED} from './default-seed.js?v=v0330-20261005b';
export const PANELS=[
 ['stage','Layout','.stage-live','main',520],
 ['faders','Virtual Faders','.bank-scroll','main',430],
 ['library','Sequence Library','.library','left',620],
 ['tools','Fixture & File Controls','.stage-tools','left',0],
 ['selection','Unit Selection','.selection-tools','left',0],
 ['units','Unit List','.fixture-strip','left',0],
 ['fuel','Fuel Estimates','#selection-fuel','left',150],
 ['screen','Screen Settings','.layout-screen-settings','right',0],
 ['fixture','Fixture Position & Name','.fixture-editor','right',0],
 ['invert','Invert','.invert-setting','right',0],
 ['browser','Comet Browser Launcher',null,'right',270],
 ['sequence','Sequence Information','.catalog-details','right',0],
 ['nozzle','Nozzle Type','.nozzle-editor','right',0],
 ['scale','Flame Scale','.flame-scale-editor','right',0],
 ['angle','Angle Limits','.angle-editor','right',0],
 ['patch','DMX Patch','.patch-editor','right',0],
 ['arm','Virtual Armed State','.virtual-arm','right',0],
 ['direction','Nozzle Direction','.readout:not(.home-panel)','right',0],
 ['home','Home Position','.home-panel','right',0],
 ['rear','Virtual Rear Panel','#rear-panel','right',0],
 ['display','Preview Guides',null,'right',0],
 ['macros','Macros','.macro-panel','main',0],
 ['master','Bank Master','.bank-master','main',300],
 ['record','Cue Recorder','.cue-recorder','main',0],
 ['stack','Cue Stack','#cue-stack','main',440],
 ['bank','Bank & Mapping Controls','.bank-toolbar','main',0],
 ['monitor','Virtual DMX Monitor','#virtual-dmx-monitor','right',0],
 ['notes','Notes',null,'right',220],
 ['clock','Clock',null,'right',250],
 ['timecode','Timecode',null,'right',310],
 ['chess','Chess',null,'right',0],
 ['ma','MA',null,'main',0]
].map(([key,title,selector,zone,height])=>({key,title,selector,zone,height}));
const zones=['left','main','right'];
// Home Position split out of Nozzle Direction in Beta 0.30: older workspaces gain it next to the direction panel.
export function addHomePanel(panels){
 if(panels.some(p=>p.key==='home'))return panels;
 const at=panels.findIndex(p=>p.key==='direction'),direction=panels[at];
 const home=direction?{key:'home',type:'home',zone:direction.zone,span:direction.span,height:0,visible:direction.visible,minimized:direction.minimized,float:direction.float?{x:direction.float.x+24,y:direction.float.y+32,width:direction.float.width}:null,options:{}}:{key:'home',type:'home',zone:'right',span:12,height:0,visible:true,minimized:false,float:null,options:{}};
 panels.splice(at>=0?at+1:panels.length,0,home);return panels;
}
// Cue Stack arrived in Beta 0.30: older workspaces gain it under the Cue Recorder.
export function addStackPanel(panels){
 if(panels.some(p=>p.key==='stack'))return panels;
 const at=panels.findIndex(p=>p.key==='record'),record=panels[at];
 const stack=record?{key:'stack',type:'stack',zone:record.zone,span:record.span,height:440,visible:record.visible,minimized:record.minimized,float:record.float?{x:record.float.x+24,y:record.float.y+48,width:record.float.width}:null,options:{}}:{key:'stack',type:'stack',zone:'main',span:12,height:440,visible:true,minimized:false,float:null,options:{}};
 panels.splice(at>=0?at+1:panels.length,0,stack);return panels;
}
export function addMaPanel(panels,visible=true){
 if(panels.some(p=>p.key==='ma'))return panels;
 panels.push({key:'ma',type:'ma',zone:'main',span:12,height:0,visible,minimized:false,float:null,options:{}});return panels;
}
export const panelType=item=>item.type??item.key;
export const definition=item=>PANELS.find(p=>p.key===panelType(item));
export function defaultProfile(mobile=false,full=false){
 const key=full?(mobile?'fullscreenMobile':'fullscreenDesktop'):(mobile?'mobile':'desktop');
 const profile=structuredClone(DEFAULT_SEED.workspace[key]);
 for(const type of ['invert','browser','chess'])if(!profile.panels.some(p=>p.key===type))profile.panels.push({key:type,type,zone:'right',span:12,height:type==='browser'?270:0,visible:type==='invert'&&!full,minimized:false,float:null,options:{}});
 // Beta 0.33: the MA panel (grandMA command section) joins the main column below the existing panels; full-screen profiles keep it in the catalog.
 addMaPanel(profile.panels,!full);
 addHomePanel(profile.panels);addStackPanel(profile.panels);
 if(full&&!mobile&&Number.isFinite(globalThis.innerWidth)){
  const sx=Math.min(1,innerWidth/DEFAULT_SEED.referenceViewport.width),sy=Math.min(1,innerHeight/DEFAULT_SEED.referenceViewport.height);
  for(const p of profile.panels)if(p.float){p.float.x*=sx;p.float.y=Math.max(60,p.float.y*sy);p.float.width=Math.max(180,p.float.width*sx);p.height=Math.max(p.type==='stage'?380:140,Math.round(p.height*sy))}
  if(innerWidth<1000){
   for(const p of profile.panels)if(p.visible){p.float=null;p.zone='main';p.span=12;if(p.type==='stage')p.height=780}
  }else{
   const stage=profile.panels.find(p=>p.type==='stage'),faders=profile.panels.find(p=>p.type==='faders'),tools=profile.panels.find(p=>p.type==='tools');
   const rightWidth=Math.max(300,faders.float.width);
   faders.float.width=rightWidth;faders.float.x=innerWidth-rightWidth-8;
   stage.float.width=Math.max(380,faders.float.x-stage.float.x-12);
   tools.float.width=Math.min(rightWidth,Math.max(220,tools.float.width));tools.float.x=innerWidth-tools.float.width-8;
  }
 }
 return profile;
}
export const freshWorkspace=()=>({version:2,buttonSize:100,labelAlignment:{desktop:'left',mobile:'center'},desktop:defaultProfile(),mobile:defaultProfile(true),fullscreenDesktop:defaultProfile(false,true),fullscreenMobile:defaultProfile(true,true),notes:'',focus:structuredClone(DEFAULT_SEED.workspace.focus)});
export function validateOptions(raw={},depth=0){
 if(!raw||typeof raw!=='object'||Array.isArray(raw))throw Error('Invalid Panel Options.');
 if(depth&&Object.keys(raw).some(k=>!['mode','zone','target','title','timers','adjust'].includes(k)))throw Error('Invalid Secondary Clock Setting.');
 const out={};
 if(raw.buttonLayout!==undefined){
  const b=raw.buttonLayout,valid=a=>Array.isArray(a)&&a.length<=160&&a.every(id=>typeof id==='string'&&/^[a-zA-Z][\w-]{0,99}$/.test(id))&&new Set(a).size===a.length;
  if(depth||!b||!valid(b.order)||!valid(b.hidden)||!valid(b.added)||Object.keys(b).some(k=>!['order','hidden','added','rows','sizes'].includes(k)))throw Error('Invalid Button Layout.');
  out.buttonLayout={order:[...b.order],hidden:[...b.hidden],added:[...b.added]};
  if(b.rows!==undefined){
   const ref=/^(top|bottom|home:[a-zA-Z][\w-]{0,99}|id:[a-zA-Z][\w-]{0,99}|path:\d{1,3}(\.\d{1,3}){0,11})$/;
   if(!Array.isArray(b.rows)||b.rows.length>40||b.rows.some(r=>!r||typeof r!=='object'||Array.isArray(r)||Object.keys(r).some(k=>!['id','at','buttons'].includes(k))||typeof r.id!=='string'||!/^[a-zA-Z][\w-]{0,39}$/.test(r.id)||!r.at||typeof r.at!=='object'||Object.keys(r.at).some(k=>!['ref','side'].includes(k))||typeof r.at.ref!=='string'||!ref.test(r.at.ref)||!['before','after'].includes(r.at.side)||!valid(r.buttons)||!r.buttons.length||r.buttons.length>24))throw Error('Invalid Button Rows.');
   const all=b.rows.flatMap(r=>r.buttons);if(new Set(all).size!==all.length||new Set(b.rows.map(r=>r.id)).size!==b.rows.length)throw Error('Invalid Button Rows.');
   out.buttonLayout.rows=b.rows.map(r=>({id:r.id,at:{ref:r.at.ref,side:r.at.side},buttons:[...r.buttons]}));
  }
  if(b.sizes!==undefined){
   const e=b.sizes&&typeof b.sizes==='object'&&!Array.isArray(b.sizes)?Object.entries(b.sizes):null,lim={w:[24,800],h:[20,300]};
   if(!e||e.length>160||e.some(([id,v])=>!/^[a-zA-Z][\w-]{0,99}$/.test(id)||!v||typeof v!=='object'||Array.isArray(v)||!Object.keys(v).length||Object.keys(v).some(k=>!lim[k]||!Number.isInteger(v[k])||v[k]<lim[k][0]||v[k]>lim[k][1])))throw Error('Invalid Button Sizes.');
   out.buttonLayout.sizes=Object.fromEntries(e.map(([id,v])=>[id,{...v}]));
  }
 }
 if(raw.adjust!==undefined){if(!Number.isInteger(raw.adjust)||Math.abs(raw.adjust)>86400)throw Error('Invalid Clock Adjustment.');if(raw.adjust)out.adjust=raw.adjust}
 if(raw.follow!==undefined){if(typeof raw.follow!=='boolean')throw Error('Invalid Follow Option.');out.follow=raw.follow}
 if(raw.name!==undefined){if(depth||typeof raw.name!=='string'||raw.name.length>60)throw Error('Invalid Panel Name.');if(raw.name.trim())out.name=raw.name.trim()}
 if(raw.secondaryEnabled!==undefined){if(depth||typeof raw.secondaryEnabled!=='boolean')throw Error('Invalid Secondary Clock.');out.secondaryEnabled=raw.secondaryEnabled}
 if(raw.secondary!==undefined){if(depth)throw Error('Only One Secondary Clock Is Allowed.');out.secondary=validateOptions(raw.secondary,1)}
 if(raw.activeNoteId!==undefined){if(typeof raw.activeNoteId!=='string'||raw.activeNoteId.length>80)throw Error('Invalid Active Note.');out.activeNoteId=raw.activeNoteId}
 for(const key of ['wheelSensitivity','selectionSensitivity'])if(raw[key]!==undefined){if(!Number.isFinite(raw[key])||raw[key]<(key==='wheelSensitivity'?10:0)||raw[key]>300)throw Error('Invalid Note Scroll Sensitivity.');out[key]=raw[key]}
 if(raw.notes!==undefined){
  if(!Array.isArray(raw.notes)||raw.notes.length>16)throw Error('Use Up To 16 Notes Per Panel.');
  const ids=new Set();out.notes=raw.notes.map(n=>{
   if(!n||typeof n.id!=='string'||n.id.length>80||ids.has(n.id)||typeof n.title!=='string'||n.title.length>80||typeof n.body!=='string'||n.body.length>4000)throw Error('Invalid Note.');
   ids.add(n.id);return {id:n.id,title:n.title,body:n.body};
  });
 }
 for(const key of ['mode','zone','target','title'])if(raw[key]!==undefined){
  if(typeof raw[key]!=='string'||raw[key].length>100)throw Error('Invalid Clock Setting.');out[key]=raw[key];
 }
 if(raw.timers!==undefined){
  if(!Array.isArray(raw.timers)||raw.timers.length>12)throw Error('Use Up To 12 Timers.');
  out.timers=raw.timers.map(t=>{if(typeof t.id!=='string'||t.id.length>80||typeof t.title!=='string'||t.title.length>80||!Number.isFinite(t.seconds)||t.seconds<1||t.seconds>604800)throw Error('Invalid Timer.');return {id:t.id,title:t.title,seconds:t.seconds}});
 }
 return out;
}
export function validateWorkspace(raw){
 if(raw===undefined||raw===null)return freshWorkspace();
 if(![1,2].includes(raw.version)||typeof raw.notes!=='string'||raw.notes.length>4000||JSON.stringify(raw).length>500000)throw Error('Invalid Workspace Document.');
 const result=freshWorkspace();
 if(raw.labelAlignment!==undefined){
  if(!raw.labelAlignment||!['desktop','mobile'].every(k=>['left','right','center'].includes(raw.labelAlignment[k])))throw Error('Invalid Panel Label Alignment.');
  result.labelAlignment={desktop:raw.labelAlignment.desktop,mobile:raw.labelAlignment.mobile};
 }
 if(raw.buttonSize!==undefined){if(!Number.isFinite(raw.buttonSize)||raw.buttonSize<75||raw.buttonSize>150)throw Error('Invalid Button Size.');result.buttonSize=raw.buttonSize}
 for(const device of ['desktop','mobile','fullscreenDesktop','fullscreenMobile']){
  const p=raw[device]??(raw.version===1&&device.startsWith('fullscreen')?result[device]:null);
  if(!p||typeof p.enabled!=='boolean'||!Number.isInteger(p.left)||p.left<15||p.left>35||!Number.isInteger(p.right)||p.right<15||p.right>35||p.left+p.right>65||!Array.isArray(p.panels)||p.panels.length<25||p.panels.length>64)throw Error('Invalid Workspace Profile.');
  const keys=new Set();
  for(const item of p.panels){
   if(typeof item.key!=='string'||!/^[a-z][a-z0-9-]{0,79}$/.test(item.key)||!definition(item)||keys.has(item.key)||!zones.includes(item.zone)||![6,9,12].includes(item.span)||!Number.isInteger(item.height)||item.height<0||item.height>1200||typeof item.visible!=='boolean')throw Error('Invalid Workspace Panel.');
   keys.add(item.key);
   if(item.minimized!==undefined&&typeof item.minimized!=='boolean')throw Error('Invalid Workspace Panel.');
   if(item.float!=null&&(!['x','y','width'].every(k=>Number.isFinite(item.float[k]))||Math.abs(item.float.x)>20000||Math.abs(item.float.y)>20000||item.float.width<180||item.float.width>2400))throw Error('Invalid Floating Panel.');
   validateOptions(item.options);
  }
  if(PANELS.filter(d=>!['timecode','invert','browser','chess','home','stack','ma'].includes(d.key)).some(d=>!p.panels.some(i=>i.key===d.key&&panelType(i)===d.key)))throw Error('Missing Workspace Panel.');
  result[device]={enabled:p.enabled,left:p.left,right:p.right,panels:p.panels.map(p=>({key:p.key,type:panelType(p),zone:p.zone,span:p.span,height:p.height,visible:p.visible,minimized:p.minimized??false,float:p.float?{x:p.float.x,y:p.float.y,width:p.float.width}:null,options:validateOptions(p.options)}))};
  if(!keys.has('timecode'))result[device].panels.push({...defaultProfile().panels.find(p=>p.key==='timecode')});
  for(const type of ['invert','browser','chess'])if(!keys.has(type))result[device].panels.push(structuredClone(defaultProfile(device.includes('Mobile')||device==='mobile',device.startsWith('fullscreen')).panels.find(p=>p.key===type)));
  if(!keys.has('home'))addHomePanel(result[device].panels);
  if(!keys.has('stack'))addStackPanel(result[device].panels);
  if(!keys.has('ma'))addMaPanel(result[device].panels,!device.startsWith('fullscreen'));
  if(result[device].panels.some(p=>['invert','browser','chess','home','stack','ma'].includes(p.key)&&p.type!==p.key))throw Error('Invalid Workspace Panel.');
  if(result[device].panels.length>64||result[device].panels.find(p=>p.key==='timecode').type!=='timecode')throw Error('Invalid Timecode Panel.');
  if(raw.version===1&&raw.notes)result[device].panels.find(p=>p.key==='notes').options.notes=[{id:'legacy',title:'Workspace Notes',body:raw.notes}];
 }
 if(!raw.focus||!['auto','row','column'].includes(raw.focus.axis)||!Number.isInteger(raw.focus.split)||raw.focus.split<30||raw.focus.split>75)throw Error('Invalid Full Screen Preferences.');
 result.notes=raw.notes;result.focus={axis:raw.focus.axis,split:raw.focus.split};
 return result;
}
