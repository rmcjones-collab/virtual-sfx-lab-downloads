// Incoming DMX -> local visualization controls. Not a USB console driver or output.
import {MA_KEYS} from './ma-keys.js?v=v0330-20261005b';
export const mapTargets=[
 ...Array.from({length:20},(_,i)=>({id:`fader:${i}`,name:`Fader ${i+1}`,kind:'level'})),
 {id:'master',name:'Bank master',kind:'level'},
 ...Array.from({length:20},(_,i)=>({id:`top:${i}`,name:`Play flash ${i+1}`,kind:'button'})),
 ...Array.from({length:20},(_,i)=>({id:`bottom:${i}`,name:`Sun flash ${i+1}`,kind:'button'})),
 ...Array.from({length:12},(_,i)=>({id:`macro:${i}`,name:`Macro F${i+1}`,kind:'button'})),
 // Beta 0.33: grandMA command-section keys for a physical grandMA2 / grandMA3 console (MA panel).
 ...MA_KEYS.map(k=>({id:`ma:${k.id}`,name:`MA ${k.label}`,kind:'button',ma:true}))
];
export const LEGACY_TARGETS=73;
export const defaultMapping=()=>({universe:1,bindings:mapTargets.map((t,i)=>({target:t.id,address:i<6?i+1:0,invert:false}))});
export const bindingUniverse=(config,b)=>b.universe??config.universe;
export function validateMapping(raw){
 if(raw===undefined)return defaultMapping();
 // Upgrade the old ordered ten-fader map without reassigning existing channels.
 if(raw?.bindings?.length===43){
  const legacy=mapTargets.filter(t=>!['fader','top','bottom'].includes(t.id.split(':')[0])||Number(t.id.split(':')[1])<10);
  if(raw.bindings.some((b,i)=>b.target!==legacy[i].id))throw Error('Invalid control mapping');
  raw={...raw,bindings:mapTargets.map(t=>raw.bindings.find(b=>b.target===t.id)??{target:t.id,address:0,invert:false})};
 }
 // Beta 0.33: maps saved before the MA keys existed gain them unmapped.
 if(raw?.bindings?.length===LEGACY_TARGETS&&raw.bindings.every((b,i)=>b.target===mapTargets[i].id))raw={...raw,bindings:[...raw.bindings,...mapTargets.slice(LEGACY_TARGETS).map(t=>({target:t.id,address:0,invert:false}))]};
 if(!raw||!Number.isInteger(raw.universe)||raw.universe<1||raw.universe>32768||!Array.isArray(raw.bindings)||raw.bindings.length!==mapTargets.length)throw Error('Invalid control mapping');
 const used=new Set();
 const bindings=raw.bindings.map((b,i)=>{
  // Beta 0.20: faders may carry their own universe; others follow the bank universe.
  if(b.universe!==undefined&&(!b.target.startsWith('fader:')||!Number.isInteger(b.universe)||b.universe<1||b.universe>32768))throw Error('Invalid fader universe');
  const u=b.universe??raw.universe,key=`${u}:${b.address}`;
  if(b.target!==mapTargets[i].id||!Number.isInteger(b.address)||b.address<0||b.address>512||typeof b.invert!=='boolean'||(b.address&&used.has(key)))throw Error('Invalid or duplicate mapped channel');
  if(b.address)used.add(key);
  return {target:b.target,address:b.address,invert:b.invert,...(b.universe!==undefined&&b.universe!==raw.universe?{universe:b.universe}:{})};
 });
 return {universe:raw.universe,bindings};
}
export class ControlMapper {
 constructor({apply,release}){this.apply=apply;this.release=release;this.config=defaultMapping();this.enabled=false;this.runtime=new Map();this.last=-Infinity;this.source=null;this.count=0;this.lastValues=[]}
 reset(){this.runtime.clear();this.last=-Infinity;this.source=null;this.release()}
 configure(config){this.config=validateMapping(config);this.reset()}
 ingest(packet,now){
  if(!this.enabled)return;
  const onPacket=b=>bindingUniverse(this.config,b)-1===packet.universe;
  if(!this.config.bindings.some(b=>b.address&&onPacket(b))&&packet.universe!==this.config.universe-1)return;
  this.count++;if(packet.universe===this.config.universe-1)this.lastValues=packet.values;
  if(!Array.isArray(packet.values)||this.config.bindings.some(b=>onPacket(b)&&b.address>packet.values.length)){this.reset();return}
  const source=packet.sourceId??packet.source;
  if(this.source!==source||now-this.last>2.5){this.reset();this.source=source}
  this.last=now;
  for(const b of this.config.bindings){
   if(!b.address||!onPacket(b))continue;
   let r=this.runtime.get(b.target);
   if(!r){r={ready:false,active:false,last:null};this.runtime.set(b.target,r)}
   const raw=packet.values[b.address-1];
   if(!Number.isInteger(raw)||raw<0||raw>255){this.reset();return}
   const value=b.invert?255-raw:raw;
   const button=mapTargets.find(t=>t.id===b.target).kind==='button';
   // Require zero/low once after reconnect, editing or source handover.
   const low=button?value<128:value<=2;
   if(!r.ready){if(low){r.ready=true;r.last=value;this.apply(b.target,0)}continue}
   if(button){
    const active=value>=128;
    if(active!==r.active){r.active=active;this.apply(b.target,active?100:0)}
   }else if(value!==r.last){this.apply(b.target,value/255*100);r.active=value>2}
   r.last=value;
  }
 }
 tick(now){if(this.enabled&&this.last!==-Infinity&&now-this.last>2.5)this.reset()}
}
