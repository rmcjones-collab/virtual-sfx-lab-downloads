import {PANELS,freshWorkspace,defaultProfile,validateWorkspace,definition,panelType} from './workspace-model.js?v=v0330-20261005b';
import {createNotes,createClock,createTimecodePanel} from './workspace-widgets.js?v=v0330-20261005b';
import {createBrowserLauncher,mountMonitorWindows} from './workspace-monitors.js?v=v0330-20261005b';
import {mirrorPanel} from './panel-mirror.js?v=v0330-20261005b';
import {syncPanelSummary} from './panel-summaries.js?v=v0330-20261005b';
import {bindMobilePanelDrag} from './mobile-panel-drag.js?v=v0330-20261005b';
import {requestFileSave} from './file-save.js?v=v0330-20261005b';
import {createChessPanel} from './chess-panel.js?v=v0330-20261005b';
import {mountPanelButtons} from './panel-buttons.js?v=v0330-20261005b';
import {mountLayoutLibrary} from './workspace-layouts.js?v=v0330-20261005b';
const $=s=>document.querySelector(s);
const PORT='__PORT_8093__',API=PORT.startsWith('__')?'http://127.0.0.1:8093':PORT;
const local=['127.0.0.1','localhost'].includes(location.hostname);
const headers={'Content-Type':'application/json',...(local?{'X-Wave-Dev-Visitor':'local-development'}:{})};
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
export function mountWorkspace({onChange=()=>{},onResize=()=>{},cancelGesture=()=>{},isLive=()=>false,timecode,timing=()=>({nextCue:null,label:'Not Available'}),ma=null}={}){
 let config=freshWorkspace(),revision=0,editing=false,focused=false,gesture=null,saveTimer=null,savePending=false,saving=false,focusScroll=0;
 const media=matchMedia('(max-width:700px)'),nodes=new Map(),cards=new Map(),widgets=new Map(),mirrors=new Map(),owners=new Map(),park=document.createElement('div');
 let heldCustomize=false,followKey=null,followPlaceholder=null,zOrder=200;
 const activeDevice=()=>focused?(media.matches?'fullscreenMobile':'fullscreenDesktop'):(media.matches?'mobile':'desktop');
 const profile=()=>config[activeDevice()];
 const itemFor=key=>profile().panels.find(p=>p.key===key);
 const widgetFor=key=>widgets.get(`${activeDevice()}:${key}`);
 const typeFor=key=>panelType(itemFor(key)??{key});
 park.hidden=true;park.id='workspace-park';document.body.append(park);
 const display=document.createElement('section');display.className='workspace-display-settings';
 $('.display-heading').before(display);
 for(const el of [$('.display-heading'),$('#guides').closest('label'),$('#path').closest('label')])display.append(el);
 function widget(key,type){
  const device=activeDevice(),opts=()=>config[device].panels.find(p=>p.key===key)?.options??{};
  const args={get:opts,change:changed,timecode,timing};
  const w=type==='notes'?createNotes(args):type==='clock'?createClock(args):type==='browser'?createBrowserLauncher():type==='chess'?createChessPanel():type==='ma'?(ma?.()??{el:document.createElement('section'),tick(){},render(){}}):createTimecodePanel(timecode);
  widgets.set(`${device}:${key}`,w);return w.el;
 }
 for(const row of document.querySelectorAll('.fader-strip[data-fader]')){
  const label=document.createElement('span');label.className='fader-compact-name';row.querySelector('.fader-number').after(label);
 }
 function compactLabels(){
  for(const row of document.querySelectorAll('.fader-strip[data-fader]')){
   const value=row.querySelector(row.classList.contains('dmx-priority-mode')?'[data-label=dmxLabel]':'[data-label=cueLabel]').value,label=row.querySelector('.fader-compact-name');
   label.textContent=value.replace(/^Fader\s+\d+\s*-\s*/i,'');label.title=value;
  }
 }
 compactLabels();
 setInterval(()=>{compactLabels();for(const w of widgets.values())w.tick();for(const m of mirrors.values())m.tick();syncMinimizedHeaders()},100);
 for(const def of PANELS){
  const el=def.key==='display'?display:['notes','clock','timecode','browser','chess','ma'].includes(def.key)?widget(def.key,def.key):$(def.selector);
  // The MA panel also has a standard-view home under the playback bank; other widgets live only in the custom workspace.
  if(!el.isConnected){const bankHome=def.key==='ma'?$('#playback-bank'):null;if(bankHome)bankHome.after(el);else park.append(el)}
  const home=document.createComment(`workspace:${def.key}`);el.before(home);nodes.set(def.key,{el,home});
 }
 // The count/assignment toolbar travels with the existing faders, not a duplicate control bank.
 const faderTools=$('.mobile-bank-tools'),faderHome=document.createComment('workspace:fader-tools');faderTools.before(faderHome);
 const bar=document.createElement('div');bar.className='workspace-custom-bar';
 bar.innerHTML='<div><button id="customize-workspace">Customize Workspace</button><button id="workspace-revert" data-revert-customize disabled>Revert Customize</button><button id="workspace-layouts" title="Save Or Load Customized Layouts">Layouts</button><button id="workspace-catalog-open">Add Panels</button><button id="workspace-collapse-all" title="Minimize Or Restore Every Visible Panel">Collapse All</button><button id="workspace-fullscreen">Full Screen</button></div><span id="workspace-save-status" role="status">Arrange Your Own Workspace</span>';
 $('.dmx-console').after(bar);
 const root=document.createElement('section');root.id='custom-workspace';root.hidden=true;root.setAttribute('aria-label','Custom Workspace');
 root.innerHTML='<div class="workspace-edit-tools"><strong>Arrange Workspace</strong><span>Drag A Panel Header. Resize Its Corner. Removed Panels Stay Available.</span><button id="workspace-add">Add Panels</button><button id="workspace-done">Done</button></div><div class="workspace-lanes"></div>';
 bar.after(root);
 const buttonEditor=mountPanelButtons({root,itemFor,editing:()=>editing&&!heldCustomize,changed});
 let wasEditing=false;
 const layouts=mountLayoutLibrary({config:()=>config,activeDevice,validateWorkspace,editing:()=>editing,
  remote:async(method,body)=>{const r=await fetch(`${API}/api/custom-layouts`,{method,headers,...(body?{body:JSON.stringify(body)}:{}),signal:AbortSignal.timeout(8000)});if(!r.ok)throw Error('Layout Storage Unavailable.');return r.json()},
  apply:(device,next)=>{config[device]=next;changed();render()},
  status:message=>{const s=document.getElementById('workspace-save-status');if(s)s.textContent=message;const f=document.getElementById('focus-message');if(f&&focused)f.textContent=message}});
 const lanes={};
 for(const [key,title] of [['left','Left'],['main','Main'],['right','Right']]){
  const lane=document.createElement('div');lane.className='workspace-lane';lane.dataset.zone=key;lane.setAttribute('aria-label',`${title} Workspace Column`);lanes[key]=lane;root.querySelector('.workspace-lanes').append(lane);
 }
 const catalog=document.createElement('dialog');catalog.className='workspace-dialog';catalog.id='workspace-catalog';
 catalog.innerHTML='<div class="dialog-head"><h2>Customize Workspace</h2><button data-ws-close>Close</button></div><p id="workspace-profile-label"></p><p>Add or remove panels without deleting their data. Changes are saved privately for this browser visitor when storage is available; download a workspace copy for backup.</p><div class="workspace-profile-actions"><button data-ws-edit>Arrange Panels</button><button data-ws-standard>Standard View</button><button data-ws-reset>Reset This Screen</button><button data-ws-export>Download Workspace</button><button data-ws-import>Load Workspace</button><input type="file" data-ws-file accept=".json,application/json" hidden></div><fieldset class="workspace-column-sizes"><legend>Desktop Column Widths</legend><label>Left <input id="workspace-left-width" type="range" min="15" max="35" step="1"><output id="workspace-left-output"></output></label><label>Right <input id="workspace-right-width" type="range" min="15" max="35" step="1"><output id="workspace-right-output"></output></label></fieldset><div class="workspace-catalog-list"></div><p data-ws-message role="status"></p>';
 document.body.append(catalog);
 const focus=document.createElement('section');focus.id='workspace-focus';focus.hidden=true;
 focus.innerHTML='<div class="focus-toolbar"><button id="focus-exit">Exit Full Screen</button><button id="focus-customize">Customize Workspace</button><button id="focus-revert" data-revert-customize disabled>Revert Customize</button><button id="focus-layouts">Layouts</button><button id="focus-add">Add Panels</button><button id="focus-axis">Stack / Columns</button><button id="focus-release">Release All</button><button id="focus-enable">Enable Virtual Faders</button></div><div class="focus-workspace-host"></div><p id="focus-message" role="status"></p>';
 document.body.append(focus);
 for(const b of [$('#customize-workspace'),$('#focus-customize')]){b.title='Hold Ctrl + Shift To Customize';b.dataset.shortcut='Ctrl + Shift';b.classList.add('customize-shortcut');b.setAttribute('aria-keyshortcuts','Control+Shift')}
 for(const [ids,keys,aria,label] of [[['#workspace-catalog-open','#workspace-add','#focus-add'],'Ctrl + Shift + P','Control+Shift+P','Add Panels'],[['#workspace-fullscreen','#focus-exit'],'Ctrl + Shift + F','Control+Shift+F','Full Screen']])for(const id of ids){const b=$(id);if(!b)continue;b.title=`${label} · ${keys}`;b.dataset.shortcut=keys;b.classList.add('customize-shortcut');b.setAttribute('aria-keyshortcuts',aria)}
 const status=message=>$('#workspace-save-status').textContent=message;
 async function api(method,body){
  const r=await fetch(`${API}/api/workspace`,{method,headers,...(body?{body:JSON.stringify(body)}:{}),signal:AbortSignal.timeout(8000)});
  if(!r.ok)throw Error('Workspace Storage Unavailable. Download A Workspace Copy.');
  return r.json();
 }
 async function flush(){
  if(saving)return;savePending=false;saving=true;status('Saving Workspace…');
  try{await api('PUT',config);status('Workspace Saved For This Visitor')}
  catch{status('Not Saved Online. Use Download Workspace To Keep A Copy.')}
  finally{saving=false;if(savePending)flush()}
 }
 function changed(){
  revision++;onChange();status('Saving Workspace…');clearTimeout(saveTimer);savePending=true;saveTimer=setTimeout(flush,550);
 }
 window.addEventListener('pagehide',()=>{if(revision)fetch(`${API}/api/workspace`,{method:'PUT',headers,body:JSON.stringify(config),keepalive:true}).catch(()=>{})});
 function restoreNodes(){
  clearFollow();
  for(const {el,home} of nodes.values())home.after(el);
  faderHome.after(faderTools);
 }
 // Custom panel names live in item.options.name; the catalog title is the fallback.
 function panelTitle(item){return item.options?.name||definition(item).title}
 let renaming=null,suppressClick=false;
 function startRename(key){
  const card=cards.get(key),item=profile().panels.find(p=>p.key===key);if(!card||!item||renaming)return;
  if(item.type==='chess')return;
  const grip=card.querySelector('.workspace-grip'),input=document.createElement('input');
  input.type='text';input.className='workspace-rename';input.maxLength=60;input.value=panelTitle(item);input.placeholder=definition(item).title;input.setAttribute('aria-label',`Rename ${definition(item).title}`);
  const scrolls=[];for(let n=card.parentElement;n;n=n.parentElement)scrolls.push([n,n.scrollTop,n.scrollLeft]);
  const keepScroll=()=>scrolls.forEach(([n,top,left])=>{n.scrollTop=top;n.scrollLeft=left});
  renaming=key;grip.hidden=true;grip.after(input);input.focus({preventScroll:true});input.select();keepScroll();requestAnimationFrame(keepScroll);
  let done=false;
  const finish=commit=>{
   if(done)return;done=true;renaming=null;
   if(commit){const name=input.value.trim().slice(0,60);if(name&&name!==definition(item).title)item.options.name=name;else delete item.options.name;changed()}
   input.remove();grip.hidden=false;applyTitle(card,item);renderCatalog();grip.focus({preventScroll:true});
  };
  input.onkeydown=e=>{e.stopPropagation();if(e.key==='Enter'){e.preventDefault();finish(true)}else if(e.key==='Escape'){e.preventDefault();finish(false)}};
  input.onblur=()=>finish(true);
  input.onpointerdown=e=>e.stopPropagation();
 }
 function applyTitle(card,item){
  const title=panelTitle(item),base=definition(item).title,grip=card.querySelector('.workspace-grip');
  grip.textContent=title;grip.title=editing?'Drag To Move · Click To Rename':'Click To Rename This Panel';
  grip.setAttribute('aria-label',`${title}${title!==base?` (${base})`:''} · click to rename`);
  card.setAttribute('aria-label',title);
  if(item.type==='chess'){
   const pawn=document.createElement('img');pawn.src='./pawn-white.svg';pawn.alt='Chess';pawn.className='chess-pawn';grip.replaceChildren(pawn);
   grip.title='Chess · Drag Header In Customize Workspace';grip.setAttribute('aria-label','Chess');
  }
  for(const b of card.querySelectorAll('[data-ws-action]')){const label=b.getAttribute('aria-label')||'';const i=label.indexOf(': ');if(i>0)b.setAttribute('aria-label',`${label.slice(0,i)}: ${title}`)}
 }
 function setCardSize(card,item){
  card.style.gridColumn=`span ${item.span}`;card.style.height=!item.minimized&&item.height?`${item.height}px`:'auto';
  card.style.setProperty('--panel-height',`${item.height||430}px`);
  card.classList.toggle('workspace-minimized',item.minimized);
  card.classList.toggle('workspace-floating',!!item.float);
  if(item.float){card.style.width=`${Math.min(item.float.width,innerWidth-16)}px`;card.style.left=`${clamp(item.float.x,0,Math.max(0,innerWidth-Math.min(item.float.width,innerWidth-16)))}px`;card.style.top=`${clamp(item.float.y,focused?60:0,Math.max(60,innerHeight-70))}px`;card.style.zIndex=String(item._z??200)}
  else{card.style.width='';card.style.left='';card.style.top='';card.style.zIndex=''}
  applyTitle(card,item);
  const follow=card.querySelector('[data-panel-follow]');if(follow)follow.checked=!!item.options.follow;
  const toggle=card.querySelector('[data-ws-action=minimize]'),title=panelTitle(item);
  toggle.textContent=item.minimized?'+':'−';toggle.title=`${item.minimized?'Restore':'Minimize'} Panel`;
  toggle.setAttribute('aria-label',`${item.minimized?'Restore':'Minimize'}: ${title}`);
  toggle.setAttribute('aria-expanded',String(!item.minimized));
 }
 function makeCard(def,key=def.key){
  def={...def,key};
  const card=document.createElement('section');card.className='workspace-card';card.dataset.panel=key;card.dataset.type=typeFor(key);card.setAttribute('aria-label',def.title);
  const head=document.createElement('div');head.className='workspace-card-head';
  const grip=document.createElement('button');grip.className='workspace-grip';grip.textContent=def.title;grip.title='Drag To Move This Panel';grip.setAttribute('aria-label',`Move ${def.title}`);head.append(grip);
  const summary=document.createElement('span');summary.className='minimized-summary';summary.hidden=true;head.append(summary);
  const minimize=document.createElement('button');minimize.type='button';minimize.className='workspace-minimize';minimize.dataset.wsAction='minimize';minimize.setAttribute('aria-controls',`workspace-content-${def.key}`);minimize.onclick=()=>act(def.key,'minimize');head.append(minimize);
  const buttons=document.createElement('div');buttons.className='workspace-card-actions';
  for(const [action,text,title] of [['up','↑','Move Up'],['down','↓','Move Down'],['left','←','Dock Left'],['right','→','Dock Right'],['float','Float','Float Panel'],['duplicate','Copy','Duplicate Panel'],['size','Size','Panel Size'],['remove','×','Remove Panel']]){
   const button=document.createElement('button');button.type='button';button.textContent=text;button.dataset.wsAction=action;button.setAttribute('aria-label',`${title}: ${def.title}`);button.onclick=()=>act(def.key,action);buttons.append(button);
  }
  head.append(buttons);card.append(head);
  const size=document.createElement('div');size.className='workspace-card-size';size.hidden=true;
  size.innerHTML='<label>Width<select data-panel-width><option value="12">100%</option><option value="9">75%</option><option value="6">50%</option></select></label><label>Height<input data-panel-height type="number" min="0" max="1200" step="10"></label><button data-panel-auto>Auto Height</button>';
  const updateSize=()=>{
   const item=profile().panels.find(p=>p.key===def.key),v=Number(size.querySelector('input').value);
   if(!Number.isFinite(v)||v<0||v>1200){size.querySelector('input').value=item.height;return}
   item.span=Number(size.querySelector('select').value);item.height=v===0?0:clamp(Math.round(v),minHeight(def.key),1200);
   size.querySelector('input').value=item.height;setCardSize(card,item);changed();onResize();
  };
  size.querySelector('select').onchange=updateSize;size.querySelector('input').onchange=updateSize;
  size.querySelector('button').onclick=()=>{size.querySelector('input').value=0;updateSize()};
  card.append(size);
  if(['stage','faders','tools','fuel'].includes(typeFor(key))){
   const row=document.createElement('label');row.className='panel-follow-option';
   const check=document.createElement('input');check.type='checkbox';check.dataset.panelFollow='';
   check.onchange=()=>{const item=itemFor(key);item.options.follow=check.checked;if(followKey!==key)clearFollow();followKey=key;changed();syncFollow()};
   row.append(check,document.createTextNode('Follow When Selected'));card.append(row);
  }
  const content=document.createElement('div');content.className='workspace-card-content';content.id=`workspace-content-${def.key}`;card.append(content);
  const resize=document.createElement('button');resize.className='workspace-resize';resize.setAttribute('aria-label',`Resize ${def.title}`);resize.title='Drag To Resize. Use Size For Exact Values.';resize.textContent='↘';card.append(resize);
  grip.onpointerdown=e=>{if(media.matches&&e.pointerType==='touch')return;if(!editing&&e.button===0){e.preventDefault();grip.focus({preventScroll:true})}begin(e,'move',def.key)};resize.onpointerdown=e=>begin(e,'resize',def.key);
  bindMobilePanelDrag(head,{panel:()=>card,title:()=>panelTitle(itemFor(key)),canDock:target=>!!mobileTargetKey(target)&&mobileTargetKey(target)!==key,drop:placement=>placePanel(key,placement)});
  grip.onclick=()=>{if(suppressClick){suppressClick=false;return}startRename(def.key)};
  resize.onclick=e=>{if(e.detail===0)act(def.key,'size')};
  grip.onkeydown=e=>{if(['ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.key)){e.preventDefault();act(def.key,e.key.replace('Arrow','').toLowerCase())}};
  cards.set(def.key,card);return card;
 }
 PANELS.forEach(def=>makeCard(def));
 function syncMinimizedHeaders(){
  for(const item of profile().panels){
   const card=cards.get(item.key),summary=card?.querySelector('.minimized-summary');if(!summary)continue;
   summary.hidden=!item.minimized;if(!item.minimized)continue;
   const source=widgetFor(item.key)?.el??nodes.get(item.type)?.el;
   if(!source)continue;
   if(syncPanelSummary({summary,type:item.type,source,timecode}))continue;
   if(item.type==='clock'){
    if(!summary.querySelector('output')){summary.replaceChildren();const out=document.createElement('output');out.className='minimized-clock';summary.append(out);
     const run=document.createElement('button');run.type='button';run.className='minimized-clock-run';run.hidden=true;run.addEventListener('pointerdown',e=>e.stopPropagation());run.addEventListener('keydown',e=>e.stopPropagation());run.onclick=e=>{e.stopPropagation();widgetFor(item.key)?.toggleRun?.();syncMinimizedHeaders()};summary.append(run)}
    summary.classList.add('minimized-summary-clock');
    const value=source.querySelector('.clock-value');summary.querySelector('output').textContent=value?.textContent??'';
    const rs=widgetFor(item.key)?.runState?.()??null,run=summary.querySelector('.minimized-clock-run');if(run){run.hidden=!rs;if(rs){run.textContent=rs.running?'■':'▶';run.setAttribute('aria-label',rs.label);run.title=rs.label;run.classList.toggle('is-running',rs.running)}}
   }else if(summary.querySelector('output'))summary.replaceChildren();
   const boxes=[...source.querySelectorAll('input[type=checkbox]')],old=summary.querySelector('input');
   if(boxes.length!==1){old?.closest('label')?.remove();continue}
   const original=boxes[0];let toggle=old;
   if(!toggle){const label=document.createElement('label');label.className='minimized-toggle';toggle=document.createElement('input');toggle.type='checkbox';label.append(toggle);summary.append(label);
    toggle.addEventListener('pointerdown',e=>e.stopPropagation());toggle.addEventListener('keydown',e=>e.stopPropagation());
    toggle.onchange=()=>{const source=widgetFor(item.key)?.el??nodes.get(item.type)?.el,original=source?.querySelector('input[type=checkbox]');if(original&&!original.matches(':disabled')&&!original.closest('[inert]'))original.click();syncMinimizedHeaders()};
   }
   const name=original.getAttribute('aria-label')||original.labels?.[0]?.textContent?.trim()||definition(item).title;
   toggle.setAttribute('aria-label',name);toggle.title=name;toggle.checked=original.checked;toggle.indeterminate=original.indeterminate;toggle.disabled=original.matches(':disabled')||!!original.closest('[inert]')||isLive()&&['arm','faders','bank','macros','master','invert'].includes(item.type);
  }
 }
 function minHeight(key){const type=typeFor(key);return type==='stage'?380:type==='faders'?260:140}
 function ensureInstances(){
  for(const item of profile().panels){
   if(!cards.has(item.key))makeCard(definition(item),item.key);
   if(['notes','clock','timecode','browser','chess','ma'].includes(item.type)&&!widgetFor(item.key))widget(item.key,item.type);
  }
 }
 function duplicate(key){
  if(profile().panels.length>=64){status('Maximum 64 Panels Per Workspace.');return}
  const source=itemFor(key),copy=structuredClone(source);copy.key=`${source.type}-${crypto.randomUUID()}`;copy.visible=true;copy.minimized=false;copy.float={x:40,y:100,width:Math.min(420,innerWidth-30)};profile().panels.push(copy);profile().enabled=true;changed();render();
 }
 function clearFollow(){if(followPlaceholder){const card=cards.get(followKey);card?.classList.remove('workspace-following');followPlaceholder.remove();followPlaceholder=null;if(card&&itemFor(followKey))setCardSize(card,itemFor(followKey))}}
 function syncFollow(){
  const current=itemFor(followKey);
  const follows=item=>item&&['notes','stage','faders','tools','fuel'].includes(item.type)&&item.options.follow&&!item.float&&item.visible;
  if(followPlaceholder&&follows(current))return;
  clearFollow();const item=itemFor(followKey);if(!follows(item))return;
  const card=cards.get(followKey),r=card.getBoundingClientRect();if(!r.width)return;
  followPlaceholder=document.createElement('div');followPlaceholder.style.height=`${r.height}px`;followPlaceholder.style.gridColumn=`span ${item.span}`;card.before(followPlaceholder);
  card.classList.add('workspace-following');card.style.width=`${Math.min(r.width,innerWidth-16)}px`;card.style.left=`${clamp(r.left,0,innerWidth-r.width)}px`;card.style.top=`${clamp(r.top,focused?60:8,Math.max(60,innerHeight-Math.min(r.height,innerHeight-80)-8))}px`;
 }
 root.addEventListener('wave-note-follow-change',e=>{const card=e.target.closest('.workspace-card');if(card){if(followKey!==card.dataset.panel)clearFollow();followKey=card.dataset.panel;syncFollow()}});
 root.addEventListener('focusin',e=>{const card=e.target.closest('.workspace-card');if(card&&!e.target.closest('.workspace-card-head')&&followKey!==card.dataset.panel){clearFollow();followKey=card.dataset.panel;syncFollow()}});
 root.addEventListener('pointerdown',e=>{const card=e.target.closest('.workspace-card');if(card){if(!e.target.closest('.workspace-card-head')&&followKey!==card.dataset.panel){clearFollow();followKey=card.dataset.panel;syncFollow()}if(itemFor(card.dataset.panel)?.float)card.style.zIndex=String(++zOrder)}});
 function render(){
  document.dispatchEvent(new Event('wave-workspace-before-layout'));
  const pagePosition={x:scrollX,y:scrollY},scrollState=[...cards.values()].map(c=>{const el=c.querySelector('.workspace-card-content');return [el,el?.scrollTop||0,el?.scrollLeft||0]});
  document.documentElement.style.setProperty('--button-scale',config.buttonSize/100);
  $('#button-size').value=config.buttonSize;$('#button-size-value').textContent=`${config.buttonSize}%`;
  const alignment=config.labelAlignment[media.matches?'mobile':'desktop'];
  document.body.style.setProperty('--panel-label-align',alignment);
  document.body.style.setProperty('--panel-label-justify',alignment==='center'?'center':alignment==='right'?'flex-end':'flex-start');
  buttonEditor.restore();stopGesture(true);restoreNodes();
  ensureInstances();const p=profile();
  // Entering Customize Workspace saves the arrangement that Revert Customize returns to.
  if(editing&&!wasEditing)layouts.capture();wasEditing=editing;
  document.body.classList.toggle('custom-workspace-mode',p.enabled||focused);document.body.classList.toggle('workspace-editing',editing&&(p.enabled||focused));
  document.body.classList.toggle('button-customizing',editing&&!heldCustomize&&(p.enabled||focused));
  root.hidden=!(p.enabled||focused);$('#customize-workspace').textContent=editing?'Finish Customizing':'Customize Workspace';
  root.style.setProperty('--workspace-left',`${p.left}fr`);root.style.setProperty('--workspace-center',`${100-p.left-p.right}fr`);root.style.setProperty('--workspace-right',`${p.right}fr`);
  for(const lane of Object.values(lanes))lane.replaceChildren();
  for(const card of cards.values())park.append(card);
  mirrors.clear();
  if(p.enabled||focused){
   for(const item of p.panels){
    const card=cards.get(item.key),content=card.querySelector('.workspace-card-content');content.replaceChildren();
    if(widgetFor(item.key)){const w=widgetFor(item.key);content.append(w.el);w.render()}
    else{
     const type=item.type,source=nodes.get(type).el;
     if(!p.panels.some(i=>i.key===owners.get(type)&&i.visible))owners.set(type,p.panels.find(i=>i.visible&&i.type===type)?.key??type);
     if(owners.get(type)===item.key){content.append(source);if(type==='faders')source.before(faderTools)}
     else{const m=mirrorPanel(source,()=>{owners.set(type,item.key);render()});mirrors.set(item.key,m);content.append(m.el)}
    }
    setCardSize(card,item);card.querySelector('[data-panel-width]').value=item.span;card.querySelector('[data-panel-height]').value=item.height;
    if(item.visible)(item.float?root:lanes[item.zone]).append(card);else park.append(card);
   }
   for(const [zone,lane] of Object.entries(lanes))lane.classList.toggle('empty',!p.panels.some(i=>i.visible&&!i.float&&i.zone===zone));
  }
  renderCatalog();syncCollapseAll();syncFocus();syncFollow();syncSafety();syncMinimizedHeaders();document.dispatchEvent(new Event('wave-workspace-layout'));buttonEditor.refresh();layouts.sync();onResize();
  for(const [el,top,left] of scrollState)if(el){el.scrollTop=top;el.scrollLeft=left}
  window.scrollTo({left:pagePosition.x,top:pagePosition.y,behavior:'instant'});
 }
 function act(key,action){
  const p=profile(),item=p.panels.find(i=>i.key===key);
  if(action==='duplicate'){duplicate(key);return}
  if(action==='float'){item.float=item.float?null:{x:50,y:100,width:Math.min(440,innerWidth-20)};changed();render();return}
  if(action==='minimize'){
   item.minimized=!item.minimized;cards.get(key).querySelector('.workspace-card-size').hidden=true;
   changed();render();cards.get(key).querySelector('[data-ws-action=minimize]').focus({preventScroll:true});return;
  }
  else if(action==='remove')item.visible=false;
  else if(action==='size'){const el=cards.get(key).querySelector('.workspace-card-size');el.hidden=!el.hidden;return}
  else if(action==='left'||action==='right'){const zones=['left','main','right'];item.float=null;item.zone=zones[clamp(zones.indexOf(item.zone)+(action==='left'?-1:1),0,2)]}
  else {
   const visible=p.panels.filter(i=>i.visible&&i.zone===item.zone),at=visible.indexOf(item),other=visible[at+(action==='up'?-1:1)];
   if(!other)return;const a=p.panels.indexOf(item),b=p.panels.indexOf(other);[p.panels[a],p.panels[b]]=[p.panels[b],p.panels[a]];
  }
  changed();render();cards.get(key).querySelector('.workspace-grip').focus({preventScroll:true});
 }
 function mobileTargetKey(target){return target?.closest('.workspace-card')?.dataset.panel??(target?.matches('.stage-live,.mobile-stage-control-panel')?'stage':null)}
 function placePanel(key,{target,after=false,float}){
  const p=profile(),item=p.panels.find(i=>i.key===key);if(!item)return;
  const targetKey=mobileTargetKey(target),other=p.panels.find(i=>i.key===targetKey);
  p.enabled=true;item.visible=true;
  if(other&&other!==item){
   p.panels=p.panels.filter(i=>i!==item);item.zone=other.zone;item.float=null;other.float=null;
   p.panels.splice(p.panels.indexOf(other)+(after?1:0),0,item);
  }else{const width=clamp(float.width,180,innerWidth-16);item.float={x:clamp(float.x,0,Math.max(0,innerWidth-width)),y:clamp(float.y,focused?60:8,Math.max(60,innerHeight-70)),width}}
  changed();render();status(other&&other!==item?`${panelTitle(item)} Docked ${after?'Below':'Above'} ${panelTitle(other)}.`:`${panelTitle(item)} Floating. Hold Its Header To Move Or Dock.`);
 }
 function begin(e,type,key){
  if(!editing||e.button!==0)return;e.preventDefault();cancelGesture();stopGesture(true);
  clearFollow();followKey=null;
  const card=cards.get(key),item=profile().panels.find(p=>p.key===key),rect=card.getBoundingClientRect();
  gesture={type,key,item,before:structuredClone(config),target:e.currentTarget,pointer:e.pointerId,x:e.clientX,y:e.clientY,left:rect.left,top:rect.top,width:rect.width,height:rect.height,moved:false,drop:null};
  e.currentTarget.setPointerCapture(e.pointerId);
 }
 function move(e){
  if(!gesture||e.pointerId!==gesture.pointer)return;
  const g=gesture,dx=e.clientX-g.x,dy=e.clientY-g.y;if(!g.moved&&Math.hypot(dx,dy)<6)return;g.moved=true;
  if(g.type==='resize'){
   const lane=cards.get(g.key).parentElement,base=lane.clientWidth;
   if(g.item.float)g.item.float.width=clamp(Math.round(g.width+dx),180,Math.min(2400,innerWidth));else g.item.span=clamp(Math.round((g.width+dx)/base*4)*3,6,12);g.item.height=clamp(Math.round(g.height+dy),minHeight(g.key),1200);
   setCardSize(cards.get(g.key),g.item);onResize();
  }else{
   const moving=cards.get(g.key);
   if(!g.placeholder){
    // Keep the original live panel (including canvas and input state), not a cloned image.
    g.style=moving.style.cssText;g.placeholder=document.createElement('div');g.placeholder.className='workspace-drag-placeholder';
    g.placeholder.style.gridColumn=`span ${g.item.span}`;g.placeholder.style.height=`${g.height}px`;g.placeholder.setAttribute('aria-hidden','true');moving.before(g.placeholder);
    moving.classList.add('workspace-dragging');moving.style.width=`${g.width}px`;moving.style.height=`${g.height}px`;
   }
   moving.style.left=`${g.left+dx}px`;moving.style.top=`${g.top+dy}px`;
   g.float={x:clamp(g.left+dx,0,Math.max(0,innerWidth-g.width)),y:clamp(g.top+dy,focused?60:0,Math.max(60,innerHeight-70)),width:Math.min(g.width,innerWidth-16)};
   document.querySelectorAll('.workspace-drop').forEach(el=>el.classList.remove('workspace-drop'));
   const under=document.elementFromPoint(e.clientX,e.clientY),card=under?.closest('.workspace-card'),lane=under?.closest('.workspace-lane');
   if(card||lane?.classList.contains('empty')){const other=card?.dataset.panel;g.drop=other===g.key?null:{zone:lane?.dataset.zone??itemFor(other).zone,key:other,after:card?e.clientY>card.getBoundingClientRect().top+card.clientHeight/2:false};if(g.drop)(card??lane).classList.add('workspace-drop')}
   else g.drop=null;
   const scrollHost=focused?focus:window;if(e.clientY<70)scrollHost.scrollBy(0,-16);else if(e.clientY>innerHeight-70)scrollHost.scrollBy(0,16);
  }
 }
 function stopGesture(cancel=false){
  if(!gesture)return;const g=gesture;gesture=null;
  if(g.placeholder){const card=cards.get(g.key);card.classList.remove('workspace-dragging');card.style.cssText=g.style;g.placeholder.remove()}
  document.querySelectorAll('.workspace-drop').forEach(el=>el.classList.remove('workspace-drop'));
  if(g.target.hasPointerCapture(g.pointer))g.target.releasePointerCapture(g.pointer);
  suppressClick=!!g.moved;
  if(cancel){config=g.before;return}
  if(g.moved){
   if(g.type==='move'&&g.drop){
    const p=profile();p.panels=p.panels.filter(i=>i!==g.item);g.item.zone=g.drop.zone;g.item.float=null;
    const target=p.panels.find(p=>p.key===g.drop.key);if(target)target.float=null;
    const i=g.drop.key?p.panels.findIndex(p=>p.key===g.drop.key)+(g.drop.after?1:0):p.panels.length;p.panels.splice(i,0,g.item);
   }else if(g.type==='move')g.item.float=g.float;
   changed();render();
  }
 }
 document.addEventListener('pointermove',move);document.addEventListener('pointerup',()=>stopGesture());
 document.addEventListener('pointercancel',()=>{if(gesture){stopGesture(true);render()}});
 window.addEventListener('blur',()=>{if(gesture){stopGesture(true);render()}});
 document.addEventListener('keydown',e=>{if(e.target.closest?.('input,textarea,select,[contenteditable=true]'))return;if(e.key==='Escape'){if(gesture){stopGesture(true);render()}else if(focused){e.preventDefault();exitFocus()}else if(editing&&!document.querySelector('dialog[open]')){editing=false;render()}}});
 function renderCatalog(){
  $('#workspace-profile-label').textContent=`Editing ${focused?'Full Screen · ':''}${media.matches?'Mobile':'Desktop'} Arrangement`;
  for(const side of ['left','right']){$(`#workspace-${side}-width`).value=profile()[side];$(`#workspace-${side}-output`).textContent=`${profile()[side]}%`}
  const list=catalog.querySelector('.workspace-catalog-list');list.replaceChildren();
  for(const item of profile().panels){
   const def=definition(item),label=document.createElement('label'),input=document.createElement('input');input.type='checkbox';input.checked=item.visible;input.dataset.panelToggle=item.key;
   input.onchange=()=>{profile().enabled=true;item.visible=input.checked;changed();render()};label.append(input,document.createTextNode(`${panelTitle(item)}${item.options?.name?` (${def.title})`:''}${item.key!==item.type?' · Copy':''}`));
   if(item.visible){const show=document.createElement('button');show.type='button';show.textContent='Show';show.title='Scroll To This Panel';show.onclick=e=>{e.preventDefault();revealPanel(item.key)};label.append(show)}
   const copy=document.createElement('button');copy.type='button';copy.textContent='Duplicate';copy.onclick=e=>{e.preventDefault();duplicate(item.key)};label.append(copy);list.append(label);
  }
 }
 for(const side of ['left','right'])$(`#workspace-${side}-width`).oninput=e=>{
  const other=side==='left'?'right':'left';profile()[side]=Math.min(Number(e.target.value),65-profile()[other]);changed();render();
 };
 const openCatalog=()=>{renderCatalog();catalog.showModal()};
 $('#workspace-catalog-open').onclick=openCatalog;$('#workspace-add').onclick=openCatalog;
 catalog.querySelector('[data-ws-close]').onclick=()=>catalog.close();
 $('#customize-workspace').onclick=()=>{profile().enabled=true;editing=!editing;changed();render()};
 function revealPanel(key){
  const p=profile(),item=p.panels.find(i=>i.key===key);if(!item)return;
  if(item.minimized){item.minimized=false;changed();render()}
  const card=cards.get(key);card?.scrollIntoView({behavior:'smooth',block:'center'});
  card?.classList.add('workspace-flash');setTimeout(()=>card?.classList.remove('workspace-flash'),1200);
  card?.querySelector('.workspace-grip')?.focus({preventScroll:true});
 }
 function syncCollapseAll(){
  const b=$('#workspace-collapse-all');if(!b)return;const p=profile(),shown=p.panels.filter(i=>i.visible&&!i.float);
  b.disabled=!(p.enabled||focused)||!shown.length;b.textContent=shown.length&&shown.every(i=>i.minimized)?'Expand All':'Collapse All';
 }
 $('#workspace-collapse-all').onclick=()=>{
  const p=profile(),shown=p.panels.filter(i=>i.visible&&!i.float);if(!shown.length)return;
  const minimize=!shown.every(i=>i.minimized);for(const i of shown)i.minimized=minimize;
  changed();render();document.dispatchEvent(new CustomEvent('wave-workspace-collapse-all',{detail:{minimized:minimize}}));$('#workspace-save-status').textContent=minimize?'All Panels Collapsed. Layout Controls Keep A Compact Play Bar.':'All Panels Restored.';
 };
 $('#workspace-done').onclick=()=>{editing=false;render()};
 catalog.querySelector('[data-ws-edit]').onclick=()=>{profile().enabled=true;editing=true;changed();catalog.close();render()};
 catalog.querySelector('[data-ws-standard]').onclick=()=>{if(focused)exitFocus();profile().enabled=false;editing=false;changed();catalog.close();render()};
 catalog.querySelector('[data-ws-reset]').onclick=()=>{if(!confirm('Reset This Panel Arrangement? Export A Workspace Copy First To Preserve Notes In Duplicate Panels.'))return;config[activeDevice()]=defaultProfile(media.matches,focused);profile().enabled=true;changed();render()};
 catalog.querySelector('[data-ws-export]').onclick=()=>{
  requestFileSave(new Blob([JSON.stringify({format:'wave-studio-workspace',...config},null,2)],{type:'application/json'}),'wave-studio-workspace.json');
 };
 catalog.querySelector('[data-ws-import]').onclick=()=>catalog.querySelector('[data-ws-file]').click();
 catalog.querySelector('[data-ws-file]').onchange=async e=>{
  try{const file=e.target.files[0];if(!file)return;if(file.size>500000)throw Error('Workspace File Too Large.');const data=JSON.parse(await file.text());if(data.format!=='wave-studio-workspace')throw Error('Choose A Wave Studio Workspace File.');config=validateWorkspace(data);changed();render();catalog.querySelector('[data-ws-message]').textContent='Workspace Loaded. Fixture Data Was Not Changed.'}catch(error){catalog.querySelector('[data-ws-message]').textContent=error.message}finally{e.target.value=''}
 };
 function focusAxis(){return config.focus.axis==='auto'?(innerWidth>900?'row':'column'):config.focus.axis}
 function syncFocus(){
  if(!focused){if(root.parentElement!==bar.parentElement)bar.after(root);return}
  focus.hidden=false;document.body.classList.add('workspace-focus-mode');focus.dataset.axis=focusAxis();focus.style.setProperty('--focus-share',`${config.focus.split}fr`);focus.style.setProperty('--focus-rest',`${100-config.focus.split}fr`);
  focus.querySelector('.focus-workspace-host').append(root);
  $('#focus-customize').textContent=editing?'Finish Customizing':'Customize Workspace';compactLabels();onResize();
 }
 function enterFocus(){
  focusScroll=scrollY;cancelGesture();editing=false;focused=true;$('#focus-message').textContent='';render();
 }
 function exitFocus(){
  focused=false;focus.hidden=true;document.body.classList.remove('workspace-focus-mode');
  render();requestAnimationFrame(()=>scrollTo(0,focusScroll));
 }
 for(const id of ['#workspace-revert','#focus-revert'])$(id).onclick=()=>layouts.revert();
 for(const id of ['#workspace-layouts','#focus-layouts'])$(id).onclick=()=>layouts.open();
 $('#workspace-fullscreen').onclick=enterFocus;$('#focus-exit').onclick=exitFocus;
 $('#focus-add').onclick=openCatalog;$('#focus-customize').onclick=()=>{editing=!editing;render()};
 $('#focus-axis').onclick=()=>{config.focus.axis=focusAxis()==='row'?'column':'row';changed();syncFocus()};
 $('#focus-release').onclick=()=>$('#bank-release').click();
 $('#focus-enable').onclick=()=>$('#mode-faders').click();
 media.addEventListener('change',()=>{editing=false;render()});window.addEventListener('resize',()=>{for(const item of profile().panels)if(item.float)setCardSize(cards.get(item.key),item);clearFollow();syncFollow();if(focused)syncFocus()});
 // Reparented faders must retain Live Input's disabled state, previously inherited from a fieldset.
 function syncSafety(){
  const live=isLive();
  for(const [key,card]of cards)if(['faders','master','macros','bank','record'].includes(typeFor(key)))card.querySelector('.workspace-card-content').inert=live;
  $('#focus-enable').disabled=live;$('#focus-release').disabled=live;
  $('#focus-enable').hidden=document.body.classList.contains('bank-mode');$('#focus-enable').textContent=live?'Live Input Owns Playback':'Enable Virtual Faders';
 }
 new MutationObserver(syncSafety).observe(document.body,{attributes:true,attributeFilter:['class']});
 // Beta 0.20: Ctrl+Shift only starts temporary customizing after a short hold with no letter,
 // so Ctrl+Shift+P/F/S/R shortcuts never flicker the workspace into edit mode.
 let heldTimer=0;
 const cancelHeldTimer=()=>{clearTimeout(heldTimer);heldTimer=0};
 const layoutToast=text=>{const host=document.querySelector('.viewport')??document.body;let t=host.querySelector('.stage-toast');if(!t){t=document.createElement('div');t.className='stage-toast';t.setAttribute('role','status');host.append(t)}t.textContent=text;t.hidden=false;clearTimeout(t._timer);t._timer=setTimeout(()=>t.hidden=true,1800)};
 const shortcutActions={
  KeyP:()=>{if(catalog.open)catalog.close();else{document.querySelectorAll('dialog[open]').forEach(d=>d.close());openCatalog()}},
  KeyF:()=>{if(focused)exitFocus();else enterFocus()},
  KeyS:()=>{const b=document.getElementById('snapshot');if(b){b.click();layoutToast('Screenshot Ready. Choose A File Name And Destination.')}},
  KeyR:()=>{const b=document.getElementById('layout-record');if(!b||b.disabled){layoutToast('Layout Recording Is Not Supported In This Browser');return}const was=b.classList.contains('is-recording');b.click();layoutToast(was?'Recording Stopped · Open Recordings To Download':'Recording Layout · Ctrl + Shift + R To Stop')}
 };
 document.addEventListener('keydown',e=>{
  const action=(e.ctrlKey||e.metaKey)&&e.shiftKey&&!e.altKey?shortcutActions[e.code]:null;
  if(action){
   e.preventDefault();e.stopPropagation();cancelHeldTimer();
   if(heldCustomize){heldCustomize=false;editing=false;if(gesture)stopGesture(true);render()}
   if(!e.repeat)action();
   return;
  }
  if(!['Control','Shift','Meta'].includes(e.key)){cancelHeldTimer();return}
  if(e.target.closest?.('input,textarea,select,[contenteditable=true]'))return;
  if(e.ctrlKey&&e.shiftKey&&!heldCustomize&&!heldTimer&&!document.querySelector('dialog[open]'))heldTimer=setTimeout(()=>{heldTimer=0;if(heldCustomize||document.querySelector('dialog[open]'))return;heldCustomize=true;editing=true;profile().enabled=true;changed();render()},350);
 },true);
 const releaseHeld=e=>{if(!e.ctrlKey||!e.shiftKey)cancelHeldTimer();if(heldCustomize&&(!e.ctrlKey||!e.shiftKey)){heldCustomize=false;editing=false;if(gesture)stopGesture(true);render()}};
 document.addEventListener('keyup',releaseHeld);window.addEventListener('blur',()=>releaseHeld({}));
 $('#button-size').oninput=e=>{config.buttonSize=Number(e.target.value);document.documentElement.style.setProperty('--button-scale',config.buttonSize/100);$('#button-size-value').textContent=`${config.buttonSize}%`;changed()};
 const monitors=mountMonitorWindows({host:$('.layout-screen-settings'),panels:()=>PANELS.map(d=>({...d,el:widgetFor(d.key)?.el??nodes.get(d.key)?.el})),isLive});
 render();syncSafety();
 const loadRevision=revision;
 api('GET').then(data=>{if(data&&revision===loadRevision){config=validateWorkspace(data);render();status('Saved Workspace Restored')}}).catch(()=>status('Local View. Download Workspace To Keep A Copy.'));
 return {
  monitors,openCatalog,placePanel,
  labelAlignment:()=>({...config.labelAlignment}),
  setLabelAlignment(device,value){if(['desktop','mobile'].includes(device)&&['left','right','center'].includes(value)){config.labelAlignment[device]=value;changed();render()}},
  async saveNow(){clearTimeout(saveTimer);try{await api('PUT',config);status('Workspace Saved For This Visitor');return true}catch{status('Not Saved Online. Download A Workspace Copy.');return false}},
  showPanel(type){profile().enabled=true;let item=profile().panels.find(p=>p.type===type);if(!item)return;item.visible=true;item.minimized=false;changed();render()},
  serialize:()=>structuredClone(config),currentProfile:()=>structuredClone(profile()),restore(raw){config=validateWorkspace(raw);changed();render()},isCustom:()=>profile().enabled||focused,
  showMaster(visible){profile().panels.find(p=>p.key==='master').visible=visible;changed();render()},
  instructor(command){
   // Narrow, presentation-only surface. Never replay arbitrary DOM input or output controls.
   if(command.action==='customize'){profile().enabled=true;editing=true;render();return}
   const item=profile().panels.find(p=>p.key===command.panel);if(!item)return;
   profile().enabled=true;item.visible=true;
   if(command.action==='minimize')item.minimized=command.value===true;
   if(command.action==='resize'){item.height=clamp(Math.round(command.height),minHeight(item.key),1200);item.span=[6,9,12].includes(command.span)?command.span:12}
   if(command.action==='move'&&['left','main','right'].includes(command.zone)){item.zone=command.zone;item.float=null}
   changed();render();cards.get(item.key).scrollIntoView({block:'center',behavior:'smooth'});
  }
 };
}
