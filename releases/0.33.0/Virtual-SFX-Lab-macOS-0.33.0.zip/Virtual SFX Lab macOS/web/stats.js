// Owner statistics page. The owner key is held in sessionStorage for this tab only and sent as a
// request header; the page renders aggregates returned by /api/owner/stats. Nothing is written back.
const PORT='__PORT_8093__';
const API=PORT.startsWith('__')?'http://127.0.0.1:8093':PORT;
const $=s=>document.querySelector(s);
const gate=$('#stats-gate'),dash=$('#stats-dash'),tools=$('#stats-tools'),status=$('#gate-status'),keyInput=$('#owner-key'),daysSelect=$('#stats-days');
const KEY='vsl-owner-key';
let data=null;
const fmt=n=>Number(n||0).toLocaleString('en-CA');
const money=(cents,cur)=>cents?`${(cents/100).toLocaleString('en-CA',{style:'currency',currency:cur||'CAD'})}`:'—';
const when=iso=>iso?new Date(iso).toLocaleString('en-CA',{dateStyle:'medium',timeStyle:'short'}):'—';
const PAGE_NAMES={landing:'Landing page',studio:'Wave Studio',monitor:'Companion monitor',other:'Other'};
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

async function load(key,days){
 const r=await fetch(`${API}/api/owner/stats?days=${encodeURIComponent(days)}`,{headers:{'X-Owner-Key':key},signal:AbortSignal.timeout(12000)});
 if(r.status===401||r.status===403)throw Error('That key is not valid.');
 if(r.status===429)throw Error('Too many attempts. Try again in fifteen minutes.');
 if(!r.ok)throw Error(`The statistics service answered ${r.status}.`);
 return r.json();
}
function rows(tbody,list,render,empty){tbody.innerHTML=list.length?list.map(render).join(''):`<tr><td class="empty" colspan="4">${empty}</td></tr>`}
function render(d){
 data=d;
 const w=d.window,a=d.allTime,t=d.today,u=d.usage;
 $('#stats-meta').textContent=`Updated ${when(d.generated)} · tracking since ${d.trackingSince?when(d.trackingSince):'first visit after publish'} · period: last ${d.days} day${d.days===1?'':'s'}`;
 $('#kpis').innerHTML=[
  ['Views · period',fmt(w.views),`${fmt(a.views)} all time`],
  ['Unique visitors · period',fmt(w.visitors),`${fmt(a.visitors)} all time`],
  ['New visitors · period',fmt(w.newVisitors),`${fmt(d.returning)} have returned`],
  ['Today (UTC)',fmt(t.views),`${fmt(t.visitors)} visitor${t.visitors===1?'':'s'}`],
  ['In the studio now',fmt(u.liveNow),'last 75 seconds'],
 ].map(([l,v,s])=>`<div class="kpi"><span>${l}</span><strong>${v}</strong><small>${s}</small></div>`).join('');
 drawChart(d.daily,d.days);
 rows($('#pages-table tbody'),d.pages,p=>`<tr><td>${esc(PAGE_NAMES[p.page]||p.page)}</td><td>${fmt(p.views)}</td><td>${fmt(p.visitors)}</td></tr>`,'No views in this period.');
 rows($('#ref-table tbody'),d.referrers,r=>`<tr><td>${esc(r.host)}</td><td>${fmt(r.views)}</td></tr>`,'No views in this period.');
 const total=d.devices.reduce((s,x)=>s+x.views,0)||1;
 rows($('#device-table tbody'),d.devices,x=>`<tr><td>${esc(x.device[0].toUpperCase()+x.device.slice(1))}</td><td>${fmt(x.views)}</td><td>${Math.round(x.views/total*100)}%</td></tr>`,'No views in this period.');
 $('#usage').innerHTML=[
  ['Trials started',u.trialsTotal,`${fmt(u.trialsWindow)} in period`],
  ['Licenses granted',u.entitlements.reduce((s,e)=>s+e.count,0),`${fmt(u.entitlementsWindow)} in period`],
  ['Orders',u.orders.reduce((s,o)=>s+o.count,0),`${fmt(u.ordersWindow)} in period`],
  ['Saved sessions',u.savedSessions,`${fmt(u.sessionOwners)} owner${u.sessionOwners===1?'':'s'}`],
  ['Saved workspaces',u.savedWorkspaces,'desktop / mobile'],
  ['Custom layouts',u.customLayouts,`${fmt(u.defaultLayouts)} saved defaults`],
 ].map(([l,v,s])=>`<div><span>${l}</span><strong>${fmt(v)}</strong><small>${s}</small></div>`).join('');
 rows($('#ent-table tbody'),u.entitlements,e=>`<tr><td>${esc(e.kind)}</td><td>${esc(e.source||'—')}</td><td>${fmt(e.count)}</td></tr>`,'No licenses granted yet.');
 rows($('#orders-table tbody'),u.orders,o=>`<tr><td>${esc(o.product||'—')}</td><td>${esc(o.status||'—')}</td><td>${fmt(o.count)}</td><td>${money(o.total,o.currency)}</td></tr>`,'No orders yet.');
 gate.hidden=true;dash.hidden=false;tools.hidden=false;
}
function dayList(n){const out=[],now=new Date();for(let i=n-1;i>=0;i--){const d=new Date(Date.UTC(now.getUTCFullYear(),now.getUTCMonth(),now.getUTCDate()-i));out.push(d.toISOString().slice(0,10))}return out}
function drawChart(daily,days){
 const canvas=$('#daily-chart'),empty=$('#chart-empty');
 const byDay=Object.fromEntries(daily.map(d=>[d.day,d]));const labels=dayList(Math.min(days,365));
 const views=labels.map(d=>byDay[d]?.views||0),visitors=labels.map(d=>byDay[d]?.visitors||0);
 const max=Math.max(1,...views);empty.hidden=views.some(v=>v);
 const dpr=window.devicePixelRatio||1,W=canvas.clientWidth||800,H=260;canvas.width=W*dpr;canvas.height=H*dpr;
 const c=canvas.getContext('2d');c.scale(dpr,dpr);c.clearRect(0,0,W,H);
 const padL=44,padR=10,padT=12,padB=30,iw=W-padL-padR,ih=H-padT-padB;
 const css=getComputedStyle(document.documentElement);
 c.font='11px Satoshi, Helvetica Neue, Arial, sans-serif';c.textBaseline='middle';
 const ticks=Math.min(4,max);
 for(let i=0;i<=ticks;i++){const v=Math.round(max*i/ticks),y=padT+ih-(v/max)*ih;c.strokeStyle='#2a3238';c.beginPath();c.moveTo(padL,y);c.lineTo(W-padR,y);c.stroke();c.fillStyle='#a2adb3';c.textAlign='right';c.fillText(String(v),padL-8,y)}
 const n=labels.length,slot=iw/n,bw=Math.max(2,Math.min(26,slot*.62));
 labels.forEach((d,i)=>{const x=padL+slot*i+(slot-bw)/2;const hv=views[i]/max*ih,hu=visitors[i]/max*ih;
  c.fillStyle=css.getPropertyValue('--views').trim()||'#ffab73';c.fillRect(x,padT+ih-hv,bw,hv);
  c.fillStyle=css.getPropertyValue('--visitors').trim()||'#7fc4d8';c.fillRect(x+bw*.3,padT+ih-hu,bw*.4,hu)});
 const step=n<=7?1:n<=31?Math.ceil(n/8):n<=90?Math.ceil(n/9):Math.ceil(n/12);
 c.fillStyle='#a2adb3';c.textAlign='center';c.textBaseline='alphabetic';
 labels.forEach((d,i)=>{if((n-1-i)%step)return;const x=padL+slot*i+slot/2;c.fillText(n>31?d.slice(5):d.slice(5).replace('-','/'),x,H-10)});
}
async function show(key){
 status.textContent='Loading…';status.classList.remove('error');$('#gate-submit').disabled=true;
 try{render(await load(key,daysSelect.value));sessionStorage.setItem(KEY,key);status.textContent=''}
 catch(e){status.textContent=e.message||'Could not load statistics.';status.classList.add('error');sessionStorage.removeItem(KEY)}
 finally{$('#gate-submit').disabled=false}
}
$('#gate-form').addEventListener('submit',e=>{e.preventDefault();const k=keyInput.value.trim();if(k.length<8){status.textContent='Enter the owner key.';status.classList.add('error');return}show(k)});
$('#stats-refresh').onclick=()=>{const k=sessionStorage.getItem(KEY);if(k)show(k)};
daysSelect.onchange=()=>{const k=sessionStorage.getItem(KEY);if(k)show(k)};
$('#stats-signout').onclick=()=>{sessionStorage.removeItem(KEY);data=null;keyInput.value='';dash.hidden=true;tools.hidden=true;gate.hidden=false;keyInput.focus()};
addEventListener('resize',()=>{if(data&&!dash.hidden)drawChart(data.daily,data.days)});
const saved=sessionStorage.getItem(KEY);if(saved)show(saved);
