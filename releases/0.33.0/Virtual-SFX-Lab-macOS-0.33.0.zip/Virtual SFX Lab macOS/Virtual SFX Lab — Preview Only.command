#!/bin/bash
# Serves the demo, full studio and manual locally with no network input. Readable; no downloads or security changes.
cd -- "$(dirname -- "$0")" || exit 1
exec "./Virtual SFX Lab.command" --mode preview
