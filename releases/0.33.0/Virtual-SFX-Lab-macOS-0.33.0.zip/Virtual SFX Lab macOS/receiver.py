"""Wave Studio local Art-Net / sACN receiver. Python 3.10+; standard library only.

Receiver build for the Beta 0.33 web app (console presets: Vista 3, grandMA3, grandMA2; sACN Final + Draft): serves the complete web folder
(including subfolders such as vendor/) through a read-only allowlist.

UDP input: 6454. Outbound UDP: ArtPollReply only, when discovery is enabled.
HTTP/SSE: loopback only. Never transmits ArtDmx, triggering, or firing commands.
In sACN mode only UDP 5568 is bound; no application UDP output is sent.
Packet reference: https://art-net.org.uk/downloads/art-net.pdf
"""
import argparse
import ipaddress
import json
from pathlib import Path
import queue
import random
import socket
import struct
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import unquote, urlparse
import webbrowser

TIMEOUT = 2.5
RECEIVER_BUILD = "0.33.0"
# Console presets: default universes, startup hints and the tab the studio's receiver dialog opens.
CONSOLES = {
    "vista": {"label": "Vista 3", "tab": "vista",
              "hints": ["In Vista: Connect Universes > Add Network Connection > Streaming ACN, universe 1, priority 100,",
                        "same IPv4 as the interface above (Art-Net: Vista on a separate PC)."]},
    "grandma3": {"label": "grandMA3", "tab": "ma3",
                 "hints": ["grandMA3: Menu > DMX Protocols > sACN: Enabled Yes, Mode Output Multicast, Local Universe 1,",
                           "Amount 4, sACN Universe 1, Priority 100, then Enable Output (Send sACN If Idle Master when alone).",
                           "Art-Net: Mode Unicast to this computer, Art-Net Absolute 0 = Wave Studio port 0.",
                           "Unicast sACN to this computer's IPv4 is accepted too. onPC needs MA hardware to output."]},
    "grandma2": {"label": "grandMA2", "tab": "ma2",
                 "hints": ["grandMA2: Setup > Network > Network Protocols > sACN: Local Start 1, Amount 4, sACN Universe 1,",
                           "Priority 100, Protocol Final or Draft (both are read), Mode Output Multicast, sACN Output Active,",
                           "Network DMX if Alone when the console is the only station. Art-Net: Network 1 / Subnet 0 / Universe 0 = port 0.",
                           "onPC needs MA hardware (command wing, fader wing, 2Port Node onPC) to output."]},
    "other": {"label": "sACN / Art-Net source", "tab": "vista",
              "hints": ["Any sACN (E1.31 Final or Draft) or Art-Net 4 ArtDmx source: universe 1 = port address 0 = Wave Studio slot 0."]},
}
HERE = Path(__file__).resolve().parent
# Packaged layout keeps web/ beside receiver.py; the repository keeps it one level up.
WEB = HERE / "web" if (HERE / "web").is_dir() else HERE.parent / "web"
# Optional explicit allowlist of relative paths. None serves any allowed file under WEB.
FILES = None
CONTENT_TYPES = {
    ".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8",
    ".js": "text/javascript; charset=utf-8", ".mjs": "text/javascript; charset=utf-8",
    ".json": "application/json; charset=utf-8", ".md": "text/markdown; charset=utf-8",
    ".svg": "image/svg+xml", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png",
    ".webp": "image/webp", ".ico": "image/x-icon", ".txt": "text/plain; charset=utf-8",
    ".woff2": "font/woff2", ".mp3": "audio/mpeg", ".wav": "audio/wav", ".LICENSE": "text/plain; charset=utf-8",
}


def resolve_web_file(web_dir, request_path):
    """Map a URL path to a file inside web_dir, or None. No traversal, dotfiles or odd types."""
    relative = request_path.lstrip("/") or "index.html"
    parts = relative.split("/")
    if any(part in {"", ".", ".."} or part.startswith(".") or "\\" in part or ":" in part
           or "\x00" in part for part in parts):
        return None
    if FILES is not None and relative not in FILES:
        return None
    root = Path(web_dir).resolve()
    try:
        candidate = (root / relative).resolve()
        if root not in candidate.parents or not candidate.is_file():
            return None
    except (OSError, ValueError):  # odd path input degrades to a plain 404
        return None
    if candidate.suffix not in CONTENT_TYPES:
        return None
    return candidate


def web_build_version(web_dir):
    try:
        return json.loads((Path(web_dir) / "development.json").read_text(encoding="utf-8")).get("version", "unknown")
    except (OSError, ValueError):
        return "unknown"
NODE_NAME = "Wave Studio"
NODE_LONG_NAME = "Wave Studio - Virtual DMX receiver"
ARTNET_PORT = 6454
SACN_PORT = 5568
ACN_ID = b"ASC-E1.17\0\0\0"


def parse_sacn(data):
    """ANSI E1.31 data PDUs, null start code; no extended/discovery PDUs."""
    if len(data) < 126 or data[:4] != b"\x00\x10\x00\x00" or data[4:16] != ACN_ID:
        return None
    for offset in (16, 38, 115):
        flags_length = struct.unpack_from(">H", data, offset)[0]
        if flags_length >> 12 != 7 or (flags_length & 0xFFF) != len(data) - offset:
            return None
    if struct.unpack_from(">I", data, 18)[0] != 4 or struct.unpack_from(">I", data, 40)[0] != 2:
        return None
    if data[117:123] != b"\x02\xa1\x00\x00\x00\x01":
        return None
    count = struct.unpack_from(">H", data, 123)[0]
    universe = struct.unpack_from(">H", data, 113)[0]
    if not 1 <= count <= 513 or len(data) != 125 + count or not 1 <= universe <= 63999:
        return None
    if data[125] != 0 or data[108] > 200:
        return None
    return {"wireUniverse": universe, "universe": universe - 1, "sequence": data[111],
            "cid": data[22:38].hex(), "priority": data[108],
            "sourceName": data[44:108].split(b"\0", 1)[0].decode("utf-8", errors="replace"),
            "terminated": bool(data[112] & 0x40), "preview": bool(data[112] & 0x80),
            "syncAddress": struct.unpack_from(">H", data, 109)[0],
            "values": list(data[126:])}


def parse_sacn_draft(data):
    """Pre-ratification E1.31 "Draft" (streaming ACN, 2006/2009) as still offered by grandMA2:
    root vector 3, 32-byte source name, no sync/options fields."""
    if len(data) < 92 or data[:4] != b"\x00\x10\x00\x00" or data[4:16] != ACN_ID:
        return None
    for offset in (16, 38, 80):
        flags_length = struct.unpack_from(">H", data, offset)[0]
        if flags_length >> 12 != 7 or (flags_length & 0xFFF) != len(data) - offset:
            return None
    if struct.unpack_from(">I", data, 18)[0] != 3 or struct.unpack_from(">I", data, 40)[0] != 2:
        return None
    if data[82:88] != b"\x02\xa1\x00\x00\x00\x01":
        return None
    count = struct.unpack_from(">H", data, 88)[0]
    universe = struct.unpack_from(">H", data, 78)[0]
    if not 1 <= count <= 513 or len(data) != 90 + count or not 1 <= universe <= 63999:
        return None
    if data[90] != 0 or data[76] > 200:
        return None
    return {"wireUniverse": universe, "universe": universe - 1, "sequence": data[77],
            "cid": data[22:38].hex(), "priority": data[76],
            "sourceName": data[44:76].split(b"\0", 1)[0].decode("utf-8", errors="replace"),
            "terminated": False, "preview": False, "syncAddress": 0, "format": "draft",
            "values": list(data[91:])}


def parse_sacn_any(data):
    """ANSI E1.31 Final first, then the grandMA2 Draft format."""
    packet = parse_sacn(data)
    if packet:
        packet["format"] = "final"
        return packet
    return parse_sacn_draft(data)


def sacn_group(universe):
    return f"239.255.{universe >> 8}.{universe & 255}"


def open_input_socket(protocol, bind, interface, universes):
    """No port stealing/reuse. Multicast joins do not open Art-Net's port."""
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    if hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
    try:
        sock.bind((bind, SACN_PORT if protocol == "sacn" else ARTNET_PORT))
        if protocol == "sacn":
            for universe in universes:
                membership = socket.inet_aton(sacn_group(universe)) + socket.inet_aton(interface)
                sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, membership)
        return sock
    except OSError:
        sock.close()
        raise


def parse_artpoll(data):
    """ArtPoll is at least 14 bytes; absent optional fields are zero."""
    if len(data) < 14 or data[:8] != b"Art-Net\0" or struct.unpack_from("<H", data, 8)[0] != 0x2000:
        return None
    if struct.unpack_from(">H", data, 10)[0] < 14:
        return None
    optional = data[:18].ljust(18, b"\0")
    top, bottom = struct.unpack_from(">HH", optional, 14)
    targeted = bool(data[12] & 0x20)
    if targeted and not 0 <= bottom <= top <= 32767:
        return None
    return {"targeted": targeted, "bottom": bottom, "top": top}


def universe_groups(universes):
    """Each bound reply shares Net/Sub-Net and describes at most four ports."""
    groups = []
    for universe in sorted(set(universes)):
        if not groups or len(groups[-1]) == 4 or groups[-1][0] >> 4 != universe >> 4:
            groups.append([])
        groups[-1].append(universe)
    return groups


def make_poll_reply(ip, universes, bind_index=1, reply_count=0):
    """Art-Net 4 ArtPollReply, 239 bytes; virtual DMX output ports, no RDM."""
    if not 1 <= len(universes) <= 4 or not 1 <= bind_index <= 255:
        raise ValueError("One to four ports and a valid BindIndex are required")
    if any(not 0 <= u <= 32767 or u >> 4 != universes[0] >> 4 for u in universes):
        raise ValueError("Bound ports must share Net and Sub-Net")
    packet = bytearray(239)
    packet[:8] = b"Art-Net\0"
    struct.pack_into("<H", packet, 8, 0x2100)
    packed_ip = socket.inet_aton(ip)
    packet[10:14] = packed_ip
    struct.pack_into("<H", packet, 14, ARTNET_PORT)
    struct.pack_into(">H", packet, 16, 0x0002)  # Receiver build 2.
    packet[18] = universes[0] >> 8
    packet[19] = (universes[0] >> 4) & 15
    struct.pack_into(">H", packet, 20, 0x00FF)  # OemUnknown, not a registered product ID.
    packet[23] = 0xC0  # Normal indicators; no RDM, UBEA or network-programming claim.
    # ESTA manufacturer and MAC stay zero: do not impersonate a vendor/interface.
    def text(offset, size, value):
        encoded = value.encode("ascii")[:size - 1]
        packet[offset:offset + len(encoded)] = encoded
    text(26, 18, NODE_NAME if bind_index == 1 else f"{NODE_NAME} {bind_index}")
    text(44, 64, NODE_LONG_NAME)  # Identical on every bound reply.
    text(108, 64, f"#0001 [{reply_count % 10000:04d}] Visual receiver; no DMX output")
    struct.pack_into(">H", packet, 172, len(universes))
    for port, universe in enumerate(universes):
        packet[174 + port] = 0x80  # Network-to-virtual-DMX sink; no network input.
        packet[190 + port] = universe & 15
        packet[213 + port] = 0xB0  # RDM disabled; no RDM/background discovery; delta.
    packet[200] = 0x00  # StNode: a virtual receiver node for controller patching.
    packet[207:211] = packed_ip
    packet[211] = bind_index
    packet[212] = 0x08  # 15-bit Port-Address support; no sACN/RDM/web-config claims.
    # GoodOutputA stays zero: there is no physical DMX512 output.
    # Status3, responder UID, refresh rate and future/reserved fields stay zero.
    return bytes(packet)


class Discovery:
    """Bounded, delayed unicast replies. Never blocks the ArtDmx receive loop."""
    def __init__(self, hub, universes=(0, 1, 2, 3), bind="0.0.0.0", advertise_ip=None, enabled=True):
        self.hub = hub
        self.groups = universe_groups(universes)
        self.bind = bind
        self.advertise_ip = advertise_ip
        self.enabled = enabled
        self.pending = {}
        self.recent = {}
        self.last_accepted = -float("inf")

    def config(self):
        return {"enabled": self.enabled, "name": NODE_NAME,
                "universes": [u for group in self.groups for u in group],
                "advertiseIP": self.advertise_ip, "replyOnly": True}

    def queue_poll(self, data, source_ip, now=None):
        now = time.monotonic() if now is None else now
        poll = parse_artpoll(data)
        if not self.enabled or poll is None:
            return
        if self.hub.source_ip and source_ip != self.hub.source_ip:
            return
        try:
            source = ipaddress.IPv4Address(source_ip)
        except ValueError:
            return
        if source.is_multicast or source.is_unspecified or str(source) == "255.255.255.255":
            return
        eligible = [(index + 1, group) for index, group in enumerate(self.groups)
                    if not poll["targeted"] or any(poll["bottom"] <= u <= poll["top"] for u in group)]
        if not eligible:
            return
        # Limit reflection and memory use: max 4 accepted polls/s globally,
        # max 2/s per source. Vista's normal polling interval is much longer.
        self.recent = {ip: stamp for ip, stamp in self.recent.items() if now - stamp < 3}
        if now - self.last_accepted < .25 or now - self.recent.get(source_ip, -float("inf")) < .5:
            return
        if len(self.pending) >= 32:
            return
        self.last_accepted = now
        self.recent[source_ip] = now
        self.pending[source_ip] = (now + random.uniform(.05, .2), eligible)
        with self.hub.lock:
            self.hub.discovery_polls += 1

    def local_ip(self, controller_ip):
        if self.advertise_ip:
            return self.advertise_ip
        if self.bind != "0.0.0.0":
            return self.bind
        # UDP connect selects an OS route without sending a datagram.
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as route:
            route.connect((controller_ip, ARTNET_PORT))
            return route.getsockname()[0]

    def flush(self, sock, now=None):
        now = time.monotonic() if now is None else now
        for source, (due, groups) in list(self.pending.items()):
            if due > now:
                continue
            del self.pending[source]
            try:
                ip = self.local_ip(source)
                for index, group in groups:
                    reply = make_poll_reply(ip, group, index, self.hub.discovery_replies + 1)
                    # The fixed Art-Net port, not an arbitrary request source port.
                    sock.sendto(reply, (source, ARTNET_PORT))
                    with self.hub.lock:
                        self.hub.discovery_replies += 1
            except OSError:
                with self.hub.lock:
                    self.hub.discovery_errors += 1


def parse_artdmx(data):
    if len(data) < 18 or data[:8] != b"Art-Net\0":
        return None
    if struct.unpack_from("<H", data, 8)[0] != 0x5000:
        return None
    if struct.unpack_from(">H", data, 10)[0] < 14 or data[15] & 0x80:
        return None
    length = struct.unpack_from(">H", data, 16)[0]
    if length < 2 or length > 512 or length % 2 or len(data) < 18 + length:
        return None
    return {
        "universe": data[14] | (data[15] << 8),
        "sequence": data[12],
        "values": list(data[18:18 + length]),
    }


class Hub:
    def __init__(self, source_ip=None):
        self.lock = threading.Lock()
        self.clients = set()
        self.sources = {}
        self.source_ip = source_ip
        self.received = 0
        self.rejected = 0
        self.conflicts = 0
        self.discovery_polls = 0
        self.discovery_replies = 0
        self.discovery_errors = 0

    def accept(self, data, source, now=None):
        now = time.monotonic() if now is None else now
        packet = parse_artdmx(data)
        with self.lock:
            if not packet or (self.source_ip and source != self.source_ip):
                self.rejected += 1
                return None
            universe = packet["universe"]
            old = self.sources.get(universe)
            if old and now - old["time"] <= TIMEOUT:
                if old["source"] != source:
                    self.conflicts += 1
                    return None
                seq, prev = packet["sequence"], old["sequence"]
                # Art-Net sequence is 1..255; zero disables sequencing.
                if seq and prev and not 0 < (seq - prev) % 255 <= 127:
                    self.rejected += 1
                    return None
            if universe not in self.sources and len(self.sources) >= 128:
                expired = [u for u, value in self.sources.items() if now - value["time"] > TIMEOUT]
                for u in expired:
                    del self.sources[u]
                if len(self.sources) >= 128:
                    self.rejected += 1
                    return None
            self.sources[universe] = {"source": source, "time": now, "sequence": packet["sequence"]}
            packet.update(source=source, kind="dmx")
            self.received += 1
            self.publish_locked(packet)
            return packet

    def publish_locked(self, packet):
        for client in self.clients:
            if client.full():
                # Never silently skip cue edges when a browser cannot keep up.
                while not client.empty():
                    try:
                        client.get_nowait()
                    except queue.Empty:
                        break
                client.put_nowait({"kind": "reset", "reason": "Input queue overflow: reset trigger"})
            client.put_nowait(packet)

    def status(self):
        with self.lock:
            return {"kind": "status", "received": self.received, "rejected": self.rejected, "conflicts": self.conflicts,
                    "discoveryPolls": self.discovery_polls, "discoveryReplies": self.discovery_replies,
                    "discoveryErrors": self.discovery_errors}


class SACNHub(Hub):
    """Single-source visualizer; higher universe priority can take ownership.

    Equal-priority HTP/PAP merging is deliberately not implemented.
    Synchronization is ignored by this unsynchronized visualizer per E1.31 §6.2.4.
    Preview data is accepted because this application is visualization-only.
    """
    def __init__(self, source_ip=None, universes=(1, 2, 3, 4)):
        super().__init__(source_ip)
        self.universes = set(universes)
        self.datagrams = 0
        self.ignored = 0
        self.terminations = 0
        self.drafts = 0

    def accept(self, data, source, now=None):
        now = time.monotonic() if now is None else now
        packet = parse_sacn_any(data)
        with self.lock:
            self.datagrams += 1
            if not packet:
                self.rejected += 1
                return None
            if packet["wireUniverse"] not in self.universes or (self.source_ip and source != self.source_ip):
                self.ignored += 1
                return None
            universe = packet["universe"]
            identity = f"{source}/{packet['cid']}"
            old = self.sources.get(universe)
            active = old and now - old["time"] <= TIMEOUT
            if packet["terminated"]:
                if old and old["identity"] == identity:
                    del self.sources[universe]
                    self.terminations += 1
                    event = {"kind": "universe_reset", "universe": universe, "reason": "sACN stream terminated"}
                    self.publish_locked(event)
                    return event
                self.ignored += 1
                return None
            if active:
                if old["identity"] != identity and packet["priority"] <= old["priority"]:
                    self.conflicts += 1
                    return None
                if old["identity"] == identity:
                    # E1.31 signed 8-bit B-A: discard duplicates and -19..-1.
                    delta = (packet["sequence"] - old["sequence"] + 128) % 256 - 128
                    if -20 < delta <= 0:
                        self.rejected += 1
                        return None
            self.sources[universe] = {"identity": identity, "priority": packet["priority"],
                                      "sequence": packet["sequence"], "time": now}
            packet.update(kind="dmx", source=source, sourceId=identity, protocol="sACN")
            if packet["format"] == "draft":
                self.drafts += 1
            self.received += 1
            self.publish_locked(packet)
            return packet

    def status(self):
        result = super().status()
        with self.lock:
            result.update(datagrams=self.datagrams, ignored=self.ignored, terminations=self.terminations, drafts=self.drafts)
        return result


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def do_GET(self):
        if getattr(self.server, "stopping", False):
            self.send_error(503, "Receiver stopped; reload after restarting")
            return
        allowed_hosts = {f"127.0.0.1:{self.server.server_port}", f"localhost:{self.server.server_port}"}
        host = self.headers.get("Host", "")
        origin = self.headers.get("Origin")
        if host not in allowed_hosts or (origin and origin not in {f"http://{h}" for h in allowed_hosts}):
            self.send_error(403, "Local Wave Studio origin required")
            return
        path = unquote(urlparse(self.path).path)
        if path == "/api/info":
            data = json.dumps({"app": "wave-studio-receiver", "version": 3, "receiverBuild": RECEIVER_BUILD,
                               "webBuild": web_build_version(self.server.web_dir), **self.server.input_config,
                               "timeout": TIMEOUT, "sourceIP": self.server.hub.source_ip,
                               "discovery": self.server.discovery.config()}).encode()
            self.reply(data, "application/json")
        elif path == "/api/events":
            self.events()
        elif path.startswith("/api/"):
            self.send_error(404, "Not provided by the local receiver")
        else:
            self.file(path)

    def reply(self, data, content_type):
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        # Desktop Start/Stop can replace this server with another protocol.
        # Do not let a pooled connection keep serving an obsolete server instance.
        self.send_header("Connection", "close")
        self.close_connection = True
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Cross-Origin-Resource-Policy", "same-origin")
        self.send_header("Content-Security-Policy", "frame-ancestors 'self'")
        self.end_headers()
        self.wfile.write(data)

    def file(self, path):
        target = resolve_web_file(self.server.web_dir, path)
        if target is None:
            self.send_error(404, "Missing app file: keep the web folder beside receiver.py")
            return
        try:
            data = target.read_bytes()
        except OSError:
            self.send_error(404, "Missing app file: keep the web folder beside receiver.py")
            return
        content_type = CONTENT_TYPES.get(target.suffix, "text/plain; charset=utf-8")
        self.reply(data, content_type)

    def events(self):
        hub = self.server.hub
        client = queue.Queue(maxsize=256)
        with hub.lock:
            full = len(hub.clients) >= 4
            if not full:
                hub.clients.add(client)
        if full:  # reply outside the lock so a stalled client cannot block DMX ingest
            self.send_error(503, "Close other Wave Studio live tabs; four connections maximum")
            return
        try:
            self.connection.settimeout(5)
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Connection", "keep-alive")
            self.end_headers()
            self.wfile.write(b'data: {"kind":"hello"}\n\n')
            self.wfile.flush()
            last_status = time.monotonic()
            while not getattr(self.server, "stopping", False):
                try:
                    payload, is_status = client.get(timeout=.5), False
                except queue.Empty:
                    payload, is_status = hub.status(), True
                self.wfile.write(("data: " + json.dumps(payload, separators=(",", ":")) + "\n\n").encode())
                # One status frame at least every second while DMX is flowing; idle ticks already are one.
                if is_status:
                    last_status = time.monotonic()
                elif time.monotonic() - last_status > 1:
                    self.wfile.write(("data: " + json.dumps(hub.status(), separators=(",", ":")) + "\n\n").encode())
                    last_status = time.monotonic()
                self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError, TimeoutError, OSError):
            pass
        finally:
            with hub.lock:
                hub.clients.discard(client)
            self.close_connection = True

    def log_message(self, message, *args):
        if args and str(args[1] if len(args) > 1 else "") not in {"200", "404"}:
            super().log_message(message, *args)

    # send_error logs once through log_error (with its message) and again through log_request.
    # Keep one line per blocked request: the descriptive one. Routine 404s stay quiet.
    def log_request(self, code="-", size="-"):
        if str(code).isdigit() and int(code) >= 400:
            return
        super().log_request(code, size)

    def log_error(self, format, *args):
        if args and args[0] == 404:
            return
        super().log_error(format, *args)


def receive(sock, hub, discovery):
    sock.settimeout(.05)
    while True:
        try:
            data, address = sock.recvfrom(2048)
            if len(data) >= 10 and data[:8] == b"Art-Net\0":
                opcode = struct.unpack_from("<H", data, 8)[0]
                if opcode == 0x2000:
                    discovery.queue_poll(data, address[0])
                elif opcode == 0x5000:
                    hub.accept(data, address[0])
                # Ignore ArtPollReply/ArtAddress/ArtTrigger/etc.; never echo them.
            else:
                with hub.lock:
                    hub.rejected += 1
        except socket.timeout:
            pass
        except OSError:
            return
        discovery.flush(sock)


def receive_sacn(sock, hub):
    sock.settimeout(.1)
    while True:
        try:
            data, address = sock.recvfrom(2048)
            hub.accept(data, address[0])
        except socket.timeout:
            pass
        except OSError:
            return


def check_universes(universes, sacn):
    """Full E1.31 range for sACN (1-63999); Art-Net port-addresses are 15-bit (0-32767)."""
    lower, upper = (1, 63999) if sacn else (0, 32767)
    if not 1 <= len(universes) <= 16 or any(u < lower or u > upper for u in universes):
        raise ValueError(f"--universes requires 1–16 addresses between {lower} and {upper}")
    return universes


def main():
    parser = argparse.ArgumentParser(description="Wave Studio: Art-Net or sACN visualization input")
    parser.add_argument("--protocol", choices=("artnet", "sacn"), default="artnet")
    parser.add_argument("--console", choices=tuple(CONSOLES), default="vista",
                        help="Console preset for the startup hints and the studio's receiver dialog (default: vista)")
    parser.add_argument("--bind", default="0.0.0.0", help="IPv4 listening address (sACN: leave wildcard)")
    parser.add_argument("--interface", default="0.0.0.0", help="sACN multicast interface IPv4; match Vista, default OS route")
    parser.add_argument("--source-ip", help="Optional allowed Vista sender IPv4 address")
    parser.add_argument("--port", type=int, default=8765, help="Loopback web port (default: 8765)")
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--no-discovery", action="store_true", help="Disable ArtPollReply; receive DMX only")
    parser.add_argument("--universes", help="Up to 16 comma-separated addresses: Art-Net 0-based, sACN 1-based")
    parser.add_argument("--advertise-ip", help="Local IPv4 address to advertise; normally selected from the route to Vista")
    parser.add_argument("--web-dir", type=Path, default=WEB, help=argparse.SUPPRESS)
    args = parser.parse_args()
    try:
        ipaddress.IPv4Address(args.bind)
        if args.source_ip:
            ipaddress.IPv4Address(args.source_ip)
        ipaddress.IPv4Address(args.interface)
        sacn = args.protocol == "sacn"
        if sacn and args.bind != "0.0.0.0":
            raise ValueError("sACN uses --interface for multicast selection; leave --bind at 0.0.0.0")
        if sacn and args.advertise_ip:
            raise ValueError("--advertise-ip is for Art-Net only; sACN uses --interface")
        if args.interface != "0.0.0.0":
            address = ipaddress.IPv4Address(args.interface)
            if address.is_multicast or str(address) == "255.255.255.255":
                raise ValueError("--interface must be a local unicast IPv4 address")
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as check:
                check.bind((str(address), 0))
        default_universes = "1,2,3,4" if sacn else "0,1,2,3"
        universes = sorted(set(int(value.strip()) for value in (args.universes or default_universes).split(",")))
        check_universes(universes, sacn)
        if args.advertise_ip:
            address = ipaddress.IPv4Address(args.advertise_ip)
            if address.is_unspecified or address.is_multicast or str(address) == "255.255.255.255":
                raise ValueError("--advertise-ip must be a local unicast IPv4 address")
            if args.bind != "0.0.0.0" and args.bind != args.advertise_ip:
                raise ValueError("--bind and --advertise-ip must match when binding a specific interface")
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as check:
                check.bind((str(address), 0))
        if not 1024 <= args.port <= 65535:
            raise ValueError("Web port must be between 1024 and 65535")
    except (ValueError, OSError) as error:
        parser.error(str(error))
    sock = None
    try:
        sock = open_input_socket(args.protocol, args.bind, args.interface, universes)
        server = ThreadingHTTPServer(("127.0.0.1", args.port), Handler)
    except OSError as error:
        if sock:
            sock.close()
        udp = SACN_PORT if sacn else ARTNET_PORT
        raise SystemExit(f"Cannot start receiver: {error}\nCheck UDP {udp}, web port {args.port}, and the selected interface.\n"
                         "For same-PC Vista, double-click Virtual SFX Lab.command. Do not run both receiver modes.")
    server.daemon_threads = True
    server.hub = SACNHub(args.source_ip, universes) if sacn else Hub(args.source_ip)
    server.discovery = Discovery(server.hub, universes if not sacn else [], args.bind,
                                 args.advertise_ip, not sacn and not args.no_discovery)
    console = CONSOLES[args.console]
    server.input_config = {"protocol": "sACN" if sacn else "Art-Net",
                           "udpPort": SACN_PORT if sacn else ARTNET_PORT, "universes": universes,
                           "interface": args.interface if sacn else args.bind,
                           "universeOffset": 1 if sacn else 0,
                           "console": args.console, "consoleLabel": console["label"], "consoleTab": console["tab"]}
    server.web_dir = args.web_dir
    if not (Path(args.web_dir) / "index.html").is_file():
        print(f"WARNING: web app not found at {args.web_dir}. Keep the web folder beside receiver.py.", flush=True)
    target, params = (receive_sacn, (sock, server.hub)) if sacn else (receive, (sock, server.hub, server.discovery))
    threading.Thread(target=target, args=params, daemon=True).start()
    # Open on the demo landing page first; the full studio (index.html) is one click away.
    url = f"http://127.0.0.1:{args.port}/welcome.html" if (Path(args.web_dir) / "welcome.html").is_file() else f"http://127.0.0.1:{args.port}"
    print(f"\nVIRTUAL SFX LAB | MODULE 1: WAVE STUDIO | DMX INPUT VISUALIZER | Beta {web_build_version(args.web_dir)} (receiver {RECEIVER_BUILD})\n"
          f"Console preset: {console['label']}\nOpen: {url}", flush=True)
    if sacn:
        print(f"sACN input: UDP 5568 (E1.31 Final and grandMA2 Draft, multicast or unicast) | multicast interface: {args.interface}\n"
              f"Subscribed universes (1-based): {', '.join(map(str, universes))}\n"
              "Art-Net port 6454 is NOT opened. No Art-Net node discovery in this mode.\n"
              "No outbound sACN/DMX/firing packets. OS multicast membership traffic only.", flush=True)
    else:
        print(f"ArtDmx input: {args.bind}:6454 UDP (ArtSync and other opcodes are ignored)\n"
              f"Discovery: {'OFF' if args.no_discovery else NODE_NAME + ' | port-addresses ' + ', '.join(map(str, universes))}\n"
              "Outbound Art-Net data: discovery replies only. No DMX/firing output.\n"
              f"Same-PC {console['label']} software conflicts on UDP 6454: use the sACN launcher instead.", flush=True)
    print("\n".join(console["hints"]), flush=True)
    print("Keep this window open. Press Ctrl+C to stop.\n", flush=True)
    if not args.no_browser:
        webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        sock.close()
        server.server_close()


if __name__ == "__main__":
    main()
