# Virtual SFX Lab for Windows — Module 1: Wave Studio

Windows desktop receiver and visualizer, version 0.31.1 — studio V0.31c (one-folder build: `Virtual SFX Lab.exe` plus an `_internal` folder that must stay beside it). This build is for 64-bit Intel/AMD Windows 10 or 11 and uses your existing Edge, Chrome, or other modern browser. Python, the receiver, the launcher, the web application, this guide, and third-party notices are bundled inside the executable.

## First launch

1. Stop your old Wave Studio receiver. Keep Vista running and keep real flame hardware disconnected from the rehearsal network.
2. Extract the ZIP to a stable folder, such as `Documents\Virtual SFX Lab`, keep `Virtual SFX Lab.exe` and `_internal` together, then double-click **Virtual SFX Lab.exe**. No Python installation, ZIP extraction, administrator access, or separate launcher is required.
3. Leave **Input mode** set to **sACN (same-PC Vista)**.
4. Choose or type the **Vista interface IPv4** shown in Vista's Network preferences. Your working setup used `192.168.137.1`; use it only if it is still Vista's selected local address. `0.0.0.0` asks Windows to choose the default interface, which may not match Vista on a multi-adapter PC.
5. Leave **Universes** at `1,2,3,4` and **Local web port** at `8765` unless your setup requires different values.
6. Step 2 of the window has two buttons. **Skip for now — open studio without a receiver** opens the demo, full studio and First Guide with no sACN or Art-Net input at all (use this if you are not connecting Vista yet; nothing in step 1 needs to be filled in). **Start receiver + open studio** (or pressing Enter) starts live input with the settings above. Click **Stop** at any time to switch between the two. Your browser opens on the **demo landing page** so you can learn the basic controls first; **Open the full studio** on that page opens the complete program, and the **First Guide** manual opens on top of it until you untick “Open when the studio starts”. The browser opens automatically unless you clear that checkbox. Keep the desktop launcher open while using live input.
7. Keep your working Vista Streaming ACN output. For the initial test, use sACN universe **1**, priority **100**, assign the intended internal Vista universe, and enable output. Vista's documented workflow adds the network connection and then assigns the internal universe ([Vista user guide](https://www.stars-europe.com/pdf/produits/LECONSOLE4+.pdf)).
8. In the browser, select **Live sACN**. Match each fixture's sACN universe and DMX start address to Vista, and apply any patch changes.
9. Check the launcher's **UDP received** and **DMX packets** counters. “Receiving DMX” means accepted level frames are arriving, not that the fixture is patched correctly or that a real device is safe to fire.

The desktop application remembers successfully started settings, but does not automatically start network reception when you next open it. Click Start receiver each time.

## Controls

- **Refresh:** Re-enumerates local IPv4 interfaces. You can type an address if it is absent from the list. Match Vista's current selection, not an address from an old screenshot.
- **Stop:** Stops reception and the local web server. The browser clears live effects when the stream closes. Restarting requires a fresh low-to-high trigger transition for visual effects.
- **Open visualizer:** Reopens the locally served demo landing page without restarting the receiver; the full studio and manual are one click away.
- **Setup guide:** Opens this bundled offline guide.
- **Open log folder:** Opens `%LOCALAPPDATA%\WaveStudio`, containing `settings.json` and bounded, rotating `receiver.log` files. Settings and logs are per Windows user; browser fixture layouts remain in browser storage or exported JSON.
- **Close the launcher:** Stops the receiver. Closing only the browser does not stop it.
- **Art-Net (separate PC):** Retains the existing Art-Net receiver and discovery replies. It uses UDP 6454 and zero-based port-addresses, so do not select it for your same-PC Vista configuration. Switching modes resets the universe list to the mode's defaults.

This build does not extract anything to a temporary folder: the Python runtime, receiver and web app live in `_internal` next to the executable, which also avoids the behaviour that antivirus heuristics flagged in the earlier single-file build. your settings and logs remain in `%LOCALAPPDATA%\WaveStudio` ([PyInstaller operating mode](https://pyinstaller.org/en/stable/operating-mode.html)).

## Security and permissions

This independently built executable is **unsigned**. It has no publisher certificate or established signing reputation. Treat Windows security warnings seriously; do not disable Defender, SmartScreen, or your firewall to run it. If your organization blocks unsigned software, ask your IT administrator to review it or continue using the already-working Python package.

If Windows asks for network permission, allow only the appropriate trusted/private rehearsal network. The web server listens only on `127.0.0.1`. sACN mode listens on UDP 5568, joins the selected multicast groups, and sends no application-level sACN or firing packets. Art-Net mode sends discovery replies only, never ArtDmx or firing commands.

This app does not contain Vista or supply a Vista output license. It is a visual rehearsal tool, not a firing controller, safety-validation system, or certified Explo emulator.

## Troubleshooting

- **Cannot start / address already in use:** Stop the old Python receiver and any second Wave Studio instance. Check that another application is not using UDP 5568 or the selected local web port. Do not kill Vista or change its working output to force a connection.
- **Selected address is not local:** Use Refresh and confirm Vista's selected interface is still connected. Re-enter its current IPv4.
- **Browser does not open:** Click Open visualizer, or type the local URL displayed in the launcher into your browser.
- **UDP received stays at zero:** Check Vista output assignment/enabling, the selected interface, subscriptions, and appropriate firewall permission. Same-PC multicast behavior depends on Vista and Windows; the Python version was confirmed working on your setup, but this packaged executable requires its own acceptance test.
- **UDP increases but DMX packets do not:** Note Rejected, Filtered, and Source conflicts, then check your universe list and other active sACN senders.
- **Packets arrive but no animation:** Check Live sACN, fixture universe/address, the six-channel profile, and low-before-high triggering. A packet count alone does not validate your patch.
- **Changed protocol or web port:** Stop reception first. After starting again, open or reload the visualizer; old tabs can retain old protocol labels until refreshed.
- **Settings are wrong:** Close the application, rename `%LOCALAPPDATA%\WaveStudio\settings.json`, and reopen. This resets launcher preferences, not fixture layouts.

No Art-Net node appears in sACN mode. Vista uses multicast sACN rather than a discovered receiver list ([Vista support discussion](https://vistaforum.chroma-q.com/t/weird-issue-with-vista-not-outputting-sacn-unless-i-open-up-sacnview-first/3236)).

## Build and test scope

Built with official Windows CPython 3.13.13 and PyInstaller 6.22.0 using a Wine compatibility environment. The application is a native Windows x64 executable, not a Linux binary or a script renamed to `.exe`. This build has not been code-signed and has not been tested on physical Windows hardware with Vista. The previously supplied Python sACN package was confirmed working by the user.

Protocol regression tests, packaged HTTP/SSE serving, synthetic sACN reception, browser rendering, and launcher behavior are checked during packaging. A final Windows/Vista test is still required before relying on this executable for rehearsal.

## References and notices

The visualization retains the published Explo six-channel DMX interpretation and 88-program catalog, with the existing prototype limitations. Consult the [Explo manual](https://explo.at/wp-content/uploads/2025/06/X2-Wave-Flamer-v2.0-ENG-2.pdf) and [program DMX values](https://explo.at/wp-content/uploads/2025/06/X2-Wave-Flame-Sequences-DMX-Values.pdf), and do not treat artistic rendering as a prediction of flame size, timing, mechanics, or safety distances.

Open the [bundled runtime license notices](licenses.html) for third-party terms. No third-party runtime needs to be installed separately.
