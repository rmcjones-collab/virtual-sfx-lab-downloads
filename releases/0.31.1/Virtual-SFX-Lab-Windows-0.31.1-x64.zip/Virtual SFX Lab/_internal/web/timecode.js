export const TC_RATES=[{label:'24 FPS',fps:24,nominal:24},{label:'25 FPS',fps:25,nominal:25},{label:'29.97 Drop Frame',fps:30000/1001,nominal:30,drop:true},{label:'30 FPS',fps:30,nominal:30}];
const pad=n=>String(n).padStart(2,'0');
export function parseTimecode(text,rate=1){
 const m=/^(\d{2}):(\d{2}):(\d{2})[:;](\d{2})$/.exec(text),r=TC_RATES[rate];
 if(!m||!r)throw Error('Use HH:MM:SS:FF.');
 const [h,mi,s,f]=m.slice(1).map(Number);
 if(h>23||mi>59||s>59||f>=r.nominal||(r.drop&&mi%10!==0&&s===0&&f<2))throw Error('Invalid Timecode At This Frame Rate.');
 return ((h*3600+mi*60+s)*r.nominal+f)-(r.drop?2*(h*60+mi-Math.floor((h*60+mi)/10)):0);
}
export function formatTimecode(frames,rate=1){
 const r=TC_RATES[rate],day=r.drop?2589408:86400*r.nominal;
 let f=((Math.floor(frames)%day)+day)%day;
 if(r.drop){const ten=Math.floor(f/17982),rest=f%17982;f+=18*ten+(rest>=2?2*Math.floor((rest-2)/1798):0)}
 const ff=f%r.nominal,seconds=Math.floor(f/r.nominal);
 return `${pad(Math.floor(seconds/3600)%24)}:${pad(Math.floor(seconds/60)%60)}:${pad(seconds%60)}${r.drop?';':':'}${pad(ff)}`;
}
export class MTCDecoder{
 constructor(){this.reset()}
 reset(){this.parts=Array(8).fill(0);this.last=null;this.count=0;this.direction=0}
 read(bytes){
  if(bytes[0]===0xf0&&bytes.length===10&&bytes[1]===0x7f&&bytes[3]===1&&bytes[4]===1&&bytes[9]===0xf7&&bytes.slice(1,9).every(v=>Number.isInteger(v)&&v>=0&&v<128)){
   this.reset();return this.decode(bytes[5],bytes[6],bytes[7],bytes[8],0);
  }
  if(bytes.length!==2||bytes[0]!==0xf1||bytes[1]>127)return null;
  const part=bytes[1]>>4,value=bytes[1]&15;
  if(this.last===null){if(part!==0&&part!==7)return null;this.direction=part===0?1:-1;this.count=0}
  else if(part!==this.last+this.direction){this.reset();if(part!==0&&part!==7)return null;this.direction=part===0?1:-1}
  this.parts[part]=value;this.last=part;this.count++;
  if(this.count<8)return null;
  const p=this.parts,result=this.decode((p[6]|((p[7]&1)<<4))|((p[7]>>1&3)<<5),p[4]|(p[5]<<4),p[2]|(p[3]<<4),p[0]|(p[1]<<4),this.direction);
  this.reset();return result;
 }
 decode(hour,minute,second,frame,direction){
  const rate=hour>>5&3;
  try{return {rate,frames:parseTimecode(`${pad(hour&31)}:${pad(minute)}:${pad(second)}:${pad(frame)}`,rate)+direction*2,direction}}
  catch{return null}
 }
}
export function createTimecode(){
 let rate=1,frames=0,origin=performance.now(),running=false,source='internal',access=null,input=null,lastRx=0,direction=1,connected=false,epoch=0,sysex=false,error='',chase=false,armed=false;
 const decoder=new MTCDecoder(),listeners=new Set();
 const notify=()=>listeners.forEach(fn=>fn());
 const value=()=>{
  const delta=(performance.now()-origin)/1000;
  return frames+(source==='internal'&&running?delta*TC_RATES[rate].fps:source==='midi'&&connected&&direction?Math.min(delta,2/TC_RATES[rate].fps)*TC_RATES[rate].fps*direction:0);
 };
 function freeze(){frames=value();origin=performance.now();running=false}
 function disconnect(){epoch++;freeze();if(access)access.onstatechange=null;if(input){input.onmidimessage=null;input.close().catch(()=>{})}input=null;connected=false;decoder.reset();notify()}
 function select(id){
  freeze();
  if(input){input.onmidimessage=null;input.close().catch(()=>{})}decoder.reset();lastRx=0;direction=0;
  input=access?.inputs.get(id)??null;connected=!!input;
  if(input)input.onmidimessage=e=>{const v=decoder.read([...e.data]);if(v){rate=v.rate;frames=v.frames;direction=v.direction;origin=lastRx=performance.now();error=''}};
  notify();
 }
 async function connect(full=false){
  disconnect();const token=epoch;source='midi';sysex=full;error='Requesting MIDI Permission';notify();
  try{
   if(!navigator.requestMIDIAccess)throw Error('Web MIDI Is Unavailable In This Browser. Use An Internal Clock Or A Web MIDI-Compatible Browser.');
   const next=await navigator.requestMIDIAccess({sysex:full});
   if(token!==epoch)return;
   access=next;error='';access.onstatechange=()=>{if(input?.state==='disconnected'){connected=false;input.onmidimessage=null;input=null;error='MIDI Input Disconnected'}notify()};
   select([...access.inputs.keys()][0]);if(!input)error='No MIDI Inputs Found';notify();
  }catch(e){if(token===epoch){error=e.message||'MIDI Permission Denied';notify()}}
 }
 return {
  subscribe(fn){listeners.add(fn);return()=>listeners.delete(fn)},
  get(){return {rate,frames:value(),text:formatTimecode(value(),rate),seconds:value()/TC_RATES[rate].fps,source,running,connected,chase:chase&&armed,chaseRequested:chase,armed,sysex,inputs:[...(access?.inputs.values()??[])].map(i=>({id:i.id,name:i.name||'MIDI Input'})),inputId:input?.id??'',status:error|| (source==='internal'?(running?'Internal Running':'Internal Paused'):!connected?'Disconnected':!lastRx?'Waiting For MTC':performance.now()-lastRx>500?'Signal Lost / Stopped':direction?'Receiving MTC':'Located (Full Frame)')}},
  connect,disconnect,select,
  internal(){disconnect();source='internal';error='';notify()},
  rate(v){if(!TC_RATES[Number(v)])return;freeze();rate=Number(v);frames=0;notify()},
  locate(text){frames=parseTimecode(text,rate);origin=performance.now();notify()},
  play(){if(source==='internal'&&!running){origin=performance.now();running=true;notify()}},
  pause(){freeze();notify()},
  reset(){frames=0;origin=performance.now();notify()},
  chase(v){chase=!!v;notify()},
  arm(v){armed=!!v;notify()}
 };
}
