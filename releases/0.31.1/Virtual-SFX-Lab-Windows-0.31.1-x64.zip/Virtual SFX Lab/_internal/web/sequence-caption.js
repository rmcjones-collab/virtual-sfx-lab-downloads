// Shared helpers for burning the running sequence into recorded video and
// keeping a timestamped sequence log alongside each clip.
const pad=n=>String(n).padStart(3,'0');
// groups: [{id, name, units:[fixture ids]}] in display order.
export function describeSequences(groups,{look='',total=0}={}){
 const clean=groups.filter(g=>g&&Number.isInteger(g.id));
 if(!clean.length)return {title:look?`Look · ${look}`:'Sequence',detail:'No Sequence Running',key:'none'};
 const unitText=units=>{
  const ids=[...units].sort((a,b)=>a-b);
  if(total&&ids.length===total)return total===1?'1 Unit':`All ${total} Units`;
  if(ids.length>4)return `${ids.length} Units`;
  return ids.map(id=>`F${String(id).padStart(2,'0')}`).join(', ');
 };
 const key=clean.map(g=>`${g.id}:${[...g.units].sort((a,b)=>a-b).join('.')}`).join('|')+(look?`#${look}`:'');
 if(clean.length===1){const g=clean[0];return {title:look?`Look · ${look} · Sequence ${pad(g.id)}`:`Sequence ${pad(g.id)}`,detail:`${g.name} · ${unitText(g.units)}`,key}}
 return {title:look?`Look · ${look} · ${clean.length} Sequences`:`${clean.length} Sequences`,detail:clean.map(g=>`${pad(g.id)} ${g.name} (${unitText(g.units)})`).join('  ·  '),key};
}
function fit(ctx,text,width){
 if(ctx.measureText(text).width<=width)return text;
 let lo=0,hi=text.length;
 while(lo<hi){const mid=(lo+hi+1)>>1;if(ctx.measureText(text.slice(0,mid)+'…').width<=width)lo=mid;else hi=mid-1}
 return text.slice(0,lo).trimEnd()+'…';
}
function lines(ctx,text,width,max){
 const words=text.split(' '),out=[];let line='';
 for(const word of words){const next=line?line+' '+word:word;if(line&&ctx.measureText(next).width>width){out.push(line);line=word;if(out.length===max)break}else line=next}
 if(out.length<max&&line)out.push(line);
 if(out.length===max&&words.join(' ')!==out.join(' '))out[max-1]=fit(ctx,out[max-1]+' …',width);
 return out.map(l=>fit(ctx,l,width));
}
// Lower-third caption painted over the recorded frame only.
export function drawSequenceCaption(ctx,w,h,info,elapsed=null){
 if(!info)return 0;
 const size=Math.max(11,Math.round(Math.min(h*.034,w*.022))),small=Math.max(10,Math.round(size*.82)),padX=Math.round(size*1.1),gap=Math.round(size*.35);
 ctx.save();
 ctx.font=`${small}px Arial, sans-serif`;
 const body=lines(ctx,info.detail||'',w-padX*2,2);
 const band=Math.round(size*1.25+body.length*(small*1.3)+gap*3);
 ctx.fillStyle='rgba(9,13,16,.78)';ctx.fillRect(0,h-band,w,band);
 ctx.fillStyle='#ff8a3d';ctx.fillRect(0,h-band,Math.max(3,Math.round(size*.22)),band);
 ctx.textBaseline='top';ctx.textAlign='left';
 ctx.font=`700 ${size}px Arial, sans-serif`;ctx.fillStyle='#ffb17c';
 const stamp=elapsed==null?'':`${Math.floor(elapsed/60)}:${String(Math.floor(elapsed%60)).padStart(2,'0')}`;
 ctx.fillText(fit(ctx,info.title||'',w-padX*2-(stamp?size*4:0)),padX,h-band+gap);
 if(stamp){ctx.textAlign='right';ctx.font=`${small}px Arial, sans-serif`;ctx.fillStyle='#a8b5bd';ctx.fillText(stamp,w-padX,h-band+gap+Math.round((size-small)/2));ctx.textAlign='left'}
 ctx.font=`${small}px Arial, sans-serif`;ctx.fillStyle='#e8edf0';
 body.forEach((line,i)=>ctx.fillText(line,padX,h-band+gap*2+size*1.1+i*small*1.3));
 ctx.restore();
 return band;
}
export function createSequenceLog(){
 const entries=[];let last='';
 return {
  mark(seconds,info){if(!info||info.key===last)return;last=info.key;if(entries.length<2000)entries.push({seconds,title:info.title,detail:info.detail})},
  entries,
  summary(){const seen=[];for(const e of entries){const t=`${e.title}: ${e.detail}`;if(!seen.includes(t))seen.push(t)}return seen},
  toText(name){
   const stamp=s=>`${String(Math.floor(s/60)).padStart(2,'0')}:${(s%60).toFixed(1).padStart(4,'0')}`;
   return [`Wave Studio sequence log for ${name}`,'Visual rehearsal only. No physical output.','',...entries.map(e=>`${stamp(e.seconds)}  ${e.title} · ${e.detail}`),''].join('\r\n');
  }
 };
}
