// Public manually reported history. No access to billing or private account usage.
export function creditHistory(data,previous=[]){
 const valid=n=>typeof n==='number'&&Number.isFinite(n)&&n>=0&&n<=Number.MAX_SAFE_INTEGER;
 const rows=(Array.isArray(data.creditsHistory)?data.creditsHistory:previous).filter(valid).slice(-120);
 if(valid(data.creditsUsed)&&rows.at(-1)!==data.creditsUsed)rows.push(data.creditsUsed);
 return rows;
}
export function drawCreditTrend(canvas,values,color='#ee9b62'){
 const scale=Math.min(2,globalThis.devicePixelRatio||1);canvas.width=42*scale;canvas.height=16*scale;
 const ctx=canvas.getContext('2d');ctx.scale(scale,scale);ctx.clearRect(0,0,42,16);if(!values.length)return;
 const low=Math.min(...values),high=Math.max(...values),range=high-low;
 ctx.strokeStyle=color;ctx.lineWidth=1.5;ctx.lineJoin='round';ctx.lineCap='round';ctx.beginPath();
 const points=values.length===1?[values[0],values[0]]:values;
 points.forEach((v,i)=>{const x=2+i/(points.length-1)*38,y=range?14-(v-low)/range*12:8;i?ctx.lineTo(x,y):ctx.moveTo(x,y)});ctx.stroke();
 canvas.setAttribute('aria-label',`Manually Reported Development Credits: ${values[0].toLocaleString()} To ${values.at(-1).toLocaleString()}, ${values.length} Reported Updates. Not Live Billing.`);
}
