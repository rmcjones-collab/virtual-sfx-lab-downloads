// A linked panel has one live control surface and any number of synchronized views.
// Activating a view reparents the ORIGINAL nodes, preserving handlers and safety state.
export function mirrorPanel(source,activate){
 const el=document.createElement('div');el.className='workspace-mirror';
 const button=document.createElement('button');button.textContent='Activate Linked Controls';button.onclick=activate;
 const hint=document.createElement('p');hint.className='widget-hint';hint.textContent='Shared Live View. Activate Here To Edit The Same Controls.';
 const view=document.createElement('div');view.className='mirror-view';view.inert=true;el.append(button,hint,view);
 let signature='',last=0;
 return {el,tick(){
  if(!el.isConnected||!el.getClientRects().length)return;
  const now=performance.now();
  if(now-last>500){
   last=now;const html=source.innerHTML;
   if(html!==signature){
    signature=html;const copy=source.cloneNode(true);
    for(const n of [copy,...copy.querySelectorAll('*')]){if(n.id){n.dataset.originId=n.id;n.removeAttribute('id')}n.removeAttribute('for');n.removeAttribute('autofocus');n.removeAttribute('name')}
    const original=source.querySelectorAll('input,select,textarea'),clones=copy.querySelectorAll('input,select,textarea');
    original.forEach((n,i)=>{clones[i].value=n.value;if('checked'in n)clones[i].checked=n.checked});
    view.replaceChildren(copy);
   }
  }
  const originals=source.querySelectorAll('input,select,textarea'),copies=view.querySelectorAll('input,select,textarea');
  originals.forEach((n,i)=>{if(!copies[i])return;copies[i].value=n.value;if('checked'in n)copies[i].checked=n.checked});
  const from=[...(source.matches('canvas')?[source]:source.querySelectorAll('canvas'))],to=[...view.querySelectorAll('canvas')];
  from.forEach((canvas,i)=>{if(!to[i]||!canvas.width||!canvas.height)return;if(to[i].width!==canvas.width)to[i].width=canvas.width;if(to[i].height!==canvas.height)to[i].height=canvas.height;to[i].getContext('2d').drawImage(canvas,0,0)});
 }};
}
