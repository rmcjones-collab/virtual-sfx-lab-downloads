// Keeps mouse/pen text work inside the panel where it started.
// 1. Clicking into a field never scrolls the page or another panel: the field is
//    already under the pointer, so any focus-driven scroll is reverted.
// 2. Drag-selecting text cannot extend into other panels, and cannot auto-scroll
//    the page or other panels. Scrolling inside the starting panel still works.
// Keyboard (Tab) focus and touch scrolling keep native behaviour.
const DEFAULT_PANELS='dialog[open],.workspace-card,.mobile-stage-control-panel,.support-panel,.conversation-window,.chess-panel,#playback-bank,.library,.inspector>section,.inspector,.fuel-panel,.quick-menu,.workspace-catalog,.simulator';
const FIELD='input:not([type=range]):not([type=checkbox]):not([type=radio]):not([type=button]):not([type=submit]):not([type=color]):not([type=file]),textarea,[contenteditable=""],[contenteditable="true"]';
// Gestures that are drags of controls rather than text selection.
const CONTROL_DRAG='button,select,a[href],input[type=range],canvas,[draggable="true"],.viewport,#fixture-handles,.fixture-strip,[data-mobile-drag-handle],.support-header,.conversation-header,[class*="grip"],[class*="resize"],[class*="handle"],[role="slider"]';
export function mountPanelContainment({panels=DEFAULT_PANELS}={}){
 let gesture=null;
 const scrollers=()=>{
  const list=[document.scrollingElement||document.documentElement];
  for(const n of document.querySelectorAll('*')){
   if(n.scrollHeight<=n.clientHeight+1&&n.scrollWidth<=n.clientWidth+1)continue;
   const s=getComputedStyle(n);if(/(auto|scroll|hidden)/.test(s.overflowY+s.overflowX))list.push(n);
  }return list;
 };
 const snapshot=()=>scrollers().map(n=>[n,n.scrollTop,n.scrollLeft]);
 const outside=(n,panel)=>n===document.scrollingElement||n===document.documentElement||n===document.body||!panel.contains(n);
 function restore(all,g=gesture){
  if(!g)return;
  for(const [n,top,left] of g.snap){
   if(!all&&!outside(n,g.panel))continue;
   if(n.scrollTop!==top)n.scrollTop=top;if(n.scrollLeft!==left)n.scrollLeft=left;
  }
 }
 function end(){
  if(!gesture)return;
  gesture.panel.removeAttribute('data-text-select-panel');document.body.classList.remove('panel-text-selecting');
  gesture=null;
 }
 addEventListener('pointerdown',e=>{
  end();
  if(e.pointerType==='touch'||e.button!==0||!(e.target instanceof Element))return;
  const panel=e.target.closest(panels);if(!panel)return;
  const field=e.target.closest(FIELD);
  if(!field&&e.target.closest(CONTROL_DRAG))return;
  gesture={id:e.pointerId,panel,field,snap:snapshot(),focusUntil:performance.now()+400,moved:false,x:e.clientX,y:e.clientY};
  panel.setAttribute('data-text-select-panel','');document.body.classList.add('panel-text-selecting');
 },true);
 addEventListener('pointermove',e=>{if(gesture&&e.pointerId===gesture.id&&Math.hypot(e.clientX-gesture.x,e.clientY-gesture.y)>3)gesture.moved=true},true);
 for(const type of ['pointerup','pointercancel'])addEventListener(type,e=>{if(!gesture||e.pointerId!==gesture.id)return;const g=gesture;restore(false,g);requestAnimationFrame(()=>restore(false,g));end()},true);
 addEventListener('blur',end);
 // A deliberate wheel/trackpad scroll is the user's choice: stop holding positions.
 addEventListener('wheel',end,{capture:true,passive:true});
 // Pointer focus: the target is visible under the cursor, so no scroll is needed anywhere.
 document.addEventListener('focusin',()=>{
  if(!gesture||performance.now()>gesture.focusUntil)return;
  const g=gesture;restore(true,g);requestAnimationFrame(()=>restore(true,g));
 },true);
 // Selection autoscroll may move the starting panel, never the page or other panels.
 document.addEventListener('scroll',()=>{if(gesture)restore(!gesture.moved&&performance.now()<=gesture.focusUntil)},true);
 return {active:()=>!!gesture};
}
