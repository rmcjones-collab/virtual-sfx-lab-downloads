export const HOLD_DELAY=350,SCROLL_RATE=240;
// Hold scrolls the list only. Releasing a hold must never trigger its tap action.
export function bindCueTransport({buttons,getList,onTap,onHolding=()=>{}}){
 let held=null,timer=null,frame=null,last=0,suppressClick=false;
 function stop(cancel=false){
  if(!held)return;
  const finished=held;held=null;clearTimeout(timer);cancelAnimationFrame(frame);
  onHolding(false);
  if(finished.pointer!==null&&finished.button.hasPointerCapture(finished.pointer))finished.button.releasePointerCapture(finished.pointer);
  suppressClick=finished.pointer!==null;
  if(!cancel&&!finished.scrolling)onTap(finished.action);
 }
 function scroll(now){
  if(!held?.scrolling)return;
  const dt=last?Math.min(.1,(now-last)/1000):0;last=now;
  const list=getList();if(list)list.scrollTop+=(held.action==='prev'||held.action==='first'?-1:1)*SCROLL_RATE*(held.action==='first'||held.action==='last'?1.5:1)*dt;
  frame=requestAnimationFrame(scroll);
 }
 function begin(button,action,pointer=null){
  if(button.disabled||held)return;suppressClick=false;held={button,action,pointer,scrolling:false};
  if(pointer!==null)button.setPointerCapture(pointer);
  timer=setTimeout(()=>{if(!held)return;held.scrolling=true;onHolding(true);last=0;frame=requestAnimationFrame(scroll)},HOLD_DELAY);
 }
 for(const [action,button] of Object.entries(buttons)){
  const label={prev:'Previous Cue',next:'Next Cue',first:'First Cue In List',last:'Last Cue In List'}[action];
  button.setAttribute('aria-label',label);button.title=`${label}. Hold To Scroll ${['first','last'].includes(action)?'50% Faster':'The List'}.`;
  button.onpointerdown=e=>{if(e.button!==0)return;e.preventDefault();button.focus({preventScroll:true});begin(button,action,e.pointerId)};
  button.onpointerup=()=>stop();button.onpointercancel=()=>stop(true);button.onlostpointercapture=()=>stop(true);
  button.onkeydown=e=>{if([' ','Enter'].includes(e.key)){e.preventDefault();if(!e.repeat)begin(button,action)}};
  button.onkeyup=e=>{if([' ','Enter'].includes(e.key)){e.preventDefault();stop()}};
  button.onclick=e=>{if(suppressClick){suppressClick=false;return}if(e.detail===0)onTap(action)};
  button.onblur=()=>{if(held?.button===button)stop(true)};
 }
 window.addEventListener('blur',()=>stop(true));document.addEventListener('visibilitychange',()=>{if(document.hidden)stop(true)});
 document.addEventListener('keydown',e=>{if(e.key==='Escape')stop(true)});
 return {cancel:()=>stop(true)};
}
