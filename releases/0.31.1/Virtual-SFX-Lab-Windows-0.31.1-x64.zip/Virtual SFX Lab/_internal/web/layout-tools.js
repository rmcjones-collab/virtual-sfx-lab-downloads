// Normalized layout coordinates only; never changes fixture patches or output.
export const GRID_STEP=.05;
const clamp=(v,min,max)=>Math.max(min,Math.min(max,v));
const round=v=>Math.round(v*1e10)/1e10;
export function groupTranslation(starts,dx,dy,{snap=false,anchorId,unbounded=false}={}){
 if(!starts.length)return [];
 const anchor=starts.find(f=>f.id===anchorId)||starts[0];
 function delta(axis,value){
  const min=(unbounded?-100:0)-Math.min(...starts.map(f=>f[axis])),max=(unbounded?100:1)-Math.max(...starts.map(f=>f[axis]));
  value=clamp(value,min,max);
  if(snap&&value!==0){
   const low=Math.ceil((anchor[axis]+min-1e-9)/GRID_STEP),high=Math.floor((anchor[axis]+max+1e-9)/GRID_STEP);
   if(low<=high)value=clamp(Math.round((anchor[axis]+value)/GRID_STEP),low,high)*GRID_STEP-anchor[axis];
  }
  return value;
 }
 dx=delta('x',dx);dy=delta('y',dy);
 return starts.map(f=>({id:f.id,x:round(f.x+dx),y:round(f.y+dy)}));
}
export function spacingInfo(starts){
 const ordered=[...starts].sort((a,b)=>a.x-b.x||a.id-b.id);
 const center=starts.length?starts.reduce((sum,f)=>sum+f.x,0)/starts.length:.5;
 const span=ordered.length>1?ordered.at(-1).x-ordered[0].x:0;
 return {ordered,center,span,maxSpan:2*Math.min(center,1-center)};
}
export function evenSpacing(starts,span,{snap=false,unbounded=false,maxSpan=2.5}={}){
 if(starts.length<2)return starts.map(f=>({...f}));
 const {ordered,center}=spacingInfo(starts),intervals=ordered.length-1;
 let gap=clamp(span,0,unbounded?Math.min(100,maxSpan):1)/intervals,left;
 if(unbounded){if(snap)gap=Math.round(gap/GRID_STEP)*GRID_STEP;left=center-gap*intervals/2;if(snap)left=Math.round(left/GRID_STEP)*GRID_STEP;left=clamp(left,-100,100-gap*intervals);return ordered.map((f,i)=>({id:f.id,x:round(left+i*gap),y:f.y}))}
 if(snap){
  // Equal grid-cell gaps, rather than independently rounding each unit.
  gap=Math.min(Math.round(gap/GRID_STEP),Math.floor((1+1e-9)/intervals/GRID_STEP))*GRID_STEP;
  left=clamp(Math.round((center-gap*intervals/2)/GRID_STEP)*GRID_STEP,0,1-gap*intervals);
 }else left=clamp(center-gap*intervals/2,0,1-gap*intervals);
 return ordered.map((f,i)=>({id:f.id,x:round(left+i*gap),y:f.y}));
}
