// Procedural artwork only. Relative nozzle sizes are not measured flame heights.
export const nozzleVisual=kind=>kind==='indoor'?{height:.52,label:'Indoor',ratio:'Compact jet'}:{height:1,label:'Outdoor',ratio:'1.9× indoor visual height'};
// Retain the requested doubled nominal length. This is not a physical-height model.
export const FLAME_LENGTH_GAIN=10/3;
const visualNoise=n=>{const v=Math.sin(n*12.9898+78.233)*43758.5453;return v-Math.floor(v)};
const flameSmooth=(a,b,x)=>{const t=Math.max(0,Math.min(1,(x-a)/(b-a)));return t*t*(3-2*t)};
const plumeNoise=x=>{const k=Math.floor(x),f=x-k,t=f*f*f*(f*(f*6-15)+10);return visualNoise(k)*(1-t)+visualNoise(k+1)*t};
export function drawFlameJet(ctx,{x,y,length,time,sampleAt,profile={},id=1,intensity=1,nozzle='outdoor',endTime=Infinity,detail=1}){
 if(intensity<=0||time<0||length<=0||!Number.isFinite(time))return 0;
 const height=length*nozzleVisual(nozzle).height*FLAME_LENGTH_GAIN;
 const travel=profile.travel??.20,life=profile.life??.64;
 const steps=detail<1?44:80,seed=id*137;
 let count=0;
 ctx.save();ctx.globalCompositeOperation='screen';
 // Reconstruct material at its emission angle. Cutoff opens a gap at the base;
 // old material travels outward instead of rotating with the moving head.
 let run=[];
 const flush=()=>{
  if(run.length<2){run=[];return}
  const last=run.at(-1);
  const silhouette=(scale,shift=0)=>{
   const edge=(p,i)=>p.w*(i===0||i===run.length-1?.12:i===1||i===run.length-2?.65:1);
   const contour=run.map((p,i)=>{const taper=p.w?edge(p,i)/p.w:0,w=(p.left*scale+p.w*shift)*taper;return {x:p.x+p.nx*w,y:p.y+p.ny*w}});
   for(let i=run.length-1;i>=0;i--){const p=run[i],taper=p.w?edge(p,i)/p.w:0,w=(p.right*scale-p.w*shift)*taper;contour.push({x:p.x-p.nx*w,y:p.y-p.ny*w})}
   ctx.beginPath();
   const a=contour[0],b=contour.at(-1);ctx.moveTo((a.x+b.x)/2,(a.y+b.y)/2);
   contour.forEach((p,i)=>{const q=contour[(i+1)%contour.length];ctx.quadraticCurveTo(p.x,p.y,(p.x+q.x)/2,(p.y+q.y)/2)});
   ctx.closePath();
  };
  for(const [scale,shift,colors] of [
   [1.12,0,[[0,'rgba(229,116,35,.04)'],[.15,'rgba(255,112,12,.23)'],[.45,'rgba(255,91,5,.36)'],[1,'rgba(232,65,4,.20)']]],
   [.93,.025,[[0,'rgba(255,150,47,.12)'],[.18,'rgba(255,160,39,.85)'],[.5,'rgba(255,126,17,.96)'],[1,'rgba(255,99,9,.72)']]],
   [.48,-.02,[[0,'rgba(255,201,116,.06)'],[.20,'rgba(255,221,141,.80)'],[.42,'rgba(255,210,99,.90)'],[.82,'rgba(255,173,48,.80)'],[1,'rgba(255,142,28,.54)']]]
  ]){
   silhouette(scale,shift);
   const gradient=ctx.createLinearGradient(x,y,last.x,last.y);
   colors.forEach(([at,color])=>gradient.addColorStop(at,color));
   ctx.globalAlpha=intensity;ctx.fillStyle=gradient;
   ctx.shadowColor='rgba(255,148,42,.26)';ctx.shadowBlur=scale>1?Math.min(7,height*.012):0;
   ctx.fill();
  }
  ctx.shadowBlur=0;run=[];
 };
 for(let j=0;j<=steps;j++){
  const u=j/steps,age=u*travel,born=time-age;
  if(born<0||born>=endTime){flush();continue}
  const emission=sampleAt(born);
  if(!emission.on){flush();continue}
  const a=emission.angle*Math.PI/180;
  if(run.length&&Math.abs(emission.angle-run.at(-1).angle)>18)flush();
  const growth=flameSmooth(0,.018,born),distance=height*.96*Math.pow(u,.82);
  const billow=.42+.85*plumeNoise(born*38+seed)+.24*plumeNoise(born*86+seed+91);
  const taper=1-flameSmooth(.80,1.06,u);
  const width=height*(.0018+.029*Math.pow(Math.sin(Math.PI*Math.min(.99,u*.91)),1.05))*billow*taper*growth;
  const drift=height*Math.pow(u,1.3)*(.021*(plumeNoise(born*29+seed+17)-.5)+.006*Math.sin(born*39+u*7+seed));
  run.push({x:x+Math.sin(a)*distance+Math.cos(a)*drift,
   y:y-Math.cos(a)*distance+Math.sin(a)*drift-height*.008*u*u,
   nx:Math.cos(a),ny:Math.sin(a),w:width,angle:emission.angle,
   left:width*(.58+.70*plumeNoise(born*82+seed+5)),right:width*(.58+.70*plumeNoise(born*91+seed+48))});
  count++;
 }
 flush();
 // Detached burning caps expand, rise and cool from gold to deep orange.
 // Absolute birth times make arbitrary scrubbing and replay deterministic.
 const cadence=detail<1?.055:.035;
 for(let k=Math.ceil((time-life)/cadence);k<=Math.floor((time-travel*.72)/cadence);k++){
  const born=(k+.37)*cadence,age=time-born;
  if(born<0||born>=endTime||age<travel*.72||age>=life)continue;
  const emission=sampleAt(born);if(!emission.on)continue;
  const tail=Math.max(0,(age-travel)/(life-travel)),fade=1-flameSmooth(.30,1,tail);
  const a=emission.angle*Math.PI/180,key=k+seed;
  const distance=height*(age<travel?.96*Math.pow(age/travel,.82):.96+.05*(1-Math.exp(-(age-travel)*5)));
  const side=height*(visualNoise(key+7)-.5)*(.012+.045*tail);
  const px=x+Math.sin(a)*distance+Math.cos(a)*side;
  const py=y-Math.cos(a)*distance+Math.sin(a)*side-height*(.008+.095*Math.pow(tail,1.35));
  const radius=height*(.012+.017*Math.sin(Math.PI*Math.min(.95,tail+.12)))*(.70+.55*visualNoise(key+19))*Math.pow(fade,.45);
  const ignite=flameSmooth(travel*.72,travel*.98,age);
  ctx.save();ctx.translate(px,py);ctx.rotate(a);
  const nodes=detail<1?14:22;
  for(const [scale,color,alpha] of [[1.16,tail>.6?'#dd4206':'#f96e08',.48],[.89,tail>.55?'#f7820e':'#ffac30',.78],[.44,'#ffd779',.75*(1-flameSmooth(.2,.72,tail))]]){
   ctx.beginPath();
   const contour=[];
   for(let n=0;n<nodes;n++){
    const theta=n/nodes*Math.PI*2,r=radius*scale*(.88+.13*Math.sin(theta*3+key+time*4)+.08*Math.sin(theta*5-key*.7-time*6));
    const xx=Math.cos(theta)*r,yy=Math.sin(theta)*r*(1.9-tail*.7);
    contour.push({x:xx,y:yy});
   }
   const first=contour[0],last=contour.at(-1);ctx.moveTo((first.x+last.x)/2,(first.y+last.y)/2);
   contour.forEach((p,n)=>{const q=contour[(n+1)%nodes];ctx.quadraticCurveTo(p.x,p.y,(p.x+q.x)/2,(p.y+q.y)/2)});
   ctx.closePath();ctx.globalAlpha=intensity*fade*ignite*alpha;ctx.fillStyle=color;ctx.fill();
  }
  ctx.restore();count++;
 }
 ctx.restore();return count;
}
export function drawFuelGauge(ctx,{x,y,radius=10,level=1}){
 const ratio=Math.max(0,Math.min(1,level));
 ctx.save();ctx.translate(x,y);ctx.lineCap='round';
 ctx.fillStyle='#11191d';ctx.beginPath();ctx.roundRect(-radius-3,-radius-3,radius*2+6,radius*1.5+6,3);ctx.fill();
 ctx.lineWidth=Math.max(.8,radius*.035);ctx.strokeStyle='#89979d';
 ctx.beginPath();ctx.arc(0,0,radius,Math.PI,Math.PI*2);ctx.stroke();
 for(const t of [0,.5,1]){const a=Math.PI*(1+t);ctx.beginPath();ctx.moveTo(Math.cos(a)*radius*.8,Math.sin(a)*radius*.8);ctx.lineTo(Math.cos(a)*radius,Math.sin(a)*radius);ctx.stroke()}
 const a=Math.PI*(1+ratio);ctx.strokeStyle=ratio<.15?'#ef795f':'#ffc18f';ctx.lineWidth=Math.max(1,radius*.045);
 ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(Math.cos(a)*radius*.72,Math.sin(a)*radius*.72);ctx.stroke();
 ctx.fillStyle='#d8e0e3';ctx.beginPath();ctx.arc(0,0,Math.max(.8,radius*.06),0,Math.PI*2);ctx.fill();
 if(radius>=9){ctx.font=`${Math.max(5,radius*.18)}px Arial`;ctx.textAlign='center';ctx.fillStyle='#a8b3b9';ctx.fillText('E',-radius*.85,radius*.36);ctx.fillText('F',radius*.85,radius*.36)}
 ctx.restore();
}
export function drawFlamerBody(ctx,{x,y,scale=1,angle=0,armed=true,brightness=1,nozzle='outdoor',fuelLevel}){
 ctx.save();ctx.translate(x,y);ctx.scale(scale,scale);
 // Weighted base, bevels and restrained brushed stainless highlights.
 ctx.fillStyle='#05080b';ctx.beginPath();ctx.roundRect(-55,55,110,12,3);ctx.fill();
 const steel=ctx.createLinearGradient(-46,18,46,60);
 [[0,'#a6afb3'],[.16,'#566167'],[.48,'#3b454b'],[.78,'#778187'],[1,'#242d33']].forEach(([at,color])=>steel.addColorStop(at,color));
 ctx.fillStyle=steel;ctx.beginPath();ctx.roundRect(-46,18,92,41,3);ctx.fill();
 ctx.strokeStyle='#a5b1b6';ctx.lineWidth=.8;ctx.stroke();
 ctx.fillStyle='#182126';ctx.beginPath();ctx.roundRect(-42,23,84,31,2);ctx.fill();
 ctx.strokeStyle='#ffffff09';for(let n=0;n<10;n++){ctx.beginPath();ctx.moveTo(-39,25+n*2.5);ctx.lineTo(38,25+n*2.5);ctx.stroke()}
 ctx.fillStyle='#bac2b4';ctx.fillRect(-35,31,20,10);ctx.fillStyle='#213c31';ctx.fillRect(-33,33,16,6);
 ctx.fillStyle='#7d9b6c';ctx.fillRect(-31,35,9,1);
 ctx.strokeStyle='#070d10';ctx.lineWidth=1.3;
 for(let n=0;n<6;n++){ctx.beginPath();ctx.moveTo(12,29+n*3.4);ctx.lineTo(34,29+n*3.4);ctx.stroke()}
 for(const py of [29,39,49]){
  ctx.beginPath();ctx.arc(-3,py,2.2,0,Math.PI*2);
  ctx.fillStyle=armed?`rgba(255,38,27,${.15+.85*brightness})`:'#321519';
  ctx.shadowColor='#ff261b';ctx.shadowBlur=armed?6*brightness:0;ctx.fill();ctx.shadowBlur=0;
 }
 for(const [px,py] of [[-41,23],[41,23],[-41,54],[41,54]]){
  ctx.fillStyle='#afb9bd';ctx.beginPath();ctx.arc(px,py,1.2,0,7);ctx.fill();
  ctx.strokeStyle='#3a454a';ctx.beginPath();ctx.moveTo(px-.6,py);ctx.lineTo(px+.6,py);ctx.stroke();
 }
 ctx.fillStyle='#242e34';ctx.fillRect(-20,10,7,13);ctx.fillRect(13,10,7,13);
 const hub=ctx.createRadialGradient(-3,5,1,0,10,13);hub.addColorStop(0,'#c3cccf');hub.addColorStop(.55,'#667278');hub.addColorStop(1,'#28343b');
 ctx.fillStyle=hub;ctx.beginPath();ctx.arc(0,10,12,0,7);ctx.fill();
 ctx.save();ctx.rotate(angle*Math.PI/180);
 const neck=ctx.createLinearGradient(-6,0,6,0);neck.addColorStop(0,'#526168');neck.addColorStop(.4,'#dde3e4');neck.addColorStop(1,'#65767e');
 ctx.fillStyle=neck;ctx.fillRect(-5,-11,10,24);
 ctx.fillStyle=nozzle==='indoor'?'#9b754c':'#aeb9bd';ctx.fillRect(-6,-13,12,5);
 ctx.fillStyle='#11191c';ctx.fillRect(-3,-14,6,2);
 ctx.restore();ctx.restore();
 if(fuelLevel!==undefined)drawFuelGauge(ctx,{x:x+Math.max(20*scale,9),y:y+40*scale,radius:Math.max(6,10*scale),level:fuelLevel});
}
