// Visual-only sequence model, shared by manual previews and receive-only DMX input.
export const SOURCE = 'https://explo.at/wp-content/uploads/2025/06/X2-Wave-Flame-Sequences-DMX-Values.pdf';
export const angle = p => (p - 8) * 15;
const range = (a,b) => Array.from({length:Math.abs(b-a)+1},(_,i)=>a+i*Math.sign(b-a));
export const presets = [];
function add(id,type,positions,duration,long=false,name='') {
  presets.push({id,type,positions,duration,long,name:name || (type==='single' ? `${long?'Long':'Short'} burst · ${angle(positions[0])}°` : `${type==='wave'?'Wave':long?'Long steps':'Short steps'} · ${positions.join(' → ')}`)});
}
for(let i=1;i<=30;i++)add(i,'single',[(i-1)%15+1],i<=15?.11:.41,i>15);
const steps=[range(1,15),range(15,1),[5,8,11],[11,8,5],[6,10],[10,6],[4,6,8,10,12],[12,10,8,6,4],[8,6,10,4,12],[8,10,6,12,4]];
const shortTimes=[2.4,2.4,.58,.58,.39,.39,.9,.9,1,1];
const longTimes=[6.9,6.9,1.48,1.48,.99,.99,2.4,2.4,2.5,2.5];
steps.forEach((p,i)=>add(31+i,'step',p,shortTimes[i]));
steps.forEach((p,i)=>add(41+i,'step',p,longTimes[i],true));
[[5,11,1.79],[11,5,1.79],[1,15,3.93],[15,1,3.93],[8,1,2.26],[8,15,2.26],[1,8,2.26],[15,8,2.26],[8,11,1.19],[8,5,1.19],[5,8,1.19],[11,8,1.19]].forEach(([a,b,t],i)=>add(51+i,'wave',[a,b],t,false,i===2?'Full wave · left to right':i===3?'Full wave · right to left':''));
[[2,14,.48,0],[14,2,.48,0],[2,14,1.08,1],[14,2,1.08,1],[8,13,.4,0],[13,8,.4,0],[8,13,1,1],[13,8,1,1],[8,3,.4,0],[3,8,.4,0],[8,3,1,1],[3,8,1,1],[3,13,.46,0],[13,3,.46,0],[2,14,.48,0],[14,2,.48,0]].forEach(([a,b,t,l],i)=>add(63+i,'step',[a,b],t,!!l));
add(79,'step',[8,5,11],.58);add(80,'step',[8,11,5],.58);
add(81,'step',range(5,11),1.4,false,'Short steps · 5 through 11');
add(82,'step',range(11,5),1.4,false,'Short steps · 11 through 5');
[[8,13],[13,8],[8,3],[3,8],[3,13],[13,3]].forEach((p,i)=>add(83+i,'wave',p,1.6));
export function sample(p,t){
  const pos=p.positions;
  if(p.type==='wave')return {angle:angle(pos[0])+(angle(pos[1])-angle(pos[0]))*Math.max(0,Math.min(t/p.duration,1)),on:t>=0&&t<p.duration};
  const pulse=p.long?.41:.11;
  const interval=pos.length>1?(p.duration-pulse)/(pos.length-1):p.duration;
  const k=Math.max(0,Math.min(pos.length-1,Math.floor((t+1e-8)/interval)));
  const local=t-k*interval;
  let a=angle(pos[k]);
  if(local>pulse&&k<pos.length-1)a+=(angle(pos[k+1])-a)*(local-pulse)/(interval-pulse);
  return {angle:a,on:t>=0&&t<p.duration&&local<pulse};
}
