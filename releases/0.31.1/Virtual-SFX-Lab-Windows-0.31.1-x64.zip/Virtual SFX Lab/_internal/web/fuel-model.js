// Estimates, not telemetry. Nominal rates: https://explo.at/product/x2-wave-flame/
// Standard capacity: https://explo.at/wp-content/uploads/2025/06/X2-Wave-Flamer-v2.0-ENG-2.pdf
export const FUEL_CAPACITY_ML=10000;
export const FUEL_RATE_ML={outdoor:75,indoor:31};
// Fuel types the operator can log against. Densities are typical liquid values (kg/L) for the mass hint only; they do not change flow rates.
export const FUEL_TYPES=[
 {id:'isopar',name:'Isopar',density:0.76},
 {id:'propane',name:'Propane',density:0.51},
 {id:'butane',name:'Butane',density:0.58},
 {id:'naphtha',name:'Naphtha',density:0.72},
 {id:'gasoline',name:'Gasoline',density:0.74}];
export const fuelTypeById=id=>FUEL_TYPES.find(t=>t.id===id)??FUEL_TYPES[0];
const defaults=()=>({capacityMl:10000,remainingMl:10000,outdoorRate:75,indoorRate:31,calibration:100,usedMl:0,fuelType:'isopar'});
const unlimited=v=>v==='infinity';
export function parseLitres(value){
 const text=String(value).trim();
 if(['999','∞','infinity'].includes(text.toLowerCase()))return 'infinity';
 const n=Number(text);if(!text||!Number.isFinite(n)||n<0||n>1e9)throw Error('Enter litres from 0 to 1,000,000,000, or 999 for ∞.');
 return n*1000;
}
export class FuelLedger{
 constructor(){this.levels=new Map();this.sessionMl=0;this.sessionStarted=Date.now()}
 sessionUsed(){return this.sessionMl}
 resetSession(){this.sessionMl=0;this.sessionStarted=Date.now()}
 fuelType(){const ids=[...this.levels.values()].map(s=>s.fuelType);return ids[0]??'isopar'}
 setFuelType(id,ids){const type=FUEL_TYPES.find(t=>t.id===id)?.id;if(!type)throw Error('Invalid fuel type');for(const fixtureId of ids)this.configure(fixtureId,{fuelType:type})}
 settings(id){return {...defaults(),...this.levels.get(id)}}
 remaining(id){const n=this.settings(id).remainingMl;return unlimited(n)?Infinity:n}
 ratio(id){const s=this.settings(id);return unlimited(s.remainingMl)||unlimited(s.capacityMl)?1:Math.min(1,s.remainingMl/s.capacityMl)}
 rate(id,nozzle){const s=this.settings(id);return (nozzle==='indoor'?s.indoorRate:s.outdoorRate)*s.calibration/100}
 configure(id,change){const next={...this.settings(id),...change};FuelLedger.validate([{id,...next}],[{id}]);this.levels.set(id,next)}
 refill(id){this.configure(id,{remainingMl:this.settings(id).capacityMl,usedMl:0})}
 reset(id){this.levels.set(id,defaults())}
 burn(id,nozzle,seconds){
  if(!Number.isFinite(seconds)||seconds<=0)return;
  const s=this.settings(id),amount=this.rate(id,nozzle)*seconds;
  const used=unlimited(s.remainingMl)?amount:Math.min(s.remainingMl,amount);
  s.usedMl+=used;this.sessionMl+=used;if(!unlimited(s.remainingMl))s.remainingMl=Math.max(0,s.remainingMl-used);
  this.levels.set(id,s);
 }
 window(id,nozzle,seconds,isEmitting,speed=1){
  if(!Number.isFinite(seconds)||seconds<=0||!this.remaining(id))return;
  const n=Math.min(1024,Math.max(1,Math.ceil(seconds*Math.max(1,speed)/.002))),step=seconds/n;
  let on=0;for(let i=0;i<n;i++)if(isEmitting((i+.5)*step))on+=step;
  if(on)this.burn(id,nozzle,on);
 }
 serialize(fixtures){return fixtures.map(f=>({id:f.id,...this.settings(f.id)}))}
 static validate(data,fixtures){
  if(data===undefined)return fixtures.map(f=>({id:f.id,...defaults()}));
  const ids=new Set(fixtures.map(f=>f.id)),seen=new Set();
  if(!Array.isArray(data)||data.length!==fixtures.length)throw Error('Invalid fuel estimate');
  return data.map(row=>{
   if(!ids.has(row?.id)||seen.has(row.id))throw Error('Invalid fuel unit');
   const s={...defaults(),...row};
   for(const key of ['capacityMl','remainingMl']){
    if(!unlimited(s[key])&&(!Number.isFinite(s[key])||s[key]<0||s[key]>1e12))throw Error('Invalid fuel amount');
   }
   if(s.capacityMl===0)throw Error('Capacity must be greater than zero.');
   if(!unlimited(s.capacityMl)&&!unlimited(s.remainingMl)&&s.remainingMl>s.capacityMl)throw Error('Remaining amount exceeds capacity. Increase capacity first, or use 999 for unlimited.');
   for(const key of ['outdoorRate','indoorRate','calibration','usedMl'])if(!Number.isFinite(s[key])||s[key]<0||s[key]>1e15)throw Error('Invalid fuel parameter');
   if(s.outdoorRate>100000||s.indoorRate>100000||s.calibration>10000)throw Error('Rate or calibration is out of range.');
   if(s.fuelType!==undefined&&!FUEL_TYPES.some(t=>t.id===s.fuelType))throw Error('Invalid fuel type');
   seen.add(row.id);
   return {id:row.id,capacityMl:s.capacityMl,remainingMl:s.remainingMl,outdoorRate:s.outdoorRate,indoorRate:s.indoorRate,calibration:s.calibration,usedMl:s.usedMl,fuelType:s.fuelType??'isopar'};
  });
 }
 restore(data,fixtures){this.levels=new Map(FuelLedger.validate(data,fixtures).map(({id,...s})=>[id,s]))}
}
