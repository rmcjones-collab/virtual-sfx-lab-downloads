// An in-app picker avoids native select popovers being suppressed in mobile
// embedded browsers. The original select remains the single source of changes.
export function mountMobileSequencePicker(select,{buttonId='demo-sequence-open',title='Internal Sequence'}={}){
 const button=document.createElement('button');button.type='button';button.id=buttonId;button.dataset.workspaceControl='selector';button.setAttribute('aria-haspopup','dialog');button.setAttribute('aria-expanded','false');select.after(button);
 const dialog=document.createElement('dialog');dialog.className='demo-sequence-dialog';dialog.setAttribute('aria-label','Internal Sequence');
 dialog.innerHTML='<div class="demo-picker-heading"><h2>Internal Sequence</h2><button type="button" data-close>Cancel</button></div><label>Find a sequence<input type="search" aria-label="Find a sequence" placeholder="Number or name" autocomplete="off"></label><div class="demo-picker-list"></div><p data-empty hidden>No matching sequences.</p>';
 dialog.id=`${buttonId}-dialog`;dialog.setAttribute('aria-label',title);dialog.querySelector('h2').textContent=title;button.setAttribute('aria-controls',dialog.id);
 document.body.append(dialog);
 const list=dialog.querySelector('.demo-picker-list'),search=dialog.querySelector('input'),options=new Map();
 for(const option of select.options){
  if(!option.value||option.disabled)continue;
  options.set(option.value,option);
  const item=document.createElement('button');item.type='button';item.textContent=option.textContent;item.dataset.value=option.value;
  item.onclick=()=>{if(select.disabled||select.closest('[inert]')||option.disabled)return;select.value=option.value;select.dispatchEvent(new Event('change',{bubbles:true}));dialog.close()};
  list.append(item);
 }
 function sync(){
  button.disabled=select.disabled||!!select.closest('[inert]');button.textContent=(select.selectedOptions[0]?.textContent||'Select internal sequence')+' ▾';
  button.setAttribute('aria-label',title+': '+(select.selectedOptions[0]?.textContent||'Choose'));
  for(const item of list.children)item.disabled=button.disabled||!!options.get(item.dataset.value)?.disabled;
 }
 function filter(){
  const query=search.value.trim().toLowerCase();let count=0;
  for(const item of list.children){item.hidden=!item.textContent.toLowerCase().includes(query);if(!item.hidden)count++}
  dialog.querySelector('[data-empty]').hidden=count>0;
 }
 button.onclick=()=>{
  sync();if(button.disabled)return;search.value='';filter();
  for(const item of list.children)item.setAttribute('aria-pressed',String(item.dataset.value===select.value));
  dialog.showModal();button.setAttribute('aria-expanded','true');
  const selected=list.querySelector('[aria-pressed=true]')||list.firstElementChild;
  selected?.focus({preventScroll:true});if(selected)list.scrollTop=selected.offsetTop-list.firstElementChild.offsetTop;
 };
 search.oninput=filter;dialog.querySelector('[data-close]').onclick=()=>dialog.close();
 dialog.addEventListener('keydown',e=>{e.stopPropagation();if(e.key==='Escape'){e.preventDefault();dialog.close()}});
 dialog.addEventListener('close',()=>{button.setAttribute('aria-expanded','false');sync();button.focus({preventScroll:true})});
 matchMedia('(max-width:700px)').addEventListener('change',()=>{if(dialog.open)dialog.close()});
 sync();return {sync,isOpen:()=>dialog.open};
}
