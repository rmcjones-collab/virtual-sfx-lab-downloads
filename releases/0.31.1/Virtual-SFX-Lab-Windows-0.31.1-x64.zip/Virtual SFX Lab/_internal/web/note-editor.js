// Confined editor interaction. Never changes page overflow, gutters or panel layout.
export const wheelPixels=(delta,mode,line,height,percent)=>delta*(mode===1?line:mode===2?height:1)*percent/100;
export const selectionVelocity=(y,top,bottom,percent)=>{
 if(!percent)return 0;
 const edge=Math.min(18,(bottom-top)/4);
 if(y<top+edge)return -Math.min(650,100+(top+edge-y)*12)*percent/100;
 if(y>bottom-edge)return Math.min(650,100+(y-bottom+edge)*12)*percent/100;
 return 0;
};
export function bindNoteEditor(host){
 const doc=host.ownerDocument,win=doc.defaultView;let drag=null,frame=0,mirror=null,lastClick=null,editRestore=null,editFrame=0;
 const on=(node,type,fn,options)=>{node.addEventListener(type,fn,options);return()=>node.removeEventListener(type,fn,options)};
 const settings=area=>{
  const notebook=area.closest('.workspace-notebook')??host;
  return {wheel:Number(notebook.querySelector('[data-note-wheel]')?.value??100),selection:Number(notebook.querySelector('[data-note-selection]')?.value??100)};
 };
 const textarea=e=>e.target.closest?.('.workspace-note textarea');
 function caret(area,x,y){
  mirror??=doc.createElement('div');mirror.className='note-caret-mirror';const css=win.getComputedStyle(area),r=area.getBoundingClientRect();
  for(const p of ['fontFamily','fontSize','fontWeight','fontStyle','lineHeight','letterSpacing','wordSpacing','textIndent','textAlign','direction','tabSize','paddingTop','paddingBottom','paddingLeft','paddingRight','borderTopWidth','borderBottomWidth','borderLeftWidth','borderRightWidth'])mirror.style[p]=css[p];
  const borderX=parseFloat(css.borderLeftWidth)+parseFloat(css.borderRightWidth),borderY=parseFloat(css.borderTopWidth)+parseFloat(css.borderBottomWidth);
  Object.assign(mirror.style,{position:'fixed',left:`${r.left}px`,top:`${r.top}px`,width:`${area.clientWidth+borderX}px`,height:`${area.clientHeight+borderY}px`,boxSizing:'border-box',whiteSpace:'pre-wrap',overflowWrap:'break-word',wordBreak:css.wordBreak,borderStyle:'solid',borderColor:'transparent',overflow:'hidden',opacity:'0',pointerEvents:'auto',zIndex:'2147483646'});
  mirror.setAttribute('aria-hidden','true');mirror.textContent=area.value+'\u200b';doc.body.append(mirror);
  mirror.scrollTop=area.scrollTop;mirror.scrollLeft=area.scrollLeft;
  x=Math.max(r.left+parseFloat(css.borderLeftWidth)+1,Math.min(r.left+area.clientWidth,x));
  y=Math.max(r.top+parseFloat(css.borderTopWidth)+1,Math.min(r.top+area.clientHeight,y));
  const point=doc.caretPositionFromPoint?.(x,y),range=point?null:doc.caretRangeFromPoint?.(x,y);
  const node=point?.offsetNode??range?.startContainer,offset=point?.offset??range?.startOffset;
  const index=node===mirror.firstChild?Math.min(area.value.length,offset):node===mirror?area.value.length:drag?.end??area.selectionStart;
  mirror.remove();return index;
 }
 const snapshot=area=>{
  const rows=[];for(let n=area.parentElement;n;n=n.parentElement)rows.push([n,n.scrollTop,n.scrollLeft]);
  const scrolling=doc.scrollingElement;if(!rows.some(([n])=>n===scrolling))rows.push([scrolling,scrolling.scrollTop,scrolling.scrollLeft]);
  return()=>rows.forEach(([n,top,left])=>{if(n.scrollTop!==top)n.scrollTop=top;if(n.scrollLeft!==left)n.scrollLeft=left});
 };
 function select(index){
  if(!drag)return;
  const {area,anchor}=drag,top=area.scrollTop,left=area.scrollLeft;
  area.setSelectionRange(Math.min(anchor,index),Math.max(anchor,index),index<anchor?'backward':'forward');
  area.scrollTop=top;area.scrollLeft=left;drag.end=index;drag.restore();
 }
 function step(time){
  if(!drag)return;
  const r=drag.area.getBoundingClientRect(),velocity=selectionVelocity(drag.y,r.top,r.bottom,settings(drag.area).selection);
  const dt=Math.min(.04,(time-(drag.time??time))/1000);drag.time=time;
  if(velocity){drag.area.scrollTop+=velocity*dt;select(caret(drag.area,drag.x,drag.y))}
  frame=win.requestAnimationFrame(step);
 }
 function stop(){
  if(!drag)return;const old=drag;drag=null;win.cancelAnimationFrame(frame);frame=0;mirror?.remove();
  old.restore();try{if(old.area.hasPointerCapture(old.pointer))old.area.releasePointerCapture(old.pointer)}catch{}
 }
 const down=e=>{
  const title=e.target.closest?.('.workspace-note input');if(title){title.focus({preventScroll:true});e.stopPropagation();return}
  const area=textarea(e);if(!area||e.button!==0||e.pointerType==='touch')return;
  const rect=area.getBoundingClientRect(),border=win.getComputedStyle(area);
  if(e.clientX>=rect.left+area.clientWidth+parseFloat(border.borderLeftWidth))return; // Native scrollbar dragging.
  e.preventDefault();e.stopPropagation();stop();
  const restore=snapshot(area);area.focus({preventScroll:true});restore();
  const index=caret(area,e.clientX,e.clientY),now=win.performance.now();
  const clicks=lastClick&&lastClick.area===area&&now-lastClick.time<400&&Math.hypot(e.clientX-lastClick.x,e.clientY-lastClick.y)<6?lastClick.count%3+1:1;
  lastClick={area,time:now,count:clicks,x:e.clientX,y:e.clientY};
  let start=index,end=index;
  if(clicks===2){const word=/[\p{L}\p{N}_]/u,isWord=word.test(area.value[index]??''),match=c=>isWord?word.test(c):/\s/u.test(c);while(start>0&&match(area.value[start-1]))start--;while(end<area.value.length&&match(area.value[end]))end++}
  if(clicks===3){start=index===0?0:area.value.lastIndexOf('\n',index-1)+1;const next=area.value.indexOf('\n',index);end=next<0?area.value.length:next+1}
  const anchor=e.shiftKey?(area.selectionDirection==='backward'?area.selectionEnd:area.selectionStart):start;
  drag={area,anchor,end,x:e.clientX,y:e.clientY,pointer:e.pointerId,restore};
  area.setPointerCapture(e.pointerId);select(end);frame=win.requestAnimationFrame(step);
 };
 const move=e=>{if(!drag||e.pointerId!==drag.pointer)return;e.preventDefault();drag.x=e.clientX;drag.y=e.clientY;select(caret(drag.area,e.clientX,e.clientY))};
 const wheel=e=>{
  if(e.ctrlKey||e.metaKey)return; // Retain browser accessibility zoom gestures.
  const area=textarea(e),tabs=e.target.closest?.('.note-tabs'),target=area??tabs??host.closest('.workspace-card-content,.monitor-card-content')??host;
  const css=win.getComputedStyle(area??host),delta=wheelPixels(e.deltaY||e.deltaX,e.deltaMode,parseFloat(css.lineHeight)||21,target.clientHeight,settings(area??host).wheel);
  e.preventDefault();e.stopPropagation();
  if(tabs)tabs.scrollLeft+=delta;else if(Math.abs(e.deltaX)>Math.abs(e.deltaY)&&area)area.scrollLeft+=wheelPixels(e.deltaX,e.deltaMode,21,target.clientWidth,settings(area).wheel);else target.scrollTop+=delta;
 };
 // Browsers can scroll ancestor containers when the first edit reveals the caret.
 // Preserve only ancestors, never the editor's own caret/scroll position.
 const beginEdit=e=>{if(e.target.matches?.('.workspace-note input,.workspace-note textarea'))editRestore=snapshot(e.target)};
 const endEdit=()=>{if(!editRestore)return;const restore=editRestore;restore();win.cancelAnimationFrame(editFrame);editFrame=win.requestAnimationFrame(()=>{restore();editRestore=null})};
 const disposers=[on(host,'pointerdown',down),on(host,'pointermove',move,{passive:false}),on(host,'pointerup',stop),on(host,'pointercancel',stop),on(host,'lostpointercapture',stop),on(host,'wheel',wheel,{passive:false}),on(host,'keydown',beginEdit,true),on(host,'beforeinput',beginEdit,true),on(host,'input',endEdit),on(host,'keyup',endEdit),on(win,'blur',stop),on(win,'pagehide',stop)];
 return {destroy(){stop();win.cancelAnimationFrame(editFrame);disposers.forEach(dispose=>dispose())}};
}
