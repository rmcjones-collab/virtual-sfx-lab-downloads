import {requestFileSave} from './file-save.js?v=v031c-20261004d';
export const escapeHTML=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function htmlDocument(title,text){
 return '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="Content-Security-Policy" content="default-src \'none\'; style-src \'unsafe-inline\'"><title>'+escapeHTML(title)+'</title><style>body{max-width:850px;margin:40px auto;padding:0 24px;font:16px/1.6 system-ui;color:#172027;background:#fff}pre{white-space:pre-wrap;overflow-wrap:anywhere;font:inherit}@media print{body{margin:0}}</style></head><body><h1>'+escapeHTML(title)+'</h1><pre>'+escapeHTML(text)+'</pre></body></html>';
}
export function downloadDocument(title,text,format='txt'){
 const types={txt:'text/plain',md:'text/markdown',html:'text/html'},type=types[format];if(!type)throw Error('Unsupported document format');
 const content=format==='html'?htmlDocument(title,text):format==='md'?'# '+title.replace(/[\r\n]/g,' ').replace(/[\\`*_{}[\]<>()#!|~]/g,'\\$&')+'\n\n'+text.replace(/[\\`*_{}[\]<>()#!|~]/g,'\\$&'):text;
 return requestFileSave(new Blob([content],{type:type+';charset=utf-8'}),(title.replace(/[^a-z0-9_-]+/gi,'-').slice(0,80)||'wave-document')+'.'+format);
}
export function exportNotesDialog(notes,selectedId){
 const dialog=document.createElement('dialog');dialog.className='chat-export-dialog';
 dialog.innerHTML='<h2>Export Notes</h2><p>Download a local copy. HTML documents can be opened in a browser and printed or saved as PDF using its print menu.</p><label>Include <select aria-label="Notes to export"><option value="selected">Current Note</option><option value="all">All Notes In This Panel</option></select></label><pre></pre><div class="support-row"><button data-format="txt">Download TXT</button><button data-format="md">Download Markdown</button><button data-format="html">Download HTML Document</button><button data-close>Close</button></div>';
 let text='',title='';
 const render=()=>{const chosen=dialog.querySelector('select').value==='all'?notes:notes.filter(n=>n.id===selectedId);title=chosen.length===1?(chosen[0].title||'Untitled Note'):'Wave Studio Notes';text=chosen.map(n=>(n.title||'Untitled Note')+'\n'+'='.repeat(24)+'\n'+(n.body||'')).join('\n\n');dialog.querySelector('pre').textContent=text;for(const b of dialog.querySelectorAll('[data-format]'))b.disabled=!chosen.length};
 dialog.querySelector('select').onchange=render;
 for(const button of dialog.querySelectorAll('[data-format]'))button.onclick=()=>downloadDocument(title,text,button.dataset.format);
 dialog.querySelector('[data-close]').onclick=()=>dialog.close();dialog.addEventListener('close',()=>dialog.remove(),{once:true});
 document.body.append(dialog);render();dialog.showModal();
}
