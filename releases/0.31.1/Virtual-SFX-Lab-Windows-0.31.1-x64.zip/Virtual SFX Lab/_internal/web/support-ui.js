import {tutorials,answerGuide} from './app-guide.js?v=v031c-20261004d';
import {watermarkedStream} from './watermark.js?v=v031c-20261004d';
import {mountChat} from './team-chat.js?v=v031c-20261004d';
import {mountTestChecklist} from './test-checklist.js?v=v031c-20261004d';
import {draggableWindow,raiseWindow} from './support-windows.js?v=v031c-20261004d';
import {bindMobileUtilityDrag} from './mobile-panel-drag.js?v=v031c-20261004d';
import {requestFileSave} from './file-save.js?v=v031c-20261004d';
const $=s=>document.querySelector(s);
export function mountSupport({workspace,state}){
 const launch=document.createElement('div');launch.className='support-launchers';
 launch.innerHTML='<button id="wave-guide-open">AI Assist</button><button id="wave-chat-open">Chat</button><button id="wave-checklist-open">Test Checklist</button><button id="wave-camera-open" aria-label="Camera" title="Camera"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 7h4l2-3h6l2 3h4v13H3z"/><circle cx="12" cy="13" r="4"/></svg></button>';
 ($('#vista-layout-download')||$('#dmx-setup')).after(launch);
 const panel=document.createElement('aside');panel.className='support-panel';panel.hidden=true;panel.setAttribute('aria-label','Wave Studio Support');
 panel.innerHTML='<div class="support-header"><strong id="support-title">App Guide</strong><button data-support-min aria-label="Minimize Support Panel">−</button><button data-support-close aria-label="Close Support Panel">×</button></div><section class="support-body" id="guide-panel"></section><section class="support-body" id="chat-panel" hidden></section><section class="support-body" id="checklist-panel" hidden></section><section class="support-body" id="camera-panel" hidden></section>';
 document.body.append(panel);
 bindMobileUtilityDrag(panel,[panel.querySelector('.support-header')],{title:()=>panel.querySelector('#support-title').textContent});
 let section='guide';
 draggableWindow(panel,panel.querySelector('.support-header'),{allowed:e=>section==='guide'||((e.ctrlKey||e.metaKey)&&e.shiftKey)||document.body.classList.contains('workspace-editing')});
 panel.querySelector('.support-header').title='Drag App Guide To Move · Ctrl + Shift + Drag Friends & Chat';
 const tabs=document.createElement('nav');tabs.className='support-tabs';tabs.setAttribute('aria-label','Support Sections');tabs.innerHTML='<button data-support-tab="guide">Guide</button><button data-support-tab="chat">Chat</button><button data-support-tab="checklist">Checklist</button><button data-support-tab="camera">Camera</button>';panel.querySelector('.support-header').after(tabs);
 const open=kind=>{section=kind;panel.hidden=false;raiseWindow(panel);panel.classList.remove('collapsed');panel.querySelector('[data-support-min]').textContent='−';for(const key of ['guide','chat','checklist','camera'])$(`#${key}-panel`).hidden=key!==kind;$('#support-title').textContent={guide:'App Guide',chat:'Friends & Chat',checklist:'Colleague Test Checklist',camera:'Camera & Video'}[kind];if(kind==='chat')chat.refresh();chat.markVisible()};
 for(const tab of tabs.querySelectorAll('button'))tab.onclick=()=>open(tab.dataset.supportTab);
 launch.querySelector('#wave-guide-open').onclick=()=>open('guide');launch.querySelector('#wave-chat-open').onclick=()=>open('chat');launch.querySelector('#wave-camera-open').onclick=()=>open('camera');
 launch.querySelector('#wave-checklist-open').onclick=()=>open('checklist');
 mountTestChecklist($('#checklist-panel'));
 panel.querySelector('[data-support-min]').onclick=e=>{const collapsed=panel.classList.toggle('collapsed');e.currentTarget.textContent=collapsed?'+':'−';e.currentTarget.setAttribute('aria-label',`${collapsed?'Restore':'Minimize'} Support Panel`)};
 panel.querySelector('[data-support-close]').onclick=()=>{panel.hidden=true;recognition?.stop();window.speechSynthesis?.cancel()};
 $('#guide-panel').innerHTML='<p class="support-note">App guide only. AI is not connected. Search written tutorials and read them aloud. Attachments stay in this browser unless you explicitly send them in Chat.</p><label for="guide-question">What Would You Like To Do?</label><textarea id="guide-question" placeholder="How do I arrange units or use faders?"></textarea><div class="support-row"><button id="guide-ask">Find Tutorial</button><button id="guide-dictate">Speak Question</button><button id="guide-stop-speaking">Stop Speaking</button></div><p class="support-note">Dictation, when supported, may use your browser’s speech service. Review the text before searching.</p><div id="guide-status" class="support-status" role="status"></div><label>Screenshot Or Diagnostics<input id="guide-upload" type="file" accept="image/png,image/jpeg,image/webp,.json,.txt,.log"></label><div id="guide-attachment"></div><div id="guide-results"></div>';
 const guideStatus=t=>$('#guide-status').textContent=t;
 function showTutorials(list){
  const host=$('#guide-results');host.replaceChildren();
  for(const t of list){const article=document.createElement('article');article.className='guide-result';const title=document.createElement('h3');title.textContent=t.title;const steps=document.createElement('ol');for(const step of t.steps){const li=document.createElement('li');li.textContent=step;steps.append(li)}const buttons=document.createElement('div');buttons.className='support-row';
   const show=document.createElement('button');show.textContent='Show Control';show.onclick=()=>{const target=$(t.target);if(!target||!target.getClientRects().length){guideStatus('This control is hidden in your current view. Open Add Panels or return to Standard View.');return}panel.hidden=true;target.scrollIntoView({block:'center',behavior:'smooth'});target.classList.add('guide-highlight');setTimeout(()=>target.classList.remove('guide-highlight'),5000)};
   const read=document.createElement('button');read.textContent='Read Aloud';read.disabled=!('speechSynthesis' in window);read.onclick=()=>{speechSynthesis.cancel();speechSynthesis.speak(new SpeechSynthesisUtterance(t.title+'. '+t.steps.join(' ')))};
   buttons.append(show,read);article.append(title,steps,buttons);host.append(article);
  }
 }
 showTutorials(tutorials);
 $('#guide-ask').onclick=()=>{const q=$('#guide-question').value.trim();if(!q)return;const found=answerGuide(q);guideStatus(found.length?'Matching App Tutorials':'No exact match. Browse the guide below; this is not a generative AI chat.');showTutorials(found.length?found:tutorials)};
 $('#guide-stop-speaking').onclick=()=>window.speechSynthesis?.cancel();
 let recognition=null,guideURL=null;
 const Speech=window.SpeechRecognition||window.webkitSpeechRecognition;
 $('#guide-dictate').onclick=()=>{if(!Speech){guideStatus('Speech input is not supported here. Use your phone’s keyboard microphone or type your question.');return}try{recognition?.stop();recognition=new Speech();recognition.lang='en-CA';recognition.interimResults=false;recognition.onresult=e=>{$('#guide-question').value=e.results[0][0].transcript;guideStatus('Dictation ready. Review it, then Find Tutorial.')};recognition.onerror=e=>guideStatus(`Dictation unavailable (${e.error}). You can still type.`);recognition.onend=()=>$('#guide-dictate').textContent='Speak Question';recognition.start();$('#guide-dictate').textContent='Listening…'}catch{guideStatus('Microphone access is blocked in this browser or embedded preview.')}};
 function guideImage(blob,name='Screenshot'){
  const host=$('#guide-attachment');host.replaceChildren();if(guideURL)URL.revokeObjectURL(guideURL);guideURL=URL.createObjectURL(blob);const image=document.createElement('img');image.src=guideURL;image.alt=name;const note=document.createElement('p');note.textContent='Local screenshot reference only. The app guide cannot analyze images. Attach it in Chat to ask a human instructor.';const clear=document.createElement('button');clear.textContent='Remove Attachment';clear.onclick=()=>{host.replaceChildren();URL.revokeObjectURL(guideURL);guideURL=null};host.append(image,note,clear);
 }
 $('#guide-upload').onchange=async e=>{const f=e.target.files[0];e.target.value='';if(!f)return;if(f.size>6000000){guideStatus('Use a file smaller than 6 MB.');return}if(['image/png','image/jpeg','image/webp'].includes(f.type)){guideImage(f,f.name);return}if(f.size>256000){guideStatus('Diagnostics must be under 256 KB.');return}const host=$('#guide-attachment');host.replaceChildren();const text=await f.text();const pre=document.createElement('pre');pre.className='guide-result';try{const d=JSON.parse(text);pre.textContent=`Diagnostic Summary\nFormat: ${String(d.format??'JSON').slice(0,80)}\nVersion: ${String(d.version??'Not Specified').slice(0,20)}\nUnits: ${d.fixtures?.length??'Not Included'}\nFaders: ${d.playback?.slots?.length??'Not Included'}\nSession Actions: ${d.actions?.length??'Not Included'}\n\nNot executed or applied. No AI analysis.`}catch{pre.textContent='Local Diagnostic Preview (Not AI-Analyzed)\n\n'+text.slice(0,6000)}host.append(pre);guideStatus('Diagnostics loaded locally. Nothing was applied to the app.')};

 const camera=$('#camera-panel');
 camera.innerHTML='<p class="support-note">Camera starts locally and is not shared until you choose Share Camera In Call. This is an observation aid, not a safety or firing control.</p><label>Camera<select id="camera-facing"><option value="environment">Rear Camera</option><option value="user">Front Camera</option></select></label><div class="support-row"><button id="camera-start">Start Camera</button><button id="camera-stop">Stop Camera</button><button id="camera-share">Share Camera In Call</button></div><video id="camera-preview" autoplay muted playsinline></video><div class="support-row"><button id="camera-record">Record Example</button><button id="camera-record-stop">Stop Recording</button></div><div id="camera-recording"></div><p id="camera-status" class="support-status" role="status"></p>';
 let cameraStream=null,recorder=null,recordChunks=[],clipURL=null,cameraGeneration=0,marked=null;
 const camStatus=t=>$('#camera-status').textContent=t;
 function stopCamera(){cameraGeneration++;if(recorder?.state==='recording')recorder.stop();else{marked?.stop();marked=null}cameraStream?.getTracks().forEach(t=>t.stop());cameraStream=null;$('#camera-preview').srcObject=null;chat.setCamera(null);document.dispatchEvent(new CustomEvent('wave-media-state',{detail:{localCamera:false}}));camStatus('Camera stopped.')}
 async function startCamera(){stopCamera();const token=cameraGeneration;try{if(!navigator.mediaDevices?.getUserMedia)throw Error('Camera unavailable in this browser. Open the standalone HTTPS site.');const stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:$('#camera-facing').value}},audio:false});if(token!==cameraGeneration){stream.getTracks().forEach(t=>t.stop());return}cameraStream=stream;$('#camera-preview').srcObject=cameraStream;document.dispatchEvent(new CustomEvent('wave-media-state',{detail:{localCamera:true}}));camStatus('Local Preview Only. Microphone is off.')}catch(e){camStatus(e.message||'Camera permission denied. Try the standalone site.')}}
 $('#camera-start').onclick=startCamera;$('#camera-stop').onclick=stopCamera;$('#camera-facing').onchange=()=>{if(cameraStream)startCamera()};
 $('#camera-share').onclick=()=>{if(!cameraStream){camStatus('Start your camera first.');return}if(!chat.setCamera(cameraStream)){camStatus('Join a chat call first.');return}camStatus('Camera shared with the current call. Stop Camera or Leave Call to end sharing.')};
 $('#camera-record').onclick=async()=>{if(!cameraStream){camStatus('Start the camera first.');return}if(!window.MediaRecorder){camStatus('Recording is not supported here.');return}if(recorder?.state==='recording')return;recordChunks=[];try{marked?.stop();marked=null;const source=cameraStream,next=await watermarkedStream(source);if(source!==cameraStream||recorder?.state==='recording'){next.stop();return}marked=next;recorder=new MediaRecorder(marked.stream,{videoBitsPerSecond:650000});recorder.ondataavailable=e=>{if(e.data.size)recordChunks.push(e.data);if(recordChunks.reduce((n,b)=>n+b.size,0)>5500000&&recorder.state==='recording')recorder.stop()};recorder.onstop=()=>{marked?.stop();marked=null;const blob=new Blob(recordChunks,{type:recorder.mimeType.split(';')[0]});if(clipURL)URL.revokeObjectURL(clipURL);clipURL=URL.createObjectURL(blob);const host=$('#camera-recording');host.replaceChildren();const v=document.createElement('video');v.controls=true;v.src=clipURL;const a=document.createElement('a');a.href=clipURL;a.download='wave-camera-example.'+(blob.type.includes('mp4')?'mp4':'webm');a.textContent='Download Clip';const attach=document.createElement('button');attach.textContent='Attach To Chat';attach.onclick=()=>{chat.attach(blob,a.download);open('chat')};host.append(v,a,attach);camStatus('Recording ready locally. Review before sharing.');};recorder.start(1000);camStatus('Recording silent video locally; automatic size limit is approximately 6 MB.')}catch(e){marked?.stop();marked=null;camStatus(e.message)}};
 $('#camera-record-stop').onclick=()=>{if(recorder?.state==='recording')recorder.stop()};
 const badge=document.createElement('button');badge.type='button';badge.className='chat-unread-badge';badge.setAttribute('aria-label','Reply to new chat message');badge.title='Open the newest unread conversation and reply';badge.hidden=true;panel.querySelector('.support-header').insertBefore(badge,panel.querySelector('[data-support-min]'));
 const chat=mountChat({host:$('#chat-panel'),workspace,onOpen:()=>open('chat'),onUnread:rooms=>{
  const has=rooms.length>0,b=$('#wave-chat-open');b.classList.toggle('has-unread',has);b.textContent=has?`Chat · ${rooms.length} New`:'Chat';b.setAttribute('aria-label',has?`Chat: unread messages in ${rooms.length} conversation${rooms.length===1?'':'s'}`:'Chat');
  badge.hidden=!has;badge.textContent=has?`${rooms.length} New`:'';panel.classList.toggle('has-unread',has);
 },onLeave:()=>{if(cameraStream)stopCamera()}});
 badge.onclick=()=>chat.openUnread();
 launch.querySelector('#wave-chat-open').onclick=()=>chat.openUnread();
 const mediaStop=document.createElement('button');mediaStop.id='support-media-stop';mediaStop.hidden=true;mediaStop.textContent='Media Active · Stop All Media';document.body.append(mediaStop);
 $('#camera-recording').addEventListener('click',async e=>{
  const a=e.target.closest('a[download]');if(!a)return;e.preventDefault();
  try{const blob=await fetch(a.href).then(r=>r.blob());await requestFileSave(blob,a.download)}catch(error){camStatus('Could not save clip: '+error.message)}
 });
 const mediaFlags={};
 document.addEventListener('wave-media-state',e=>{Object.assign(mediaFlags,e.detail);mediaStop.hidden=!Object.values(mediaFlags).some(Boolean)});
 mediaStop.onclick=()=>{stopCamera();chat.leave()};

 const shot=document.createElement('button');shot.id='workspace-screenshot';shot.textContent='Screenshot';$('#workspace-fullscreen').after(shot);
 shot.classList.add('customize-shortcut');shot.dataset.shortcut='Ctrl + Shift + S';shot.title='Screenshot · Ctrl + Shift + S';shot.setAttribute('aria-keyshortcuts','Control+Shift+S');
 const capture=document.createElement('dialog');capture.className='capture-dialog';capture.innerHTML='<h2>Layout Screenshot</h2><p>Current virtual stage only, not your desktop, camera or private chat.</p><img alt="Screenshot Preview"><div class="support-row"><button data-shot-download>Download PNG</button><button data-shot-guide>Attach To Guide</button><button data-shot-chat>Attach To Chat</button><button data-shot-close>Close</button></div>';document.body.append(capture);
 let shotBlob=null,shotURL=null;
 shot.onclick=()=>{const canvas=$('#viewport canvas')??$('#stage');if(!canvas||canvas.width<1||canvas.height<1){alert('Restore the Layout panel before capturing.');return}try{canvas.toBlob(blob=>{if(!blob)return;if(shotURL)URL.revokeObjectURL(shotURL);shotBlob=blob;shotURL=URL.createObjectURL(blob);capture.querySelector('img').src=shotURL;capture.showModal()},'image/png')}catch{alert('This browser blocked screenshot capture. Use your device’s screenshot controls.')}};
 capture.querySelector('[data-shot-close]').onclick=()=>capture.close();
 capture.querySelector('[data-shot-download]').onclick=()=>requestFileSave(shotBlob,'wave-layout-screenshot.png');
 capture.querySelector('[data-shot-guide]').onclick=()=>{guideImage(shotBlob);capture.close();open('guide')};
 capture.querySelector('[data-shot-chat]').onclick=()=>{chat.attach(shotBlob,'wave-layout-screenshot.png');capture.close();open('chat')};
 const tools=$('.mobile-bank-tools'),master=document.createElement('label');master.className='master-visibility';master.innerHTML='<input id="show-master-fader" type="checkbox">Show Master';tools.append(master);
 const masterInput=$('#show-master-fader');
 const applyMaster=(value,save=false)=>{state.masterVisible=value;masterInput.checked=value;document.body.classList.toggle('master-hidden',!value);if(save)workspace.showMaster(value)};
 masterInput.onchange=()=>applyMaster(masterInput.checked,true);
 document.addEventListener('wave-master-visible',e=>applyMaster(e.detail,true));
 document.addEventListener('wave-workspace-layout',()=>{const cfg=workspace.currentProfile();if(workspace.isCustom())applyMaster(cfg.panels.find(p=>p.key==='master').visible)});
 applyMaster(!matchMedia('(max-width:700px)').matches);
 window.addEventListener('pagehide',()=>{stopCamera();window.speechSynthesis?.cancel();recognition?.stop()});
}
