import {mountDemoEditor} from './demo-editor.js?v=v031c-20261004d';
import {trialState,startTrial,trialLabel,gateEnabled,PRICES,formatPrice,redeemCode,downloadLink,downloadUrlFromToken,downloadManifest,formatSize,startCheckout,storeInfo} from './trial.js?v=v031c-20261004d';
// Progressive enhancement: accessible OS tabs and decorative, non-calibrated art.
const tabs=[...document.querySelectorAll('[role="tab"]')];
function selectPlatform(platform,focus=false){
 for(const tab of tabs){
  const selected=tab.dataset.platform===platform;
  tab.setAttribute('aria-selected',String(selected));tab.tabIndex=selected?0:-1;
  document.getElementById(tab.getAttribute('aria-controls')).hidden=!selected;
  if(selected&&focus)tab.focus();
 }
}
tabs.forEach((tab,index)=>{
 tab.addEventListener('click',()=>selectPlatform(tab.dataset.platform));
 tab.addEventListener('keydown',event=>{
  if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Home','End'].includes(event.key))return;
  event.preventDefault();
  const next=event.key==='Home'?0:event.key==='End'?tabs.length-1:(index+(['ArrowLeft','ArrowUp'].includes(event.key)?-1:1)+tabs.length)%tabs.length;
  selectPlatform(tabs[next].dataset.platform,true);
 });
});
document.querySelectorAll('.guide-jump').forEach(link=>link.addEventListener('click',()=>selectPlatform(link.dataset.platform)));
const licenseDialog=document.getElementById('license-dialog');
document.querySelectorAll('.license-open').forEach(button=>button.addEventListener('click',()=>{
openLicense(button.dataset.platform)}));
function openLicense(kind){
 const mac=kind==='macos',studio=kind==='studio',platform=mac?'macOS':'Windows';
 licenseDialog.querySelector('.license-dialog-head .eyebrow').textContent=studio?'ONE-TIME PURCHASE / FULL STUDIO':'ONE-TIME PURCHASE / ONE COMPUTER';
 document.getElementById('license-title').textContent=studio?'Virtual SFX Lab — Wave Studio full studio':`Vista receiver add-on for ${platform}`;
 document.getElementById('license-platform').textContent=studio?'Web browser':platform;
 licenseDialog.querySelector('.license-facts dd').textContent=studio?'This browser account':'One computer';
 const buy=document.getElementById('license-buy');buy.dataset.product=studio?'studio':mac?'macos':'windows';buy.innerHTML=`Buy ${studio?'the full studio':`for ${platform}`} · $29.99 CAD <span aria-hidden="true">→</span>`;
 const owned=studio?trial.status==='licensed':(trial.downloads||[]).includes(mac?'macos':'windows');buy.disabled=owned||!(store?.live);if(owned){buy.dataset.owned='1';buy.textContent=studio?'Already unlocked in this browser':`Already purchased · download above`}else{delete buy.dataset.owned;if(!(store?.live))buy.textContent='Checkout opening soon'}
 document.getElementById('license-platform-note').textContent=studio
  ?'Unlocks the full Wave Studio module after the seven-day trial: 40 units, 88 presets, virtual faders, cue stacks, layouts and workspaces. The free demo never needs this. Live Vista input additionally needs the Windows or Mac app.'
  :mac?'Python launcher package for one Mac (Python 3.10+, no pip packages). Native macOS, Safari and Vista interoperability testing is pending; it is not a signed or notarized app.'
  :'Code-signed one-folder build for one Windows PC: Virtual SFX Lab.exe, local sACN / Art-Net receiver and the full studio, no Python install. SmartScreen may warn because the publisher identity is new.';
 licenseDialog.showModal();
}
document.getElementById('license-close').addEventListener('click',()=>licenseDialog.close());
licenseDialog.addEventListener('click',event=>{
 if(event.target!==licenseDialog)return;
 const box=licenseDialog.getBoundingClientRect();
 if(event.clientX<box.left||event.clientX>box.right||event.clientY<box.top||event.clientY>box.bottom)licenseDialog.close();
});
mountDemoEditor();
// Keep the first screen focused on the demo, without removing support information.
const support=document.querySelector('#landing-support'),header=document.querySelector('.header-inner');
function placeSupport(){
 const contribution=header.querySelector('.contribution-bar'),thanks=header.querySelector('.donor-thanks');
 if(contribution)support.append(contribution);
 if(thanks)support.prepend(thanks);
}
placeSupport();new MutationObserver(placeSupport).observe(header,{childList:true});

// Seven-day full-studio trial: every studio link becomes Start Trial, Open Studio (N days left) or Buy.
const trialDialog=document.getElementById('trial-dialog'),ctas=[...document.querySelectorAll('.studio-cta')],standing=document.getElementById('trial-standing');
const gate=gateEnabled();
function paintCtas(state){
 const arrow='<span aria-hidden="true">↗</span>';
 for(const cta of ctas){
  cta.dataset.state=state.status;
  if(!gate){cta.innerHTML=`Open the full studio ${arrow}`;cta.href='./index.html';continue}
  if(state.status==='licensed'){cta.innerHTML=`Open the full studio <span class="cta-days">· tester access</span> ${arrow}`;cta.href='./index.html'}
  else if(state.status==='none'){cta.innerHTML=`Start 7-day trial ${arrow}`;cta.href='./index.html'}
  else if(state.status==='active'){cta.innerHTML=`Open the full studio <span class="cta-days">· ${trialLabel(state).replace('Trial · ','')}</span> ${arrow}`;cta.href='./index.html'}
  else{cta.innerHTML=`Buy the full studio · ${formatPrice(PRICES.studio)} ${arrow}`;cta.href='#license'}
 }
 if(standing)standing.textContent=!gate?'':state.status==='licensed'?`Tester access is active in this browser — the full studio and the Windows download are free until version ${state.license?.until??'1.0'}.`:state.status==='active'?`Your trial is running — ${trialLabel(state).replace('Trial · ','')}.`:state.status==='expired'?'Your seven-day trial has ended. The demo above stays free.':'';
}
let trial={status:'none',daysLeft:7};
trialState().then(state=>{trial=state;paintCtas(state);paintDownload(state);if(gate&&state.status==='none'&&new URLSearchParams(location.search).get('studio')==='trial')trialDialog.showModal()}).catch(()=>paintCtas(trial));
ctas.forEach(cta=>cta.addEventListener('click',event=>{
 if(!gate||trial.status==='active'||trial.status==='licensed')return;
 event.preventDefault();
 if(trial.status==='expired')openLicense('studio');else trialDialog.showModal();
}));
document.getElementById('trial-close').addEventListener('click',()=>trialDialog.close());
trialDialog.addEventListener('click',event=>{if(event.target===trialDialog)trialDialog.close()});
trialDialog.querySelector('[data-demo-expand]').addEventListener('click',()=>trialDialog.close());
document.getElementById('trial-begin').addEventListener('click',async()=>{
 const button=document.getElementById('trial-begin');button.disabled=true;button.textContent='Starting…';
 try{trial=await startTrial();paintCtas(trial);document.getElementById('trial-dialog-status').textContent='Trial started. Opening the studio…';location.assign('./index.html')}
 catch{button.disabled=false;button.textContent='Start the 7-day trial';document.getElementById('trial-dialog-status').textContent='Could not record the trial start. Please try again.'}
});

// Tester code → license → Windows download. The code itself never appears in this bundle; the
// backend compares a salted digest and issues fifteen-minute download links to licensed visitors.
const promoForm=document.getElementById('promo-form'),promoInput=document.getElementById('promo-code'),promoStatus=document.getElementById('promo-status'),promoSubmit=document.getElementById('promo-submit');
const CARDS={windows:{button:document.getElementById('windows-download'),buy:document.getElementById('windows-buy'),note:document.getElementById('windows-download-note'),hash:document.getElementById('windows-hash'),run:'Unzip, run Virtual SFX Lab.exe; if SmartScreen appears choose More info → Run anyway.',price:'Plus applicable tax · one-time · one computer. Price subject to change as updates continue. Testers with a code download free until 1.0.'},
 macos:{button:document.getElementById('macos-download'),buy:document.getElementById('macos-buy'),note:document.getElementById('macos-download-note'),hash:document.getElementById('macos-hash'),run:'Unzip, install Python 3.10+ if needed, then double-click Virtual SFX Lab.command.',price:'Plus applicable tax · one-time · one computer. Price subject to change as updates continue. Not a signed or notarized app; native Mac testing is still pending.'}};
let manifest=null,store=null;
downloadManifest().then(m=>{manifest=m;paintDownload(trial)}).catch(()=>{});
storeInfo().then(info=>{store=info;paintStore()}).catch(()=>{});
function paintStore(){
 for(const b of document.querySelectorAll('.buy-button,#license-buy')){
  const live=!!store?.live,product=b.dataset.product,price=store?.prices?.[product]??'29.99';
  if(b.classList.contains('buy-button')&&!b.hidden){b.innerHTML=live?`Buy for ${product==='macos'?'macOS':'Windows'} · $${price} CAD${store.mode==='test'?' · test mode':''} <span aria-hidden="true">→</span>`:`Checkout opening soon · $${price} CAD`}
  if(store&&!live){b.disabled=true;b.classList.add('is-pending')}else if(store&&!b.dataset.owned){b.disabled=false;b.classList.remove('is-pending')}
  b.title=live?'Checkout opens on Lemon Squeezy':'Checkout is being connected — try again shortly';
 }
}
function paintDownload(state){
 const owned=file=>!gate||state.status==='licensed'||(state.downloads||[]).includes(file);
 for(const [file,card] of Object.entries(CARDS)){
  const meta=manifest?.[file],has=owned(file);
  if(card.button)card.button.hidden=!has;
  if(card.buy)card.buy.hidden=has;
  if(card.note)card.note.innerHTML=has
   ?`${state.status==='licensed'?`Free for testers until version ${state.license?.until??'1.0'}. `:'Purchased · unlocked in this browser. '}${meta?`${meta.label}, ${formatSize(meta.size)}. `:''}${card.run}`
   :card.price.replace('a code',`a <a href="#promo">code</a>`);
  if(card.hash){card.hash.hidden=!(has&&meta);if(meta)card.hash.innerHTML=`SHA-256 <code>${meta.sha256}</code>`}
 }
 if(promoForm){promoForm.hidden=state.status==='licensed';const done=promoForm.parentElement.querySelector('.promo-done');if(state.status==='licensed'){if(!done){const p=document.createElement('p');p.className='promo-done';p.innerHTML=`<strong>Tester access active.</strong> ${state.license?.label?state.license.label+'. ':''}Your Windows and Mac downloads are ready in the cards above, and every studio link on this page now opens the full studio.`;promoForm.after(p)}}else done?.remove()}
 paintStore();
}
for(const [file,card] of Object.entries(CARDS)){
 card.button?.addEventListener('click',async()=>{
  const b=card.button;b.disabled=true;const label=b.innerHTML;b.textContent='Preparing download…';
  try{
   let url;
   if(b.dataset.token&&Date.now()-Number(b.dataset.tokenAt)<10*60*1000)url=downloadUrlFromToken(b.dataset.token,file);
   else{const link=await downloadLink(file);url=link.url}
   delete b.dataset.token;
   const a=document.createElement('a');a.href=url;a.download='';a.rel='noopener';document.body.append(a);a.click();a.remove();
   if(card.note)card.note.textContent=`Download started. The link is valid for fifteen minutes; press the button again for a fresh one. ${card.run}`;
  }catch(err){if(card.note)card.note.textContent=err.message||'The download could not be prepared. Try again in a moment.'}
  finally{b.disabled=false;b.innerHTML=label}
 });
}
// Buy → hosted Lemon Squeezy checkout, carrying this browser's visitor identity so the webhook can unlock it.
async function buy(button){
 const product=button.dataset.product;const label=button.innerHTML;button.disabled=true;button.textContent='Opening checkout…';
 try{const {url}=await startCheckout(product);location.assign(url)}
 catch(err){button.disabled=false;button.innerHTML=label;const note=CARDS[product]?.note||document.getElementById('license-status');if(note)note.textContent=err.message||'Checkout could not be opened. Please try again.'}
}
document.querySelectorAll('.buy-button,#license-buy').forEach(b=>b.addEventListener('click',()=>buy(b)));
// Returning from checkout: poll until the webhook has landed, then thank the buyer.
const params=new URLSearchParams(location.search),purchased=params.get('purchase');
if(purchased&&['studio','windows','macos'].includes(purchased)){
 const target=document.getElementById(purchased==='studio'?'license':`${purchased}-card`);
 const banner=document.createElement('p');banner.className='purchase-banner';banner.setAttribute('role','status');banner.textContent='Thank you. Confirming your purchase…';
 (target||document.getElementById('license')).prepend(banner);
 let tries=0;const owned=s=>purchased==='studio'?s.status==='licensed':(s.downloads||[]).includes(purchased);
 const poll=async()=>{const s=await trialState().catch(()=>trial);trial=s;paintCtas(s);paintDownload(s);
  if(owned(s)){banner.textContent=purchased==='studio'?'Purchase confirmed. The full studio is unlocked in this browser — open it from any studio button.':`Purchase confirmed. Your ${purchased==='macos'?'macOS':'Windows'} download is unlocked below; keep your Lemon Squeezy receipt as proof of purchase.`;return}
  if(++tries<20)setTimeout(poll,3000);else banner.textContent='Payment received, but this browser has not been unlocked yet. Reload in a minute; if it still shows a Buy button, reply to your receipt email with this page’s address.'};
 poll();
}
if(params.get('buy')==='studio')trialState().then(()=>{if(gate&&trial.status!=='licensed')openLicense('studio')});
promoForm?.addEventListener('submit',async event=>{
 event.preventDefault();
 const code=promoInput.value.trim();
 if(code.length<4){promoStatus.textContent='Enter the code you were given.';promoInput.focus();return}
 promoSubmit.disabled=true;promoSubmit.textContent='Checking…';promoStatus.textContent='';
 try{
  const state=await redeemCode(code);
  trial=state;paintCtas(state);paintDownload(state);
  promoStatus.textContent='Code accepted.';
  document.getElementById('windows-card')?.scrollIntoView({behavior:'smooth',block:'center'});
  for(const [file,token] of Object.entries(state.downloadTokens||{})){const b=CARDS[file]?.button;if(b){b.dataset.token=token;b.dataset.tokenAt=String(Date.now())}}
 }catch(err){promoStatus.textContent=err.message||'That code could not be redeemed.';promoInput.select()}
 finally{promoSubmit.disabled=false;promoSubmit.textContent='Unlock'}
});
