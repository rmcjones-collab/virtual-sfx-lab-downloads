// Fixed, presentation-only media slots: microphone, camera, screen.
export function createCall({container,status,send,me,session}){
 const peers=new Map();let microphone=null,camera=null,screen=null,generation=0,micGeneration=0;
 const mediaState=()=>document.dispatchEvent(new CustomEvent('wave-media-state',{detail:{callMic:!!microphone,callCamera:!!camera,callScreen:!!screen}}));
 const getTrack=i=>(i===0?microphone:i===1?camera:screen)?.getTracks().find(t=>t.kind===(i===0?'audio':'video'))??null;
 const signalPeer=(code,peer,body)=>send({target:code,body:{...body,fromSession:peer.localSession,toSession:peer.session}});
 function makePeer(code,name,remoteSession){
  if(peers.has(code))return peers.get(code);
  const pc=new RTCPeerConnection({iceServers:[{urls:'stun:stun.l.google.com:19302'}]});
  const row=document.createElement('section');row.className='call-peer';const title=document.createElement('h4');title.textContent=name;const state=document.createElement('p');state.className='support-note';state.textContent='Connecting…';row.append(title,state);container.append(row);
  // Only the offerer creates slots; the answerer adopts the offered transceivers.
  const slots=me()<code?['audio','video','video'].map(kind=>pc.addTransceiver(kind,{direction:'sendrecv'})):[];
  const peer={pc,slots,row,queue:[],making:false,ignore:false,polite:me()>code,session:remoteSession,localSession:session()};peers.set(code,peer);
  slots.forEach((s,i)=>{const track=getTrack(i);if(track)s.sender.replaceTrack(track).catch(e=>status(e.message))});
  pc.onicecandidate=e=>{if(e.candidate&&peers.get(code)===peer)signalPeer(code,peer,{kind:'ice',candidate:e.candidate.toJSON()}).catch(()=>{})};
  pc.onconnectionstatechange=()=>{state.textContent=pc.connectionState==='failed'?'Connection failed. This network may require a TURN relay.':pc.connectionState};
  pc.ontrack=e=>{
   const i=pc.getTransceivers().indexOf(e.transceiver),name=i===0?'Microphone':i===1?'Camera':'Shared Screen';
   let media=row.querySelector(`[data-slot="${i}"]`),label=row.querySelector(`[data-media-label="${i}"]`);
   if(!media){
    label=document.createElement('p');label.className='support-note';label.dataset.mediaLabel=i;
    media=document.createElement(e.track.kind==='audio'?'audio':'video');media.dataset.slot=i;media.autoplay=true;media.controls=true;media.playsInline=true;media.setAttribute('aria-label',name);row.append(label,media);
   }
   const showState=()=>{const active=!e.track.muted&&e.track.readyState==='live';media.hidden=!active;label.textContent=active?name:`${name}: Off / Not Shared`};
   e.track.onmute=showState;e.track.onunmute=showState;e.track.onended=showState;
   media.srcObject=new MediaStream([e.track]);showState();
   media.play().catch(()=>{if(!media.hidden)state.textContent='Press Play on the media control to hear or see this participant.'});
  };
  return peer;
 }
 async function offer(code,peer){try{peer.making=true;await peer.pc.setLocalDescription();await signalPeer(code,peer,{kind:peer.pc.localDescription.type,sdp:peer.pc.localDescription.sdp})}finally{peer.making=false}}
 async function sync(codes,members,sessions={}){
  for(const [code,p] of peers)if(!codes.includes(code)||sessions[code]!==p.session){p.pc.close();p.row.remove();peers.delete(code)}
  for(const code of codes){if(code===me()||peers.has(code)||!sessions[code])continue;const peer=makePeer(code,members.find(m=>m.code===code)?.name??'Participant',sessions[code]);if(me()<code)await offer(code,peer)}
 }
 async function signal(code,b){
  const p=peers.get(code);if(!p||b.fromSession!==p.session||b.toSession!==p.localSession)return;
  const pc=p.pc;
  if(b.kind==='ice'){if(p.ignore)return;if(!pc.remoteDescription){p.queue.push(b.candidate);return}await pc.addIceCandidate(b.candidate);return}
  const collision=b.kind==='offer'&&(p.making||pc.signalingState!=='stable');p.ignore=!p.polite&&collision;if(p.ignore)return;
  await pc.setRemoteDescription({type:b.kind,sdp:b.sdp});for(const ice of p.queue.splice(0))await pc.addIceCandidate(ice);
  if(b.kind==='offer'){
   p.slots=pc.getTransceivers().slice(0,3);
   await Promise.all(p.slots.map((t,i)=>{t.direction='sendrecv';return t.sender.replaceTrack(getTrack(i))}));
   await pc.setLocalDescription();await signalPeer(code,p,{kind:'answer',sdp:pc.localDescription.sdp});
  }
 }
 async function update(i){await Promise.all([...peers.values()].filter(p=>p.slots[i]).map(p=>p.slots[i].sender.replaceTrack(getTrack(i))))}
 function stopMic(){
  micGeneration++;microphone?.getTracks().forEach(t=>t.stop());microphone=null;update(0).catch(()=>{});mediaState();
 }
 async function toggleMic(){
  if(microphone){stopMic();return false}
  if(!navigator.mediaDevices?.getUserMedia)throw Error('Microphone unavailable. Open a supported standalone HTTPS browser.');
  const token=++micGeneration,stream=await navigator.mediaDevices.getUserMedia({audio:true,video:false});
  if(token!==micGeneration){stream.getTracks().forEach(t=>t.stop());return false}
  microphone=stream;
  for(const track of stream.getAudioTracks())track.onended=()=>{if(microphone===stream){stopMic();status('Microphone stopped. Push To Talk is off.')}};
  try{await update(0)}catch(error){if(microphone===stream)stopMic();throw error}
  if(token!==micGeneration)return false;
  mediaState();return true;
 }
 function stopScreen(){screen?.getTracks().forEach(t=>t.stop());screen=null;update(2).catch(()=>{});mediaState();status('Screen sharing stopped.')}
 async function shareScreen(){
  if(!navigator.mediaDevices?.getDisplayMedia)throw Error('Screen sharing is unsupported here. Try the standalone desktop site.');
  const token=generation,stream=await navigator.mediaDevices.getDisplayMedia({video:true,audio:false});
  if(token!==generation){stream.getTracks().forEach(t=>t.stop());return}
  stopScreen();screen=stream;screen.getVideoTracks()[0].onended=stopScreen;await update(2);mediaState();status('Screen shared with this room. Use Stop Screen Share to end.');
 }
 function setCamera(stream){camera=stream;update(1).catch(e=>status(e.message));mediaState()}
 function close(){generation++;for(const p of peers.values()){p.pc.close();p.row.remove()}peers.clear();stopMic();screen?.getTracks().forEach(t=>t.stop());screen=null;camera=null;mediaState()}
 return {sync,signal,toggleMic,stopMic,shareScreen,stopScreen,setCamera,close};
}
