// Documented menu order: Explo X2 Wave Flamer v2.0, §§3.5.2–4.3.
// A partial local visual emulation. No hardware functions or telemetry.
export function mountRearPanel({state,readArmed,apply,now=()=>performance.now()}){
 const el=id=>document.getElementById(id),root=el('rear-panel');
 const menus={
  main:[
   ['ID and Box number','Virtual ID only'],
   ['Pressure','No pressure sensor'],
   ['Mains supply informations','No power telemetry'],
   ['Type and Showname','X2 / Wave Studio'],
   ['Check and Lines','No AutoShow loaded'],
   ['Sec-Key and Frequency','Radio not modelled'],
   ['Power and Timeout','Radio not modelled'],
   ['Position min/max','limits'],
   ['View AUTOSHOW list','Not modelled'],
   ['Edit Wave Flamer settings','settings'],
   ['Edit DMX settings','dmx'],
   ['Systemtest start?','Hardware only'],
   ['Pump and vent','Hardware only'],
   ['Software version','Virtual UI / v2 menu'],
   ['Group BOX','Radio not modelled']
  ],
  settings:[
   ['M-Set: MODUS','mode',['Test','Armed','Sleep']],
   ['M-Set: BOX','Radio not modelled'],
   ['M-Set: SEC-KEY','Radio not modelled'],
   ['M-Set: FREQUENCY','Radio not modelled'],
   ['M-Set: POWER','Radio not modelled'],
   ['M-Set: TIMEOUT','Radio not modelled'],
   ['M-Set: LOCK','Not modelled'],
   ['M-Set: SYS','Radio not modelled'],
   ['M-Set: Pos 1-15 (Igntime)','Not modelled'],
   ['M-Set: Pos 16-30 (Igntime)','Not modelled'],
   ['M-Set: Pos 1-15 (20ms pulse)','Not modelled'],
   ['M-Set: Pos 16-30 (20ms pulse)','Not modelled'],
   ['M-Set: CENTER','Calibration not modelled'],
   ['M-Set: Invert','invert',['OFF','ON']],
   ['M-Set: Pos MIN','min',Array.from({length:15},(_,i)=>i+1)],
   ['M-Set: Pos MAX','max',Array.from({length:15},(_,i)=>i+1)],
   ['M-Set: System Restore Default','Hardware reset unavailable'],
   ['M-Set: Demo Mode','Hardware demo not modelled'],
   ['M-Set: Radio prog','Radio not modelled'],
   ['M-Set: GroupBOX','Radio not modelled'],
   ['M-Set: Pump','Hardware only'],
   ['M-Set: Pressure','Hardware only']
  ],
  dmx:[
   ['M-DMX: Modus','Input controlled by app'],
   ['M-DMX: Startadresse','address',Array.from({length:507},(_,i)=>i+1)],
   ['M-DMX: Customer','Explo model only'],
   ['M-DMX: CH5 vers.','Current model only'],
   ['M-DMX: Protocol','DMX 512 model only'],
   ['M-Set: DMX EASY','Not modelled']
  ]
 };
 let page='home',index=0,parent=0,editing=false,draft=null,lit=true,touched=now(),selection='',lastPaint='';
 const selected=()=>state.fixtures.find(f=>f.id===state.selectedId);
 const group=()=>state.fixtures.filter(f=>state.selectedIds.includes(f.id));
 const item=()=>menus[page]?.[index];
 const value=(key,f=selected())=>key==='invert'?(f.inverted?'ON':'OFF'):key==='min'?(f.minAngle??-105)/15+8:key==='max'?(f.maxAngle??105)/15+8:key==='address'?f.patch.address:key==='mode'?(f.virtualSleep?'Sleep':readArmed(f)?'Armed':'Test'):null;
 const info=message=>el('rear-status').textContent=message;
 const reset=()=>{page='home';index=0;editing=false;draft=null;lastPaint=''};
 function paint(){
  const f=selected(),n=group().length,entry=item();
  let lines;
  if(page==='home')lines=[`F${String(f.id).padStart(2,'0')}  ${state.live?'LIVE INPUT':String(value('mode')).toUpperCase()}`,`DMX ${String(f.patch.address).padStart(3,'0')}  ${n} selected`];
  else{
   const values=entry[2]?group().map(f=>value(entry[1],f)):[];
   const mixed=values.length>1&&values.some(v=>v!==values[0]);
   let detail=entry[2]?`${editing?draft:value(entry[1])}${!editing&&mixed?' · MIXED':''}`:entry[1];
   if(page==='main'){
    if(index===0)detail=`F${String(f.id).padStart(2,'0')} / Box not modelled`;
    if(entry[1]==='limits')detail=`POS ${value('min')} to ${value('max')}`;
    if(['settings','dmx'].includes(entry[1]))detail='OK to enter';
   }
   lines=[entry[0],`${editing?'> ':''}${detail}${editing?' <':''}`];
  }
  const signature=JSON.stringify([lines,lit,editing]);
  if(signature!==lastPaint){
   el('rear-line1').textContent=lines[0];el('rear-line2').textContent=lines[1];
   el('rear-screen').classList.toggle('unlit',!lit);el('rear-screen').classList.toggle('editing',editing);
   lastPaint=signature;
  }
  root.dataset.menu=page;root.dataset.index=index;root.dataset.editing=editing;
 }
 function canEdit(){return !state.live&&group().length>0}
 function action(key){
  tick();touched=now();
  if(key==='esc'){
   if(editing){editing=false;draft=null;info('Edit cancelled. No fixture values changed.')}
   else if(page==='settings'||page==='dmx'){page='main';index=parent;info('Main menu. +/− scroll; OK selects.')}
   else if(page==='main'){reset();info('Returned to virtual status.')}
   else info('Radio test unavailable: this panel is a local preview.');
  }else if(page==='home'){
   if(key==='plus'){lit=!lit;info(`Virtual backlight ${lit?'on':'off'}.`)}
   else if(key==='minus'){
    if(canEdit()){
     const result=apply('mode','Test');
     info(result.ok?'Selected virtual units are in Test mode. Press Mode/OK to open the menu.':result.message);
    }else info('Live Input is read-only. Switch to Manual preview to edit virtual mode.');
   }else if(key==='ok'){
    if(!group().length)info('Select one or more fixtures first.');
    else if(!state.live&&group().some(f=>readArmed(f)))info('Menu opens in Test mode. Press E/− to disarm the selected virtual units first.');
    else{page='main';index=0;lit=true;info(state.live?'Live Input: browse only; menu edits are disabled.':'+/− scroll; OK selects; ESC returns. Changes apply to selected units.')}
   }
  }else if(key==='plus'||key==='minus'){
   const step=key==='plus'?1:-1;
   if(editing){
    const choices=item()[2],at=choices.indexOf(draft);draft=choices[Math.max(0,Math.min(choices.length-1,at+step))];
   }else index=(index+step+menus[page].length)%menus[page].length;
  }else if(key==='ok'){
   const entry=item();
   if(page==='main'&&['settings','dmx'].includes(entry[1])){parent=index;page=entry[1];index=0;info('+ / − scroll settings. OK edits; ESC goes back.')}
   else if(entry[2]){
    if(!canEdit())info('Read-only. Select fixtures and leave Live Input to change virtual settings.');
    else if(editing){
     const result=apply(entry[1],draft);
     if(result.ok){editing=false;info(result.message);if(entry[1]==='mode'&&draft!=='Test')reset()}
     else info(result.message);
    }else{
     editing=true;draft=value(entry[1]);info('Editing selected units. +/− changes the draft; OK saves; ESC cancels.');
    }
   }else info('Reference only. This hardware or firmware function is not modelled; no setting was changed.');
  }
  paint();
 }
 function tick(){
  const next=JSON.stringify([state.selectedId,state.selectedIds,state.live]);
  if(next!==selection){selection=next;reset();info(state.live?'Live Input: virtual panel is read-only.':'Local virtual settings. E/− enters Test; Mode/OK opens the menu.')}
  if(page!=='home'&&now()-touched>=60000){reset();info('Menu closed after 60 seconds. Unsaved edits cancelled.')}
  paint();
 }
 for(const key of ['ok','minus','plus','esc'])el(`rear-${key}`).onclick=()=>action(key);
 el('rear-screen').addEventListener('keydown',e=>{
  const key={ArrowDown:'plus',ArrowRight:'plus',ArrowUp:'minus',ArrowLeft:'minus',Enter:'ok',Escape:'esc'}[e.key];
  if(key){e.preventDefault();e.stopPropagation();action(key)}
 });
 el('rear-screen').addEventListener('wheel',e=>{
  if(e.ctrlKey||!e.deltaY||page==='home')return;
  e.preventDefault();action(e.deltaY>0?'plus':'minus');
 },{passive:false});
 tick();return {tick};
}
