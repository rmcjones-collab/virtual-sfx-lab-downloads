// Live visitor counter for the studio footer. Sends an anonymous heartbeat to the
// local backend and shows how many browsers have checked in within the last minute.
// Nothing about the layout, cues or stage is sent — only the visitor identity the
// backend already uses for private storage, which it hashes before counting.
const PORT='__PORT_8093__';
const API=PORT.startsWith('__')?'http://127.0.0.1:8093':PORT;
const local=['127.0.0.1','localhost'].includes(location.hostname);
const headers={'Content-Type':'application/json',...(local?{'X-Wave-Dev-Visitor':'local-development'}:{})};
export function mountPresence(output,{interval=30000}={}){
 if(!output)return;
 const count=output.querySelector('b'),label=document.createTextNode('');
 let timer=0,failures=0;
 const paint=n=>{output.hidden=false;output.dataset.state='live';count.textContent=String(n);output.lastChild.textContent=n===1?' in the studio now (just you)':' in the studio now'};
 const quiet=()=>{failures++;if(failures>=2){output.dataset.state='offline';output.hidden=true}};
 async function beat(){
  if(document.hidden)return;
  try{
   const r=await fetch(`${API}/api/presence`,{method:'POST',headers,body:'{}',signal:AbortSignal.timeout(6000)});
   if(!r.ok)throw Error(String(r.status));
   const data=await r.json();failures=0;paint(Math.max(1,Number(data.active)||1));
  }catch{quiet()}
 }
 const start=()=>{clearInterval(timer);beat();timer=setInterval(beat,interval)};
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)beat()});
 start();
 return {beat,stop:()=>clearInterval(timer)};
}
