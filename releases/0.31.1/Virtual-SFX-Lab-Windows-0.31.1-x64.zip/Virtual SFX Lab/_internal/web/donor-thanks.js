// Presentation only. This module does not verify payments or expose an ingestion API.
// An eventual trusted feed must verify payment, currency and public display consent.
export function eligibleDonations(feed) {
  if (feed?.mode !== 'approved') return [];
  const ids = new Set();
  return (Array.isArray(feed.donations) ? feed.donations : []).slice(0, 1000).filter(row => {
    if (!row || typeof row.id !== 'string' || !row.id.trim() || row.id.length > 100 || ids.has(row.id) ||
      row.paymentStatus !== 'completed' || row.publicConsent !== true ||
      typeof row.username !== 'string' || !row.username.trim() || row.username.length > 40 ||
      /[\u0000-\u001f\u007f-\u009f\u202a-\u202e\u2066-\u2069]/u.test(row.username) ||
      typeof row.amount !== 'number' || !Number.isFinite(row.amount) || row.amount <= 0 || row.amount > 1e9 ||
      typeof row.currency !== 'string' || !/^[A-Z]{3}$/.test(row.currency)) return false;
    if (!Intl.supportedValuesOf('currency').includes(row.currency)) return false;
    ids.add(row.id);
    return true;
  }).map(row => ({id: row.id, username: row.username.trim(), amount: row.amount, currency: row.currency}));
}

export function mountDonorThanks({brand, header}) {
  const panel = document.createElement('section');
  panel.className = 'donor-thanks';
  panel.hidden = true;
  panel.setAttribute('aria-label', 'Donor Thank-You');
  const message = document.createElement('p');
  message.className = 'donor-thanks-message';
  message.setAttribute('role', 'status');
  message.setAttribute('aria-live', 'polite');
  message.setAttribute('aria-atomic', 'true');
  const pause = document.createElement('button');
  pause.type = 'button';
  pause.className = 'donor-thanks-pause';
  pause.textContent = 'Pause';
  pause.setAttribute('aria-label', 'Pause Donor Thank-You Rotation');
  pause.setAttribute('aria-pressed', 'false');
  panel.append(message, pause);
  brand.after(panel);
  let rows = [], currentId = null, paused = false, elapsed = 0, lastTick = performance.now(), loading = false;

  function render() {
    const row = rows.find(item => item.id === currentId);
    panel.hidden = !row;
    header.classList.toggle('has-donor-thanks', !!row);
    pause.hidden = rows.length < 2;
    if (!row) {
      message.textContent = '';
      return;
    }
    const amount = new Intl.NumberFormat('en-CA', {style: 'currency', currency: row.currency, currencyDisplay: 'code'}).format(row.amount);
    const text = `Thank you! ${row.username} for your donation of ${amount}`;
    if (message.textContent !== text) message.textContent = text;
  }
  function tick() {
    const now = performance.now(), delta = now - lastTick;
    lastTick = now;
    if (paused || document.hidden || rows.length < 2) return;
    elapsed += delta;
    if (elapsed >= 60000) {
      const index = Math.max(0, rows.findIndex(row => row.id === currentId));
      currentId = rows[(index + 1) % rows.length].id;
      elapsed = 0;
      render();
    }
  }
  pause.addEventListener('click', () => {
    tick();
    paused = !paused;
    pause.textContent = paused ? 'Resume' : 'Pause';
    pause.setAttribute('aria-label', `${paused ? 'Resume' : 'Pause'} Donor Thank-You Rotation`);
    pause.setAttribute('aria-pressed', String(paused));
  });
  async function refresh() {
    if (loading || document.hidden) return;
    loading = true;
    try {
      const response = await fetch(new URL('./donations.json', import.meta.url), {cache: 'no-store', signal: AbortSignal.timeout(8000)});
      if (!response.ok) throw new Error('Donation display unavailable');
      const next = eligibleDonations(await response.json());
      if (!next.some(row => row.id === currentId)) {
        currentId = next[0]?.id ?? null;
        elapsed = 0;
        lastTick = performance.now();
      }
      rows = next;
      render();
    } catch {
      // Hide stale acknowledgements when their approval/consent cannot be refreshed.
      rows = [];
      currentId = null;
      elapsed = 0;
      render();
    } finally {
      loading = false;
    }
  }
  document.addEventListener('visibilitychange', () => {
    lastTick = performance.now();
    if (!document.hidden) refresh();
  });
  refresh();
  setInterval(tick, 1000);
  setInterval(refresh, 15000);
}
