// Virtual SFX Lab — seven-day full-studio trial.
// The demo landing page is always free. The full studio (index.html) opens for seven days
// after the visitor presses Start Trial on the landing page; afterwards it locks behind the
// purchase screen until sales open. The start time is kept in this browser and, when the
// local backend is reachable, against the visitor identity the backend already uses for
// private storage, so clearing the browser does not restart the clock.
//
// Gate scope: enforced on every public host. 127.0.0.1 (the paid local receiver and the
// development test suite) is never gated; add ?gate=on to any URL to force the gate for QA.
export const PRODUCT='Virtual SFX Lab';
export const MODULE='Wave Studio';
export const MODULE_FIXTURE='Explo X2 Wave Flame';
export const TRIAL_DAYS=7;
export const PRICES={studio:{amount:'29.99',currency:'CAD',label:'Virtual SFX Lab · full studio',terms:'One-time purchase · plus applicable tax'},receiver:{amount:'29.99',currency:'CAD',label:'Vista receiver add-on · one computer',terms:'One-time purchase · plus applicable tax · Windows or macOS'}};
const KEY='vsl-trial';
const LICENSE_KEY='vsl-license';
const PORT='__PORT_8093__';
const API=PORT.startsWith('__')?'http://127.0.0.1:8093':PORT;
const localHost=['127.0.0.1','localhost'].includes(location.hostname);
// Owner-only store test token: while the Lemon Squeezy store is in test mode, ?storetest=<token> in the
// address (kept in sessionStorage) lets the owner exercise checkout; everyone else sees "opening soon".
const storeTest=(()=>{try{const q=new URLSearchParams(location.search).get('storetest');if(q){sessionStorage.setItem('wave-store-test',q);history.replaceState(null,'',location.pathname+location.search.replace(/[?&]storetest=[^&]*/,'').replace(/^&/,'?')+location.hash)}return sessionStorage.getItem('wave-store-test')||''}catch{return ''}})();
const headers={'Content-Type':'application/json',...(localHost?{'X-Wave-Dev-Visitor':'local-development'}:{}),...(storeTest?{'X-Wave-Store-Test':storeTest}:{})};
const DAY=86400000;

function readLocal(){try{const raw=localStorage.getItem(KEY);const rec=raw?JSON.parse(raw):null;return rec&&typeof rec.started==='string'&&Number.isFinite(Date.parse(rec.started))?rec:null}catch{return null}}
function writeLocal(rec){try{if(rec)localStorage.setItem(KEY,JSON.stringify({started:rec.started}));else localStorage.removeItem(KEY)}catch{}}

function readLicense(){try{const raw=localStorage.getItem(LICENSE_KEY);const rec=raw?JSON.parse(raw):null;return rec&&typeof rec.label==='string'?rec:null}catch{return null}}
function writeLicense(rec){try{if(rec)localStorage.setItem(LICENSE_KEY,JSON.stringify({kind:rec.kind,label:rec.label,until:rec.until??null,granted:rec.granted??null}));else localStorage.removeItem(LICENSE_KEY)}catch{}}

// A licensed record (tester code or, later, a purchase) overrides the trial clock entirely.
function withLicense(rec,license,downloads){
 if(!license)return rec;
 return {...rec,status:'licensed',licensed:true,license,downloads:downloads??['windows']};
}

export function describe(started){
 if(!started)return {status:'none',started:null,expires:null,daysLeft:TRIAL_DAYS,trialDays:TRIAL_DAYS,licensed:false};
 const begin=Date.parse(started),end=begin+TRIAL_DAYS*DAY,left=end-Date.now();
 return {status:left>0?'active':'expired',started:new Date(begin).toISOString(),expires:new Date(end).toISOString(),daysLeft:left>0?Math.ceil(left/DAY):0,hoursLeft:left>0?Math.ceil(left/3600000):0,trialDays:TRIAL_DAYS,licensed:false};
}

export function gateEnabled(){
 const params=new URLSearchParams(location.search),flag=params.get('gate');
 try{
  if(flag==='on'||flag==='off')sessionStorage.setItem('vsl-gate',flag);
  const forced=sessionStorage.getItem('vsl-gate');
  if(forced)return forced==='on';
 }catch{if(flag)return flag==='on'}
 return !['127.0.0.1','::1','[::1]'].includes(location.hostname);
}

async function remote(path,init){
 try{
  const r=await fetch(`${API}${path}`,{headers,signal:AbortSignal.timeout(5000),...init});
  if(!r.ok)return null;
  return await r.json();
 }catch{return null}
}

// Merge the browser record with the backend record; the earlier start wins everywhere.
// The backend is the authority on licenses; the browser copy only bridges an offline backend.
export async function trialState(){
 let rec=readLocal();
 const server=await remote('/api/trial');
 if(server){if(server.licensed&&server.license)writeLicense(server.license);else writeLicense(null)}
 const extras=server?{downloads:server.downloads??[],licenses:server.licenses??[]}:{};
 if(server&&server.licensed)return withLicense(describe(server.started??rec?.started??null),server.license,server.downloads);
 if(!server&&readLicense())return withLicense(describe(rec?.started??null),readLicense());
 if(server&&server.started){
  if(!rec||Date.parse(server.started)<Date.parse(rec.started))rec={started:server.started};
  else if(Date.parse(rec.started)<Date.parse(server.started))await remote('/api/trial/start',{method:'POST',body:JSON.stringify({started:rec.started})});
  writeLocal(rec);
 }else if(server&&rec){
  await remote('/api/trial/start',{method:'POST',body:JSON.stringify({started:rec.started})});
 }
 return {...describe(rec?.started??null),...extras};
}

export async function startTrial(){
 const existing=readLocal();
 const started=existing?.started??new Date().toISOString();
 writeLocal({started});
 const server=await remote('/api/trial/start',{method:'POST',body:JSON.stringify({started})});
 if(server&&server.started&&Date.parse(server.started)<Date.parse(started))writeLocal({started:server.started});
 return describe(readLocal()?.started??started);
}

// Exchange a privately shared tester code for a license. Resolves to the new state, or throws
// with the server's message (invalid code, throttled, backend offline).
// Hosted checkout for a product; resolves {url} or throws with the server's message.
export async function startCheckout(product){
 let r;
 try{r=await fetch(`${API}/api/checkout`,{method:'POST',headers,body:JSON.stringify({product}),signal:AbortSignal.timeout(15000)})}
 catch{throw new Error('The studio service is not reachable right now. Try again in a moment.')}
 let body=null;try{body=await r.json()}catch{}
 if(!r.ok||!body?.url)throw new Error(body?.detail||'Checkout could not be opened. Please try again.');
 return body;
}
export async function storeInfo(){return await remote('/api/store')}

export async function redeemCode(code){
 let r;
 try{r=await fetch(`${API}/api/promo/redeem`,{method:'POST',headers,body:JSON.stringify({code:String(code??'').trim()}),signal:AbortSignal.timeout(8000)})}
 catch{throw new Error('The studio service is not reachable right now. Try again in a moment.')}
 let body=null;try{body=await r.json()}catch{}
 if(!r.ok)throw new Error(body?.detail||(r.status===429?'Too many attempts. Try again in fifteen minutes.':'That code could not be redeemed.'));
 if(body?.license)writeLicense(body.license);
 const state=withLicense(describe(body?.started??readLocal()?.started??null),body?.license,body?.downloads);
 state.downloadTokens=body?.downloadTokens??null;
 return state;
}

// Mint a fresh fifteen-minute download link for a licensed visitor.
export async function downloadLink(file='windows'){
 const body=await remote('/api/download/token',{method:'POST',body:JSON.stringify({file})});
 if(!body?.token)throw new Error('This download needs a tester code. Enter yours above.');
 return {...body,url:`${API}/api/download/${encodeURIComponent(file)}?t=${encodeURIComponent(body.token)}`};
}
export function downloadUrlFromToken(token,file='windows'){return `${API}/api/download/${encodeURIComponent(file)}?t=${encodeURIComponent(token)}`}
export async function downloadManifest(){return await remote('/api/download/manifest')}
export function formatSize(bytes){return bytes>=1e6?`${(bytes/1e6).toFixed(bytes>=1e7?0:1)} MB`:`${Math.round(bytes/1e3)} KB`}

export function trialLabel(state){
 if(state.status==='licensed')return state.license?.until?`Tester access · free until ${state.license.until}`:'Licensed';
 if(state.status==='none')return `${TRIAL_DAYS}-day trial available`;
 if(state.status==='expired')return 'Trial ended';
 if(state.daysLeft<=1)return `Trial · ${state.hoursLeft} hour${state.hoursLeft===1?'':'s'} left`;
 return `Trial · ${state.daysLeft} day${state.daysLeft===1?'':'s'} left`;
}

export function formatPrice(p){return `$${p.amount} ${p.currency}`}
