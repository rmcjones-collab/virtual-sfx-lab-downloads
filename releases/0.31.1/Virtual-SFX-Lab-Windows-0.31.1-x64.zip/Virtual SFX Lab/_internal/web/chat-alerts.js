// Only per-browser preferences and read cursors are retained locally. No message text.
export function createChatAlerts({host,visible,onUnread,onOpen}){
 const key='wave-chat-alerts-v1';let opts={enabled:false,sound:false,volume:50},read={},observed={},identity=null,context=null,lastDing=0;
 try{opts={...opts,...JSON.parse(localStorage.getItem(key)||'{}')}}catch{}
 opts.volume=Math.max(0,Math.min(100,Number(opts.volume)||0));
 const box=document.createElement('details');box.className='chat-alert-settings';
 box.innerHTML='<summary>Notifications & Sounds</summary><label><input type="checkbox" data-alert-enable> Enable Notifications</label><label><input type="checkbox" data-alert-sound> Play A Ding For New Messages</label><label>Volume <input type="range" min="0" max="100" step="1" data-alert-volume aria-label="Notification Volume"><output></output></label><div class="support-row"><button type="button" data-alert-test>Test Sound</button><button type="button" data-alert-desktop>Enable Browser Notifications</button></div><p class="support-note">Unread badges are always shown. Sound needs a browser interaction. Alerts work while Wave Studio is open; background tabs may be delayed. Browser notifications show no message text.</p><p data-alert-status role="status"></p>';
 host.prepend(box);
 const $=s=>box.querySelector(s),persist=()=>{try{localStorage.setItem(key,JSON.stringify(opts))}catch{}};
 $('[data-alert-enable]').checked=opts.enabled;$('[data-alert-sound]').checked=opts.sound;$('[data-alert-volume]').value=opts.volume;
 const volume=()=>$('output').textContent=`${opts.volume}%`;volume();
 function unlock(){const Audio=window.AudioContext||window.webkitAudioContext;if(!Audio)return null;context??=new Audio();context.resume().catch(()=>{});return context}
 document.addEventListener('pointerdown',()=>{if(opts.enabled&&opts.sound)unlock()},{capture:true});
 function ding(){
  const audio=unlock();if(!audio||audio.state!=='running'||!opts.volume)return;
  const t=audio.currentTime,osc=audio.createOscillator(),gain=audio.createGain();
  osc.type='sine';osc.frequency.setValueAtTime(880,t);osc.frequency.exponentialRampToValueAtTime(660,t+.18);
  gain.gain.setValueAtTime(.0001,t);gain.gain.exponentialRampToValueAtTime(opts.volume/100*.16,t+.015);gain.gain.exponentialRampToValueAtTime(.0001,t+.5);
  osc.connect(gain);gain.connect(audio.destination);osc.start(t);osc.stop(t+.52);osc.onended=()=>{osc.disconnect();gain.disconnect()};
 }
 $('[data-alert-enable]').onchange=e=>{opts.enabled=e.target.checked;persist();if(opts.enabled&&opts.sound)unlock()};
 $('[data-alert-sound]').onchange=e=>{opts.sound=e.target.checked;persist();if(opts.sound)unlock()};
 $('[data-alert-volume]').oninput=e=>{opts.volume=+e.target.value;volume();persist()};
 $('[data-alert-test]').onclick=()=>{unlock();setTimeout(ding,40);$('[data-alert-status]').textContent=opts.volume?'Playing test ding.':'Volume is muted.'};
 $('[data-alert-desktop]').onclick=async()=>{
  if(!('Notification' in window)){$('[data-alert-status]').textContent='Browser notifications are unavailable here. In-app badges and sound still work.';return}
  try{const p=await Notification.requestPermission();$('[data-alert-status]').textContent=p==='granted'?'Browser notifications allowed. Enable Notifications to use them.':'Browser notifications not allowed. In-app badges still work.'}catch{$('[data-alert-status]').textContent='Open Wave Studio in a standalone browser to request notification permission.'}
 };
 const saveRead=()=>{if(identity)try{localStorage.setItem(key+':'+identity,JSON.stringify(read))}catch{}};
 function sync(rows){
  const unread=rows.filter(r=>(r.lastOther||0)>(read[r.id]||0));onUnread(unread);
 }
 let latest=[];
 return {
  identify(code){
   if(identity===code)return;identity=code;observed={};read={};
   try{const saved=JSON.parse(localStorage.getItem(key+':'+identity)||'{}');if(saved&&typeof saved==='object'&&!Array.isArray(saved))read=Object.fromEntries(Object.entries(saved).filter(([k,v])=>typeof k==='string'&&Number.isSafeInteger(v)&&v>=0))}catch{}
  },
  update(rows){
   latest=rows;
   for(const r of rows){
    const last=Number(r.lastOther)||0,prior=observed[r.id];observed[r.id]=last;
    if(visible(r.id)){read[r.id]=last;continue}
    if(prior!==undefined&&last>prior&&opts.enabled){
     if(opts.sound&&Date.now()-lastDing>700){lastDing=Date.now();ding()}
     if('Notification' in window&&Notification.permission==='granted')try{
      const n=new Notification('Wave Studio: New Message',{body:'A private conversation has a new message.',tag:'wave-chat-'+r.id});
      n.onclick=()=>{window.focus();onOpen(r.id);n.close()};
     }catch{}
    }
   }
   saveRead();sync(rows);
  },
  markVisible(){for(const r of latest)if(visible(r.id))read[r.id]=r.lastOther||0;saveRead();sync(latest)},
  unread(id){return (latest.find(r=>r.id===id)?.lastOther||0)>(read[id]||0)}
 };
}
