import {draggableWindow,raiseWindow} from './support-windows.js?v=v031c-20261004d';
import {bindMobilePanelDrag} from './mobile-panel-drag.js?v=v031c-20261004d';

// Shared phone/desktop presentation. Restore original nodes before workspace
// rendering; never migrate or overwrite saved workspace/fixture documents here.
export function mountMobileStagePanels({workspace}){
 const media=matchMedia('(max-width:700px)'),stage=document.querySelector('.stage-live');
 const header=document.createElement('div');header.className='mobile-layout-heading';
 header.innerHTML='<strong>Layout View</strong><label>Height <input type="range" min="260" max="700" step="20" aria-label="Layout panel height"><output></output></label>';
 const panel=document.createElement('section');panel.className='mobile-stage-control-panel';panel.setAttribute('aria-label','Layout Controls');
 panel.innerHTML='<div class="mobile-control-heading"><strong>Layout Controls</strong><button type="button" data-dock>Float Controls</button><button type="button" data-controls-min aria-label="Minimize Layout Controls" title="Minimize Layout Controls" aria-expanded="true">−</button></div><div class="layout-mini-transport" role="group" aria-label="Compact Layout Playback"><span>Controls</span><button type="button" data-play-proxy="prev" aria-label="Previous cue">‹</button><button type="button" data-play-proxy="play">Play</button><button type="button" data-play-proxy="next" aria-label="Next cue">›</button><button type="button" data-controls-expand aria-label="Expand Layout Controls" title="Expand Layout Controls" aria-expanded="false">+</button></div><label class="mobile-control-size">Height <input type="range" min="220" max="700" step="20" aria-label="Controls panel height"><output></output></label><div class="mobile-control-body"></div>';
 const body=panel.querySelector('.mobile-control-body'),grip=panel.querySelector('.mobile-control-heading'),dock=panel.querySelector('[data-dock]');
 const screenState={mobile:{view:420,controls:420,floating:false,minimized:false},desktop:{view:440,controls:340,floating:false,minimized:false}};
 let homes=[],active=false,prefs=screenState[media.matches?'mobile':'desktop'];
 try{const saved=JSON.parse(localStorage.getItem('wave-mobile-stage-size'));for(const key of ['view','controls'])if(Number.isFinite(saved?.[key]))screenState.mobile[key]=Math.max(key==='view'?260:220,Math.min(700,saved[key]))}catch{}
 const undo=document.createElement('button');undo.type='button';undo.id='layout-quick-undo';undo.textContent='Undo';undo.setAttribute('aria-label','Undo layout change');undo.title='Undo Layout Change';
 document.querySelector('#select-multiple').after(undo);
 const selectionActions=document.createElement('span');selectionActions.className='layout-selection-actions';
 const multiple=document.querySelector('#select-multiple');multiple.before(selectionActions);selectionActions.append(multiple,undo);
 function proxyClick(id){const original=document.getElementById(id);if(original&&!original.disabled&&!original.closest('[inert]'))original.click();syncCompact()}
 undo.onclick=()=>proxyClick('undo-layout');
 for(const button of panel.querySelectorAll('[data-play-proxy]'))button.onclick=()=>proxyClick(button.dataset.playProxy);
 function syncCompact(){
  undo.disabled=document.querySelector('#undo-layout').disabled;
  for(const button of panel.querySelectorAll('[data-play-proxy]')){
   const original=document.getElementById(button.dataset.playProxy);
   button.disabled=original.disabled||!!original.closest('[inert]');
   if(button.dataset.playProxy==='play'){if(button.textContent!==original.textContent)button.textContent=original.textContent;button.setAttribute('aria-label',original.getAttribute('aria-label')||original.textContent)}
  }
 }
 const proxyObserver=new MutationObserver(syncCompact);
 for(const id of ['play','prev','next','undo-layout'])proxyObserver.observe(document.getElementById(id),{attributes:true,childList:true,subtree:true,characterData:true});
 proxyObserver.observe(document.querySelector('.transport'),{attributes:true,attributeFilter:['inert']});
 syncCompact();
 function size(){
  stage.style.setProperty('--mobile-view-height',prefs.view+'px');
  panel.style.setProperty('--mobile-controls-height',prefs.controls+'px');
  for(const [node,key]of [[header,'view'],[panel,'controls']]){node.querySelector('input').value=prefs[key];node.querySelector('output').textContent=prefs[key]+'px'}
  if(prefs.floating&&!prefs.minimized)panel.style.height=Math.min(prefs.controls+(media.matches?104:0),innerHeight-100)+'px';
  if(prefs.minimized)panel.style.removeProperty('height');
 }
 for(const [node,key]of [[header,'view'],[panel,'controls']])node.querySelector('input').oninput=e=>{
  const value=Number(e.target.value);if(!Number.isFinite(value)||value<Number(e.target.min)||value>Number(e.target.max))return;
  prefs[key]=value;size();
 };
 function move(node){if(!node)return;const home=document.createComment('mobile-controls-home');node.before(home);homes.push([node,home]);body.append(node)}
 function restore(){
  for(const [node,home]of homes){home.replaceWith(node)}homes=[];
  header.remove();panel.remove();stage.classList.remove('mobile-layout-view');stage.closest('.workspace-card')?.classList.remove('mobile-layout-card');
  active=false;
 }
 function place(){
  panel.classList.toggle('is-floating',prefs.floating);dock.textContent=prefs.floating?'Dock To Layout':'Float Controls';
  panel.style.removeProperty('height');panel.style.removeProperty('width');panel.style.removeProperty('left');panel.style.removeProperty('top');panel.style.removeProperty('right');panel.style.removeProperty('bottom');panel.style.removeProperty('position');
  if(prefs.floating){document.body.append(panel);raiseWindow(panel);if(prefs.position)Object.assign(panel.style,{left:prefs.position.x+'px',right:'auto',top:prefs.position.y+'px',width:prefs.position.width+'px'})}
  else{panel.style.removeProperty('z-index');const card=stage.closest('.workspace-card'),anchor=prefs.anchor?.isConnected&&!prefs.anchor.closest('#workspace-park')?prefs.anchor:card??stage;anchor[prefs.anchor&&prefs.before?'before':'after'](panel);panel.style.order=getComputedStyle(anchor).order}
  minimize(prefs.minimized);
 }
 function minimize(value){
  prefs.minimized=!!value;panel.classList.toggle('controls-minimized',prefs.minimized);
  panel.querySelector('[data-controls-min]').setAttribute('aria-expanded',String(!prefs.minimized));
  panel.querySelector('[data-controls-expand]').setAttribute('aria-expanded',String(!prefs.minimized));
  syncCompact();size();
 }
 function mount(){
  restore();prefs=screenState[media.matches?'mobile':'desktop'];
  const height=panel.querySelector('.mobile-control-size input');height.type=media.matches?'range':'number';height.step=media.matches?'20':'10';
  panel.querySelector('.mobile-control-size output').hidden=!media.matches;
  const custom=document.body.classList.contains('custom-workspace-mode');
  if(media.matches&&!custom&&document.body.dataset.mobilePanel!=='stage')return;
  if(custom&&!stage.closest('#custom-workspace .workspace-card'))return;
  stage.classList.add('mobile-layout-view');stage.prepend(header);
  for(const selector of ['.mobile-under-layout','.playback-bar','.compact-timeline','.layout-tools'])move(stage.querySelector(selector));
  if(media.matches&&!custom)for(const selector of ['.stage-tools','.selection-tools','.fixture-strip'])move(document.querySelector(selector));
  stage.closest('.workspace-card')?.classList.add('mobile-layout-card');active=true;place();
 }
 dock.onclick=()=>{prefs.floating=!prefs.floating;prefs.anchor=null;prefs.position=null;place()};
 panel.querySelector('[data-controls-min]').onclick=()=>{minimize(true);panel.querySelector('[data-controls-expand]').focus({preventScroll:true})};
 panel.querySelector('[data-controls-expand]').onclick=()=>{minimize(false);panel.querySelector('[data-controls-min]').focus({preventScroll:true})};
 draggableWindow(panel,grip,{allowed:()=>active&&prefs.floating});
 draggableWindow(panel,panel.querySelector('.layout-mini-transport'),{allowed:()=>active&&prefs.floating});
 const layoutPanel=()=>stage.closest('.workspace-card')??stage;
 bindMobilePanelDrag(header,{panel:layoutPanel,title:()=> 'Layout',canDock:target=>target.matches('.workspace-card'),drop:p=>workspace.placePanel(layoutPanel().dataset.panel??'stage',p)});
 for(const handle of [grip,panel.querySelector('.layout-mini-transport')])bindMobilePanelDrag(handle,{panel:()=>panel,title:()=> 'Layout Controls',canDock:target=>target.matches('.workspace-card,.stage-live'),drop:p=>{
  prefs.floating=!p.target;prefs.position=p.float;prefs.anchor=p.target;prefs.before=!p.after;place();
 }});
 document.addEventListener('wave-workspace-before-layout',restore);
 document.addEventListener('wave-workspace-layout',mount);
 document.addEventListener('wave-workspace-collapse-all',e=>minimize(e.detail.minimized));
 media.addEventListener('change',mount);
 // Keep floating controls on the Stage tab only, unless in a custom workspace.
 new MutationObserver(mount).observe(document.body,{attributes:true,attributeFilter:['data-mobile-panel']});
 mount();
}
