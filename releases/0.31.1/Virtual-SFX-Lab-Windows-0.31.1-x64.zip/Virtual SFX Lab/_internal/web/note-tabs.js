// Pointer reordering works with mouse, pen and touch. Alt+arrows is the keyboard alternative.
export function bindNoteTabs(host,{reorder}){
 const doc=host.ownerDocument,win=doc.defaultView;let drag=null,suppress=false;const off=[];
 const on=(type,fn,options)=>{host.addEventListener(type,fn,options);off.push(()=>host.removeEventListener(type,fn,options))};
 on('pointerdown',e=>{
  const tab=e.target.closest('[role=tab]');if(!tab||e.button!==0)return;
  drag={tab,id:tab.dataset.note,pointer:e.pointerId,x:e.clientX,y:e.clientY,started:false,target:null};
 });
 on('pointermove',e=>{
  if(!drag||drag.pointer!==e.pointerId)return;
  if(!drag.started&&Math.hypot(e.clientX-drag.x,e.clientY-drag.y)<7)return;
  if(!drag.started){drag.started=true;suppress=true;drag.tab.setPointerCapture(e.pointerId);drag.tab.classList.add('note-tab-moving')}
  e.preventDefault();e.stopPropagation();
  drag.tab.style.transform=`translate(${e.clientX-drag.x}px,${e.clientY-drag.y}px)`;
  const tabs=[...host.querySelectorAll('[role=tab]')].filter(t=>t!==drag.tab);
  let target=tabs.find(t=>{const r=t.getBoundingClientRect();return e.clientX>=r.left&&e.clientX<=r.right});
  tabs.forEach(t=>t.classList.toggle('note-tab-target',t===target));drag.target=target;
  if(target)drag.after=e.clientX>target.getBoundingClientRect().left+target.getBoundingClientRect().width/2;
  const r=host.getBoundingClientRect();if(e.clientX<r.left+20)host.scrollLeft-=8;else if(e.clientX>r.right-20)host.scrollLeft+=8;
 },{passive:false});
 function finish(e,cancel=false){
  if(!drag||e.pointerId!==drag.pointer)return;const d=drag;drag=null;
  d.tab.style.transform='';d.tab.classList.remove('note-tab-moving');host.querySelectorAll('.note-tab-target').forEach(t=>t.classList.remove('note-tab-target'));
  if(d.tab.hasPointerCapture(d.pointer))d.tab.releasePointerCapture(d.pointer);
  if(d.started&&!cancel&&d.target)reorder(d.id,d.target.dataset.note,d.after);
  if(d.started)win.setTimeout(()=>suppress=false,0);
 }
 on('pointerup',e=>finish(e));
 on('pointercancel',e=>finish(e,true));
 on('lostpointercapture',e=>finish(e,true));
 on('click',e=>{if(suppress){e.preventDefault();e.stopImmediatePropagation()}},true);
 on('keydown',e=>{
  if(!e.altKey||!['ArrowLeft','ArrowRight'].includes(e.key))return;
  const tab=e.target.closest('[role=tab]');if(!tab)return;
  const tabs=[...host.querySelectorAll('[role=tab]')],index=tabs.indexOf(tab),other=tabs[index+(e.key==='ArrowLeft'?-1:1)];
  if(other){e.preventDefault();e.stopPropagation();reorder(tab.dataset.note,other.dataset.note,e.key==='ArrowRight');tab.focus({preventScroll:true})}
 },true);
 return {destroy(){if(drag)finish({pointerId:drag.pointer},true);off.forEach(fn=>fn())}};
}
