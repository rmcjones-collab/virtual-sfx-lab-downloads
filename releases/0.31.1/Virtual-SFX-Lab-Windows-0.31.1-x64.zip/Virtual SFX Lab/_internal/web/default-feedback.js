const notices=new WeakMap();
export function showDefaultFeedback(text,anchor){
 const doc=anchor.ownerDocument,win=doc.defaultView;let state=notices.get(doc);
 if(!state){const el=doc.createElement('output');el.className='default-layout-confirmation';el.setAttribute('role','status');el.setAttribute('aria-live','polite');el.hidden=true;doc.body.append(el);state={el,timer:null};notices.set(doc,state)}
 win.clearTimeout(state.timer);state.el.textContent=text;state.el.hidden=false;
 const r=anchor.getBoundingClientRect(),box=state.el.getBoundingClientRect();
 state.el.style.left=`${Math.max(8,Math.min(win.innerWidth-box.width-8,r.left+r.width/2-box.width/2))}px`;
 state.el.style.top=`${Math.max(8,Math.min(win.innerHeight-box.height-8,r.top+r.height/2-box.height/2))}px`;
 state.timer=win.setTimeout(()=>{state.el.hidden=true;state.el.textContent=''},2800);
 return state.el;
}
