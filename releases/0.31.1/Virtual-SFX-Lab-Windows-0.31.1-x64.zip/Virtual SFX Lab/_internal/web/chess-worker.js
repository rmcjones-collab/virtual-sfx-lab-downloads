import {chooseMove} from './chess-ai.js';
self.onmessage=e=>{
 try{self.postMessage({...chooseMove(e.data.fen),id:e.data.id})}
 catch{self.postMessage({id:e.data.id,error:'Computer Could Not Choose A Move.'})}
};
