const fields=[['email','Email',120,'email'],['phone','Phone / Mobile',80,'tel'],['company','Company',120,'text'],['role','Role / Job Title',120,'text'],['location','Location',120,'text'],['website','Website',240,'url'],['social','Social Handle / Other Contact',240,'text']];
function contactForm(values={}){
 const form=document.createElement('div');form.className='chat-contact-fields';
 const note=document.createElement('p');note.className='support-note';note.textContent='Only your display name is required. Contact details are optional, stored with this visitor profile, and private unless you enable sharing below. Do not enter passwords or sensitive information.';form.append(note);
 for(const [key,title,max,type]of fields){const label=document.createElement('label'),input=document.createElement('input');label.textContent=title+' (Optional)';input.dataset.contact=key;input.type=type;input.maxLength=max;input.value=values.contacts?.[key]??'';label.append(input);form.append(label)}
 const label=document.createElement('label'),share=document.createElement('input');share.type='checkbox';share.dataset.shareContacts='';share.checked=values.shareContacts===true;label.append(share,' Share these contact details with accepted friends');form.append(label);
 return {el:form,read:()=>{
  for(const input of form.querySelectorAll('input[data-contact]'))if(!input.reportValidity())throw Error('Please check the optional '+input.dataset.contact+' field, or leave it empty.');
  return {contacts:Object.fromEntries([...form.querySelectorAll('[data-contact]')].map(i=>[i.dataset.contact,i.value.trim()])),shareContacts:share.checked};
 }};
}
export function showFriendContacts(friend){
 const dialog=document.createElement('dialog');dialog.className='chat-export-dialog';
 const h=document.createElement('h2');h.textContent=friend.name+' · Contact Info';dialog.append(h);
 for(const [key,title]of fields)if(friend.contacts?.[key]){const p=document.createElement('p');p.textContent=title+': '+friend.contacts[key];dialog.append(p)}
 const note=document.createElement('p');note.textContent='Shared by this friend. These details are not verified and may not be current.';dialog.append(note);
 const close=document.createElement('button');close.textContent='Close';close.onclick=()=>dialog.close();dialog.append(close);dialog.addEventListener('close',()=>dialog.remove(),{once:true});document.body.append(dialog);dialog.showModal();
}
export function mountContactProfile({host,get,save,status}){
 const $=s=>host.querySelector(s),optional=document.createElement('details'),summary=document.createElement('summary');
 summary.textContent='Optional Contact Info';optional.append(summary);const registration=contactForm();optional.append(registration.el);$('#chat-register-button').before(optional);
 const copy=document.createElement('button');copy.type='button';copy.id='chat-copy-code';copy.textContent='Copy';copy.setAttribute('aria-label','Copy Your Friend Code');$('#chat-code').after(copy);
 copy.onclick=async()=>{
  const code=$('#chat-code').textContent;if(!code)return;
  try{await navigator.clipboard.writeText(code);status('Friend code copied.')}
  catch{const selection=getSelection(),range=document.createRange();range.selectNodeContents($('#chat-code'));selection.removeAllRanges();selection.addRange(range);status('Clipboard unavailable. Your friend code is selected; use Copy in your browser.')}
 };
 const edit=document.createElement('button');edit.type='button';edit.textContent='Edit My Profile / Contact Info';$('#chat-code').parentElement.after(edit);
 edit.onclick=()=>{
  const me=get();if(!me)return;const dialog=document.createElement('dialog');dialog.className='chat-export-dialog chat-profile-dialog';
  dialog.innerHTML='<h2>My Profile</h2><label>Display Name (Required)<input data-name maxlength="40" required></label><div class="support-row"><button data-save>Save Profile</button><button data-close>Cancel</button></div><p data-status role="status"></p>';
  dialog.querySelector('[data-name]').value=me.name;const form=contactForm(me);dialog.querySelector('.support-row').before(form.el);
  dialog.querySelector('[data-close]').onclick=()=>dialog.close();
  dialog.querySelector('[data-save]').onclick=async e=>{
   const input=dialog.querySelector('[data-name]');if(!input.reportValidity())return;
   e.currentTarget.disabled=true;
   try{await save({name:input.value,...form.read()});dialog.close();status('Profile saved. Contact sharing preference updated.')}
   catch(error){dialog.querySelector('[data-status]').textContent=error.message}
   finally{dialog.querySelector('[data-save]').disabled=false}
  };
  dialog.addEventListener('close',()=>dialog.remove(),{once:true});document.body.append(dialog);dialog.showModal();
 };
 return {registration:registration.read};
}
