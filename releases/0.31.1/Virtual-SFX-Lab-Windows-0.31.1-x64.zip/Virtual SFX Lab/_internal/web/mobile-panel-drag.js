// Touch-only long-press movement. No panel is reparented until the drop commits,
// so canvases, text inputs and saved workspace state survive cancellation.
const media=matchMedia('(max-width:700px)'),bindings=new WeakMap();
const candidates='.workspace-card,.mobile-stage-control-panel,.stage-live,.support-panel,.conversation-window';
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
let current=null,suppressed=null,until=0;
export function mobileDockTargets(panel){
 return [...document.querySelectorAll(candidates)].filter(e=>e!==panel&&!panel.contains(e)&&!e.contains(panel)&&e.getClientRects().length&&getComputedStyle(e).display!=='none'&&(!e.matches('.stage-live')||!e.closest('.workspace-card')));
}
function titleOf(el){return el.getAttribute('aria-label')||el.querySelector('.workspace-grip,.mobile-layout-heading strong,.mobile-control-heading strong,.support-header strong,.conversation-header strong')?.textContent||'Panel'}
function clean(){
 if(!current)return;clearTimeout(current.timer);cancelAnimationFrame(current.frame);
 current.handle.classList.remove('mobile-panel-pressing');current.panel?.classList.remove('mobile-panel-origin');
 current.ghost?.remove();current.zone?.remove();
 document.querySelectorAll('.mobile-dock-before,.mobile-dock-after').forEach(e=>e.classList.remove('mobile-dock-before','mobile-dock-after'));
 document.body.classList.remove('mobile-panel-drag-active');
 const old=current;current=null;return old;
}
function suppress(handle){suppressed=handle;until=performance.now()+900}
function floatAt(g){
 const width=Math.min(g.rect.width,innerWidth-16);
 return {x:clamp(g.x-g.offsetX,0,innerWidth-width),y:clamp(g.y-g.offsetY,8,Math.max(8,innerHeight-Math.min(g.rect.height,innerHeight-100)-12)),width};
}
function targetAt(g){
 const allowed=mobileDockTargets(g.panel).filter(e=>!g.binding.canDock||g.binding.canDock(e));
 return document.elementsFromPoint(g.x,g.y).map(e=>e.closest?.(candidates)).find(e=>allowed.includes(e))??null;
}
function draw(){
 const g=current;if(!g?.active)return;
 const p=floatAt(g);g.ghost.style.left=p.x+'px';g.ghost.style.top=clamp(g.y-25,8,innerHeight-130)+'px';
 document.querySelectorAll('.mobile-dock-before,.mobile-dock-after').forEach(e=>e.classList.remove('mobile-dock-before','mobile-dock-after'));
 g.target=g.y>innerHeight-80?null:targetAt(g);
 g.after=g.target?g.y>g.target.getBoundingClientRect().top+g.target.getBoundingClientRect().height/2:false;
 if(g.target)g.target.classList.add(g.after?'mobile-dock-after':'mobile-dock-before');
 g.ghost.querySelector('small').textContent=g.target?`Release to dock ${g.after?'below':'above'} ${titleOf(g.target)}`:'Release to float';
 g.zone.classList.toggle('is-selected',!g.target);
}
function placementMenu(g){
 const dialog=document.createElement('dialog');dialog.className='mobile-panel-placement';
 const heading=document.createElement('h2');heading.textContent='Move '+g.binding.title();
 const hint=document.createElement('p');hint.textContent='Hold and drag the header to position it directly, or choose a placement here.';
 const select=document.createElement('select');select.setAttribute('aria-label','Dock next to panel');
 const targets=mobileDockTargets(g.panel).filter(e=>!g.binding.canDock||g.binding.canDock(e));
 targets.forEach((e,i)=>select.add(new Option(titleOf(e),String(i))));
 const row=document.createElement('div');row.className='support-row';
 for(const [text,action]of [['Float Panel','float'],['Dock Above','before'],['Dock Below','after'],['Cancel','cancel']]){
  const b=document.createElement('button');b.textContent=text;b.type='button';b.disabled=['before','after'].includes(action)&&!targets.length;
  b.onclick=()=>{dialog.close();if(action!=='cancel')g.binding.drop({target:action==='float'?null:targets[Number(select.value)],after:action==='after',float:floatAt(g)})};row.append(b);
 }
 dialog.append(heading,hint,select,row);document.body.append(dialog);dialog.addEventListener('close',()=>dialog.remove(),{once:true});dialog.showModal();
}
function activate(){
 const g=current;if(!g||!g.handle.isConnected)return clean();
 g.active=true;g.panel=g.binding.panel();g.rect=g.panel.getBoundingClientRect();g.offsetX=clamp(g.x-g.rect.left,0,g.rect.width);g.offsetY=clamp(g.y-g.rect.top,0,50);
 g.panel.classList.add('mobile-panel-origin');g.handle.classList.remove('mobile-panel-pressing');
 g.ghost=document.createElement('div');g.ghost.className='mobile-panel-drag-ui mobile-panel-ghost';g.ghost.style.width=Math.min(g.rect.width,innerWidth-16)+'px';
 const title=document.createElement('strong'),hint=document.createElement('small');title.textContent=g.binding.title();hint.setAttribute('role','status');g.ghost.append(title,hint);
 g.zone=document.createElement('div');g.zone.className='mobile-panel-drag-ui mobile-panel-float-zone';g.zone.textContent='Drop here to float';document.body.append(g.ghost,g.zone);document.body.classList.add('mobile-panel-drag-active');draw();
 const tick=()=>{if(current!==g)return;const scroller=document.body.classList.contains('workspace-focus-mode')?document.querySelector('#workspace-focus'):window;if(g.moved&&g.y<95)scroller.scrollBy(0,-8);else if(g.moved&&g.y>innerHeight-160&&g.y<innerHeight-80)scroller.scrollBy(0,8);draw();g.frame=requestAnimationFrame(tick)};g.frame=requestAnimationFrame(tick);
}
document.addEventListener('touchstart',e=>{
 if(!media.matches||e.touches.length!==1){clean();return}
 const handle=e.target.closest?.('[data-mobile-drag-handle]'),binding=bindings.get(handle);if(!binding||binding.enabled?.()===false)return;
 const interactive=e.target.closest('input,textarea,select,a,label,.minimized-summary,button');
 if(interactive&&!interactive.classList.contains('workspace-grip'))return;
 clean();const t=e.touches[0];current={handle,binding,id:t.identifier,x:t.clientX,y:t.clientY,startX:t.clientX,startY:t.clientY,active:false,moved:false};
 handle.classList.add('mobile-panel-pressing');current.timer=setTimeout(activate,450);
},{passive:true,capture:true});
document.addEventListener('touchmove',e=>{
 const g=current;if(!g)return;if(e.touches.length!==1){clean();return}const t=[...e.touches].find(t=>t.identifier===g.id);if(!t)return;
 g.x=t.clientX;g.y=t.clientY;const distance=Math.hypot(g.x-g.startX,g.y-g.startY);
 if(!g.active){if(distance>9){suppress(g.handle);clean()}return}
 e.preventDefault();if(distance>6)g.moved=true;draw();
},{passive:false,capture:true});
document.addEventListener('touchend',e=>{
 const g=current;if(!g||![...e.changedTouches].some(t=>t.identifier===g.id))return;
 if(!g.active){clean();return}e.preventDefault();suppress(g.handle);const placement={target:g.target,after:g.after,float:floatAt(g)};clean();
 if(g.moved)g.binding.drop(placement);else placementMenu(g);
},{passive:false,capture:true});
document.addEventListener('touchcancel',()=>{if(current?.active)suppress(current.handle);clean()},{passive:true});
document.addEventListener('click',e=>{if(performance.now()<until&&suppressed?.contains(e.target)){e.preventDefault();e.stopImmediatePropagation()}},true);
// Block only the click synthesized by the completed hold, not a fresh tap on
// Minimize/Play/Rename immediately afterward.
document.addEventListener('pointerdown',()=>{suppressed=null;until=0},true);
document.addEventListener('contextmenu',e=>{if(media.matches&&e.target.closest?.('[data-mobile-drag-handle]')&&!e.target.closest('input,textarea,select'))e.preventDefault()});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&current){suppress(current.handle);clean()}});
window.addEventListener('blur',clean);media.addEventListener('change',clean);
document.addEventListener('visibilitychange',()=>{if(document.hidden)clean()});
document.addEventListener('wave-workspace-before-layout',clean);
export function bindMobilePanelDrag(handle,binding){
 handle.dataset.mobileDragHandle='';bindings.set(handle,binding);
 handle.title=(handle.title?handle.title+' · ':'')+'On phone: hold to move, then drop to dock or float';
}

// Support/Chat windows have their own lifecycle, not workspace-model entries.
export function bindMobileUtilityDrag(panel,handles,{title,onPlacement=()=>{}}){
 let placement=null;
 function reset(){placement=null;panel.classList.remove('mobile-utility-docked','mobile-utility-floating');panel.style.cssText=''}
 function place(){
  if(!placement)return;
  const {target,after,float}=placement,docked=target?.isConnected&&!target.closest('#workspace-park');
  panel.classList.toggle('mobile-utility-docked',!!docked);panel.classList.toggle('mobile-utility-floating',!docked);
  panel.style.cssText='';
  if(docked){target[after?'after':'before'](panel);panel.style.order=getComputedStyle(target).order}
  else{document.body.append(panel);Object.assign(panel.style,{left:float.x+'px',top:float.y+'px',width:float.width+'px',height:Math.min(560,innerHeight-float.y-16)+'px'})}
  onPlacement(docked?target:null);
 }
 for(const handle of handles)bindMobilePanelDrag(handle,{panel:()=>panel,title,canDock:e=>e.matches('.workspace-card,.stage-live,.mobile-stage-control-panel'),drop:p=>{placement=p;place()}});
 document.addEventListener('wave-workspace-before-layout',()=>{if(placement)document.body.append(panel)});
 document.addEventListener('wave-workspace-layout',()=>requestAnimationFrame(place));
 return {reset};
}
