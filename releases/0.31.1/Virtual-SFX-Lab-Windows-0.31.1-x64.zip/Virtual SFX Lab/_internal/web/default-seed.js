// Sanitized public stage/workspace defaults extracted from the approved saved layout.
// No notes, session history, depleted fuel, chat or user identifiers are included.
export const DEFAULT_SEED={
  "fixtures": [
    {
      "id": 1,
      "x": -0.5338283784,
      "y": 0.75,
      "presetId": 64,
      "inverted": true,
      "flameScale": 200,
      "minAngle": -105,
      "maxAngle": 105,
      "patch": {
        "universe": 0,
        "address": 1
      }
    },
    {
      "id": 2,
      "x": -0.120297027,
      "y": 0.75,
      "presetId": 64,
      "inverted": false,
      "flameScale": 200,
      "minAngle": -105,
      "maxAngle": 105,
      "patch": {
        "universe": 0,
        "address": 7
      }
    },
    {
      "id": 3,
      "x": 0.2932343243,
      "y": 0.75,
      "presetId": 64,
      "inverted": true,
      "flameScale": 200,
      "minAngle": -105,
      "maxAngle": 105,
      "patch": {
        "universe": 0,
        "address": 13
      }
    },
    {
      "id": 4,
      "x": 0.7067656757,
      "y": 0.75,
      "presetId": 64,
      "inverted": false,
      "flameScale": 200,
      "minAngle": -105,
      "maxAngle": 105,
      "patch": {
        "universe": 0,
        "address": 19
      }
    },
    {
      "id": 5,
      "x": 1.120297027,
      "y": 0.75,
      "presetId": 64,
      "inverted": true,
      "flameScale": 200,
      "minAngle": -105,
      "maxAngle": 105,
      "patch": {
        "universe": 0,
        "address": 25
      }
    },
    {
      "id": 6,
      "x": 1.5338283784,
      "y": 0.75,
      "presetId": 64,
      "inverted": false,
      "flameScale": 200,
      "minAngle": -105,
      "maxAngle": 105,
      "patch": {
        "universe": 0,
        "address": 31
      }
    }
  ],
  "preferences": {
    "theme": "dark",
    "guides": true,
    "path": true
  },
  "sceneScale": 1,
  "view": {
    "zoom": 1,
    "panX": 0,
    "panY": 0
  },
  "selectedId": 2,
  "selectedIds": [
    1,
    2,
    3,
    4,
    5,
    6
  ],
  "layoutLocked": false,
  "workspace": {
    "version": 2,
    "buttonSize": 100,
    "desktop": {
      "enabled": true,
      "left": 20,
      "right": 30,
      "panels": [
        {
          "key": "tools",
          "type": "tools",
          "zone": "main",
          "span": 12,
          "height": 0,
          "visible": true,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "fuel",
          "type": "fuel",
          "zone": "main",
          "span": 12,
          "height": 150,
          "visible": true,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "clock",
          "type": "clock",
          "zone": "left",
          "span": 12,
          "height": 196,
          "visible": true,
          "minimized": true,
          "float": null,
          "options": {
            "mode": "world",
            "secondaryEnabled": true,
            "secondary": {
              "mode": "stopwatch",
              "zone": "UTC"
            }
          }
        },
        {
          "key": "timecode",
          "type": "timecode",
          "zone": "left",
          "span": 12,
          "height": 279,
          "visible": true,
          "minimized": true,
          "float": null,
          "options": {}
        },
        {
          "key": "library",
          "type": "library",
          "zone": "left",
          "span": 12,
          "height": 818,
          "visible": true,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "scale",
          "type": "scale",
          "zone": "left",
          "span": 12,
          "height": 0,
          "visible": true,
          "minimized": true,
          "float": null,
          "options": {}
        },
        {
          "key": "angle",
          "type": "angle",
          "zone": "left",
          "span": 12,
          "height": 0,
          "visible": true,
          "minimized": true,
          "float": null,
          "options": {}
        },
        {
          "key": "selection",
          "type": "selection",
          "zone": "left",
          "span": 12,
          "height": 0,
          "visible": true,
          "minimized": true,
          "float": null,
          "options": {}
        },
        {
          "key": "units",
          "type": "units",
          "zone": "left",
          "span": 12,
          "height": 0,
          "visible": true,
          "minimized": true,
          "float": null,
          "options": {}
        },
        {
          "key": "nozzle",
          "type": "nozzle",
          "zone": "left",
          "span": 12,
          "height": 0,
          "visible": true,
          "minimized": true,
          "float": null,
          "options": {}
        },
        {
          "key": "patch",
          "type": "patch",
          "zone": "left",
          "span": 12,
          "height": 0,
          "visible": true,
          "minimized": true,
          "float": null,
          "options": {}
        },
        {
          "key": "monitor",
          "type": "monitor",
          "zone": "left",
          "span": 12,
          "height": 0,
          "visible": true,
          "minimized": true,
          "float": null,
          "options": {}
        },
        {
          "key": "sequence",
          "type": "sequence",
          "zone": "right",
          "span": 6,
          "height": 383,
          "visible": true,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "rear",
          "type": "rear",
          "zone": "right",
          "span": 6,
          "height": 385,
          "visible": true,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "faders",
          "type": "faders",
          "zone": "right",
          "span": 12,
          "height": 525,
          "visible": true,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "invert",
          "type": "invert",
          "zone": "right",
          "span": 12,
          "height": 0,
          "visible": true,
          "minimized": true,
          "float": null,
          "options": {}
        },
        {
          "key": "arm",
          "type": "arm",
          "zone": "right",
          "span": 6,
          "height": 172,
          "visible": true,
          "minimized": true,
          "float": null,
          "options": {}
        },
        {
          "key": "direction",
          "type": "direction",
          "zone": "right",
          "span": 6,
          "height": 174,
          "visible": true,
          "minimized": true,
          "float": null,
          "options": {}
        },
        {
          "key": "notes",
          "type": "notes",
          "zone": "right",
          "span": 12,
          "height": 399,
          "visible": true,
          "minimized": true,
          "float": null,
          "options": {}
        },
        {
          "key": "fixture",
          "type": "fixture",
          "zone": "right",
          "span": 12,
          "height": 294,
          "visible": true,
          "minimized": true,
          "float": null,
          "options": {}
        },
        {
          "key": "display",
          "type": "display",
          "zone": "right",
          "span": 12,
          "height": 0,
          "visible": true,
          "minimized": true,
          "float": null,
          "options": {}
        },
        {
          "key": "screen",
          "type": "screen",
          "zone": "right",
          "span": 12,
          "height": 0,
          "visible": true,
          "minimized": true,
          "float": null,
          "options": {}
        },
        {
          "key": "bank",
          "type": "bank",
          "zone": "right",
          "span": 12,
          "height": 0,
          "visible": true,
          "minimized": true,
          "float": null,
          "options": {}
        },
        {
          "key": "stage",
          "type": "stage",
          "zone": "main",
          "span": 12,
          "height": 721,
          "visible": true,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "macros",
          "type": "macros",
          "zone": "main",
          "span": 12,
          "height": 0,
          "visible": true,
          "minimized": true,
          "float": null,
          "options": {}
        },
        {
          "key": "master",
          "type": "master",
          "zone": "main",
          "span": 12,
          "height": 300,
          "visible": true,
          "minimized": true,
          "float": null,
          "options": {}
        },
        {
          "key": "record",
          "type": "record",
          "zone": "main",
          "span": 12,
          "height": 0,
          "visible": true,
          "minimized": true,
          "float": null,
          "options": {}
        },
        {
          "key": "browser",
          "type": "browser",
          "zone": "right",
          "span": 12,
          "height": 270,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        }
      ]
    },
    "mobile": {
      "enabled": false,
      "left": 20,
      "right": 35,
      "panels": [
        {
          "key": "stage",
          "type": "stage",
          "zone": "main",
          "span": 12,
          "height": 460,
          "visible": true,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "faders",
          "type": "faders",
          "zone": "main",
          "span": 12,
          "height": 430,
          "visible": true,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "library",
          "type": "library",
          "zone": "main",
          "span": 12,
          "height": 620,
          "visible": true,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "tools",
          "type": "tools",
          "zone": "main",
          "span": 12,
          "height": 0,
          "visible": true,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "selection",
          "type": "selection",
          "zone": "main",
          "span": 12,
          "height": 0,
          "visible": true,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "units",
          "type": "units",
          "zone": "main",
          "span": 12,
          "height": 0,
          "visible": true,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "fuel",
          "type": "fuel",
          "zone": "main",
          "span": 12,
          "height": 150,
          "visible": true,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "screen",
          "type": "screen",
          "zone": "main",
          "span": 12,
          "height": 0,
          "visible": true,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "fixture",
          "type": "fixture",
          "zone": "main",
          "span": 12,
          "height": 0,
          "visible": true,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "sequence",
          "type": "sequence",
          "zone": "main",
          "span": 12,
          "height": 0,
          "visible": true,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "nozzle",
          "type": "nozzle",
          "zone": "main",
          "span": 12,
          "height": 0,
          "visible": true,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "scale",
          "type": "scale",
          "zone": "main",
          "span": 12,
          "height": 0,
          "visible": true,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "angle",
          "type": "angle",
          "zone": "main",
          "span": 12,
          "height": 0,
          "visible": true,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "patch",
          "type": "patch",
          "zone": "main",
          "span": 12,
          "height": 0,
          "visible": true,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "arm",
          "type": "arm",
          "zone": "main",
          "span": 12,
          "height": 0,
          "visible": true,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "direction",
          "type": "direction",
          "zone": "main",
          "span": 12,
          "height": 0,
          "visible": true,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "rear",
          "type": "rear",
          "zone": "main",
          "span": 12,
          "height": 0,
          "visible": true,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "display",
          "type": "display",
          "zone": "main",
          "span": 12,
          "height": 0,
          "visible": true,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "macros",
          "type": "macros",
          "zone": "main",
          "span": 12,
          "height": 0,
          "visible": true,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "master",
          "type": "master",
          "zone": "main",
          "span": 12,
          "height": 300,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "record",
          "type": "record",
          "zone": "main",
          "span": 12,
          "height": 0,
          "visible": true,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "bank",
          "type": "bank",
          "zone": "main",
          "span": 12,
          "height": 0,
          "visible": true,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "monitor",
          "type": "monitor",
          "zone": "main",
          "span": 12,
          "height": 0,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "notes",
          "type": "notes",
          "zone": "main",
          "span": 12,
          "height": 220,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "clock",
          "type": "clock",
          "zone": "main",
          "span": 12,
          "height": 250,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "timecode",
          "type": "timecode",
          "zone": "main",
          "span": 12,
          "height": 310,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "invert",
          "type": "invert",
          "zone": "right",
          "span": 12,
          "height": 0,
          "visible": true,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "browser",
          "type": "browser",
          "zone": "right",
          "span": 12,
          "height": 270,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        }
      ]
    },
    "fullscreenDesktop": {
      "enabled": true,
      "left": 20,
      "right": 35,
      "panels": [
        {
          "key": "tools",
          "type": "tools",
          "zone": "right",
          "span": 6,
          "height": 315,
          "visible": true,
          "minimized": false,
          "float": {
            "x": 2507,
            "y": 637.03125,
            "width": 275
          },
          "options": {}
        },
        {
          "key": "library",
          "type": "library",
          "zone": "left",
          "span": 12,
          "height": 620,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "selection",
          "type": "selection",
          "zone": "left",
          "span": 12,
          "height": 0,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "units",
          "type": "units",
          "zone": "left",
          "span": 12,
          "height": 0,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "fuel",
          "type": "fuel",
          "zone": "left",
          "span": 12,
          "height": 150,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "screen",
          "type": "screen",
          "zone": "left",
          "span": 12,
          "height": 0,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "fixture",
          "type": "fixture",
          "zone": "left",
          "span": 12,
          "height": 0,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "sequence",
          "type": "sequence",
          "zone": "left",
          "span": 12,
          "height": 0,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "nozzle",
          "type": "nozzle",
          "zone": "left",
          "span": 12,
          "height": 0,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "scale",
          "type": "scale",
          "zone": "left",
          "span": 12,
          "height": 0,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "angle",
          "type": "angle",
          "zone": "left",
          "span": 12,
          "height": 0,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "patch",
          "type": "patch",
          "zone": "left",
          "span": 12,
          "height": 0,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "arm",
          "type": "arm",
          "zone": "left",
          "span": 12,
          "height": 0,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "direction",
          "type": "direction",
          "zone": "left",
          "span": 12,
          "height": 0,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "rear",
          "type": "rear",
          "zone": "left",
          "span": 12,
          "height": 0,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "display",
          "type": "display",
          "zone": "left",
          "span": 12,
          "height": 0,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "macros",
          "type": "macros",
          "zone": "left",
          "span": 12,
          "height": 0,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "master",
          "type": "master",
          "zone": "left",
          "span": 12,
          "height": 300,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "record",
          "type": "record",
          "zone": "left",
          "span": 12,
          "height": 0,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "bank",
          "type": "bank",
          "zone": "left",
          "span": 12,
          "height": 0,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "monitor",
          "type": "monitor",
          "zone": "left",
          "span": 12,
          "height": 0,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "notes",
          "type": "notes",
          "zone": "left",
          "span": 12,
          "height": 220,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "clock",
          "type": "clock",
          "zone": "left",
          "span": 12,
          "height": 250,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {
            "secondary": {}
          }
        },
        {
          "key": "timecode",
          "type": "timecode",
          "zone": "left",
          "span": 12,
          "height": 310,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "faders",
          "type": "faders",
          "zone": "right",
          "span": 6,
          "height": 439,
          "visible": true,
          "minimized": false,
          "float": {
            "x": 2308.0546875,
            "y": 170.44921875,
            "width": 473.9453125
          },
          "options": {}
        },
        {
          "key": "stage",
          "type": "stage",
          "zone": "main",
          "span": 12,
          "height": 990,
          "visible": true,
          "minimized": false,
          "float": {
            "x": 399.7265625,
            "y": 60.44921875,
            "width": 2085
          },
          "options": {}
        },
        {
          "key": "invert",
          "type": "invert",
          "zone": "right",
          "span": 12,
          "height": 0,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "browser",
          "type": "browser",
          "zone": "right",
          "span": 12,
          "height": 270,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        }
      ]
    },
    "fullscreenMobile": {
      "enabled": true,
      "left": 20,
      "right": 35,
      "panels": [
        {
          "key": "stage",
          "type": "stage",
          "zone": "main",
          "span": 12,
          "height": 780,
          "visible": true,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "faders",
          "type": "faders",
          "zone": "main",
          "span": 12,
          "height": 620,
          "visible": true,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "library",
          "type": "library",
          "zone": "main",
          "span": 12,
          "height": 620,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "tools",
          "type": "tools",
          "zone": "main",
          "span": 12,
          "height": 0,
          "visible": true,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "selection",
          "type": "selection",
          "zone": "main",
          "span": 12,
          "height": 0,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "units",
          "type": "units",
          "zone": "main",
          "span": 12,
          "height": 0,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "fuel",
          "type": "fuel",
          "zone": "main",
          "span": 12,
          "height": 150,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "screen",
          "type": "screen",
          "zone": "main",
          "span": 12,
          "height": 0,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "fixture",
          "type": "fixture",
          "zone": "main",
          "span": 12,
          "height": 0,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "sequence",
          "type": "sequence",
          "zone": "main",
          "span": 12,
          "height": 0,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "nozzle",
          "type": "nozzle",
          "zone": "main",
          "span": 12,
          "height": 0,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "scale",
          "type": "scale",
          "zone": "main",
          "span": 12,
          "height": 0,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "angle",
          "type": "angle",
          "zone": "main",
          "span": 12,
          "height": 0,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "patch",
          "type": "patch",
          "zone": "main",
          "span": 12,
          "height": 0,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "arm",
          "type": "arm",
          "zone": "main",
          "span": 12,
          "height": 0,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "direction",
          "type": "direction",
          "zone": "main",
          "span": 12,
          "height": 0,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "rear",
          "type": "rear",
          "zone": "main",
          "span": 12,
          "height": 0,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "display",
          "type": "display",
          "zone": "main",
          "span": 12,
          "height": 0,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "macros",
          "type": "macros",
          "zone": "main",
          "span": 12,
          "height": 0,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "master",
          "type": "master",
          "zone": "main",
          "span": 12,
          "height": 300,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "record",
          "type": "record",
          "zone": "main",
          "span": 12,
          "height": 0,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "bank",
          "type": "bank",
          "zone": "main",
          "span": 12,
          "height": 0,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "monitor",
          "type": "monitor",
          "zone": "main",
          "span": 12,
          "height": 0,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "notes",
          "type": "notes",
          "zone": "main",
          "span": 12,
          "height": 220,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "clock",
          "type": "clock",
          "zone": "main",
          "span": 12,
          "height": 250,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "timecode",
          "type": "timecode",
          "zone": "main",
          "span": 12,
          "height": 310,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "invert",
          "type": "invert",
          "zone": "right",
          "span": 12,
          "height": 0,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        },
        {
          "key": "browser",
          "type": "browser",
          "zone": "right",
          "span": 12,
          "height": 270,
          "visible": false,
          "minimized": false,
          "float": null,
          "options": {}
        }
      ]
    },
    "notes": "",
    "focus": {
      "axis": "auto",
      "split": 50
    }
  },
  "referenceViewport": {
    "width": 2880,
    "height": 1100
  }
};
