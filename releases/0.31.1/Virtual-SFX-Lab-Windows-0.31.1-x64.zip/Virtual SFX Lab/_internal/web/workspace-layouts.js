// Customize checkpoints and named Customized Layouts.
// Saved privately for this visitor on the Wave Studio server (like the workspace
// itself), with this browser's storage as a backup and the current session as a
// last resort. Everything is re-validated before use; note text is never copied.
const CACHE_KEY='wave-studio-custom-layouts-v2';
const MAX_LAYOUTS=24,MAX_BYTES=1400000;
const DEVICES={desktop:'Desktop',mobile:'Phone',fullscreenDesktop:'Full Screen Desktop',fullscreenMobile:'Full Screen Phone'};
const CONTENT_KEYS=['notes','activeNoteId'];
const empty=()=>({version:1,checkpoints:{},layouts:[]});
const readCache=()=>{try{const v=JSON.parse(localStorage.getItem(CACHE_KEY)||'null');return v&&typeof v==='object'?v:null}catch{return null}};
const writeCache=value=>{try{localStorage.setItem(CACHE_KEY,JSON.stringify(value));return true}catch{return false}};
const cleanName=v=>String(v||'').replace(/[\u0000-\u001f<>]/g,'').replace(/\s+/g,' ').trim().slice(0,60);
export function mountLayoutLibrary({config,activeDevice,validateWorkspace,apply,status,editing,remote}){
 let data=empty(),where='session';
 const shape=v=>({version:1,checkpoints:v&&typeof v.checkpoints==='object'&&!Array.isArray(v.checkpoints)?v.checkpoints:{},layouts:Array.isArray(v?.layouts)?v.layouts:[]});
 // Saves to the server first; the browser copy and session memory are fallbacks.
 async function persist(){
  const text=JSON.stringify(data);if(text.length>MAX_BYTES)return 'full';
  const cached=writeCache(data);
  try{await remote('PUT',data);where='server';return 'server'}catch{where=cached?'browser':'session';return where}
 }
 const ready=(async()=>{
  const cached=readCache();
  try{const server=await remote('GET');const has=v=>v&&(Object.keys(v.checkpoints||{}).length||(v.layouts||[]).length);
   data=shape(has(server)?server:cached||server);where='server';if(!has(server)&&has(cached))persist();
  }catch{data=shape(cached);where=cached?'browser':'session'}
  sync();
 })();
 // A stored profile is only used after the full workspace validator accepts it.
 function validProfile(device,profile){
  if(!DEVICES[device]||!profile||typeof profile!=='object')return null;
  try{const doc=structuredClone(config());doc[device]=structuredClone(profile);return validateWorkspace(doc)[device]}catch{return null}
 }
 // Layout data comes from the snapshot; panel note text stays as it is now.
 function keepContent(next,current){
  const out=structuredClone(next);
  for(const item of out.panels){
   const now=current.panels.find(p=>p.key===item.key);
   for(const k of CONTENT_KEYS){delete item.options?.[k];if(now?.options&&now.options[k]!==undefined)(item.options??={})[k]=structuredClone(now.options[k])}
  }
  return out;
 }
 function stripContent(profile){
  const out=structuredClone(profile);
  for(const item of out.panels)for(const k of CONTENT_KEYS)if(item.options)delete item.options[k];
  return out;
 }
 const checkpoints=()=>data.checkpoints;
 function checkpointFor(device){const c=checkpoints()[device],profile=c&&validProfile(device,c.profile);return profile?{savedAt:c.savedAt,profile}:null}
 function capture(){
  const device=activeDevice();
  data.checkpoints[device]={savedAt:new Date().toISOString(),profile:stripContent(config()[device])};
  sync();ready.then(persist).then(r=>{if(r==='session')status('Revert Point Kept For This Session Only. Storage Is Unavailable.')});
 }
 function same(a,b){return JSON.stringify(stripContent(a))===JSON.stringify(stripContent(b))}
 function revert(){
  const device=activeDevice(),c=checkpointFor(device);if(!c){status('No Saved Customize Layout To Revert To Yet.');return}
  const current=config()[device];if(same(c.profile,current)){status('Already At The Last Saved Customize Layout.');return}
  if(!confirm(`Revert ${DEVICES[device]} To The Layout Saved When You Pressed Customize Workspace (${new Date(c.savedAt).toLocaleString()})? Panel Notes Are Kept; Panels Added Since Then Are Removed.`))return;
  const profile=validProfile(device,keepContent(c.profile,current));if(!profile){status('Saved Customize Layout Is No Longer Valid.');return}
  apply(device,profile);status('Reverted To The Last Saved Customize Layout.');
 }
 const library=()=>data.layouts.filter(l=>l&&typeof l.id==='string'&&typeof l.name==='string'&&DEVICES[l.device]);
 const store=async list=>{const before=data.layouts;data.layouts=list;const r=await persist();if(r==='full')data.layouts=before;return r};
 const savedNote=r=>r==='server'?'':r==='browser'?' Saved In This Browser Only (Server Unavailable).':' Kept For This Session Only — Storage Is Unavailable, So Download A Workspace Copy To Keep It.';
 const dialog=document.createElement('dialog');dialog.className='workspace-dialog layout-library-dialog';dialog.id='layout-library';dialog.setAttribute('aria-labelledby','layout-library-title');
 dialog.innerHTML='<div class="dialog-head"><h2 id="layout-library-title">Customized Layouts</h2><button type="button" data-ll-close>Close</button></div><p class="widget-hint" data-ll-device></p><form class="layout-library-save"><label>Layout name <input type="text" maxlength="60" required placeholder="e.g. Rehearsal Desk" data-ll-name></label><button type="submit">Save Current Layout</button></form><p class="layout-library-status" role="status" data-ll-status></p><div class="layout-library-list" data-ll-list></div><p class="widget-hint">Saved privately for this visitor, like your workspace. Layouts include panels, sizes and button arrangements; note text is not saved in them. Loading a layout keeps your current notes, and Revert Customize can undo a load.</p>';
 document.body.append(dialog);
 const $d=s=>dialog.querySelector(s),say=t=>{$d('[data-ll-status]').textContent=t};
 $d('[data-ll-close]').onclick=()=>dialog.close();
 $d('.layout-library-save').onsubmit=async e=>{
  e.preventDefault();const name=cleanName($d('[data-ll-name]').value);if(!name){say('Enter A Layout Name.');return}
  const device=activeDevice(),list=library(),existing=list.find(l=>l.device===device&&l.name.toLowerCase()===name.toLowerCase());
  if(existing&&!confirm(`Replace The Saved Layout “${existing.name}”?`))return;
  if(!existing&&list.length>=MAX_LAYOUTS){say(`Up To ${MAX_LAYOUTS} Layouts Can Be Saved. Delete One First.`);return}
  const entry={id:existing?.id||`layout-${Date.now().toString(36)}`,name,device,savedAt:new Date().toISOString(),profile:stripContent(config()[device])};
  const next=existing?list.map(l=>l===existing?entry:l):[...list,entry];
  await ready;const r=await store(next);
  if(r==='full'){say('Layout Storage Is Full. Delete A Saved Layout First.');return}
  $d('[data-ll-name]').value='';say(`Saved “${name}”.${savedNote(r)}`);draw();
 };
 function load(entry){
  const device=activeDevice();if(entry.device!==device)return;
  if(!confirm(`Load “${entry.name}”? Your current ${DEVICES[device]} arrangement becomes the Revert Customize point.`))return;
  const current=config()[device],checked=validProfile(device,entry.profile),profile=checked&&validProfile(device,keepContent(checked,current));
  if(!profile){say('This Saved Layout Is No Longer Valid And Was Not Loaded.');return}
  data.checkpoints[device]={savedAt:new Date().toISOString(),profile:stripContent(current)};persist();
  apply(device,profile);say(`Loaded “${entry.name}”.`);status(`Loaded Layout “${entry.name}”. Revert Customize Returns To The Previous Arrangement.`);draw();
 }
 function draw(){
  const device=activeDevice(),list=library().filter(l=>l.device===device).sort((a,b)=>a.name.localeCompare(b.name));
  $d('[data-ll-device]').textContent=`Showing ${DEVICES[device]} layouts. Each screen type keeps its own layouts.`;
  const host=$d('[data-ll-list]');host.replaceChildren();
  if(!list.length){const p=document.createElement('p');p.className='widget-hint';p.textContent='No Saved Layouts For This Screen Yet.';host.append(p)}
  for(const entry of list){
   const row=document.createElement('div');row.className='layout-library-row';
   const text=document.createElement('span');const name=document.createElement('strong');name.textContent=entry.name;const when=document.createElement('small');when.textContent=new Date(entry.savedAt).toLocaleString();text.append(name,when);
   const loadB=document.createElement('button');loadB.type='button';loadB.textContent='Load';loadB.setAttribute('aria-label',`Load ${entry.name}`);loadB.onclick=()=>load(entry);
   const del=document.createElement('button');del.type='button';del.textContent='Delete';del.setAttribute('aria-label',`Delete ${entry.name}`);
   del.onclick=async()=>{if(!confirm(`Delete The Saved Layout “${entry.name}”?`))return;await store(library().filter(l=>l.id!==entry.id));say(`Deleted “${entry.name}”.`);draw()};
   row.append(text,loadB,del);host.append(row);
  }
 }
 function open(){say('');draw();dialog.showModal();$d('[data-ll-name]').focus();ready.then(draw)}
 function sync(){
  const c=checkpointFor(activeDevice()),current=config()[activeDevice()];
  for(const b of document.querySelectorAll('[data-revert-customize]')){
   b.disabled=!c||same(c.profile,current);
   b.title=c?`Revert To The Layout Saved ${new Date(c.savedAt).toLocaleString()}`:'Press Customize Workspace To Save A Layout You Can Revert To';
  }
 }
 setInterval(sync,1000);
 return {capture,revert,open,sync};
}
