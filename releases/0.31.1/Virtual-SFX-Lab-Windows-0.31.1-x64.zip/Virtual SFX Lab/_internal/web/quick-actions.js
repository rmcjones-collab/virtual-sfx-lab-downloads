// Beta 0.19 navigation helpers: a right-click / long-press menu on stage fixtures and a keyboard shortcut reference.
// Presentation only. Every action routes to an existing control, so no playback or fixture rules are duplicated here.
const $=s=>document.querySelector(s);
export const SHORTCUTS=[
 ['Space','Play or pause the preview'],
 ['← / →','Previous or next sequence'],
 ['H','Home the selected units and release their cues'],
 ['Delete','Remove the selected units'],
 ['Arrow keys','Nudge a focused fixture (Shift for larger steps)'],
 ['Ctrl / Cmd + click','Add a fixture to the selection'],
 ['Esc','Cancel a drag, release flashes, close menus'],
 ['Ctrl + Shift (hold)','Temporarily customize the workspace'],
 ['Ctrl + Shift + P','Open or close Add Panels'],
 ['Ctrl + Shift + F','Enter or exit Full Screen'],
 ['Ctrl + Shift + S','Save a screenshot of the layout view (PNG)'],
 ['Ctrl + Shift + R','Start or stop recording the layout view'],
 ['Drag across the Unit List','Select several fixtures at once'],
 ['?','Show this shortcut list'],
 ['Right-click a fixture','Quick actions: Home, Invert, Fuel, Apply, Remove']
];
export function mountQuickActions({state,actions}){
 const menu=document.createElement('div');menu.className='quick-menu';menu.hidden=true;menu.setAttribute('role','menu');menu.setAttribute('aria-label','Fixture quick actions');
 document.body.append(menu);
 const items=[
  ['home','Home selected',()=>actions.home()],
  ['invert','Invert selected',()=>actions.invert()],
  ['apply','Apply this look to all units',()=>actions.applyAll()],
  ['fuel','Fuel consumption…',()=>actions.fuel(openFor,openElement)],
  ['rename','Rename fixture',()=>actions.rename()],
  ['select','Select all units',()=>actions.selectAll()],
  ['fit','Fit view',()=>actions.fitView()],
  ['remove','Remove selected',()=>actions.remove()]
 ];
 for(const [id,label,run] of items){
  const b=document.createElement('button');b.type='button';b.dataset.quick=id;b.textContent=label;b.setAttribute('role','menuitem');
  b.onclick=()=>{close();run()};menu.append(b);
 }
 let openFor=null,openElement=null;
 function close(){if(menu.hidden)return;menu.hidden=true;document.body.classList.remove('quick-menu-open')}
 function open(x,y,fixtureId,element=null){
  openFor=fixtureId;openElement=element;menu.hidden=false;document.body.classList.add('quick-menu-open');
  const count=state.selectedIds.length;
  menu.querySelector('[data-quick=home]').textContent=count>1?`Home ${count} selected`:'Home this unit';
  menu.querySelector('[data-quick=invert]').textContent=count>1?`Invert ${count} selected`:'Invert this unit';
  menu.querySelector('[data-quick=remove]').textContent=count>1?`Remove ${count} selected`:'Remove this unit';
  menu.querySelector('[data-quick=home]').disabled=menu.querySelector('[data-quick=invert]').disabled=!!state.live;
  menu.querySelector('[data-quick=remove]').disabled=!!state.layoutLocked;
  const w=menu.offsetWidth||220,h=menu.offsetHeight||300;
  menu.style.left=`${Math.max(8,Math.min(x,innerWidth-w-8))}px`;menu.style.top=`${Math.max(8,Math.min(y,innerHeight-h-8))}px`;
  menu.querySelector('button:not(:disabled)')?.focus({preventScroll:true});
 }
 const layer=$('#fixture-handles');
 layer.addEventListener('contextmenu',e=>{
  const handle=e.target.closest('.fixture-handle');if(!handle)return;
  e.preventDefault();const id=+handle.dataset.fixture;
  if(!state.selectedIds.includes(id))actions.select(id);
  open(e.clientX,e.clientY,id,handle);
 });
 layer.addEventListener('keydown',e=>{
  if(e.key!=='ContextMenu'&&!(e.shiftKey&&e.key==='F10'))return;const handle=e.target.closest('.fixture-handle');if(!handle)return;
  e.preventDefault();const id=+handle.dataset.fixture,r=handle.getBoundingClientRect();if(!state.selectedIds.includes(id))actions.select(id);open(r.left,r.bottom,id,handle);
 });

 // Touch: a still 600 ms press opens the same menu (Fuel Consumption is one of its items).
 let press=null;
 layer.addEventListener('pointerdown',e=>{
  if(e.pointerType!=='touch')return;const handle=e.target.closest('.fixture-handle');if(!handle)return;
  const x=e.clientX,y=e.clientY,id=+handle.dataset.fixture;
  press={timer:setTimeout(()=>{press=null;actions.cancelGesture?.();if(!state.selectedIds.includes(id))actions.select(id);open(x,y,id,handle)},600),x,y};
 },true);
 const cancelPress=e=>{if(!press)return;if(e.type==='pointermove'&&Math.hypot(e.clientX-press.x,e.clientY-press.y)<8)return;clearTimeout(press.timer);press=null};
 for(const type of ['pointermove','pointerup','pointercancel'])layer.addEventListener(type,cancelPress,true);
 document.addEventListener('pointerdown',e=>{if(!menu.hidden&&!menu.contains(e.target))close()},true);
 document.addEventListener('keydown',e=>{
  if(!menu.hidden&&e.key==='Escape'){e.preventDefault();close();return}
  if(!menu.hidden&&['ArrowDown','ArrowUp'].includes(e.key)){
   e.preventDefault();const list=[...menu.querySelectorAll('button:not(:disabled)')],i=list.indexOf(document.activeElement);
   list[(i+(e.key==='ArrowDown'?1:list.length-1))%list.length]?.focus();
  }
 });
 window.addEventListener('scroll',close,{passive:true});window.addEventListener('resize',close);
 // Shortcut reference.
 const dialog=document.createElement('dialog');dialog.id='shortcuts-dialog';dialog.className='shortcuts-dialog';
 dialog.innerHTML=`<div class="shortcuts-head"><h2>Keyboard shortcuts</h2><button type="button" id="shortcuts-close" aria-label="Close shortcuts">×</button></div><dl class="shortcuts-list">${SHORTCUTS.map(([k,d])=>`<div><dt><kbd>${k}</kbd></dt><dd>${d}</dd></div>`).join('')}</dl><p class="shortcuts-note">Shortcuts pause while you type in a field. Visual rehearsal only; nothing here fires hardware.</p>`;
 document.body.append(dialog);
 dialog.querySelector('#shortcuts-close').onclick=()=>dialog.close();
 dialog.addEventListener('click',e=>{if(e.target===dialog)dialog.close()});
 function toggleShortcuts(){if(dialog.open)dialog.close();else dialog.showModal()}
 document.addEventListener('keydown',e=>{
  const isHelpKey=e.key==='?'||(e.key==='/'&&e.shiftKey);
  if(!isHelpKey||e.ctrlKey||e.metaKey||e.altKey||e.target.closest?.('input,textarea,select,[contenteditable="true"]'))return;
  if(document.querySelector('dialog[open]')&&!dialog.open)return;
  e.preventDefault();toggleShortcuts();
 });
 return {close,toggleShortcuts,menu,dialog,isOpen:()=>!menu.hidden,openFor:()=>openFor};
}
