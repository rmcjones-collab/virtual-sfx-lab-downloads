// Landing-page demo recorder: up to one minute of the demo layout as MP4.
// Canvas only. No camera, microphone or page content is captured.
import {drawSequenceCaption,createSequenceLog} from './sequence-caption.js?v=v031c-20261004d';
import {drawWatermark} from './watermark.js?v=v031c-20261004d';
const MAX_SECONDS=60,MAX_CLIPS=5;
const types=['video/mp4;codecs=avc1.42001E','video/mp4;codecs=avc1','video/mp4','video/webm;codecs=vp9','video/webm;codecs=vp8','video/webm'];
export function mountDemoRecorder({canvas,bar,optionHost,getSequence}){
 const supported=!!(globalThis.MediaRecorder&&canvas.captureStream);
 const chosen=supported?types.find(t=>MediaRecorder.isTypeSupported(t)):null;
 const mp4=!!chosen?.startsWith('video/mp4');
 let recorder=null,stream=null,frame=0,timer=0,started=0,busy=false,clips=[];
 const group=document.createElement('div');group.className='demo-record-tools';
 group.innerHTML='<button type="button" id="demo-record" aria-pressed="false"><span class="record-dot" aria-hidden="true"></span><span data-label>Record</span><span class="record-time" aria-hidden="true"></span></button><button type="button" id="demo-videos" aria-haspopup="dialog">Videos</button>';
 bar.querySelector('#demo-expand').before(group);
 const record=group.querySelector('#demo-record'),open=group.querySelector('#demo-videos'),label=record.querySelector('[data-label]'),time=record.querySelector('.record-time');
 const option=document.createElement('label');option.className='demo-record-sequence';
 option.innerHTML='<input id="demo-record-sequence" type="checkbox" checked> Record Sequence';
 option.title='Shows the running sequence in the video and saves a sequence log with the clip';
 const tour=optionHost.querySelector('.demo-tour-label'),toggles=document.createElement('div');toggles.className='demo-toggles';
 if(tour){tour.before(toggles);toggles.append(tour,option)}else optionHost.append(option);
 const sequenceBox=option.querySelector('input');
 const dialog=document.createElement('dialog');dialog.id='demo-recordings';dialog.setAttribute('aria-labelledby','demo-recordings-title');
 dialog.innerHTML='<div class="demo-recordings-head"><h2 id="demo-recordings-title">Demo Videos</h2><button type="button" data-close>Close</button></div><p class="demo-recordings-note">Records up to 1 minute of the demo layout only. No camera, microphone or sound. Videos stay in this tab: download them before you leave or reload.</p><label class="demo-record-sequence demo-record-sequence-dialog"><input type="checkbox" data-sequence> <span>Record The Running Sequence<small>Shows each unit\'s sequence number and name in the video, and saves a timestamped sequence log with the clip.</small></span></label><p class="demo-recordings-status" role="status" aria-live="polite"></p><div class="demo-recordings-actions"><button type="button" class="button primary" data-toggle>Start Recording</button></div><div class="demo-recordings-list"></div>';
 document.body.append(dialog);
 const status=dialog.querySelector('.demo-recordings-status'),toggle=dialog.querySelector('[data-toggle]'),list=dialog.querySelector('.demo-recordings-list'),dialogSequence=dialog.querySelector('[data-sequence]');
 const syncOption=value=>{sequenceBox.checked=dialogSequence.checked=value};
 sequenceBox.onchange=()=>syncOption(sequenceBox.checked);dialogSequence.onchange=()=>syncOption(dialogSequence.checked);syncOption(true);
 function tell(text){status.textContent=text;record.title=text}
 function sync(){
  record.classList.toggle('is-recording',busy);record.setAttribute('aria-pressed',String(busy));
  record.setAttribute('aria-label',busy?'Stop Demo Recording':'Record Demo Video, Up To 1 Minute');
  label.textContent=busy?'Stop':'Record';toggle.textContent=busy?'Stop Recording':'Start Recording';
  sequenceBox.disabled=dialogSequence.disabled=busy;
  record.disabled=toggle.disabled=!chosen;
  open.textContent=clips.length?`Videos (${clips.length})`:'Videos';
 }
 function save(blob,name){const a=document.createElement('a'),url=URL.createObjectURL(blob);a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),4000)}
 function renderClips(){
  list.replaceChildren();
  if(!clips.length){const p=document.createElement('p');p.className='demo-recordings-empty';p.textContent='No videos yet. Press Record above the demo to start.';list.append(p)}
  for(const clip of [...clips].reverse()){
   const article=document.createElement('article'),title=document.createElement('h3'),details=document.createElement('p'),video=document.createElement('video'),actions=document.createElement('div');
   title.textContent=clip.name;details.textContent=`${clip.width} × ${clip.height} · ${clip.seconds.toFixed(1)} s · ${(clip.blob.size/1048576).toFixed(1)} MB · ${clip.type==='video/mp4'?'MP4':'WebM'}`;
   video.controls=true;video.playsInline=true;video.muted=true;video.preload='metadata';video.src=clip.url;
   actions.className='demo-recordings-actions';
   const download=document.createElement('a');download.className='button primary';download.href=clip.url;download.download=clip.name;download.textContent=clip.type==='video/mp4'?'Download MP4':'Download WebM';
   actions.append(download);
   article.append(title,details);
   if(clip.log?.entries.length){
    const used=document.createElement('p'),names=clip.log.summary();used.className='demo-recordings-sequences';
    used.textContent=`Sequences: ${names.slice(0,5).join(' | ')}${names.length>5?` | +${names.length-5} more`:''}`;article.append(used);
    const log=document.createElement('button');log.type='button';log.textContent='Download Sequence Log';
    log.onclick=()=>save(new Blob([clip.log.toText(clip.name)],{type:'text/plain'}),clip.name.replace(/\.(mp4|webm)$/,'-sequences.txt'));actions.append(log);
   }
   const remove=document.createElement('button');remove.type='button';remove.textContent='Remove';
   remove.onclick=()=>{video.pause();video.removeAttribute('src');video.load();URL.revokeObjectURL(clip.url);clips=clips.filter(c=>c!==clip);renderClips();sync()};
   actions.append(remove);article.append(video,actions);list.append(article);
  }
 }
 function cleanup(){cancelAnimationFrame(frame);clearInterval(timer);stream?.getTracks().forEach(t=>t.stop());stream=null;recorder=null;busy=false;time.textContent='';sync()}
 function stop(reason='Video ready. Download it below.'){if(recorder?.state==='recording'){tell(reason);record.disabled=toggle.disabled=true;recorder.stop()}}
 function start(){
  if(busy||!chosen)return;
  if(clips.length>=MAX_CLIPS){tell(`Up to ${MAX_CLIPS} videos per visit. Download and remove one to record another.`);if(!dialog.open)dialog.showModal();return}
  const target=document.createElement('canvas'),ratio=Math.min(Math.max(1,720/canvas.height),1080/canvas.height,1920/canvas.width);
  target.width=Math.max(2,Math.floor(canvas.width*ratio/2)*2);target.height=Math.max(2,Math.floor(canvas.height*ratio/2)*2);
  const ctx=target.getContext('2d',{alpha:false}),log=sequenceBox.checked?createSequenceLog():null;
  let info=null,infoAt=-1,chunks=[];
  function paint(){
   ctx.fillStyle='#090d10';ctx.fillRect(0,0,target.width,target.height);ctx.drawImage(canvas,0,0,target.width,target.height);let band=0;
   if(log){const now=performance.now(),elapsed=started?(now-started)/1000:0;if(now-infoAt>200){infoAt=now;try{info=getSequence()}catch{info=null}log.mark(elapsed,info)}band=drawSequenceCaption(ctx,target.width,target.height,info,elapsed)}
   drawWatermark(ctx,target.width,target.height,band);
   frame=requestAnimationFrame(paint);
  }
  try{
   paint();stream=target.captureStream(30);
   const current=new MediaRecorder(stream,{mimeType:chosen,videoBitsPerSecond:5000000});recorder=current;started=performance.now();
   let bytes=0;current.ondataavailable=e=>{if(e.data.size){chunks.push(e.data);bytes+=e.data.size;if(bytes>=64*1048576)stop('Recording stopped at the 64 MB clip limit. Download it below.')}};
   current.onerror=()=>{tell('The browser could not finish recording.');if(current.state!=='inactive')current.stop();else cleanup()};
   current.onstop=()=>{
    const seconds=Math.min(MAX_SECONDS,(performance.now()-started)/1000),type=current.mimeType.split(';')[0]||chosen.split(';')[0],blob=new Blob(chunks,{type});
    if(blob.size){const name=`wave-studio-demo-${new Date().toISOString().replace(/[:.]/g,'-').slice(0,19)}.${type==='video/mp4'?'mp4':'webm'}`;clips.push({name,blob,type,url:URL.createObjectURL(blob),seconds,width:target.width,height:target.height,log})}
    else tell('No video was captured. Please try again.');
    cleanup();renderClips();if(blob.size&&!dialog.open)dialog.showModal();
   };
   current.start(500);busy=true;sync();
   tell(mp4?'Recording MP4. Press Stop or wait for the 1 minute limit.':'This browser cannot record MP4, so this clip will be WebM. Use Chrome, Edge or Safari for MP4.');
   timer=setInterval(()=>{const elapsed=(performance.now()-started)/1000;time.textContent=`${Math.floor(elapsed/60)}:${String(Math.floor(elapsed%60)).padStart(2,'0')} / 1:00`;if(elapsed>=MAX_SECONDS)stop('Recording stopped at the 1 minute limit. Download it below.')},200);
   if(dialog.open)dialog.close();
  }catch(error){cleanup();tell(`Recording could not start: ${error.message}`);if(!dialog.open)dialog.showModal()}
 }
 record.onclick=toggle.onclick=()=>busy?stop():start();
 open.onclick=()=>{renderClips();dialog.showModal()};
 dialog.querySelector('[data-close]').onclick=()=>{dialog.querySelectorAll('video').forEach(v=>v.pause());dialog.close()};
 dialog.addEventListener('click',e=>{if(e.target===dialog)dialog.querySelector('[data-close]').click()});
 document.addEventListener('visibilitychange',()=>{if(document.hidden)stop('Recording stopped because the tab was hidden. Download it below.')});
 window.addEventListener('beforeunload',e=>{if(busy||clips.length){e.preventDefault();e.returnValue=''}});
 if(!chosen)tell('Video recording is not supported in this browser. Try a current Chrome, Edge or Safari.');
 else if(!mp4)tell('This browser cannot record MP4, so videos will be WebM. Use Chrome, Edge or Safari for MP4.');
 else tell('Press Record above the demo. Recording stops automatically at 1 minute.');
 sync();renderClips();
 return {isRecording:()=>busy};
}
