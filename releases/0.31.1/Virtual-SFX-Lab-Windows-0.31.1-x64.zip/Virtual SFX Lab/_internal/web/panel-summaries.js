// Compact controls proxy the original live controls, never a separate settings copy.
export function syncPanelSummary({summary,type,source,timecode}){
 if(!['scale','direction','home','nozzle','selection','timecode','patch','angle','fuel','stack'].includes(type))return false;
 if(summary.dataset.kind!==type){
  summary.replaceChildren();summary.dataset.kind=type;
  for(const event of ['pointerdown','keydown','click'])summary.addEventListener(event,e=>e.stopPropagation());
  const output=(name)=>{const node=document.createElement('output');node.dataset.reading=name;summary.append(node);return node};
  const proxy=(selector,name,short=false)=>{
   const original=source.querySelector(selector),control=original.cloneNode(true);
   control.removeAttribute('id');control.removeAttribute('name');control.removeAttribute('aria-describedby');control.setAttribute('aria-label',name);control.title=name;control.dataset.proxy=selector;
   if(short)for(const o of control.options)o.textContent=o.value==='indoor'?'Indoor':'Outdoor';
   if(type==='angle')for(const o of control.options)o.textContent=o.textContent.split(' · ')[0];
   for(const event of ['input','change','blur'])control.addEventListener(event,()=>{
    if(original.disabled||original.closest('[inert]'))return;
    original.value=control.value;original.dispatchEvent(new Event(event,{bubbles:true}));
   });
   summary.append(control);return control;
  };
  if(type==='scale'){proxy('#size','Visual Flame Scale');output('scale')}
  if(type==='nozzle')proxy('#fixture-nozzle','Nozzle Type',true);
  if(type==='angle'){proxy('#fixture-min-angle','Minimum Angle');proxy('#fixture-max-angle','Maximum Angle')}
  if(['direction','home','selection','patch','fuel'].includes(type))output(type);
  if(type==='stack'){
   output('stack');
   const go=document.createElement('button');go.type='button';go.dataset.stackGoProxy='';go.textContent='GO';go.title='Play the next stack entry';go.onclick=()=>source.querySelector('[data-stack-go]')?.click();summary.append(go);
  }
  if(type==='timecode'){
   output('timecode');
   const play=document.createElement('button');play.type='button';play.dataset.tcPlay='';play.onclick=()=>{const t=timecode.get();if(t.source==='internal')timecode[t.running?'pause':'play']()};summary.append(play);
   const arm=document.createElement('button');arm.type='button';arm.dataset.tcArm='';arm.onclick=()=>timecode.arm(!timecode.get().armed);summary.append(arm);
  }
 }
 for(const control of summary.querySelectorAll('[data-proxy]')){
  const original=source.querySelector(control.dataset.proxy);
  control.disabled=original.disabled||!!original.closest('[inert]');
  if(document.activeElement!==control)control.value=original.value;
 }
 const out=summary.querySelector('output');
 if(type==='scale')out.textContent=`${source.querySelector('#size').value}%`;
 if(type==='direction'){const emitting=source.querySelector('#emission')?.textContent??'';out.textContent=source.querySelector('#live-angle').textContent;out.title=emitting}
 if(type==='home'){const summary=source.querySelector('#home-angle')?.dataset.homeSummary??'0°';out.textContent=summary==='No Selection'?'Home: No Selection':`Home ${summary}`;out.title='Home Angle Of The Selected Units'}
 if(type==='selection')out.textContent=source.querySelector('#selection-count').textContent;
 if(type==='fuel'){const total=source.querySelector('[data-fuel-session-total]');out.textContent=total?`Session ${total.textContent.split(' · ')[0]}`:'';out.title='Estimated fuel used by all units this session'}
 if(type==='stack'){const cur=source.querySelector('[data-stack-current]')?.textContent??'',nxt=source.querySelector('[data-stack-next]')?.textContent??'';out.textContent=`${cur.split(' · ').slice(0,2).join(' · ')} · ${nxt}`;out.title='Running entry · next entry';const go=summary.querySelector('[data-stack-go-proxy]');if(go)go.disabled=!!source.querySelector('[data-stack-go]')?.disabled}
 if(type==='patch'){
  out.textContent=source.querySelector('#dmx-patch').disabled?'No Selection':`Port ${source.querySelector('#dmx-universe').value} · DMX ${source.querySelector('#dmx-address').value}`;
  out.title='Port-Address (0-Based) · DMX Address (1-Based)';
 }
 if(type==='timecode'){
  const t=timecode.get(),play=summary.querySelector('[data-tc-play]'),arm=summary.querySelector('[data-tc-arm]');
  out.textContent=t.text;out.title=t.status;
  play.textContent=t.running?'Ⅱ':'▶';play.setAttribute('aria-label',t.running?'Pause Timecode':'Play Timecode');play.title=t.source==='internal'?(t.running?'Pause Timecode':'Play Timecode'):'External Timecode Transport Is Controlled At Its Source';play.disabled=t.source!=='internal';
  arm.textContent=t.armed?'Armed':'Arm';arm.setAttribute('aria-label',t.armed?'Disarm Timecode Preview':'Arm Timecode Preview');arm.setAttribute('aria-pressed',String(t.armed));arm.title='Enable Timecode Chase Of Preset Preview Only. No Hardware Output.';
 }
 return true;
}
