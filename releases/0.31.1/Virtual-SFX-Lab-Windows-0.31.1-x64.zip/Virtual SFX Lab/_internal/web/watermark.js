// "Made with Virtual SFX Lab · WaveStudio Beta 0.xx" watermark burned into every recorded video.
// The version is the newest development-log entry, i.e. the build that recorded it.
import {DEV_LOG} from './dev-log.js?v=v031c-20261004d';
export const BUILD_VERSION=DEV_LOG[0].version;
export const WATERMARK_TEXT=`Made with Virtual SFX Lab · WaveStudio Beta ${BUILD_VERSION}`;
const logo=typeof Path2D==='function'?new Path2D('M4 25V12L11 5v20M15 25V8l6 6v11M25 25V18l4 4v3'):null;
// bottom: pixels reserved at the bottom of the frame (for example a caption band).
export function drawWatermark(ctx,w,h,bottom=0){
 const size=Math.max(9,Math.round(Math.min(h*.024,w*.016))),icon=Math.round(size*1.35),pad=Math.round(size*.55),margin=Math.round(size*.9);
 ctx.save();
 ctx.font=`600 ${size}px Arial, sans-serif`;ctx.textBaseline='middle';ctx.textAlign='left';
 const textW=ctx.measureText(WATERMARK_TEXT).width,boxW=Math.round(pad*2+icon+pad*.8+textW),boxH=Math.round(icon+pad*1.2);
 const x=margin,y=Math.round(h-bottom-margin-boxH);
 ctx.fillStyle='rgba(9,13,16,.55)';
 if(ctx.roundRect){ctx.beginPath();ctx.roundRect(x,y,boxW,boxH,Math.round(boxH/4));ctx.fill()}else ctx.fillRect(x,y,boxW,boxH);
 ctx.globalAlpha=.9;
 if(logo){ctx.save();ctx.translate(x+pad,y+(boxH-icon)/2);ctx.scale(icon/32,icon/32);ctx.strokeStyle='#ffab73';ctx.lineWidth=3;ctx.lineJoin='miter';ctx.stroke(logo);ctx.restore()}
 ctx.fillStyle='#f0eee8';ctx.fillText(WATERMARK_TEXT,x+pad+icon+pad*.8,y+boxH/2+1);
 ctx.restore();
}
// Wraps a live camera stream in a watermarked canvas stream.
export async function watermarkedStream(source,fps=30){
 const video=document.createElement('video');video.muted=true;video.playsInline=true;video.srcObject=source;
 await video.play();
 if(!video.videoWidth)await new Promise(r=>{video.addEventListener('loadedmetadata',r,{once:true});setTimeout(r,1500)});
 const canvas=document.createElement('canvas'),ctx=canvas.getContext('2d',{alpha:false});
 canvas.width=Math.max(2,(video.videoWidth||640)&~1);canvas.height=Math.max(2,(video.videoHeight||480)&~1);
 let frame=0;
 const paint=()=>{ctx.drawImage(video,0,0,canvas.width,canvas.height);drawWatermark(ctx,canvas.width,canvas.height);frame=requestAnimationFrame(paint)};
 paint();
 const stream=canvas.captureStream(fps);
 return {stream,stop(){cancelAnimationFrame(frame);stream.getTracks().forEach(t=>t.stop());video.pause();video.srcObject=null}};
}
