import {Chess} from './vendor/chess.js';
const value={p:100,n:320,b:330,r:500,q:900,k:0};
export function chooseMove(fen){
 const game=new Chess(fen),side=game.turn(),start=performance.now();
 let nodes=0;
 const score=()=>{
  if(game.isCheckmate())return game.turn()===side?-100000:100000;
  if(game.isDraw())return 0;
  return game.board().flat().reduce((s,p)=>s+(p?(p.color===side?1:-1)*(value[p.type]+(p.type==='p'?p.color==='w'?(Number(p.square[1])-2)*2:(7-Number(p.square[1]))*2:0)):0),0);
 };
 function search(depth,alpha,beta){
  nodes++;if(!depth||game.isGameOver()||performance.now()-start>650)return score();
  const maximizing=game.turn()===side;let best=maximizing?-Infinity:Infinity;
  const moves=game.moves({verbose:true}).sort((a,b)=>(value[b.captured]||0)-(value[a.captured]||0));
  for(const m of moves){
   game.move(m);const s=search(depth-1,alpha,beta);game.undo();
   best=maximizing?Math.max(best,s):Math.min(best,s);
   if(maximizing)alpha=Math.max(alpha,s);else beta=Math.min(beta,s);
   if(beta<=alpha)break;
  }return best;
 }
 let best=-Infinity,choice=null;
 for(const m of game.moves({verbose:true})){
  game.move(m);const s=search(1,-Infinity,Infinity);game.undo();
  if(s>best){best=s;choice={from:m.from,to:m.to,...(m.promotion?{promotion:m.promotion}:{})}}
  if(performance.now()-start>650&&choice)break;
 }
 return {move:choice,nodes,ms:Math.round(performance.now()-start)};
}
