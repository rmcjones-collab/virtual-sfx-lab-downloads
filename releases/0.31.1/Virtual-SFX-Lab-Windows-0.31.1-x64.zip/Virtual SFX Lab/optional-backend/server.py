"""Wave Studio local backend. Python 3.10+; standard library only (http.server + sqlite3).

Rebuilt from the Beta 0.29 web client's API calls. Serves the per-visitor
storage and the Friends & Chat service that the app expects on port 8093:

  GET/PUT  /api/default-layout      saved default fixture layout
  GET/PUT  /api/workspace           customized workspace document
  GET/PUT  /api/custom-layouts      Customize checkpoints and named layouts
  GET/PUT  /api/preferences         autosave preferences
  GET      /api/sessions            session log list
  GET/PUT  /api/sessions/<uuid>     one session log
  GET/POST /api/social              chat profile, friends, rooms, operations
  GET      /api/social/room/<id>    messages, signals, members, calls, grants
  GET      /api/social/room/<id>/export
  GET      /api/social/blob/<id>    chat attachment
  GET      /api/health

Binds to 127.0.0.1 by default. It never sends DMX, Art-Net, sACN or firing data.
"""
import argparse
import base64
import json
import os
from pathlib import Path
import re
import secrets
import sqlite3
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

SERVER_VERSION = "0.29.0"
HERE = Path(__file__).resolve().parent
DEFAULT_DB = HERE / "data" / "wave-studio.db"

MAX_BODY = 9_000_000                # attachments are base64 (6 MB raw ≈ 8 MB)
LIMITS = {"default-layout": 300_000, "workspace": 500_000, "custom-layouts": 1_400_000,
          "preferences": 2_000, "session": 6_000_000}
MAX_SESSIONS = 300
MAX_ATTACHMENT = 6_000_000
ATTACHMENT_TYPES = re.compile(r"^(image/(png|jpeg|gif|webp)|audio/(webm|mp4|mpeg|ogg|wav)|video/(webm|mp4))$")
CONTACT_FIELDS = {"email": 120, "phone": 80, "company": 120, "role": 120, "location": 120,
                  "website": 240, "social": 240}
CALL_TIMEOUT = 12        # seconds without a heartbeat before a caller drops
SIGNAL_TTL = 600         # seconds signals are kept
GRANT_SECONDS = 300      # instructor control lasts five minutes
MESSAGE_PAGE = 100
UUID = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$")
CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"


class ApiError(Exception):
    def __init__(self, status, detail):
        super().__init__(detail)
        self.status, self.detail = status, detail


def clean_text(value, limit):
    text = re.sub(r"[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]", "", str(value or ""))
    return text.strip()[:limit]


def new_code():
    raw = "".join(secrets.choice(CODE_ALPHABET) for _ in range(8))
    return raw[:4] + "-" + raw[4:]


SCHEMA = """
PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS docs (visitor TEXT, kind TEXT, key TEXT, body TEXT NOT NULL,
  updated REAL NOT NULL, PRIMARY KEY (visitor, kind, key));
CREATE TABLE IF NOT EXISTS profiles (visitor TEXT PRIMARY KEY, code TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL, contacts TEXT NOT NULL DEFAULT '{}', share INTEGER NOT NULL DEFAULT 0,
  created REAL NOT NULL);
CREATE TABLE IF NOT EXISTS friends (requester TEXT, recipient TEXT, accepted INTEGER NOT NULL DEFAULT 0,
  created REAL NOT NULL, PRIMARY KEY (requester, recipient));
CREATE TABLE IF NOT EXISTS rooms (id TEXT PRIMARY KEY, title TEXT NOT NULL, creator TEXT NOT NULL,
  created REAL NOT NULL);
CREATE TABLE IF NOT EXISTS members (room TEXT, code TEXT, PRIMARY KEY (room, code));
CREATE TABLE IF NOT EXISTS messages (id INTEGER PRIMARY KEY AUTOINCREMENT, room TEXT NOT NULL,
  sender TEXT NOT NULL, text TEXT NOT NULL, created REAL NOT NULL, blob TEXT, blob_name TEXT);
CREATE INDEX IF NOT EXISTS messages_room ON messages (room, id);
CREATE TABLE IF NOT EXISTS blobs (id TEXT PRIMARY KEY, room TEXT NOT NULL, mime TEXT NOT NULL,
  data BLOB NOT NULL, created REAL NOT NULL);
CREATE TABLE IF NOT EXISTS signals (id INTEGER PRIMARY KEY AUTOINCREMENT, room TEXT NOT NULL,
  sender TEXT NOT NULL, target TEXT NOT NULL, body TEXT NOT NULL, created REAL NOT NULL);
CREATE TABLE IF NOT EXISTS calls (room TEXT, code TEXT, session TEXT NOT NULL, seen REAL NOT NULL,
  PRIMARY KEY (room, code));
CREATE TABLE IF NOT EXISTS grants (room TEXT, owner TEXT, instructor TEXT, expires REAL NOT NULL,
  PRIMARY KEY (room, owner, instructor));
"""


class Store:
    """All database access, serialized through one lock."""

    def __init__(self, path, chat_retention_days=0):
        path = Path(path)
        if str(path) != ":memory:":
            path.parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(str(path), check_same_thread=False, isolation_level=None)
        self.db.row_factory = sqlite3.Row
        self.lock = threading.RLock()
        self.retention = chat_retention_days
        self.message_times = {}
        with self.lock:
            self.db.executescript(SCHEMA)

    def q(self, sql, *args):
        return self.db.execute(sql, args)

    # ---- simple per-visitor documents ----
    def get_doc(self, visitor, kind, key=""):
        with self.lock:
            row = self.q("SELECT body FROM docs WHERE visitor=? AND kind=? AND key=?", visitor, kind, key).fetchone()
        return json.loads(row["body"]) if row else None

    def put_doc(self, visitor, kind, value, key=""):
        body = json.dumps(value, separators=(",", ":"))
        with self.lock:
            self.q("INSERT INTO docs VALUES (?,?,?,?,?) ON CONFLICT(visitor,kind,key) DO UPDATE SET "
                   "body=excluded.body, updated=excluded.updated", visitor, kind, key, body, time.time())

    def doc_revision(self, visitor, kind, key=""):
        """Opaque revision of a stored document ("0" when there is none)."""
        with self.lock:
            row = self.q("SELECT updated FROM docs WHERE visitor=? AND kind=? AND key=?", visitor, kind, key).fetchone()
        return repr(row["updated"]) if row else "0"

    def put_doc_if(self, visitor, kind, value, base, key=""):
        """Write only if the stored revision still equals base (None = unconditional).
        Returns the new revision, or None when another tab saved first."""
        body = json.dumps(value, separators=(",", ":"))
        with self.lock:
            row = self.q("SELECT updated FROM docs WHERE visitor=? AND kind=? AND key=?", visitor, kind, key).fetchone()
            current = repr(row["updated"]) if row else "0"
            if base is not None and base != current:
                return None
            stamp = max(time.time(), (row["updated"] + 1e-6) if row else 0)
            self.q("INSERT INTO docs VALUES (?,?,?,?,?) ON CONFLICT(visitor,kind,key) DO UPDATE SET "
                   "body=excluded.body, updated=excluded.updated", visitor, kind, key, body, stamp)
            return repr(stamp)

    def list_sessions(self, visitor):
        with self.lock:
            rows = self.q("SELECT body FROM docs WHERE visitor=? AND kind='session' ORDER BY updated DESC",
                          visitor).fetchall()
        result = []
        for row in rows:
            doc = json.loads(row["body"])
            result.append({"id": doc["id"], "title": doc.get("title", "Session"),
                           "actions": len(doc.get("actions", [])), "startedAt": doc.get("startedAt"),
                           "updatedAt": doc.get("updatedAt")})
        return result

    def put_session(self, visitor, doc):
        with self.lock:
            self.put_doc(visitor, "session", doc, doc["id"])
            stale = self.q("SELECT key FROM docs WHERE visitor=? AND kind='session' ORDER BY updated DESC "
                           "LIMIT -1 OFFSET ?", visitor, MAX_SESSIONS).fetchall()
            for row in stale:
                self.q("DELETE FROM docs WHERE visitor=? AND kind='session' AND key=?", visitor, row["key"])
            count = self.q("SELECT COUNT(*) FROM docs WHERE visitor=? AND kind='session'", visitor).fetchone()[0]
        return {"pruned": len(stale), "count": count, "limit": MAX_SESSIONS}

    # ---- chat ----
    def profile(self, visitor):
        with self.lock:
            return self.q("SELECT * FROM profiles WHERE visitor=?", visitor).fetchone()

    def require_profile(self, visitor):
        row = self.profile(visitor)
        if not row:
            raise ApiError(400, "Create a chat profile first.")
        return row

    def by_code(self, code):
        with self.lock:
            return self.q("SELECT * FROM profiles WHERE code=?", code).fetchone()

    def friends_of(self, code):
        with self.lock:
            rows = self.q("SELECT requester, recipient FROM friends WHERE accepted=1 AND (requester=? OR recipient=?)",
                          code, code).fetchall()
        return {r["recipient"] if r["requester"] == code else r["requester"] for r in rows}

    def is_member(self, room, code):
        with self.lock:
            return self.q("SELECT 1 FROM members WHERE room=? AND code=?", room, code).fetchone() is not None

    def require_member(self, room, code):
        if not isinstance(room, str) or not self.is_member(room, code):
            raise ApiError(404, "That conversation is not available.")

    def cleanup(self):
        now = time.time()
        with self.lock:
            self.q("DELETE FROM signals WHERE created<?", now - SIGNAL_TTL)
            self.q("DELETE FROM calls WHERE seen<?", now - CALL_TIMEOUT)
            self.q("DELETE FROM grants WHERE expires<?", now)
            # Forget rate-limit history for senders with nothing in the last minute.
            for code in [c for c, times in self.message_times.items() if not times or now - times[-1] >= 60]:
                del self.message_times[code]
            if self.retention:
                cutoff = now - self.retention * 86400
                self.q("DELETE FROM blobs WHERE created<?", cutoff)
                self.q("DELETE FROM messages WHERE created<?", cutoff)


def public_profile(row):
    return {"code": row["code"], "name": row["name"], "contacts": json.loads(row["contacts"]),
            "shareContacts": bool(row["share"])}


class Social:
    def __init__(self, store):
        self.s = store

    def overview(self, visitor):
        s = self.s
        me = s.profile(visitor)
        if not me:
            return {"profile": None, "friends": [], "requests": [], "rooms": []}
        code = me["code"]
        with s.lock:
            friends = []
            for other in sorted(s.friends_of(code)):
                row = s.by_code(other)
                if row:
                    entry = {"code": row["code"], "name": row["name"]}
                    contacts = {k: v for k, v in json.loads(row["contacts"]).items() if v}
                    if row["share"] and contacts:
                        entry["contacts"] = contacts
                    friends.append(entry)
            requests = []
            for r in s.q("SELECT requester, recipient FROM friends WHERE accepted=0 AND (requester=? OR recipient=?)",
                         code, code).fetchall():
                outgoing = r["requester"] == code
                other = s.by_code(r["recipient"] if outgoing else r["requester"])
                if other:
                    requests.append({"code": other["code"], "name": other["name"], "outgoing": outgoing})
            rooms = []
            for r in s.q("SELECT rooms.id, rooms.title FROM rooms JOIN members ON members.room=rooms.id "
                         "WHERE members.code=? ORDER BY rooms.created", code).fetchall():
                last = s.q("SELECT MAX(id) AS last FROM messages WHERE room=? AND sender<>?", r["id"], code).fetchone()
                rooms.append({"id": r["id"], "title": r["title"], "lastOther": last["last"] or 0})
        return {"profile": public_profile(me), "friends": friends, "requests": requests, "rooms": rooms}

    def operate(self, visitor, body):
        op = body.get("op")
        handler = getattr(self, "op_" + str(op), None) if isinstance(op, str) and op.isalpha() else None
        if not handler:
            raise ApiError(400, "Unknown chat operation.")
        if op != "profile":
            me = self.s.require_profile(visitor)
            return handler(me, body)
        return handler(visitor, body)

    def op_profile(self, visitor, body):
        s = self.s
        existing = s.profile(visitor)
        name = clean_text(body.get("name", existing["name"] if existing else ""), 40)
        if not name:
            raise ApiError(400, "Enter a display name.")
        contacts_in = body.get("contacts") if isinstance(body.get("contacts"), dict) else (
            json.loads(existing["contacts"]) if existing else {})
        contacts = {k: clean_text(contacts_in.get(k, ""), limit) for k, limit in CONTACT_FIELDS.items()}
        contacts = {k: v for k, v in contacts.items() if v}
        share = 1 if body.get("shareContacts", bool(existing["share"]) if existing else False) is True else 0
        with s.lock:
            if existing:
                s.q("UPDATE profiles SET name=?, contacts=?, share=? WHERE visitor=?", name, json.dumps(contacts),
                    share, visitor)
            else:
                code = new_code()
                while s.by_code(code):
                    code = new_code()
                s.q("INSERT INTO profiles VALUES (?,?,?,?,?,?)", visitor, code, name, json.dumps(contacts), share,
                    time.time())
        return {"ok": True, "profile": public_profile(s.profile(visitor))}

    def op_friend(self, me, body):
        s = self.s
        code = clean_text(body.get("code"), 12).upper()
        other = s.by_code(code)
        if not other:
            raise ApiError(404, "No profile has that code.")
        if other["code"] == me["code"]:
            raise ApiError(400, "That is your own code.")
        with s.lock:
            pair = s.q("SELECT * FROM friends WHERE (requester=? AND recipient=?) OR (requester=? AND recipient=?)",
                       me["code"], code, code, me["code"]).fetchone()
            if pair and pair["accepted"]:
                raise ApiError(400, "You are already friends.")
            if pair and pair["requester"] == code:
                s.q("UPDATE friends SET accepted=1 WHERE requester=? AND recipient=?", code, me["code"])
                return {"ok": True, "accepted": True}
            if not pair:
                s.q("INSERT INTO friends VALUES (?,?,0,?)", me["code"], code, time.time())
        return {"ok": True}

    def op_accept(self, me, body):
        with self.s.lock:
            changed = self.s.q("UPDATE friends SET accepted=1 WHERE requester=? AND recipient=? AND accepted=0",
                               clean_text(body.get("code"), 12).upper(), me["code"]).rowcount
        if not changed:
            raise ApiError(404, "That friend request is no longer pending.")
        return {"ok": True}

    def op_decline(self, me, body):
        with self.s.lock:
            self.s.q("DELETE FROM friends WHERE requester=? AND recipient=? AND accepted=0",
                     clean_text(body.get("code"), 12).upper(), me["code"])
        return {"ok": True}

    def op_room(self, me, body):
        s = self.s
        codes = body.get("codes")
        if not isinstance(codes, list) or not codes or len(codes) > 24:
            raise ApiError(400, "Choose one to 24 friends for the room.")
        friends = s.friends_of(me["code"])
        chosen = sorted({str(c) for c in codes})
        if any(c not in friends for c in chosen):
            raise ApiError(403, "Rooms can include accepted friends only.")
        names = [s.by_code(c)["name"] for c in chosen]
        title = clean_text(body.get("title"), 60) or ", ".join([me["name"], *names])[:60]
        room = secrets.token_hex(8)
        with s.lock:
            s.q("INSERT INTO rooms VALUES (?,?,?,?)", room, title, me["code"], time.time())
            for code in [me["code"], *chosen]:
                s.q("INSERT OR IGNORE INTO members VALUES (?,?)", room, code)
        return {"ok": True, "room": room}

    def op_message(self, me, body):
        s = self.s
        room = body.get("room")
        s.require_member(room, me["code"])
        now = time.time()
        with s.lock:
            recent = [t for t in s.message_times.get(me["code"], []) if now - t < 60]
            if len(recent) >= 30:
                raise ApiError(429, "Too many messages. Wait a moment and try again.")
            s.message_times[me["code"]] = recent + [now]
        text = clean_text(body.get("text"), 4000)
        attachment = body.get("attachment")
        blob_id = blob_name = None
        if attachment:
            if not isinstance(attachment, dict):
                raise ApiError(400, "Invalid attachment.")
            mime = str(attachment.get("mime", "")).lower()
            if not ATTACHMENT_TYPES.match(mime):
                raise ApiError(400, "Attach an image, audio or video file.")
            try:
                data = base64.b64decode(str(attachment.get("data", "")), validate=True)
            except ValueError:
                raise ApiError(400, "Invalid attachment data.")
            if not data or len(data) > MAX_ATTACHMENT:
                raise ApiError(413, "File exceeds 6 MB. Use a shorter clip.")
            blob_id = secrets.token_urlsafe(18)
            blob_name = clean_text(attachment.get("name"), 120) or "attachment"
            with s.lock:
                s.q("INSERT INTO blobs VALUES (?,?,?,?,?)", blob_id, room, mime, data, now)
        if not text and not blob_id:
            raise ApiError(400, "Type a message or attach a file.")
        with s.lock:
            cur = s.q("INSERT INTO messages (room, sender, text, created, blob, blob_name) VALUES (?,?,?,?,?,?)",
                      room, me["code"], text, now, blob_id, blob_name)
        return {"ok": True, "id": cur.lastrowid}

    def op_call(self, me, body):
        s = self.s
        room = body.get("room")
        s.require_member(room, me["code"])
        session = clean_text(body.get("session"), 64)
        with s.lock:
            if body.get("active") is True:
                if not session:
                    raise ApiError(400, "Missing call session.")
                current = s.q("SELECT session FROM calls WHERE room=? AND code=?", room, me["code"]).fetchone()
                if current and current["session"] != session and not body.get("start"):
                    return {"ok": True, "active": False}
                s.q("INSERT INTO calls VALUES (?,?,?,?) ON CONFLICT(room,code) DO UPDATE SET session=excluded.session,"
                    " seen=excluded.seen", room, me["code"], session, time.time())
            else:
                s.q("DELETE FROM calls WHERE room=? AND code=? AND (?='' OR session=?)", room, me["code"], session,
                    session)
                s.q("DELETE FROM grants WHERE room=? AND (owner=? OR instructor=?)", room, me["code"], me["code"])
        return {"ok": True}

    def op_signal(self, me, body):
        s = self.s
        room = body.get("room")
        s.require_member(room, me["code"])
        target = clean_text(body.get("target"), 12)
        if not s.is_member(room, target) or target == me["code"]:
            raise ApiError(400, "That participant is not in this room.")
        payload = json.dumps(body.get("body"), separators=(",", ":"))
        if len(payload) > 65_000:
            raise ApiError(413, "Signal too large.")
        with s.lock:
            s.q("INSERT INTO signals (room, sender, target, body, created) VALUES (?,?,?,?,?)", room, me["code"],
                target, payload, time.time())
        return {"ok": True}

    def op_grant(self, me, body):
        s = self.s
        room = body.get("room")
        s.require_member(room, me["code"])
        target = clean_text(body.get("target"), 12)
        if not s.is_member(room, target) or target == me["code"]:
            raise ApiError(400, "That participant is not in this room.")
        with s.lock:
            s.q("DELETE FROM grants WHERE room=? AND owner=?", room, me["code"])
            s.q("INSERT INTO grants VALUES (?,?,?,?)", room, me["code"], target, time.time() + GRANT_SECONDS)
        return {"ok": True, "expires": time.time() + GRANT_SECONDS}

    def op_revoke(self, me, body):
        s = self.s
        room = body.get("room")
        s.require_member(room, me["code"])
        with s.lock:
            s.q("DELETE FROM grants WHERE room=? AND (owner=? OR instructor=?)", room, me["code"], me["code"])
        return {"ok": True}

    def room(self, visitor, room, after, signal_after):
        s = self.s
        me = s.require_profile(visitor)
        s.require_member(room, me["code"])
        s.cleanup()
        with s.lock:
            members = [{"code": r["code"], "name": r["name"]} for r in s.q(
                "SELECT profiles.code, profiles.name FROM members JOIN profiles ON profiles.code=members.code "
                "WHERE members.room=? ORDER BY profiles.name", room).fetchall()]
            names = {m["code"]: m["name"] for m in members}
            if after:
                rows = s.q("SELECT * FROM messages WHERE room=? AND id>? ORDER BY id LIMIT ?", room, after,
                           MESSAGE_PAGE).fetchall()
            else:
                rows = list(reversed(s.q("SELECT * FROM messages WHERE room=? ORDER BY id DESC LIMIT ?", room,
                                         MESSAGE_PAGE).fetchall()))
            messages = [{"id": r["id"], "sender": r["sender"], "name": names.get(r["sender"], "Former Member"),
                         "text": r["text"], "created": r["created"], "attachment": r["blob"],
                         "attachmentName": r["blob_name"]} for r in rows]
            signals = [{"id": r["id"], "sender": r["sender"], "body": json.loads(r["body"])} for r in s.q(
                "SELECT * FROM signals WHERE room=? AND target=? AND id>? ORDER BY id LIMIT 200", room, me["code"],
                signal_after).fetchall()]
            grants = [{"owner": r["owner"], "instructor": r["instructor"], "expires": r["expires"]}
                      for r in s.q("SELECT * FROM grants WHERE room=?", room).fetchall()]
            calls = s.q("SELECT code, session FROM calls WHERE room=?", room).fetchall()
        return {"members": members, "messages": messages, "signals": signals, "grants": grants,
                "callers": [c["code"] for c in calls], "callSessions": {c["code"]: c["session"] for c in calls}}

    def export(self, visitor, room):
        s = self.s
        me = s.require_profile(visitor)
        s.require_member(room, me["code"])
        with s.lock:
            title = s.q("SELECT title FROM rooms WHERE id=?", room).fetchone()["title"]
            rows = s.q("SELECT messages.*, profiles.name FROM messages LEFT JOIN profiles ON "
                       "profiles.code=messages.sender WHERE room=? ORDER BY id", room).fetchall()
        return {"title": title, "messages": [{"created": r["created"], "name": r["name"] or "Former Member",
                                              "text": r["text"], "attachmentName": r["blob_name"]} for r in rows]}

    def blob(self, visitor, blob_id):
        s = self.s
        me = s.require_profile(visitor)
        with s.lock:
            row = s.q("SELECT * FROM blobs WHERE id=?", blob_id).fetchone()
        if not row or not s.is_member(row["room"], me["code"]):
            raise ApiError(404, "Attachment unavailable.")
        return row["mime"], bytes(row["data"])


# ---- validation for stored documents ----
def need_object(value, message):
    if not isinstance(value, dict):
        raise ApiError(400, message)
    return value


def validate_default(doc):
    need_object(doc, "Invalid default layout.")
    if doc.get("format") != "wave-studio-default" or doc.get("version") != 1:
        raise ApiError(400, "Invalid default layout.")
    if not isinstance(doc.get("fixtures"), list) or not 1 <= len(doc["fixtures"]) <= 40:
        raise ApiError(400, "A default layout needs 1 to 40 fixtures.")
    return doc


def validate_workspace(doc):
    need_object(doc, "Invalid workspace document.")
    if doc.get("version") not in (1, 2) or not isinstance(doc.get("notes", ""), str):
        raise ApiError(400, "Invalid workspace document.")
    return doc


def validate_custom_layouts(doc):
    need_object(doc, "Invalid layout library.")
    # Both halves are required: defaulting a missing half would silently delete it.
    if not isinstance(doc.get("checkpoints"), dict) or not isinstance(doc.get("layouts"), list):
        raise ApiError(400, "Invalid layout library.")
    if len(doc.get("layouts", [])) > 24:
        raise ApiError(400, "Up to 24 Customized Layouts can be saved.")
    return {"version": 1, "checkpoints": doc["checkpoints"], "layouts": doc["layouts"]}


def validate_preferences(doc):
    need_object(doc, "Invalid preferences.")
    minutes = doc.get("minutes")
    if not isinstance(doc.get("enabled"), bool) or isinstance(minutes, bool) or \
            not isinstance(minutes, (int, float)) or not 0.1 <= minutes <= 1440:
        raise ApiError(400, "Autosave needs an interval between 0.1 and 1440 minutes.")
    return {"enabled": doc["enabled"], "minutes": minutes}


def validate_session(doc, session_id):
    need_object(doc, "Invalid session document.")
    if doc.get("format") != "wave-studio-session" or doc.get("version") != 1 or doc.get("id") != session_id:
        raise ApiError(400, "Invalid session document.")
    if not isinstance(doc.get("actions"), list) or len(doc["actions"]) > 2000:
        raise ApiError(400, "Invalid session actions.")
    return doc


DEFAULT_ORIGINS = frozenset(f"http://{host}:{port}" for host in ("127.0.0.1", "localhost") for port in (8765, 8766))


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    timeout = 30  # reap stalled or idle connections so they cannot pin threads
    body_read = False
    server_version = "WaveStudioServer/" + SERVER_VERSION

    # ---- plumbing ----
    def origin_allowed(self, origin):
        if not origin:
            return True
        # Only the Wave Studio pages themselves (receiver 8765, grandMA3 PoC 8766) plus any --allow-origin.
        # Other local pages (dev servers, tools) must not read or write this visitor's data.
        return origin in DEFAULT_ORIGINS or origin in self.server.allowed_origins

    def cors(self):
        origin = self.headers.get("Origin")
        if origin and self.origin_allowed(origin):
            self.send_header("Access-Control-Allow-Origin", origin)
            self.send_header("Vary", "Origin")
            self.send_header("Access-Control-Allow-Methods", "GET, PUT, POST, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "Content-Type, X-Wave-Dev-Visitor, X-Wave-Base-Revision")
            self.send_header("Access-Control-Expose-Headers", "X-Wave-Revision")
            self.send_header("Access-Control-Max-Age", "600")

    def send_bytes(self, status, data, content_type):
        self.send_response(status)
        self.cors()
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        for name, value in getattr(self, "extra_headers", ()):
            self.send_header(name, value)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(data)

    def send_json(self, status, value):
        self.send_bytes(status, json.dumps(value, separators=(",", ":")).encode(), "application/json")

    def visitor(self):
        trusted = self.server.trusted_visitor_header
        if trusted:
            value = self.headers.get(trusted, "")
            if re.fullmatch(r"[A-Za-z0-9._:-]{8,128}", value):
                return "hdr:" + value
        if self.client_address[0] in ("127.0.0.1", "::1") and self.headers.get("X-Wave-Dev-Visitor"):
            if self.server.split_by_origin:
                origin = self.headers.get("Origin") or "same-origin"
                return "local:" + origin
            return "local:" + clean_text(self.headers.get("X-Wave-Dev-Visitor"), 64)
        raise ApiError(401, "Private storage identity unavailable.")

    def read_json(self):
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            raise ApiError(400, "Invalid Content-Length.")
        if length < 0:
            raise ApiError(400, "Invalid Content-Length.")
        if length > MAX_BODY:
            raise ApiError(413, "Request too large.")
        raw = self.rfile.read(length) if length else b""
        self.body_read = True
        try:
            return json.loads(raw or b"null"), len(raw)
        except ValueError:
            raise ApiError(400, "Request body must be JSON.")

    def host_allowed(self):
        """Block DNS-rebinding when bound to loopback: the Host must be this computer."""
        if not self.server.loopback_only:
            return True
        port = self.server.server_port
        return self.headers.get("Host", "") in {f"127.0.0.1:{port}", f"localhost:{port}", f"[::1]:{port}"}

    def handle_api(self):
        if not self.host_allowed():
            raise ApiError(403, "Local Wave Studio host required.")
        if not self.origin_allowed(self.headers.get("Origin")):
            raise ApiError(403, "Origin not allowed.")
        url = urlparse(self.path)
        path, method = url.path.rstrip("/"), self.command
        if path == "/api/health":
            return self.send_json(200, {"ok": True, "app": "wave-studio-server", "version": SERVER_VERSION})
        visitor = self.visitor()
        store, social = self.server.store, self.server.social
        simple = {"/api/default-layout": ("default-layout", validate_default, None),
                  "/api/workspace": ("workspace", validate_workspace, None),
                  "/api/custom-layouts": ("custom-layouts", validate_custom_layouts,
                                          {"version": 1, "checkpoints": {}, "layouts": []}),
                  "/api/preferences": ("preferences", validate_preferences, {"enabled": True, "minutes": 5})}
        if path in simple:
            kind, validate, fallback = simple[path]
            if kind == "workspace":
                return self.workspace(visitor, method, validate)
            if method == "GET":
                return self.send_json(200, store.get_doc(visitor, kind) or fallback)
            if method == "PUT":
                body, size = self.read_json()
                if size > LIMITS[kind]:
                    raise ApiError(413, "Document too large.")
                store.put_doc(visitor, kind, validate(body))
                return self.send_json(200, {"ok": True})
            raise ApiError(405, "Method not allowed.")
        if path == "/api/sessions" and method == "GET":
            return self.send_json(200, store.list_sessions(visitor))
        match = re.fullmatch(r"/api/sessions/([0-9a-f-]{36})", path)
        if match and UUID.match(match[1]):
            if method == "GET":
                doc = store.get_doc(visitor, "session", match[1])
                if doc is None:
                    raise ApiError(404, "Session not found.")
                return self.send_json(200, doc)
            if method == "PUT":
                body, size = self.read_json()
                if size > LIMITS["session"]:
                    raise ApiError(413, "Session too large. Download it instead.")
                result = store.put_session(visitor, validate_session(body, match[1]))
                return self.send_json(200, {"ok": True, **result})
            raise ApiError(405, "Method not allowed.")
        if path == "/api/social":
            if method == "GET":
                return self.send_json(200, social.overview(visitor))
            if method == "POST":
                body, _ = self.read_json()
                return self.send_json(200, social.operate(visitor, need_object(body, "Invalid chat request.")))
            raise ApiError(405, "Method not allowed.")
        match = re.fullmatch(r"/api/social/room/([0-9a-f]{16})(/export)?", path)
        if match and method == "GET":
            if match[2]:
                return self.send_json(200, social.export(visitor, match[1]))
            query = parse_qs(url.query)
            try:  # clamp so huge cursors cannot overflow SQLite's 64-bit integers
                after = min(2**62, max(0, int(query.get("after", ["0"])[0])))
                signal_after = min(2**62, max(0, int(query.get("signal_after", ["0"])[0])))
            except ValueError:
                raise ApiError(400, "Invalid cursor.")
            return self.send_json(200, social.room(visitor, match[1], after, signal_after))
        match = re.fullmatch(r"/api/social/blob/([A-Za-z0-9_-]{16,40})", path)
        if match and method == "GET":
            mime, data = social.blob(visitor, match[1])
            return self.send_bytes(200, data, mime)
        raise ApiError(404, "Not found.")

    def workspace(self, visitor, method, validate):
        """Workspace saves carry the revision they were based on, so a stale tab
        cannot silently overwrite a newer save from another tab (409 instead)."""
        store = self.server.store
        if method == "GET":
            self.extra_headers = [("X-Wave-Revision", store.doc_revision(visitor, "workspace"))]
            return self.send_json(200, store.get_doc(visitor, "workspace"))
        if method != "PUT":
            raise ApiError(405, "Method not allowed.")
        body, size = self.read_json()
        if size > LIMITS["workspace"]:
            raise ApiError(413, "Document too large.")
        base = self.headers.get("X-Wave-Base-Revision")
        if base is not None and not re.fullmatch(r"[0-9.e+-]{1,32}", base):
            raise ApiError(400, "Invalid revision.")
        revision = store.put_doc_if(visitor, "workspace", validate(body), base)
        if revision is None:
            self.extra_headers = [("X-Wave-Revision", store.doc_revision(visitor, "workspace"))]
            raise ApiError(409, "Another Wave Studio tab saved a newer workspace.")
        self.extra_headers = [("X-Wave-Revision", revision)]
        return self.send_json(200, {"ok": True, "revision": revision})

    def dispatch(self):
        self.body_read = False
        self.extra_headers = []
        try:
            if not self.path.startswith("/api/"):
                raise ApiError(404, "Not found.")
            self.handle_api()
        except ApiError as error:
            self.drop_unread_body()
            self.send_json(error.status, {"detail": error.detail})
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as error:  # keep the server alive; report a generic error
            self.log_error("Unhandled error: %r", error)
            self.drop_unread_body()
            self.send_json(500, {"detail": "Server error."})

    def drop_unread_body(self):
        """An error before the body was read would leave its bytes on a keep-alive
        connection, where they would be parsed as the next request. Close instead."""
        declared = self.headers.get("Content-Length") or self.headers.get("Transfer-Encoding")
        if declared and declared.strip() != "0" and not self.body_read:
            self.close_connection = True

    do_GET = do_PUT = do_POST = dispatch

    def do_OPTIONS(self):
        if not self.host_allowed():
            return self.send_json(403, {"detail": "Local Wave Studio host required."})
        if not self.origin_allowed(self.headers.get("Origin")):
            return self.send_json(403, {"detail": "Origin not allowed."})
        self.send_response(204)
        self.cors()
        self.send_header("Content-Length", "0")
        self.end_headers()

    def log_message(self, message, *args):
        if self.server.verbose:
            super().log_message(message, *args)


def make_server(host="127.0.0.1", port=8093, db=DEFAULT_DB, allowed_origins=(), trusted_visitor_header=None,
                split_by_origin=False, chat_retention_days=0, verbose=False):
    server = ThreadingHTTPServer((host, port), Handler)
    server.daemon_threads = True
    server.store = Store(db, chat_retention_days)
    server.social = Social(server.store)
    server.allowed_origins = set(allowed_origins)
    server.trusted_visitor_header = trusted_visitor_header
    server.split_by_origin = split_by_origin
    server.verbose = verbose
    server.loopback_only = host in ("127.0.0.1", "localhost", "::1")
    return server


def main():
    parser = argparse.ArgumentParser(description="Wave Studio local backend (storage and chat)")
    parser.add_argument("--host", default="127.0.0.1", help="Listening address (default: loopback only)")
    parser.add_argument("--port", type=int, default=8093)
    parser.add_argument("--db", type=Path, default=Path(os.environ.get("WAVE_STUDIO_DB", DEFAULT_DB)))
    parser.add_argument("--allow-origin", action="append", default=[],
                        help="Extra browser origin allowed to call the API (the Wave Studio pages on ports 8765 and 8766 are always allowed)")
    parser.add_argument("--trusted-visitor-header",
                        help="Header set by a trusted reverse proxy that identifies each visitor")
    parser.add_argument("--split-visitors-by-origin", action="store_true",
                        help="Local testing: treat each page origin (port) as a separate visitor")
    parser.add_argument("--chat-retention-days", type=float, default=0,
                        help="Delete chat messages and attachments older than this (0 keeps them)")
    parser.add_argument("--verbose", action="store_true")
    args = parser.parse_args()
    if args.host not in ("127.0.0.1", "localhost", "::1"):
        print("WARNING: listening beyond this computer. Put HTTPS and an authenticating proxy in front, and use "
              "--trusted-visitor-header. Data is stored unencrypted.", flush=True)
    server = make_server(args.host, args.port, args.db, args.allow_origin, args.trusted_visitor_header,
                         args.split_visitors_by_origin, args.chat_retention_days, args.verbose)
    print(f"\nWAVE STUDIO SERVER {SERVER_VERSION}\nAPI: http://{args.host}:{args.port}/api/health\n"
          f"Database: {Path(args.db).resolve()}\n"
          "Stores workspaces, layouts, sessions and chat. Sends no DMX or firing data.\n"
          "Keep this window open. Press Ctrl+C to stop.\n", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
