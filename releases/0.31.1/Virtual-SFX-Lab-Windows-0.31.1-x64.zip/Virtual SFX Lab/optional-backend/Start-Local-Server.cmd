@echo off
setlocal
cd /d "%~dp0"
title Wave Studio - local server (storage and chat)
set "PYCMD="
py -3 --version >nul 2>&1 && set "PYCMD=py -3"
if not defined PYCMD (
  python --version >nul 2>&1 && set "PYCMD=python"
)
if not defined PYCMD (
  echo Python was not found. Install Python 3.10 or newer from https://www.python.org/downloads/windows/
  pause
  exit /b 1
)
%PYCMD% -B server.py %*
echo.
echo Server stopped.
pause
