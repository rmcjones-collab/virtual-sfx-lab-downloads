@echo off
setlocal
cd /d "%~dp0"
title Wave Studio - Vista Check (receive-only)
echo.
echo WAVE STUDIO - VISTA CHECK
echo Receive-only. Sends no DMX or firing commands. Keep flame hardware disconnected.
echo Close the Wave Studio receiver window first; both use the same UDP port.
echo.

set "PYCMD="
py -3 --version >nul 2>&1 && set "PYCMD=py -3"
if not defined PYCMD (
  python --version >nul 2>&1 && set "PYCMD=python"
)
if not defined PYCMD (
  echo Python was not found. Install Python 3.10 or newer from https://www.python.org/downloads/windows/
  pause
  exit /b 1
)
if not exist "vista_check.py" (
  echo vista_check.py is missing. Extract the complete ZIP into a folder and run this from there.
  pause
  exit /b 1
)

echo 1 = sACN  (Vista on this PC, or any PC on the network)   [default]
echo 2 = Art-Net (this PC is a separate receiver PC)
set "MODE=1"
set /p "MODE=Choose 1 or 2: "
if "%MODE%"=="2" (
  set "ARGS=--protocol artnet"
) else (
  echo.
  echo Enter the IPv4 address selected in Vista's Network preferences,
  echo or press Enter for the Windows default interface.
  set "VISTA_IP="
  set /p "VISTA_IP=Vista interface IPv4: "
  if not defined VISTA_IP set "VISTA_IP=0.0.0.0"
)
if not "%MODE%"=="2" set "ARGS=--protocol sacn --interface %VISTA_IP%"
echo.
echo Listening for 30 seconds. Start your Vista rehearsal cue now (output on, flame hardware disconnected).
echo.
%PYCMD% -B vista_check.py %ARGS% %*
echo.
echo The report was saved next to this file as Vista-Check-^<date-time^>.txt
pause
