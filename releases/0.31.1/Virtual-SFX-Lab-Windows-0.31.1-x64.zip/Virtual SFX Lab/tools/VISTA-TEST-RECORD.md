# Wave Studio × Vista: Windows Test Record (Beta 0.29)

Copy this file for each session (one copy per PC or setup change). Mark each check **PASS**, **FAIL**, **BLOCKED** or **NOT RUN**, and attach the matching `Vista-Check-*.txt` report and a screenshot of the DMX monitor where asked.

Rules for every session:

- Use a **rehearsal copy** of the Vista show. Physical flame fixtures stay **disconnected** from the PC and the network for the whole session.
- Wave Studio only receives. Passing every check here proves the network path and the visualization, nothing about real X2 behaviour, firing or safety.
- If a check fails, stop, fill in a failure report (bottom), and carry on with the next section only if it does not depend on the failed one.

## Environment

| Item | Value |
|---|---|
| Date and tester | |
| Windows edition and version (Settings → System → About) | |
| PC model / CPU / GPU | |
| Python version (`py -3 --version`) | |
| Browser and version | |
| Vista version (Help → About) and dongle type | |
| Setup | Same PC (sACN) / Separate receiver PC (Art-Net) |
| Network adapters in use and the IPv4 Vista shows in Network preferences | |
| Vista universe → sACN universe (or Art-Net Net/Sub-Net/Universe) | |
| Fixture profile used in Vista (X2 build sheet / six generic channels) | |
| Flame hardware physically disconnected | Yes / No |

## 1. Install and start (no Vista needed)

| # | Check | Result | Evidence / comments |
|---|---|---|---|
| 1.1 | ZIP extracted to a normal folder (not run from inside the ZIP) | | |
| 1.2 | `Start-Wave-Studio-sACN.cmd` finds Python 3.10+ and starts; console says **sACN input: UDP 5568**, universes **1, 2, 3, 4**, Art-Net 6454 not opened | | |
| 1.3 | Windows Firewall prompt (if any) answered for **Private** networks only | | Write what the prompt said |
| 1.4 | Browser opens `http://127.0.0.1:8765`; the page shows **Beta 0.29**; no error banner | | |
| 1.5 | Live button reads **Live sACN**; DMX monitor shows **Waiting for sACN data** | | |
| 1.6 | Closing the console window stops the receiver; restarting it works (no "address already in use") | | |
| 1.7 | `Run-Receiver-Tests.cmd` ends with **OK** | | Paste the last 3 lines |

## 2. Network check with Vista Check (receiver closed)

Close the receiver window, start Vista with the rehearsal show, set a fixture on universe 1, address 1 to the **visual-only first cue** (CH1 128, CH2 0, CH3 0, CH4 0, CH5 131, CH6 128). Then double-click `Run-Vista-Check.cmd`, choose **1 (sACN)**, enter Vista's interface IPv4 and, while it listens, take CH3 to 255 and back to 0 twice.

| # | Check | Result | Evidence / comments |
|---|---|---|---|
| 2.1 | Report says **RESULT: DMX RECEIVED** (same-PC multicast works on this PC) | | If NO DMX RECEIVED: try once with the interface blank, then record both reports |
| 2.2 | Source address and source name are Vista's; only **one** sender is listed | | |
| 2.3 | Packet rate is steady (write the /s figure) and **lost = 0**, **out of order = 0** | | |
| 2.4 | Longest gap is under **2500 ms** | | |
| 2.5 | Priority matches Vista's output setting (normally **100**) | | |
| 2.6 | Address 1 shows **Program 131 = preset 51**, **mode armed (50-200)** | | |
| 2.7 | **2 CH3 edges**, each marked **would trigger a preset** | | |
| 2.8 | Optional: Vista output on universe 2-4 or a high universe (start the check with `--universes 1,40000`) shows up under the right universe | | |

## 3. Live visualization (receiver running, Vista outputting)

Start `Start-Wave-Studio-sACN.cmd` again with Vista's IPv4. Patch two virtual fixtures in Wave Studio to **sACN universe 1, addresses 1 and 7** and Vista to match. Click **Live sACN**.

| # | Check | Result | Evidence / comments |
|---|---|---|---|
| 3.1 | DMX packets counter rises; **rejected**, **source conflicts** stay 0 | | Screenshot of monitor |
| 3.2 | All six monitor values follow Vista's faders/encoders for fixture 1, then fixture 2 | | |
| 3.3 | CH1 moves the virtual head left/right across the full range (0 = one end, 255 = other) | | |
| 3.4 | Visual-only first cue: CH3 0 → 255 plays **preset 51 once** | | |
| 3.5 | Holding CH3 at 255 does **not** retrigger; back to 0 then 255 plays it again | | |
| 3.6 | CH6 set to 0 (or 255): monitor shows **Test mode: no flame**; CH3 edge does not play | | |
| 3.7 | CH5 set to 240: CH3 edge does not play (unsupported program) | | |
| 3.8 | Fixtures 1 and 7 trigger independently from separate Vista cues | | |
| 3.9 | A short Vista cue list (3+ cues with fades and follows) plays back with the expected visual timing | | Note anything that looks late or early |
| 3.10 | Turning Vista's sACN output off: after about **2.5 s** the monitor shows **Signal lost** and effects clear | | |
| 3.11 | Turning output back on with CH3 already at 255: **no** effect starts until CH3 goes low then high | | |
| 3.12 | Closing Vista (stream terminated) clears effects at once; the terminated counter goes up | | |
| 3.13 | Browser tab left visible for 15 minutes of looping cues: no stalls, no growing lag | | |

## 4. Vista files from Wave Studio (manual-build preview)

| # | Check | Result | Evidence / comments |
|---|---|---|---|
| 4.1 | **Export For Vista 3** downloads a ZIP; it opens in Windows Explorer and contains the patch CSV, cuelist CSVs and build sheet | | |
| 4.2 | The fixture build sheet is enough to build the six-channel profile in the Vista 3 Fixture Editor | | Note any field that did not match |
| 4.3 | Cue-list CSV opens in Excel/Notepad with correct names, timing and CH3 stored at 0 (Fire Pulse column shows 255 then 0) | | |
| 4.4 | If your Vista has **File > Import Cues CSV**, the cuelist CSV imports; note any rejected column | | Write the exact Vista message |
| 4.5 | Cues imported or rebuilt in Vista play back in Wave Studio as they did inside Wave Studio | | |

## 5. Art-Net on a separate receiver PC (optional)

| # | Check | Result | Evidence / comments |
|---|---|---|---|
| 5.1 | `Run-Vista-Check.cmd` → **2 (Art-Net)** on the receiver PC shows DMX from the Vista PC | | Attach report |
| 5.2 | `Start-Wave-Studio.cmd` on the receiver PC: **Wave Studio** appears in Vista's Connect Universes | | |
| 5.3 | Port-addresses 0-3 route correctly; monitor values follow Vista | | |

## 6. Local server (optional)

| # | Check | Result | Evidence / comments |
|---|---|---|---|
| 6.1 | `Start-Wave-Studio-Server.cmd` starts on 127.0.0.1:8093 | | |
| 6.2 | A custom layout and a session log survive closing and reopening the browser | | |

## Summary

- Sections passed: ____ / failed: ____ / blocked: ____
- Biggest open question after this session:
- Next step:

## Failure report

Copy this block for each failure.

```text
Check number:
What I did (exact clicks / Vista settings):
Expected:
What happened (exact message or monitor counters):
Happens every time / sometimes / once:
Vista Check report attached (file name):
Screenshot attached (file name):
Receiver console text (last 20 lines):
```

Do not include passwords, licence keys or client information in screenshots or reports.
