"""Wave Studio Vista Check: a receive-only network check for Windows + Vista testing.

Listens (never transmits) for Vista's sACN or Art-Net output for a set time, then writes a plain-text
report you can keep with your test record or send to whoever is helping you. It answers:

- Is anything arriving at all, from which source address and source name?
- Which universes, at what rate, with what sACN priority, and are packets lost or out of order?
- For each six-channel X2 slot (addresses 1, 7, 13 ... 499) that changed: angle range, program,
  mode, and every CH3 trigger edge (a change into 254-255), as the visualizer would see it.

Close Wave Studio's receiver first: both need the same UDP port. This tool is not a firing or
safety check and says nothing about real flame hardware.

    py -3 vista_check.py                         sACN universes 1-4, Windows default interface
    py -3 vista_check.py --interface 192.168.137.1 --seconds 60
    py -3 vista_check.py --protocol artnet       Art-Net port-addresses 0-3 (separate receiver PC)
"""
import argparse
import ipaddress
import platform
import socket
import sys
import time
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import receiver  # noqa: E402  (same folder in the Windows package and the repo)

FIELDS = ("Angle", "Speed", "Trigger", "Open time", "Program", "Mode")


def load_starts():
    """CH5 preset start values, read from the web app so both always agree."""
    import re
    try:
        text = (receiver.WEB / "dmx.js").read_text(encoding="utf-8")
        starts = [int(v) for v in re.search(r"DMX_STARTS=\[([\d,]+)\]", text).group(1).split(",")]
        return starts if len(starts) == 88 else None
    except (OSError, AttributeError, ValueError):
        return None


STARTS = load_starts()


def program_label(value):
    """CH5: 0-2 direct, 3-226 presets 1-88, 227-255 unsupported."""
    if value <= 2:
        return f"{value} = direct control"
    if value >= 227:
        return f"{value} = unsupported (227-255)"
    if not STARTS:
        return f"{value} = a preset"
    return f"{value} = preset {sum(1 for start in STARTS if value >= start):02d}"


def trigger_note(program, armed):
    if not armed:
        return "would NOT trigger: CH6 mode outside 50-200"
    if program >= 227:
        return "would NOT trigger: CH5 227-255 unsupported"
    return "would trigger (direct control)" if program <= 2 else "would trigger a preset"


class Slot:
    """One six-channel fixture footprint inside a universe."""

    def __init__(self, address):
        self.address = address
        self.first = None
        self.last = None
        self.changed = False
        self.angle = [255, 0]
        self.programs = set()
        self.modes = set()
        self.edges = []          # (seconds from start, program, mode, armed)
        self.started_high = False

    def feed(self, values, t):
        ch = values[self.address - 1:self.address + 5]
        if len(ch) < 6:
            return
        if self.first is None:
            self.first = ch
            self.started_high = ch[2] >= 254
        elif ch != self.last:
            self.changed = True
        if self.last is not None and self.last[2] < 254 <= ch[2]:
            self.edges.append((t, ch[4], ch[5], 50 <= ch[5] <= 200))
        self.angle = [min(self.angle[0], ch[0]), max(self.angle[1], ch[0])]
        self.programs.add(ch[4])
        self.modes.add(ch[5])
        self.last = ch

    @property
    def active(self):
        return self.changed or any(self.first or ())


class Stream:
    """Packets for one (source address, universe)."""

    def __init__(self, protocol, source, universe):
        self.protocol, self.source, self.universe = protocol, source, universe
        self.packets = self.lost = self.out_of_order = self.preview = self.terminated = 0
        self.first_time = self.last_time = None
        self.max_gap = 0.0
        self.names, self.priorities, self.cids = set(), set(), set()
        self.sequence = None
        self.slots = {a: Slot(a) for a in range(1, 508, 6)}

    def feed(self, packet, now, start):
        self.packets += 1
        if self.last_time is not None:
            self.max_gap = max(self.max_gap, now - self.last_time)
        self.first_time = self.first_time if self.first_time is not None else now
        self.last_time = now
        seq = packet.get("sequence")
        if self.sequence is not None and seq is not None:
            step = (seq - self.sequence) % 256
            if step == 0 or step > 236:     # duplicate or backwards (E1.31 6.7.2 window)
                self.out_of_order += 1
                return
            self.lost += step - 1
        self.sequence = seq
        if self.protocol == "sACN":
            self.names.add(packet["sourceName"])
            self.priorities.add(packet["priority"])
            self.cids.add(packet["cid"])
            if packet["preview"]:
                self.preview += 1
                return
            if packet["terminated"]:
                self.terminated += 1
        values = packet["values"] + [0] * (512 - len(packet["values"]))
        for slot in self.slots.values():
            slot.feed(values, now - start)

    @property
    def rate(self):
        span = (self.last_time or 0) - (self.first_time or 0)
        return (self.packets - 1) / span if span > 0 and self.packets > 1 else 0.0


class Check:
    def __init__(self, protocol, universes):
        self.protocol = "sACN" if protocol == "sacn" else "Art-Net"
        self.universes = universes
        self.streams = {}
        self.udp = self.rejected = self.other_universe = 0
        self.start = time.monotonic()

    def feed(self, data, source, now=None):
        now = time.monotonic() if now is None else now
        self.udp += 1
        if self.protocol == "sACN":
            packet = receiver.parse_sacn(data)
            universe = packet and packet["wireUniverse"]
        else:
            if data[:8] == b"Art-Net\0" and len(data) >= 10 and data[8:10] != b"\x00\x50":
                return                      # ArtPoll / ArtPollReply etc.: not DMX
            packet = receiver.parse_artdmx(data)
            universe = packet and packet["universe"]
        if not packet:
            self.rejected += 1
            return
        if universe not in self.universes:
            self.other_universe += 1
            return
        key = (source, universe)
        if key not in self.streams:
            self.streams[key] = Stream(self.protocol, source, universe)
        self.streams[key].feed(packet, now, self.start)


def local_ipv4():
    found = set()
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            found.add(info[4][0])
    except OSError:
        pass
    try:  # UDP connect sends nothing; it only asks Windows which interface has the default route
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as probe:
            probe.connect(("192.0.2.1", 9))
            found.add(probe.getsockname()[0])
    except OSError:
        pass
    return sorted(found, key=lambda a: (a.startswith("127."), a))


def tcp_in_use(port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.3)
        return s.connect_ex(("127.0.0.1", port)) == 0


def report(check, args, environment, error=None):
    lines = ["WAVE STUDIO VISTA CHECK (receive-only)", "=" * 38,
             f"Date: {datetime.now():%Y-%m-%d %H:%M:%S}",
             f"Listen: {check.protocol} on UDP {receiver.SACN_PORT if check.protocol == 'sACN' else receiver.ARTNET_PORT}"
             f" for {args.seconds:g} s, interface {args.interface}",
             f"Universes: {', '.join(map(str, check.universes))}"
             + (" (sACN, 1-based)" if check.protocol == "sACN" else " (Art-Net port-addresses, 0-based)"),
             ""]
    lines += [f"{k}: {v}" for k, v in environment.items()] + [""]
    if error:
        lines += ["RESULT: COULD NOT LISTEN", error, ""]
    lines += [f"UDP datagrams: {check.udp} · valid DMX: {sum(s.packets for s in check.streams.values())}"
              f" · rejected/malformed: {check.rejected} · other universes: {check.other_universe}", ""]
    if not check.streams and not error:
        lines += ["RESULT: NO DMX RECEIVED", "Things to check, in order:"]
        if check.protocol == "sACN":
            lines += ["- Vista is running the rehearsal show and its Streaming ACN output is added, enabled and"
                      " assigned to a Vista universe.",
                      f"- The sACN universe in Vista is one of: {', '.join(map(str, check.universes))}.",
                      "- --interface is the IPv4 address shown in Vista's Network preferences"
                      " (one of the local addresses above).",
                      "- Windows Firewall allowed Python on the private rehearsal network.",
                      "- Same-PC Vista: multicast loopback depends on Vista and Windows. If nothing arrives,"
                      " note it in the test record; it is a known open question."]
        else:
            lines += ["- Vista's Art-Net output is enabled and routed to these port-addresses.",
                      "- This PC is the separate receiver PC (Art-Net cannot share UDP 6454 with Vista on one PC).",
                      "- Windows Firewall allowed Python on the private rehearsal network."]
        lines.append("")
    elif check.streams:
        lines.append("RESULT: DMX RECEIVED")
        lines.append("")
    sources = {s.source for s in check.streams.values()}
    if len(sources) > 1:
        lines += [f"NOTE: {len(sources)} different senders: {', '.join(sorted(sources))}. Wave Studio follows one;"
                  " use --source-ip on the receiver to pick Vista.", ""]
    for (source, universe), s in sorted(check.streams.items(), key=lambda kv: (kv[0][1], kv[0][0])):
        head = f"Universe {universe} from {source}"
        if s.names:
            head += f" · \"{', '.join(sorted(s.names))}\""
        lines += [head, "-" * len(head),
                  f"Packets {s.packets} · {s.rate:.1f}/s · longest gap {s.max_gap * 1000:.0f} ms"
                  f" · lost {s.lost} · out of order/duplicate {s.out_of_order}"]
        if s.protocol == "sACN":
            lines.append(f"Priority {', '.join(map(str, sorted(s.priorities)))} · preview frames {s.preview}"
                         f" · stream terminated {s.terminated}" + (" · MORE THAN ONE CID" if len(s.cids) > 1 else ""))
        if s.max_gap > 2.5:
            lines.append("WARNING: a gap over 2.5 s; Wave Studio shows signal loss after that.")
        active = [slot for slot in s.slots.values() if slot.active]
        if not active:
            lines.append("All six-channel slots stayed at 0.")
        for slot in active:
            last = slot.last
            lines.append(f"  Address {slot.address:>3} (CH{slot.address}-{slot.address + 5}): now "
                         + ", ".join(f"{name} {v}" for name, v in zip(FIELDS, last)))
            lines.append(f"      angle range {slot.angle[0]}-{slot.angle[1]} · program {program_label(last[4])}"
                         f" · mode {'armed (50-200)' if 50 <= last[5] <= 200 else 'test/not armed'}"
                         f" · CH3 edges {len(slot.edges)}"
                         + (" · CH3 was already high at start (not a trigger)" if slot.started_high else ""))
            for t, program, mode, armed in slot.edges[:20]:
                lines.append(f"      {t:7.2f} s  CH3 -> high  program {program_label(program)}  mode {mode}"
                             f"  {trigger_note(program, armed)}")
            if len(slot.edges) > 20:
                lines.append(f"      ... {len(slot.edges) - 20} more")
        lines.append("")
    lines += ["This report is a receive-only network check. It is not a firing, show or safety test,",
              "and it does not validate behaviour of real X2 hardware."]
    return "\n".join(lines) + "\n"


def parse_universes(text, sacn):
    universes = sorted({int(v.strip()) for v in text.split(",") if v.strip()})
    return receiver.check_universes(universes, sacn)


def main(argv=None):
    parser = argparse.ArgumentParser(description="Wave Studio Vista Check (receive-only)")
    parser.add_argument("--protocol", choices=("sacn", "artnet"), default="sacn")
    parser.add_argument("--interface", default="0.0.0.0", help="sACN multicast interface IPv4 (Vista's)")
    parser.add_argument("--universes", help="sACN 1-63999 (default 1,2,3,4); Art-Net 0-32767 (default 0,1,2,3)")
    parser.add_argument("--seconds", type=float, default=30)
    parser.add_argument("--out", type=Path, help="Report file (default: Vista-Check-<date-time>.txt here)")
    args = parser.parse_args(argv)
    sacn = args.protocol == "sacn"
    try:
        ipaddress.IPv4Address(args.interface)
        universes = parse_universes(args.universes or ("1,2,3,4" if sacn else "0,1,2,3"), sacn)
        if not 1 <= args.seconds <= 3600:
            raise ValueError("--seconds must be 1-3600")
    except ValueError as error:
        parser.error(str(error))
    check = Check(args.protocol, universes)
    environment = {
        "Windows / OS": platform.platform(),
        "Python": platform.python_version(),
        "Local IPv4 addresses": ", ".join(local_ipv4()) or "none found",
        "Wave Studio receiver on 127.0.0.1:8765": "RUNNING (close it first)" if tcp_in_use(8765) else "not running",
        "Wave Studio server on 127.0.0.1:8093": "running" if tcp_in_use(8093) else "not running",
    }
    error = None
    print(f"Listening for {check.protocol} for {args.seconds:g} s (receive-only). Run your Vista cue now ...", flush=True)
    try:
        sock = receiver.open_input_socket(args.protocol, "0.0.0.0", args.interface, universes)
    except OSError as exc:
        sock = None
        port = receiver.SACN_PORT if sacn else receiver.ARTNET_PORT
        error = (f"UDP {port} could not be opened: {exc}. Close the Wave Studio receiver (and on Art-Net,"
                 " any other Art-Net program such as Vista on this PC), then try again.")
    if sock:
        sock.settimeout(0.25)
        end = time.monotonic() + args.seconds
        last_print = 0
        try:
            while time.monotonic() < end:
                try:
                    data, (source, _) = sock.recvfrom(1500)
                    check.feed(data, source)
                except socket.timeout:
                    pass
                if time.monotonic() - last_print >= 5:
                    last_print = time.monotonic()
                    print(f"  {int(end - last_print):>4} s left · {check.udp} UDP datagrams", flush=True)
        except KeyboardInterrupt:
            print("Stopped early.")
        finally:
            sock.close()
    text = report(check, args, environment, error)
    out = args.out or Path(__file__).resolve().parent / f"Vista-Check-{datetime.now():%Y%m%d-%H%M%S}.txt"
    out.write_text(text, encoding="utf-8")
    print("\n" + text + f"Saved: {out}")
    return 1 if error or not check.streams else 0


if __name__ == "__main__":
    sys.exit(main())
