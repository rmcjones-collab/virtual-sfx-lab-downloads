# Virtual SFX Lab for macOS — Module 1: Wave Studio (0.31.1 — studio V0.31c)

Readable Python and shell source for one Mac: the receive-only sACN / Art-Net receiver and the complete Wave Studio web app (demo landing page, full studio, First Guide manual). It is **not** a signed or notarized `.app`; an unsigned `.app` would be blocked outright by Gatekeeper on current macOS, so this package uses a plain `.command` launcher that you can read before running.

This is a prototype for visual rehearsal, not a firing controller, certified device emulator or safety-validation tool. Keep real flame hardware disconnected from the rehearsal network.

## Requirements

- **Python 3.10 or newer** from [python.org](https://www.python.org/downloads/macos/) (the universal2 installer). No pip packages are needed for the receiver or the visualizer. The Apple developer-tools stub at `/usr/bin/python3` is skipped on purpose.
- **A current browser** — Safari, Chrome or Edge.
- **Vista** only for live input, with Vista's own output licensing. Vista interoperability on macOS is still pending native testing.

## First launch

1. Extract the ZIP into a new folder, for example `Documents/Virtual SFX Lab`. Keep every file together.
2. Double-click **Virtual SFX Lab.command**. If macOS says it cannot be opened because it is from an unidentified developer, right-click it, choose **Open**, then **Open** again — once. Do not disable Gatekeeper or remove quarantine attributes with the Terminal.
3. Terminal asks which interface Vista uses for Streaming ACN output; press Return to accept the first address.
4. Your browser opens on the **demo landing page**: six fixtures, Quick Looks and the internal sequence list, so you can learn the basic controls first.
5. Click **Open the full studio**. The **First Guide** manual opens on top of the studio; read through it, then close it. Untick “Open when the studio starts” once you no longer need it.
6. In the studio choose **Live Input**; match each fixture's universe and start address to Vista. Keep the Terminal window open while rehearsing; press Ctrl+C or close it to stop.

**Preview without Vista:** double-click **Virtual SFX Lab — Preview Only.command**. It serves the same demo, studio and manual locally without opening any network input.

**Modes:** run `python3 mac_launcher.py --menu` for manual preview / Live sACN / Live Art-Net, or `--mode artnet` when Vista is on a separate computer (UDP 6454, zero-based port-addresses).

## Pricing and licence status

The demo is free. The full studio is a planned one-time purchase of $29.99 CAD after a seven-day trial on the web; the Vista receiver in this package is a planned $29.99 CAD one-time add-on per computer. Sales are not yet open, so this package is a tester build: nothing in it checks a licence, and the local studio at 127.0.0.1 is not time-limited.

## Optional local backend

`server.py` is the optional layout/workspace/social backend used by the web version. It needs `pip install fastapi uvicorn` and is started with `python3 server.py` in a second Terminal window; see `SERVER.md`. The receiver and visualizer work fully without it.

## Verification boundary

Launcher logic, archive contents, the browser UI, the manual auto-open and synthetic multicast reception were tested outside macOS. Finder launch, Gatekeeper prompts, macOS multicast loopback, Safari behaviour and real Vista output on a Mac still need a native test. Please report the Terminal output of the first launch.
