# Wave Studio local server

Storage and Friends & Chat backend for the Wave Studio web app (Beta 0.29). Python 3.10+, standard library only, data in one SQLite file. It never sends DMX, Art-Net, sACN or firing data.

This is a rebuild. The original hosted backend's code was not available, so it was rewritten to match every API call the Beta 0.29 web app makes.

## Start it

Windows: double-click `Start-Wave-Studio-Server.cmd` and keep the window open. Or run:

```
py -3 server.py
```

It listens on `http://127.0.0.1:8093`, the address the app uses when opened from `127.0.0.1` or `localhost`, such as the receiver page at `http://127.0.0.1:8765`. Data is saved in `server/data/wave-studio.db` (not committed to Git).

## What it provides

| Feature in the app | API |
|---|---|
| Set Default Layout / Reset Layout | `GET/PUT /api/default-layout` |
| Customized workspace (panels, docking, sizes) | `GET/PUT /api/workspace` |
| Customize checkpoints and saved Customized Layouts (up to 24) | `GET/PUT /api/custom-layouts` |
| Autosave settings | `GET/PUT /api/preferences` |
| Session Files and autosave logs (newest 300 kept) | `GET /api/sessions`, `GET/PUT /api/sessions/<id>` |
| Friends & Chat: profiles, friend codes, rooms, messages, attachments up to 6 MB, transcript export | `GET/POST /api/social`, `/api/social/room/<id>`, `/export`, `/api/social/blob/<id>` |
| Room calls (signalling only; media goes browser to browser) and five-minute instructor control | `op: call / signal / grant / revoke` |

## Who is a "visitor"

Each visitor gets private storage. On this computer the app sends a fixed local identity, so every tab on the PC shares one visitor. That is right for one operator.

To try chat between two people on one PC, start the server with `--split-visitors-by-origin` and open the app from two different addresses. For example, use the receiver at `http://127.0.0.1:8765`, plus `py -m http.server 8080` in `web/` for `http://127.0.0.1:8080`, and add `--allow-origin http://127.0.0.1:8080` so the server accepts the second address. Each one becomes a separate visitor.

## Options

```
--port 8093                     API port
--db path\to\file.db            database file (or set WAVE_STUDIO_DB)
--chat-retention-days 30        delete chat messages and attachments older than 30 days (default keeps them)
--split-visitors-by-origin      local testing of chat between two "people"
--allow-origin https://host     allow another browser origin
--host 0.0.0.0                  listen beyond this PC (see below)
--trusted-visitor-header NAME   identity header set by a trusted proxy
--verbose                       log every request
```

## Security and privacy

- Binds to loopback by default and only accepts requests whose Host is this computer, which blocks DNS-rebinding.
- Accepts browser requests only from the Wave Studio pages themselves (`http://127.0.0.1:8765`, `http://localhost:8765`, and the grandMA3 PoC on port 8766) unless you add `--allow-origin`. Other local pages, such as a dev server on another port, are refused.
- Workspace saves include the revision they started from. If another tab saved in between, the server answers 409 and keeps the newer save, and the app asks which one to keep.
- Without `--split-visitors-by-origin`, every allowed Wave Studio page on this PC shares one private visitor (your own workspace, layouts, sessions and chat identity). That is intended for a single-user PC; anything you add with `--allow-origin` gets the same access.
- The local identity header is only honoured from this computer.
- Chat rooms are limited to accepted friends. Room data, attachments and transcripts are visible only to room members. Contact details go only to accepted friends, and only when the owner turns on sharing.
- Attachments are limited to images, audio and video up to 6 MB. Messages are limited to 30 per minute per person.
- **Not encrypted at rest.** Anyone with access to the database file can read it.
- **Calls are peer to peer.** Participants can see each other's network (IP) addresses.
- **Do not expose it to the internet as is.** For multi-user hosting, put it behind HTTPS and a login proxy that sets a per-user header, then use `--host` with `--trusted-visitor-header`.

## Tests

`Run-Server-Tests.cmd`, or `py -3 -B -m unittest discover -s tests -v` from this folder.
